import React, { useEffect, useState } from "react";
import { Dropdown, Menu, Button } from "antd";
import { DownOutlined } from "@ant-design/icons";

const languages = [
    { code: "hi", label: "Hindi" },
    { code: "gu", label: "Gujarati" },
    { code: "en", label: "English" },
    { code: "fr", label: "French" },
    { code: "es", label: "Spanish" },
    { code: "de", label: "German" },
    { code: "zh-CN", label: "Chinese (Simplified)" },
    { code: "ja", label: "Japanese" },
];

export default function GoogleTranslateDropdown() {
    const [selectedLang, setSelectedLang] = useState(() => {
        return localStorage.getItem("selectedLang") || 'en';
    });

    const onMenuClick = ({ key }) => {
        setSelectedLang(key);
        localStorage.setItem("selectedLang", key);
        window.location.reload();
    };

    const menu = (
        <Menu onClick={onMenuClick}>
            {languages.map(({ code, label }) => (
                <Menu.Item key={code}>{label}</Menu.Item>
            ))}
        </Menu>
    );

    return (
        <div>
            <Dropdown overlay={menu} trigger={["click"]}>
                <Button>
                    {selectedLang
                        ? languages.find((l) => l.code === selectedLang)?.label
                        : "Select Language"}{" "}
                    <DownOutlined />
                </Button>
            </Dropdown>
        </div>
    );
}
