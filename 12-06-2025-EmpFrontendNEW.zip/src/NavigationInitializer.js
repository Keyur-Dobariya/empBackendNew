// NavigationInitializer.js
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { setNavigator } from "./NavigationService";

const NavigationInitializer = () => {
    const navigate = useNavigate();

    useEffect(() => {
        setNavigator(navigate);
    }, [navigate]);

    return null;
};

export default NavigationInitializer;