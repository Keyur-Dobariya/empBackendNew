import doc from './doc.png'
import dat from './dat.png'
import bmp from './bmp.png'
import psd from './psd.png'
import wmv from './wmv.png'
import avi from './avi.png'
import indd from './indd.png'
import html from './html.png'
import cdr from './cdr.png'
import midi from './midi.png'
import gif from './gif.png'
import dll from './dll.png'
import php from './php.png'
import iso from './iso.png'
import eps from './eps.png'
import pdf from './pdf.png'
import css from './css.png'
import raw from './raw.png'
import zip from './zip.png'
import xml from './xml.png'
import i_3ds from './i_3ds.png'
import xls from './xls.png'
import mp3 from './mp3.png'
import flv from './flv.png'
import aac from './aac.png'
import tif from './tif.png'
import fla from './fla.png'
import svg from './svg.png'
import dmg from './dmg.png'
import png from './png.png'
import ps from './ps.png'
import ppt from './ppt.png'
import mpg from './mpg.png'
import ai from './ai.png'
import file from './file.png'
import txt from './txt.png'
import js from './js.png'
import jpg from './jpg.png'
import cad from './cad.png'
import sql from './sql.png'
import mov from './mov.png'

const extIcons = {
    doc,
    dat,
    bmp,
    psd,
    wmv,
    avi,
    indd,
    html,
    cdr,
    midi,
    gif,
    dll,
    php,
    iso,
    eps,
    pdf,
    css,
    raw,
    zip,
    xml,
    i_3ds,
    xls,
    mp3,
    flv,
    aac,
    tif,
    fla,
    svg,
    dmg,
    png,
    ps,
    ppt,
    mpg,
    ai,
    file,
    txt,
    js,
    jpg,
    cad,
    sql,
    mov,
};

export default extIcons;