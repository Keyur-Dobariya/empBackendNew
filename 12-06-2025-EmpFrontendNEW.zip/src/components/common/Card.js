import React from 'react';
import PropTypes from 'prop-types';

// Card component
const Card = ({ children, elevation = true, style, className, height = 'auto', width = '100%', padding, margin, borderRadius }) => {
  const cardStyle = {
    borderRadius: borderRadius || '8px',
    boxShadow: elevation ? `0px 10px 50px rgba(0, 0, 0, 0.1)` : 'none',
    padding: padding || '0px',
    margin: margin || '0px',
    backgroundColor: '#fff',
    height: height || 'auto',  // Set height to 'auto' if not provided
    width: width,    // Set width to '100%' if not provided
    ...style,
  };

  return <div className={className} style={cardStyle}>{children}</div>;
};

// Prop validation
Card.propTypes = {
  children: PropTypes.node.isRequired,
  elevation: PropTypes.bool,
  style: PropTypes.object,
  className: PropTypes.string,
  height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),  // height can be string or number
  width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),   // width can be string or number
};

export default Card;
