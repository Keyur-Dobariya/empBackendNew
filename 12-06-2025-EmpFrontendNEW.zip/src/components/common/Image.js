import React from "react";
import PropTypes from "prop-types";
import { hexToRgba } from "../CommonComponents";
import appColor from "../../utils/appColors";

const Image = ({ path, backgroundColor, isTransparentBg, iconColor, style, className, width, height, padding, borderRadius, opacity }) => {
  const imgStyle = {
    width: "100%",
    height: "100%",
    backgroundColor: iconColor,
    isTransparentBg: true,
    mask: `url(${path})`,
    maskSize: "contain",
    maskRepeat: "no-repeat",
    maskPosition: "center",
    ...style,
  };

  return (
    <div
      className={className}
      style={{
        backgroundColor: isTransparentBg ? appColor.transparant : hexToRgba({hex: backgroundColor, opacity: opacity}),
        width: width,
        height: height,
        padding: padding,
        borderRadius: borderRadius,
      }}
    >
      <div className={className} style={imgStyle} />
    </div>
  );
};

Image.propTypes = {
  path: PropTypes.string.isRequired,
  backgroundColor: PropTypes.string,
  iconColor: PropTypes.string,
  padding: PropTypes.string,
  borderRadius: PropTypes.string,
  opacity: PropTypes.string,
  style: PropTypes.object,
  className: PropTypes.string,
  width: PropTypes.string,
  height: PropTypes.string,
};

export default Image;
