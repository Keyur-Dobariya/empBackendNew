import React, { useState, useEffect } from "react";

const ResponsiveGrid = () => {
  const [screenSize, setScreenSize] = useState(getScreenSize());

  useEffect(() => {
    const handleResize = () => {
      setScreenSize(getScreenSize());
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  function getScreenSize() {
    if (window.innerWidth >= 1024) return "desktop";
    if (window.innerWidth >= 600) return "medium";
    return "mobile";
  }

  const items = ["a", "b", "c", "d", "e", "f", "g"];

  const getGridStyle = () => {
    if (screenSize === "desktop") {
      return {
        display: "grid",
        gridTemplateColumns: "1fr 1fr 1fr 1fr",
        gridTemplateRows: "auto",
        gap: "10px",
      };
    } else if (screenSize === "medium") {
      return {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gridTemplateRows: "auto",
        gap: "10px",
      };
    } else {
      return {
        display: "flex",
        flexDirection: "column",
        gap: "10px",
      };
    }
  };

  const getItemStyle = (item) => {
    return {
      padding: "20px",
      border: "1px solid black",
      fontWeight: "bold",
      textAlign: "center",
      backgroundColor: "#f8f8f8",
    };
  };

  const getItemOrder = () => {
    if (screenSize === "desktop") {
      return [
        ["a", "b", "c", "d"],
        ["a", "e", "f", "g"],
      ].flat();
    } else if (screenSize === "medium") {
      return [
        ["a", "b"],
        ["a", "c"],
        ["d", "e"],
        ["f", "g"],
      ].flat();
    } else {
      return items; // Mobile: Just a vertical stack
    }
  };

  return (
    <div style={{ padding: "20px", border: "2px solid red", maxWidth: "90vw" }}>
      <div style={getGridStyle()}>
        {getItemOrder().map((item) => (
          <div key={item} style={getItemStyle(item)}>
            {item}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResponsiveGrid;