import React, {useState, useEffect, useRef} from "react";
import {
    Avatar, Button, DatePicker, Dropdown, Form, Radio, Input, message, Modal, Select, Tag, TimePicker, Tooltip, Upload
} from "antd";
import {
    confirmPasswordFieldRules, passwordFieldRules,
} from "../config/formConfig";
import {
    checkImageExists, generateEmployeeCode, getTwoCharacterFromName,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import {CloseCircleOutlined, FileOutlined, LoadingOutlined, PlusOutlined, UploadOutlined} from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {
    InputType, SelectMode,
} from "../components/common/AppTextFormField";
import WrapBox from "../components/common/WrapBox";
import Row from "../components/common/Row";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {useLoading} from "..";
import {endpoints} from "../api/apiEndpoints";
import apiCall, {HttpMethod} from "../api/apiServiceProvider";
import {
    leaveTypeLabel,
    UserRole, dayTypeLabel, leaveCategoryLabel, leaveHalfDayTypeLabel, leaveLabelKeys, leaveStatusLabel,
} from "../utils/enum";
import {Loader} from "../components/Loader";
import imagePaths from "../assets/assetsPaths";
import dayjs from "dayjs";
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import {isAdmin} from "../utils/utils";

dayjs.extend(isSameOrBefore);

const {Option} = Select;

export default function LeaveAddUpdateModel({
                                                isModelOpen,
                                                setIsModelOpen,
                                                employeeList,
                                                leaveData,
                                                isEditing,
                                                isLeaveStatusChange,
                                                setIsEditing,
                                                setIsLeaveStatusChange,
                                                onSuccessCallback,
                                            }) {
    const [isLoading, setIsLoading] = useState(false);
    const [form] = Form.useForm();
    const containerRef = useRef(null);

    const parseDate = (dateString) => {
        if (!dateString) return null;

        const isoParsed = dayjs(dateString);
        if (isoParsed.isValid()) return isoParsed;

        const customParsed = dayjs(dateString, "hh:mm A");
        if (customParsed.isValid()) return customParsed;

        return null; // If both fail
    };

    const defaultLeaveValues = {
        [appKeys.user]: leaveData[appKeys.user] ? leaveData[appKeys.user].userId : null,
        [appKeys.leaveType]: leaveData[appKeys.leaveType] || null,
        [appKeys.dayType]: leaveData[appKeys.dayType] || leaveLabelKeys.singleDay,
        [appKeys.leaveHalfDayType]: leaveData[appKeys.leaveHalfDayType] || leaveLabelKeys.firstHalf,
        [appKeys.startDate]: leaveData[appKeys.startDate] ? dayjs(leaveData[appKeys.startDate]) : dayjs(),
        [appKeys.endDate]: leaveData[appKeys.endDate] ? dayjs(leaveData[appKeys.endDate]) : null,
        // [appKeys.startDate]: parseDate(leaveData[appKeys.startDate]),
        // [appKeys.endDate]: parseDate(leaveData[appKeys.endDate]),
        [appKeys.startTime]: parseDate(leaveData[appKeys.startTime]),
        [appKeys.endTime]: parseDate(leaveData[appKeys.endTime]),
        [appKeys.leaveCategory]: leaveData[appKeys.leaveCategory] || leaveLabelKeys.unpaid,
        [appKeys.reason]: leaveData[appKeys.reason] || null,
    };

    const [leaveValues, setLeaveValues] = useState(defaultLeaveValues);
    const [isAfter3Days, setIsAfter3Days] = useState(true);

    useEffect(() => {
        if(isLeaveStatusChange) {
            form.setFieldsValue({
                [appKeys.status]: leaveData[appKeys.status],
                [appKeys.rejectedReason]: leaveData[appKeys.rejectedReason],
            })
        }
        if (isEditing) {
            const isAfter3 = !!(leaveData[appKeys.startDate] && dayjs(leaveData[appKeys.startDate]).diff(dayjs(), 'day') < 3);
            setIsAfter3Days(isAfter3);
            form.setFieldsValue(leaveValues);
            setLeaveValues(leaveValues);
        }
    }, []);

    // useEffect(() => {
    //     if (
    //         isAfter3Days &&
    //         leaveValues[appKeys.leaveCategory] === leaveLabelKeys.paid
    //     ) {
    //         setLeaveValues((prev) => ({
    //             ...prev,
    //             [appKeys.leaveCategory]: leaveLabelKeys.unpaid,
    //         }));
    //     }
    // }, [isAfter3Days, leaveValues[appKeys.leaveCategory]]);
    //
    // useEffect(() => {
    //     const currentLeaveCategory = form.getFieldValue(appKeys.leaveCategory);
    //
    //     if (isAfter3Days && currentLeaveCategory === leaveLabelKeys.paid) {
    //         form.setFieldsValue({
    //             [appKeys.leaveCategory]: leaveLabelKeys.unpaid,
    //         });
    //
    //         setLeaveValues((prev) => ({
    //             ...prev,
    //             [appKeys.leaveCategory]: leaveLabelKeys.unpaid,
    //         }));
    //     }
    // }, [isAfter3Days]);

    const resetLeaveValues = () => {
        setLeaveValues(defaultLeaveValues);
        form.resetFields();
        if (containerRef.current) {
            containerRef.current.scrollTop = 0;
        }
    };

    const handleEditCancel = () => {
        setIsModelOpen(false);
        setIsEditing(false);
        setIsLeaveStatusChange(false);
        resetLeaveValues();
    };

    const handleFieldChange = (changedValues, allValues) => {
        form.setFieldsValue(allValues);
        setLeaveValues((prev) => ({
            ...prev,
            [appKeys.reason]: allValues[appKeys.reason],
        }));
    };

    const handleAddUpdateLeaveApi = async () => {
        try {
            if(!isLeaveStatusChange) {
                await form.validateFields([
                    appKeys.reason,
                    appKeys.leaveType,
                    ...(isAdmin() ? [appKeys.user] : []),
                    ...(leaveValues[appKeys.leaveType] === leaveLabelKeys.manualHours ? [appKeys.startTime, appKeys.endTime] : []),
                    ...(leaveValues[appKeys.dayType] === leaveLabelKeys.multipleDay ? [appKeys.endDate] : []),
                ]);
            } else {
                await form.validateFields([
                    ...(form.getFieldValue(appKeys.status) === leaveLabelKeys.rejected ? [appKeys.rejectedReason] : []),
                ]);
            }

            const payload = {
                ...leaveValues,
                [appKeys.user]:  isAdmin() ? leaveValues[appKeys.user] : getLocalData(loginDataKeys._id),
                // [appKeys.startDate]: leaveValues[appKeys.startDate]?.format("YYYY-MM-DD"),
                // [appKeys.endDate]: leaveValues[appKeys.endDate]?.format("YYYY-MM-DD"),
            };

            const statusChangePayload = {
                [appKeys.status]: form.getFieldValue(appKeys.status),
                [appKeys.rejectedReason]: form.getFieldValue(appKeys.status) === leaveLabelKeys.rejected ? form.getFieldValue(appKeys.rejectedReason) : null,
            };

            setIsLoading(true);

            await apiCall({
                method: HttpMethod.POST,
                url: isLeaveStatusChange ? `${endpoints.leaveStatusChange}${leaveData["_id"]}` : isEditing ? `${endpoints.addLeave}/${leaveData["_id"]}` : endpoints.addLeave,
                data: isLeaveStatusChange ? statusChangePayload : payload,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    handleEditCancel();
                    onSuccessCallback(data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const formUi = () => {
        return (<>
            {isLoading ? <Loader/> : ""}
            <Column justifyContent="center" alignItems="center">
                <Form
                    form={form}
                    name="EmpAddUpdateModel"
                    layout="vertical"
                    onValuesChange={handleFieldChange}
                    style={{
                        marginTop: 15, width: "100%", alignContent: "center", overflowX: "hidden",
                    }}
                >
                    {isLeaveStatusChange ? <WrapBox>
                        <Form.Item name={appKeys.status} label={"Leave Status"} span={24}>
                            <Select
                                placeholder="Select Leave Type"
                                style={{height: '40px'}}
                                value={form.getFieldValue(appKeys.status)}
                                onChange={(value) => {
                                    form.setFieldValue(appKeys.status, value)
                                }}
                                options={leaveStatusLabel}
                            />
                        </Form.Item>
                        {
                            leaveData[appKeys.status] === leaveLabelKeys.rejected || form.getFieldValue(appKeys.status) === leaveLabelKeys.rejected ? <AppTextFormField
                                name={appKeys.rejectedReason}
                                label={appString.reason}
                                type={InputType.TextArea}
                                isRequired={true}
                                placeholder={appString.rejectedReason}
                                value={form.getFieldValue(appKeys.rejectedReason)}
                                span={24}
                            /> : null
                        }
                    </WrapBox> : <WrapBox>
                        {isAdmin() ?
                            <Form.Item name={appKeys.user} label={"User"}
                                       rules={[{required: true, message: 'Please select User!'}]} span={24}>
                                <Select
                                    placeholder="Select User"
                                    allowClear
                                    style={{height: '40px'}}
                                    showSearch
                                    value={leaveValues[appKeys.user]}
                                    onChange={(key) => {
                                        setLeaveValues((prev) => ({
                                            ...prev,
                                            [appKeys.user]: key,
                                        }));
                                    }}
                                    filterOption={(input, option) =>
                                        option?.label?.toLowerCase().includes(input.toLowerCase())
                                    }
                                >
                                    {employeeList.map(employee => (
                                        <Option key={employee._id} value={employee._id}
                                                label={employee.fullName}>
                                            <div
                                                style={{display: "flex", alignItems: "center", gap: "10px"}}
                                            >
                                                <Avatar
                                                    src={employee.profilePhoto || imagePaths.profile_placeholder}
                                                    size="small"/>
                                                {employee.fullName}
                                            </div>
                                        </Option>))}
                                </Select>
                            </Form.Item> : null}
                        <Form.Item name={appKeys.leaveType} label={"Leave Type"}
                                   rules={[{required: true, message: 'Please select a leave type!'}]} span={24}>
                            <Select
                                placeholder="Select Leave Type"
                                allowClear
                                style={{height: '40px'}}
                                value={leaveValues[appKeys.leaveType]}
                                onChange={(value) => {
                                    setLeaveValues((prev) => ({
                                        ...prev,
                                        [appKeys.dayType]: value === leaveLabelKeys.fullDay ? leaveLabelKeys.singleDay : null,
                                        [appKeys.leaveHalfDayType]: value === leaveLabelKeys.halfDay ? leaveLabelKeys.firstHalf : null,
                                        [appKeys.endDate]: null,
                                        [appKeys.startTime]: null,
                                        [appKeys.endTime]: null,
                                        [appKeys.leaveType]: value,
                                    }));
                                }}
                                options={leaveTypeLabel}
                            />
                        </Form.Item>
                        {leaveValues[appKeys.leaveType] === leaveLabelKeys.fullDay ?
                            <Form.Item name={appKeys.dayType} label={"Select One"} span={24}>
                                <Radio.Group
                                    name={appKeys.dayType}
                                    defaultValue={leaveLabelKeys.singleDay}
                                    options={dayTypeLabel}
                                    value={leaveValues[appKeys.dayType]}
                                    onChange={({target: {value}}) => {
                                        setLeaveValues((prev) => ({
                                            ...prev,
                                            [appKeys.endDate]: null,
                                            [appKeys.dayType]: value,
                                        }));
                                    }}
                                />
                            </Form.Item> : null}
                        {leaveValues[appKeys.leaveType] === leaveLabelKeys.halfDay ?
                            <Form.Item name={appKeys.leaveHalfDayType} label={"Select One"} span={24}>
                                <Radio.Group
                                    name={appKeys.leaveHalfDayType}
                                    defaultValue={leaveLabelKeys.firstHalf}
                                    options={leaveHalfDayTypeLabel}
                                    value={leaveValues[appKeys.leaveHalfDayType]}
                                    onChange={({target: {value}}) => {
                                        setLeaveValues((prev) => ({
                                            ...prev,
                                            [appKeys.leaveHalfDayType]: value,
                                        }));
                                    }}
                                />
                            </Form.Item> : null}
                        <AppTextFormField
                            name={appKeys.reason}
                            label={appString.reason}
                            type={InputType.Text}
                            isRequired={true}
                            placeholder={appString.reason}
                            value={leaveValues[appKeys.reason]}
                            span={24}
                        />
                        <Form.Item name={appKeys.startDate} label={"Start Date"} rules={[{required: true}]}
                                   span={leaveValues[appKeys.dayType] === leaveLabelKeys.multipleDay ? 12 : 24}>
                            <DatePicker defaultValue={leaveValues[appKeys.startDate]}
                                        value={leaveValues[appKeys.startDate] ? dayjs(leaveValues[appKeys.startDate], 'YYYY-MM-DD') : null}
                                        style={{height: '40px', width: "100%"}}
                                        allowClear={false}
                                        onChange={(date, dateString) => {
                                            const isAfter3 = !!(dateString && dayjs(dateString).diff(dayjs(), 'day') < 3);
                                            setIsAfter3Days(isAfter3);

                                            setLeaveValues((prev) => ({
                                                ...prev,
                                                [appKeys.startDate]: dateString,
                                                // [appKeys.leaveCategory]:
                                                //     isAfter3 && prev[appKeys.leaveCategory] === leaveLabelKeys.paid
                                                //         ? leaveLabelKeys.unpaid
                                                //         : prev[appKeys.leaveCategory],
                                            }));
                                        }}/>
                        </Form.Item>
                        {leaveValues[appKeys.dayType] === leaveLabelKeys.multipleDay ?
                            <Form.Item name={appKeys.endDate} label={"End Date"}
                                       rules={[{required: true, message: 'Please select end date!'}]} span={12}>
                                <DatePicker
                                    value={leaveValues[appKeys.endDate] ? dayjs(leaveValues[appKeys.endDate], 'YYYY-MM-DD') : null}
                                            style={{height: '40px', width: "100%"}}
                                            disabledDate={(current) =>
                                                current && current.isSameOrBefore(dayjs(leaveValues[appKeys.startDate]), 'day')
                                            }
                                            onChange={(date, dateString) => {
                                                setLeaveValues((prev) => ({
                                                    ...prev,
                                                    [appKeys.endDate]: dateString,
                                                }));
                                            }}/>
                            </Form.Item> : null}
                        {leaveValues[appKeys.leaveType] === leaveLabelKeys.manualHours ?
                            <Form.Item name={appKeys.startTime} label={"Start Time"}
                                       rules={[{required: true, message: 'Please select start time!'}]} span={12}>
                                <TimePicker use12Hours minuteStep={30} showNow={false} showSecond={false}
                                            value={leaveValues[appKeys.startTime] ? dayjs(leaveValues[appKeys.startTime], 'hh:mm A') : null}
                                            style={{height: '40px', width: "100%"}}
                                            onChange={(time, timeString) => {
                                                setLeaveValues((prev) => ({
                                                    ...prev,
                                                    [appKeys.startTime]: timeString,
                                                }));
                                            }}/>
                            </Form.Item> : null}
                        {leaveValues[appKeys.leaveType] === leaveLabelKeys.manualHours ?
                            <Form.Item name={appKeys.endTime} label={"End Time"}
                                       rules={[{required: true, message: 'Please select end time!'}]} span={12}>
                                <TimePicker use12Hours minuteStep={30} showNow={false} showSecond={false}
                                            value={leaveValues[appKeys.endTime] ? dayjs(leaveValues[appKeys.endTime], 'hh:mm A') : null}
                                            style={{height: '40px', width: "100%"}}
                                            disabledTime={() => {
                                                // const isSameDay = dayjs(leaveValues[appKeys.startDate]).isSame(leaveValues[appKeys.endDate], 'day');
                                                // if (!isSameDay) return {};

                                                const [startHour, startMinute] = dayjs(leaveValues[appKeys.startTime], "hh:mm A").format("HH:mm").split(":").map(Number);

                                                return {
                                                    disabledHours: () =>
                                                        Array.from({length: 24}, (_, i) => i).filter(h => h < startHour),
                                                    disabledMinutes: (selectedHour) => {
                                                        if (selectedHour === startHour) {
                                                            return Array.from({length: 60}, (_, i) => i).filter(m => m < startMinute);
                                                        }
                                                        return [];
                                                    }
                                                };
                                            }}
                                            onChange={(time, timeString) => {
                                                setLeaveValues((prev) => ({
                                                    ...prev,
                                                    [appKeys.endTime]: timeString,
                                                }));
                                            }}/>
                            </Form.Item> : null}
                        <Form.Item name={appKeys.leaveCategory} label="Select One" span={24}>
                            <Radio.Group
                                name={appKeys.leaveCategory}
                                options={leaveCategoryLabel({
                                    // disabledValues: isAfter3Days ? [leaveLabelKeys.paid] : [],
                                    disabledValues: [],
                                })}
                                defaultValue={leaveValues[appKeys.leaveCategory]}
                                onChange={({target: {value}}) => {
                                    setLeaveValues((prev) => ({
                                        ...prev,
                                        [appKeys.leaveCategory]: value,
                                    }));
                                }}
                            />
                        </Form.Item>
                    </WrapBox>}
                </Form>
            </Column>
        </>);
    };

    return (<>
        {isModelOpen && (<Modal
            title={isEditing ? "Edit Leave" : "Add Leave"}
            maskClosable={false}
            centered
            open={isModelOpen}
            width={450}
            onOk={() => {
                handleAddUpdateLeaveApi();
            }}
            onCancel={handleEditCancel}
            onClose={handleEditCancel}
            okText={"Save"}
        >
            {<div
                className="container-with-scrollbar"
                ref={containerRef}
                style={{
                    width: "100%", maxHeight: "75vh", overflow: "auto", alignItems: "center",
                }}
            >
                {formUi()}
            </div>}
        </Modal>)}
    </>);
}