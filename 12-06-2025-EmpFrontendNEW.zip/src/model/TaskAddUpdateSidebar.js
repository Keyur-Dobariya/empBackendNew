import React, {useState, useEffect, useRef, useLayoutEffect} from "react";
import {
    Avatar,
    Button,
    DatePicker, Divider, Drawer,
    Dropdown,
    Form,
    Image, Input,
    message,
    Modal, Popconfirm, Popover, Select, Spin, Tabs,
    Tag,
    TimePicker,
    Tooltip, Tree,
    Upload
} from "antd";
import {
    confirmPasswordFieldRules,
    passwordFieldRules,
} from "../config/formConfig";
import {
    checkImageExists,
    generateEmployeeCode,
    getTwoCharacterFromName,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import {
    CloseCircleOutlined,
    DeleteOutlined, DislikeFilled, DislikeOutlined, DownOutlined,
    FileOutlined, LikeFilled, LikeOutlined,
    LoadingOutlined, MessageFilled,
    PlusOutlined,
    UploadOutlined, UpOutlined
} from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {
    InputType,
    SelectMode,
} from "../components/common/AppTextFormField";

import Row from "../components/common/Row";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import {getLocalData, getUserData, loginDataKeys} from "../dataStorage/DataPref";
import {useLoading} from "..";
import {endpoints} from "../api/apiEndpoints";
import apiCall, {HttpMethod} from "../api/apiServiceProvider";
import {
    ApprovalStatus,
    BloodGroup,
    DateTimeFormat,
    Gender,
    getIconByKey,
    getKeyByLabel,
    getLabelByKey,
    taskCategoryLabel,
    taskColumnLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
    taskStatusLabel,
    Technology,
    UserRole,
} from "../utils/enum";
import {Loader} from "../components/Loader";
import dayjs from "dayjs";
import imagePaths from "../assets/assetsPaths";
import axios from "axios";
import {MessageSquare, MoreVertical, X} from "react-feather";
import {deleteTaskApi} from "../api/apiUtils";
import {formatMessageTime, formatMessageTimeReal, getDataById, isAdmin} from "../utils/utils";
import Editor from "../components/Editor";
import WrapBox from "../components/common/WrapBox";
import {getDarkColor} from "../utils/colorMapper";
import {useNavigate} from "react-router-dom";
import {AppDataFields, useAppData} from "../AppDataContext";

const {Option} = Select;

export const CommentSection = ({ tasksData, employeeList }) => {

    const {
        taskBoardData,
        updateAppDataField,
    } = useAppData();

    const updatedComments = tasksData && tasksData[appKeys.comments] ? tasksData[appKeys.comments].map((c) => ({
        ...c,
        sent: true,
    })) : [];

    const [showAllComments, setShowAllComments] = useState(false);
    const [comments, setComments] = useState(updatedComments);
    const hasScrolledRef = useRef(false);
    const scrollContainerRef = useRef(null);
    const [activeReplyId, setActiveReplyId] = useState(null);
    const [expandedComments, setExpandedComments] = useState({});

    useEffect(() => {
        const evtSource = new EventSource(endpoints.tasksChange);

        evtSource.onmessage = (event) => {
            if(event.data) {
                updateAppDataField(AppDataFields.taskBoardData, JSON.parse(event.data));

                for (const statusKey in JSON.parse(event.data)) {
                    const tasksInStatus = JSON.parse(event.data)[statusKey];
                    const task = tasksInStatus.find(task => task.taskId === tasksData.taskId);
                    if (task) {
                        console.log("CommentSection=>", task);
                        const updatedComments = task && task[appKeys.comments] ? task[appKeys.comments].map((c) => ({
                            ...c,
                            sent: true,
                        })) : [];

                        setComments(updatedComments);
                    }
                }
            }
        };

        evtSource.addEventListener('end', () => {
            console.log('Stream ended');
            evtSource.close();
        });
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            if (!hasScrolledRef.current && scrollContainerRef.current) {
                scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
                hasScrolledRef.current = true;
            }
        }, 100);

        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        const container = scrollContainerRef.current;
        if (container) {
            container.scrollTop = container.scrollHeight;
        }
    }, [comments]);

    // Group comments by parentId to create a threaded structure
    const groupCommentsByParent = (comments) => {
        const commentMap = {};
        const threadedComments = [];

        comments.forEach(comment => {
            comment.children = [];
            commentMap[comment._id] = comment;
        });

        comments.forEach(comment => {
            if (comment.parentId && commentMap[comment.parentId]) {
                commentMap[comment.parentId].children.push(comment);
            } else {
                threadedComments.push(comment);
            }
        });

        return threadedComments;
    };

    // Group comments by date
    const groupMessagesByDate = (comments) => {
        const groups = {};

        comments.forEach(comment => {
            const date = new Date(comment.commentTime);
            const now = new Date();

            const todayStr = now.toDateString();
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = yesterday.toDateString();

            let label = '';
            if (date.toDateString() === todayStr) label = 'Today';
            else if (date.toDateString() === yesterdayStr) label = 'Yesterday';
            else label = new Intl.DateTimeFormat('en-GB', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                }).format(date);

            if (!groups[label]) groups[label] = [];
            groups[label].push(comment);
        });

        return groups;
    };

    async function handleSendComment(text, parentId = null) {
        const newComment = {
            comment: text,
            commentTime: Date.now(),
            parentId,
            sent: false,
            tempId: Date.now(),
        };

        setComments((prev) => [...prev, newComment]);

        try {
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.postTaskComment}${tasksData["_id"]}`,
                data: newComment,
                setIsLoading: false,
                showSuccessMessage: false,
                successCallback: (data) => {
                    const updatedComments = data?.data.comments.map((c) => ({
                        ...c,
                        sent: true,
                    }));
                    setComments(updatedComments || tasksData[appKeys.comments]);
                },
            });
        } catch (error) {
            setComments((prev) =>
                prev.map((c) =>
                    c.tempId === newComment.tempId ? { ...c, sent: false, failed: true } : c
                )
            );
            console.error('Failed to send comment');
        }
    }

    async function handleLikeDisLikeComment(commentId, type) {
        try {
            const newComment = {
                commentId: commentId,
                [type]: getLocalData(loginDataKeys._id),
            };
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.postTaskComment}${tasksData["_id"]}`,
                data: newComment,
                setIsLoading: false,
                showSuccessMessage: false,
                successCallback: (data) => {
                    setComments(data?.data.comments || tasksData[appKeys.comments]);
                },
            });
        } catch (error) {
            console.error('Failed to send comment');
        }
    }

    const getFlattenedMessages = () => {
        const allComments = comments.sort((a, b) => new Date(a.commentTime) - new Date(b.commentTime));
        const threadedComments = groupCommentsByParent(allComments);
        const groupedMessages = groupMessagesByDate(threadedComments);
        const allMessages = [];

        Object.entries(groupedMessages).forEach(([dateLabel, msgs]) => {
            msgs.forEach((msg) => {
                allMessages.push({
                    ...msg,
                    dateLabel,
                });
            });
        });

        return allMessages.sort((a, b) => new Date(a.commentTime) - new Date(b.commentTime));
    };

    const allFlattenedMessages = getFlattenedMessages();
    const visibleMessages = showAllComments ? allFlattenedMessages : allFlattenedMessages.slice(-5);

    const groupedVisibleMessages = visibleMessages.reduce((acc, msg) => {
        if (!acc[msg.dateLabel]) acc[msg.dateLabel] = [];
        acc[msg.dateLabel].push(msg);
        return acc;
    }, {});

    const toggleExpand = (commentId) => {
        setExpandedComments((prev) => ({
            ...prev,
            [commentId]: !prev[commentId],
        }));
    };

    const RenderComment = ({ comment, level = 0 }) => {
        const sender = getDataById(employeeList, comment.commentBy);
        const parentId = comment?.parentId || null;
        const displayName = sender?.fullName || "";
        const profilePhoto = sender?.profilePhoto || "";
        const initials = getTwoCharacterFromName(displayName);

        const isFindLike = comment?.likes?.find(id => id === getLocalData(loginDataKeys._id)) || false;
        const isFindDislike = comment?.dislikes?.find(id => id === getLocalData(loginDataKeys._id)) || false;
        const isExpanded = expandedComments[comment._id] || false;

        return (
            <div style={{position: 'relative'}}>
                {level > 0 && (
                    <div
                        style={{
                            position: 'absolute',
                            left: (level - 1) * 40 + 15,
                            top: 0,
                            bottom: 0,
                            width: '2px',
                            backgroundColor: '#e0e0e0',
                            zIndex: 0,
                        }}
                    />
                )}
                <div style={{ marginLeft: level * 40, position: 'relative', zIndex: 1 }}>
                    <div
                        style={{
                            display: 'flex',
                            alignItems: 'flex-start',
                            marginBottom: '7px',
                            flexDirection: 'row',
                        }}
                    >
                        <div
                            style={{
                                width: 30,
                                height: 30,
                                borderRadius: '50%',
                                backgroundColor: getDarkColor(initials),
                                overflow: 'hidden',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontWeight: 'bold',
                                fontSize: 14,
                                color: '#fff',
                                margin: 5,
                            }}
                        >
                            {profilePhoto ? (
                                <img
                                    src={profilePhoto}
                                    alt={displayName}
                                    style={{
                                        width: '100%',
                                        height: '100%',
                                        objectFit: 'cover',
                                    }}
                                />
                            ) : (
                                initials
                            )}
                        </div>
                        <div className="messageContainer" style={{ flex: 1 }}>
                            <div
                                style={{
                                    marginBottom: '4px',
                                    fontSize: '13px',
                                    fontWeight: '550',
                                    color: 'black',
                                    display: 'flex',
                                    alignItems: 'center',
                                }}
                            >
                                {displayName}
                                <span
                                    style={{
                                        marginLeft: '15px',
                                        fontSize: '11px',
                                        fontWeight: '450',
                                        color: '#4e4e4e',
                                    }}
                                >
                                    <MessageTime dateString={comment.commentTime} />
                                </span>
                            </div>
                            {Array.isArray(comment.attachments) && comment.attachments.length > 0 && (
                                <div style={{ marginTop: '5px' }}>
                                    <Image.PreviewGroup
                                        preview={{
                                            onChange: (current, prev) =>
                                                console.log(`current index: ${current}, prev index: ${prev}`),
                                        }}
                                    >
                                        {comment.attachments
                                            .filter((att) => att.attachmentType.startsWith('image'))
                                            .map((att, index) => (
                                                <Image
                                                    key={index}
                                                    src={att.url}
                                                    style={{
                                                        marginRight: 8,
                                                        marginBottom: 8,
                                                        maxWidth: '150px',
                                                    }}
                                                />
                                            ))}
                                    </Image.PreviewGroup>
                                </div>
                            )}
                            <div
                                dangerouslySetInnerHTML={{ __html: comment.comment }}
                                style={{ marginBottom: '4px' }}
                            />
                            <div className="commentManageRow">
                                <div className="commentLikeManageRow">
                                    <div className="commentBtn" onClick={() => handleLikeDisLikeComment(comment._id, 'like')}>
                                        <LikeFilled style={{ color: isFindLike ? appColor.primary : appColor.secondary }} />
                                        <div>{comment.likes?.length || 0}</div>
                                    </div>
                                    <div className="commentBtn" onClick={() => handleLikeDisLikeComment(comment._id, 'dislike')}>
                                        <DislikeFilled style={{ color: isFindDislike ? appColor.primary : appColor.secondary }} />
                                        <div>{comment.dislikes?.level || 0}</div>
                                    </div>
                                </div>
                                {!parentId && (
                                    <>
                                        <div
                                            className="commentBtn"
                                            onClick={() => {
                                                const commentReplyId = comment.tempId || comment._id;
                                                setActiveReplyId(commentReplyId);
                                                // if (commentReplyId !== activeReplyId) {
                                                //     setActiveReplyId(commentReplyId);
                                                // } else {
                                                //     setActiveReplyId(null);
                                                // }
                                            }}
                                        >
                                            <MessageFilled style={{ color: appColor.secondary }} />
                                            <div>Reply</div>
                                        </div>
                                        {comment.children && comment.children.length > 0 && (
                                            <div
                                                className="commentBtn"
                                                onClick={() => toggleExpand(comment._id)}
                                                style={{ marginLeft: 10 }}
                                            >
                                                {isExpanded ? <UpOutlined /> : <DownOutlined />}
                                                <div>{isExpanded ? 'Hide Replies' : `Show ${comment.children.length} Replies`}</div>
                                            </div>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>
                    </div>
                    {activeReplyId === (comment.tempId || comment._id) && (
                        <div style={{ marginLeft: (level + 1) * 40, marginTop: 8, marginBottom: 10 }}>
                            <Editor
                                onClickSendButton={(text) => {
                                    handleSendComment(text, comment._id);
                                    setActiveReplyId(null);
                                }}
                            />
                        </div>
                    )}
                    {comment.children && comment.children.length > 0 && isExpanded && (
                        <div>
                            {comment.children.map((child) => (
                                <RenderComment key={child._id} comment={child} level={level + 1} />
                            ))}
                        </div>
                    )}
                </div>
            </div>
        );
    };

    return (
        <div>
            <Editor onClickSendButton={handleSendComment} span={24} />
            <SpaceBox space={10} />
            <Divider span={24} />
            <SpaceBox space={10} />
            {comments.length > 0 ? (
                <Column span={24}>
                    <div
                        style={{
                            gap: '10px',
                            display: 'flex',
                            alignItems: 'center',
                        }}
                    >
                        <AppText
                            text={`Comments`}
                            fontSize={14}
                            fontWeight={550}
                            color={appColor.black}
                        />
                        <div
                            style={{
                                padding: '0px 10px',
                                backgroundColor: appColor.primary,
                                fontWeight: '500',
                                fontSize: '12px',
                                borderRadius: '50px',
                                color: 'white',
                            }}
                        >
                            {comments.length}
                        </div>
                    </div>
                    <div
                        ref={scrollContainerRef}
                        style={{
                            flex: 1,
                            overflowY: 'auto',
                            display: 'flex',
                            flexDirection: 'column',
                        }}
                    >
                        {Object.entries(groupedVisibleMessages).reverse().map(([dateLabel, msgs]) => (
                            <div key={dateLabel}>
                                <Divider
                                    style={{
                                        fontSize: '13px',
                                        fontWeight: '550',
                                        color: 'black',
                                        borderColor: '#cfcfcf',
                                    }}
                                >
                                    {dateLabel}
                                </Divider>
                                {msgs.reverse().map((comment) => (
                                    <RenderComment key={comment._id} comment={comment} />
                                ))}
                            </div>
                        ))}
                        {comments.length > 5 ? <div
                            className="chatShowHideButton"
                            onClick={() => setShowAllComments(!showAllComments)}
                            style={{
                                textAlign: 'center',
                                cursor: 'pointer',
                                color: appColor.primary,
                                fontSize: '14px',
                                margin: '10px 0',
                            }}
                        >
                            {!showAllComments && comments.length > 5 ? 'Show more' : 'Show less'}
                        </div> : null}
                    </div>
                    <Divider />
                </Column>
            ) : null}
        </div>
    );
};

export default function TaskAddUpdateSidebar({
                                                 isModelOpen,
                                                 setIsModelOpen,
                                                 employeeList,
                                                 taskData,
                                                 projectData,
                                                 clientRecord,
                                                 isEditing,
                                                 setIsEditing,
                                                 onSuccessCallback,
                                             }) {

    const [internalOpen, setInternalOpen] = useState(false);
    const [taskDataValue, setTaskDataValue] = useState(taskData);

    useEffect(() => {
        if (isModelOpen) {
            setInternalOpen(true);
        } else {
            const timer = setTimeout(() => {
                setInternalOpen(false);
            }, 300);

            return () => clearTimeout(timer);
        }
    }, [isModelOpen]);

    const [loading, setLoading] = useState(true);

    const navigate = useNavigate();

    const loginUserData = getDataById(employeeList, getUserData._id);

    const parseDate = (dateString) => {
        if (!dateString) return null;

        const customParsed = dayjs(dateString, "DD-MM-YYYY hh:mm:ss A", true);
        if (customParsed.isValid()) return customParsed;

        const isoParsed = dayjs(dateString);
        if (isoParsed.isValid()) return isoParsed;

        return null;
    };

    const [isLoading, setIsLoading] = useState(false);
    const [isDeleteLoading, setIsDeleteLoading] = useState(false);
    const [form] = Form.useForm();
    const containerRef = useRef(null);

    const [selectedClient, setSelectedClient] = useState(null);
    const [filteredProjects, setFilteredProjects] = useState([]);

    useEffect(() => {
        if (taskDataValue[appKeys.clientName]) {
            const clientDetail = getDataById(clientRecord, taskDataValue[appKeys.clientName]);
            setSelectedClient(clientDetail ? clientDetail._id : null);
            const projects = clientDetail ? clientDetail.projects : [];
            setFilteredProjects(projects);
        }
    }, []);

    const defaultTaskValues = {
        [appKeys.projectName]: taskDataValue[appKeys.projectName] ? getDataById(projectData, taskDataValue[appKeys.projectName])?._id : undefined,
        [appKeys.taskTitle]: taskDataValue[appKeys.taskTitle] || "",
        [appKeys.taskDescription]: taskDataValue[appKeys.taskDescription] || "",
        [appKeys.taskStatus]: taskDataValue[appKeys.taskStatus] || getKeyByLabel(taskColumnLabel.ToDo, taskColumnStatusLabel),
        [appKeys.taskPriority]: taskDataValue[appKeys.taskPriority] || taskPriorityLabel[0].key,
        [appKeys.taskCategory]: taskDataValue[appKeys.taskCategory] || "development",
        [appKeys.taskAssignee]: taskDataValue[appKeys.taskAssignee] ? taskDataValue[appKeys.taskAssignee] : [{userId: loginUserData._id}],
        [appKeys.taskLabels]: taskDataValue[appKeys.taskLabels] || "toDo",
        [appKeys.taskStartDate]: parseDate(taskDataValue[appKeys.taskStartDate]),
        [appKeys.taskEndDate]: parseDate(taskDataValue[appKeys.taskEndDate]),
        [appKeys.comments]: taskDataValue[appKeys.comments] || [],
        [appKeys.taskEstimatedTime]: taskDataValue[appKeys.taskEstimatedTime] || null,
        [appKeys.taskAttachments]: taskDataValue[appKeys.taskAttachments] || [],
        [appKeys.clientName]: taskDataValue[appKeys.clientName] ? getDataById(clientRecord, taskDataValue[appKeys.clientName])?._id : null,
        [appKeys.taskAddedBy]: taskDataValue[appKeys.taskAddedBy] || getUserData._id,
        "createdAt": taskDataValue["createdAt"] || null,
    };

    const [tasksValues, setTasksValues] = useState(defaultTaskValues);

    useEffect(() => {
        if (selectedClient) {
            const clientDetail = getDataById(clientRecord, selectedClient);
            if (clientDetail) {
                const projects = clientDetail ? clientDetail.projects : [];
                setFilteredProjects(projects);
            }
        }
    }, [selectedClient]);

    useEffect(() => {
        if (isEditing) {
            form.setFieldsValue(tasksValues);

            const taskAttachmentsLive = taskDataValue[appKeys.taskAttachments]?.map((attachment, index) => ({
                uid: `${Date.now()}_${index}`,
                name: attachment.url?.split('/').pop() || 'file.png',
                url: attachment.url,
            })) || [];

            // setFileList(taskAttachmentsLive);

            setTasksValues((prev) => ({
                ...prev,
                [appKeys.taskAttachments]: taskAttachmentsLive,
            }));
            setSelectedClient(taskDataValue[appKeys.clientName]);

        }
    }, []);

    const resetTaskValues = () => {
        setTasksValues(defaultTaskValues);
        form.resetFields();
        if (containerRef.current) {
            containerRef.current.scrollTop = 0;
        }
    };

    const handleEditCancel = () => {
        setIsModelOpen(false);
        setIsEditing(false);
        navigate('/tasks');
        resetTaskValues();
    };

    const handleFieldChange = (changedValues, allValues) => {
        form.setFieldsValue(allValues);
        if (isEditing) {
            setTasksValues((prev) => ({
                ...prev,
                [appKeys.clientName]: allValues[appKeys.clientName],
                [appKeys.projectName]: allValues[appKeys.projectName],
                [appKeys.taskTitle]: allValues[appKeys.taskTitle],
                [appKeys.taskDescription]: allValues[appKeys.taskDescription],
            }));
        } else {
            setTasksValues((prev) => ({
                ...prev,
                [appKeys.clientName]: allValues[appKeys.clientName],
                [appKeys.projectName]: allValues[appKeys.projectName],
                [appKeys.taskTitle]: allValues[appKeys.taskTitle],
                [appKeys.taskDescription]: allValues[appKeys.taskDescription],
                [appKeys.taskAddedBy]: getLocalData(loginDataKeys._id),
            }));
        }
    };

    const handleSelectUser = (user) => {
        if (!tasksValues.taskAssignee.some((u) => u.userId.toString() === user._id)) {
            setTasksValues((prev) => ({
                ...prev,
                taskAssignee: [
                    ...prev.taskAssignee,
                    {
                        userId: user._id,
                    },
                ],
            }));
        }
    };

    const handleRemoveUser = (userId) => {
        setTasksValues((prev) => ({
            ...prev,
            taskAssignee: prev.taskAssignee.filter((user) => user.userId !== userId),
        }));
    };

    const menu = {
        items: employeeList.map((user) => ({
            key: user._id,
            label: (
                <div
                    onClick={() => handleSelectUser(user)}
                    style={{display: "flex", alignItems: "center", gap: "10px"}}
                >
                    <Avatar src={user.profilePhoto || imagePaths.profile_placeholder} size="small"/>
                    {user.fullName}
                </div>
            ),
        })),
    };

    const handleAddUpdateTaskApi = async () => {
        try {
            await form.validateFields([
                appKeys.clientName,
                appKeys.taskTitle,
                appKeys.taskDescription,
                appKeys.taskStartDate,
                appKeys.taskEndDate,
            ]);

            // let uploadedAttachments = [];

            // if (newFileList.length > 0) {
            //
            //     const formData = new FormData();
            //     newFileList.forEach((file) => {
            //         formData.append("taskAttachment", file);
            //     });
            //
            //     await apiCall({
            //         method: HttpMethod.POST,
            //         url: endpoints.uploadFiles,
            //         data: formData,
            //         isMultipart: true,
            //         setIsLoading: setIsLoading,
            //         successCallback: (data) => {
            //             if (data.data) {
            //                 uploadedAttachments = data.data;
            //             }
            //         },
            //     });
            // }

            // const existingAttachments = tasksValues[appKeys.taskAttachments] || [];
            // const allAttachments = [...existingAttachments, ...uploadedAttachments];


            const finalTaskData = {
                ...tasksValues,
                [appKeys.projectName]: tasksValues[appKeys.projectName] || "",
                // [appKeys.taskAttachments]: allAttachments,
            };

            await apiCall({
                method: HttpMethod.POST,
                url: !isEditing
                    ? endpoints.updateTask
                    : `${endpoints.updateTask}/${taskDataValue["_id"]}`,
                data: finalTaskData,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    handleEditCancel();
                    onSuccessCallback(data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDeleteTaskApi = () => {
        deleteTaskApi({
            id: taskDataValue._id,
            setIsLoading: setIsDeleteLoading,
            successCallback: (data) => {
                handleEditCancel();
                onSuccessCallback(data);
            },
        });
    };

    const taskDetailTabUi = () => {
        return (
            <div style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
                <div
                    ref={containerRef}
                    style={{flex: 1, overflowY: 'auto'}}
                >
                    <Column justifyContent="center" alignItems="center">
                        <Form
                            form={form}
                            name="EmpAddUpdateModel"
                            layout="vertical"
                            onValuesChange={handleFieldChange}
                            style={{
                                marginRight: 10,
                                alignContent: "center",
                                overflowX: "hidden",
                            }}
                        >
                            <WrapBox>
                                <Form.Item name={appKeys.clientName}
                                           label={appString.clientName} rules={[
                                    {
                                        required: true,
                                        message: "Client Selection Required"
                                    }
                                ]}>
                                    <Select
                                        placeholder="Select Client"
                                        allowClear
                                        style={{height: '40px'}}
                                        showSearch
                                        value={selectedClient}
                                        onChange={(value) => {
                                            setSelectedClient(value);
                                            form.setFieldsValue({[appKeys.projectName]: undefined}); // clear project on client change
                                        }}
                                        filterOption={(input, option) =>
                                            option.children.toLowerCase().includes(input.toLowerCase())
                                        }
                                    >
                                        {clientRecord.map(client => (
                                            <Option key={client._id} value={client._id}>{client.clientName}</Option>
                                        ))}
                                    </Select>
                                </Form.Item>
                                <Form.Item name={appKeys.projectName} label={appString.projectName}
                                           style={{marginBottom: 0}}>
                                    <Select
                                        placeholder="Select Project"
                                        disabled={!selectedClient}
                                        style={{height: '40px'}}
                                        showSearch
                                        filterOption={(input, option) =>
                                            option.children.toLowerCase().includes(input.toLowerCase())
                                        }
                                    >
                                        {filteredProjects.map(project => (
                                            <Option key={project._id} value={project._id}>
                                                {project.projectName}
                                            </Option>
                                        ))}
                                    </Select>
                                </Form.Item>
                                <AppTextFormField
                                    name={appKeys.taskTitle}
                                    label={appString.taskTitle}
                                    type={InputType.Text}
                                    isRequired={true}
                                    placeholder={appString.taskTitle}
                                    value={tasksValues[appKeys.taskTitle]}
                                    span={24}
                                />
                                <AppTextFormField
                                    name={appKeys.taskDescription}
                                    label={appString.taskDescription}
                                    type={InputType.TextArea}
                                    isRequired={true}
                                    minRows={4}
                                    placeholder={appString.taskDescription}
                                    value={tasksValues[appKeys.taskDescription]}
                                    span={24}
                                />
                                <CommentSection tasksData={taskDataValue} employeeList={employeeList} span={24}/>
                                <Column span={24}>
                                    <div className="categoryAssigneeRow">
                                        <AppText
                                            text={`Fields:`}
                                            fontSize={14}
                                            fontWeight={550}
                                            color={appColor.black}
                                        />
                                    </div>
                                    <SpaceBox space={3}/>
                                    <div className="taskFieldContainer">
                                        <div className="taskFieldRow">
                                            <div className="taskFieldLabel">
                                                📌 Task Status
                                            </div>
                                            <div className="taskFieldValue">
                                                <Dropdown menu={{
                                                    items: taskColumnStatusLabel, onClick: ({key}) => {
                                                        setTasksValues((prev) => ({
                                                            ...prev,
                                                            [appKeys.taskStatus]: key
                                                        }));
                                                    }
                                                }} trigger={["click"]}>
                                                    <div
                                                        className="taskFieldValueSelectorItem">{getLabelByKey(tasksValues[appKeys.taskStatus], taskColumnStatusLabel)}</div>
                                                </Dropdown>
                                            </div>
                                        </div>
                                        <div className="taskFieldRow">
                                            <div className="taskFieldLabel">
                                                ⏳ Task Start/End
                                            </div>
                                            <div className="taskFieldValue">
                                                <Form.Item
                                                    className="custom-form-item"
                                                    name={appKeys.taskStartDate}
                                                    rules={[
                                                        {
                                                            required: true,
                                                            message: "Start date is required",
                                                        },
                                                    ]}
                                                    style={{marginBottom: "0px"}}
                                                >
                                                    <DatePicker
                                                        className="taskFieldValueSelectorItem"
                                                        format={"DD-MM-YYYY hh:mm:ss A"}
                                                        showTime={
                                                            {
                                                                format: "HH:mm",
                                                            }
                                                        }
                                                        placeholder="Start Date"
                                                        value={tasksValues[appKeys.taskStartDate] ? dayjs(tasksValues[appKeys.taskStartDate], 'DD-MM-YYYY hh:mm:ss A') : null}
                                                        onChange={(time, timeString) => {
                                                            setTasksValues((prev) => ({
                                                                ...prev,
                                                                [appKeys.taskStartDate]: timeString
                                                            }));
                                                        }}
                                                    />
                                                </Form.Item>

                                                <Form.Item
                                                    className="custom-form-item"
                                                    name={appKeys.taskEndDate}
                                                    rules={[
                                                        {
                                                            required: true,
                                                            message: "End date is required",
                                                        },
                                                    ]}
                                                    style={{marginBottom: "0px"}}
                                                >
                                                    <DatePicker
                                                        className="taskFieldValueSelectorItem"
                                                        format={"DD-MM-YYYY hh:mm:ss A"}
                                                        showTime={
                                                            {
                                                                format: "HH:mm",
                                                            }
                                                        }
                                                        placeholder="End Date"
                                                        value={tasksValues[appKeys.taskEndDate] ? dayjs(tasksValues[appKeys.taskEndDate], 'DD-MM-YYYY hh:mm:ss A') : null}
                                                        onChange={(time, timeString) => {
                                                            setTasksValues((prev) => ({
                                                                ...prev,
                                                                [appKeys.taskEndDate]: timeString
                                                            }));
                                                        }}
                                                    />
                                                </Form.Item>
                                            </div>
                                        </div>
                                        <div className="taskFieldRow">
                                            <div className="taskFieldLabel">
                                                👥 Assignees
                                            </div>
                                            <div className="taskFieldValue">
                                                <div style={{display: "flex", alignItems: "center", gap: "5px"}}>
                                                    {tasksValues[appKeys.taskAssignee].map((user) => {
                                                        const userData = getDataById(employeeList, user.userId);
                                                        return (user && user.userId ? <Tooltip key={user.userId}
                                                                                               title={userData?.fullName || "Unknown User"}>
                                                            <div style={{
                                                                position: "relative",
                                                                display: "inline-block"
                                                            }}>
                                                                <Avatar
                                                                    src={userData?.profilePhoto || null}
                                                                    style={{
                                                                        backgroundColor: appColor.primaryTrans,
                                                                        color: appColor.primary,
                                                                        fontWeight: "600",
                                                                        border: "none"
                                                                    }}
                                                                >
                                                                    {getTwoCharacterFromName(userData?.fullName)}
                                                                </Avatar>
                                                                {
                                                                    user.userId !== tasksValues.taskAddedBy ? (
                                                                        <CloseCircleOutlined
                                                                            onClick={() => handleRemoveUser(user.userId)}
                                                                            style={{
                                                                                position: "absolute",
                                                                                top: 0,
                                                                                right: 0,
                                                                                fontSize: "13px",
                                                                                color: "red",
                                                                                cursor: "pointer",
                                                                                background: "white",
                                                                                borderRadius: "50%",
                                                                            }}
                                                                        />
                                                                    ) : null
                                                                }
                                                            </div>
                                                        </Tooltip> : null);
                                                    })}
                                                    {
                                                        <Dropdown menu={menu} trigger={["click"]}
                                                                  dropdownRender={menu => (
                                                                      <div style={{
                                                                          maxHeight: '200px',
                                                                          overflowY: 'auto'
                                                                      }}>
                                                                          {menu}
                                                                      </div>
                                                                  )}>
                                                            <Button shape="circle" icon={<PlusOutlined/>}/>
                                                        </Dropdown>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                        <div className="taskFieldRow">
                                            <div className="taskFieldLabel">
                                                🔥 Priority
                                            </div>
                                            <div className="taskFieldValue">
                                                <Dropdown menu={{
                                                    items: taskPriorityLabel, onClick: ({key}) => {
                                                        setTasksValues((prev) => ({
                                                            ...prev,
                                                            [appKeys.taskPriority]: key
                                                        }));
                                                    }
                                                }} trigger={["click"]}>
                                                    <div
                                                        className="taskFieldValueSelectorItem">{getIconByKey(tasksValues[appKeys.taskPriority], taskPriorityLabel)}{getLabelByKey(tasksValues[appKeys.taskPriority], taskPriorityLabel)}</div>
                                                </Dropdown>
                                            </div>
                                        </div>
                                        {/*<div className="taskFieldRow">*/}
                                        {/*    <div className="taskFieldLabel">*/}
                                        {/*        ⏱️ Estimated Time*/}
                                        {/*    </div>*/}
                                        {/*    <div className="taskFieldValue">*/}
                                        {/*        <TimePicker*/}
                                        {/*            className="taskFieldValueSelectorItem"*/}
                                        {/*            defaultValue={tasksValues[appKeys.taskEstimatedTime] ? dayjs(tasksValues[appKeys.taskEstimatedTime], 'HH:mm') : null}*/}
                                        {/*            format={'HH:mm'}*/}
                                        {/*            showNow={false}*/}
                                        {/*            onChange={(time, timeString) => {*/}
                                        {/*                setTasksValues((prev) => ({*/}
                                        {/*                    ...prev,*/}
                                        {/*                    [appKeys.taskEstimatedTime]: timeString*/}
                                        {/*                }));*/}
                                        {/*            }}*/}
                                        {/*            placeholder="Duration"/>*/}
                                        {/*    </div>*/}
                                        {/*</div>*/}
                                        {isEditing ? <div className="taskFieldRow">
                                            <div className="taskFieldLabel">
                                                📅 Created At
                                            </div>
                                            <div className="taskFieldValue">
                                                <div style={{
                                                    fontSize: "12px",
                                                    fontWeight: "500",
                                                    fontStyle: "italic"
                                                }}>{dayjs(tasksValues["createdAt"]).format("DD, MMM YYYY [at] hh:mm A")}</div>
                                            </div>
                                        </div> : null}
                                        <div className="taskFieldRow" style={{borderBottom: "none"}}>
                                            <div className="taskFieldLabel">
                                                📂 Category
                                            </div>
                                            <div className="taskFieldValue">
                                                <Dropdown menu={{
                                                    items: taskCategoryLabel, onClick: ({key}) => {
                                                        setTasksValues((prev) => ({
                                                            ...prev,
                                                            [appKeys.taskCategory]: key
                                                        }));
                                                    }
                                                }} trigger={["click"]}>
                                                    <div
                                                        className="taskFieldValueSelectorItem">{getLabelByKey(tasksValues[appKeys.taskCategory], taskCategoryLabel)}</div>
                                                </Dropdown>
                                            </div>
                                        </div>
                                    </div>
                                </Column>
                            </WrapBox>
                        </Form>
                    </Column>
                </div>
                <div style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "10px",
                    marginTop: "15px"
                }}>
                    {isEditing && isAdmin() && (
                        <Tooltip title="Delete Task">
                            <Popconfirm
                                title={appString.deleteConfirmation}
                                onConfirm={handleDeleteTaskApi}
                                style={{margin: "0"}}
                            >
                                <Button color="danger" variant="solid" loading={isDeleteLoading}>
                                    Delete
                                </Button>
                            </Popconfirm>
                        </Tooltip>
                    )}
                    <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", gap: "10px"}}>
                        <Button color="default" variant="outlined" onClick={handleEditCancel}>
                            Cancel
                        </Button>
                        <Button color="primary" variant="solid" onClick={handleAddUpdateTaskApi} loading={isLoading}>
                            Save
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    const historyTabUi = () => {
        return (
            <div
                className="container-with-scrollbar"
                ref={containerRef}
                style={{
                    width: "100%",
                    minHeight: "85vh",
                    maxHeight: "85vh",
                    alignItems: "center",
                    overflow: "auto",
                }}
            >
                <TaskHistory taskHistory={taskDataValue.taskHistory} employeeList={employeeList}/>
            </div>
        );
    }

    const taskTabItems = [
        {
            key: '1',
            label: '📋 Details',
            children: taskDetailTabUi(),
        },
        ...(isAdmin()
            ? [
                {
                    key: '3',
                    label: '🕓 History',
                    children: historyTabUi(),
                },
            ]
            : []),
    ];

    return (
        <Drawer
            title="Manage Task"
            placement="right"
            onClose={handleEditCancel}
            onCancel={handleEditCancel}
            open={internalOpen}
            maskClosable={false}
            mask={false}
            width={700}
            bodyStyle={{ padding: 24, height: '100%', overflow: "hidden" }}
        >
            {taskTabItems.length > 1 ? <div style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
                {internalOpen && (
                    <Tabs
                        defaultActiveKey="1"
                        items={taskTabItems}
                        style={{flex: 1, display: 'flex', flexDirection: 'column', overflowY: 'auto'}}
                    />
                )}
            </div> : <div style={{height: '100%', display: 'flex', flexDirection: 'column', marginTop: " 10px"}}>
                {taskDetailTabUi()}
            </div>}
        </Drawer>
    );
}

const formatDate = (date) => {
    return dayjs(date).format('DD-MM-YYYY HH:mm:ss');
};

const stageWiseColor = (stage) => {
    switch (stage) {
        case taskColumnLabel.ToDo:
            return appColor.primary;
        case taskColumnLabel.InProgress:
            return appColor.info;
        case taskColumnLabel.Testing:
            return appColor.warning;
        case taskColumnLabel.OnHold:
            return appColor.secondary;
        case taskColumnLabel.Completed:
            return appColor.success;
        case taskColumnLabel.Reopened:
            return appColor.danger;
        default:
            return "#FFFFFF";
    }
};

const priorityWiseColor = (priorityKey) => {
    const priority = taskPriorityLabel.find((p) => p.key === priorityKey);
    return priority ? priority.color : "#FFFFFF";
};

const TaskHistory = ({taskHistory, employeeList}) => {
    const groupedHistory = [];

    taskHistory.forEach((historyItem, index) => {
        if (index === 0 || historyItem.changedBy !== taskHistory[index - 1].changedBy) {
            groupedHistory.push({
                user: getDataById(employeeList, historyItem.changedBy),
                changes: [historyItem],
            });
        } else {
            groupedHistory[groupedHistory.length - 1].changes.push(historyItem);
        }
    });

    return (
        <div className="task-history-container">
            {groupedHistory.length > 0 ? groupedHistory.map((group, index) => {
                return (
                    <div key={index} className="task-history-group">
                        {group.user ? <div style={{display: "flex", alignItems: "center", gap: "10px"}}>
                            {
                                group.user.profilePhoto ? <Avatar src={group.user.profilePhoto}/> :
                                    <Avatar style={{
                                        backgroundColor: appColor.primary,
                                        color: appColor.white
                                    }}>{getTwoCharacterFromName(group.user.fullName)}</Avatar>
                            }
                            <div className="taskCardTitle">
                                <strong>{group.user.fullName}</strong> made {group.changes.length} changes<br/>{}</div>
                        </div> : null}
                        <div className="statusMainRow">
                            {group.changes.map((change, i) => {

                                if (change.fieldName === appKeys.taskTitle) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Title: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskDescription) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Description: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskStartDate) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Start Date: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskEndDate) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>End Date: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskEstimatedTime) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Estimated Time: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskStatus) {
                                    const oldLabel = getLabelByKey(change.oldValue, taskColumnStatusLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskColumnStatusLabel);
                                    const oldLabelColor = `${stageWiseColor(oldLabel)}`;
                                    const newLabelColor = `${stageWiseColor(newLabel)}`;

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Status: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${oldLabelColor}20`,
                                                    color: oldLabelColor,
                                                    fontSize: "12px"
                                                }}>{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${newLabelColor}20`,
                                                    color: newLabelColor,
                                                    fontSize: "12px"
                                                }}>{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskCategory) {
                                    const oldLabel = getLabelByKey(change.oldValue, taskCategoryLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskCategoryLabel);

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Category: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.danger}20`,
                                                    color: appColor.danger,
                                                    fontSize: "12px"
                                                }}>{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.success}20`,
                                                    color: appColor.success,
                                                    fontSize: "12px"
                                                }}>{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskPriority) {
                                    const oldLabelIcon = getIconByKey(change.oldValue, taskPriorityLabel);
                                    const newLabelIcon = getIconByKey(change.newValue, taskPriorityLabel);
                                    const oldLabel = getLabelByKey(change.oldValue, taskPriorityLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskPriorityLabel);
                                    const oldLabelColor = priorityWiseColor(change.oldValue);
                                    const newLabelColor = priorityWiseColor(change.newValue);

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Priority: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${oldLabelColor}20`,
                                                    color: oldLabelColor,
                                                    fontSize: "12px"
                                                }}>{oldLabelIcon}{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${newLabelColor}20`,
                                                    color: newLabelColor,
                                                    fontSize: "12px"
                                                }}>{newLabelIcon}{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskLabels) {
                                    const oldLabel = getLabelByKey(change.oldValue, taskStatusLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskStatusLabel);

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Label: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.danger}20`,
                                                    color: appColor.danger,
                                                    fontSize: "12px"
                                                }}>{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.success}20`,
                                                    color: appColor.success,
                                                    fontSize: "12px"
                                                }}>{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }
                            })}
                        </div>
                    </div>
                );
            }) : <div className="noDataContent">
                <img src={imagePaths.noDataFoundImage}/>
            </div>}
        </div>
    );
};

const MessageTime = ({dateString}) => {

    const [formattedTime, setFormattedTime] = useState(formatMessageTimeReal(dateString));

    useEffect(() => {
        const interval = setInterval(() => {
            setFormattedTime(formatMessageTimeReal(dateString));
        }, 10000);

        return () => clearInterval(interval);
    }, [dateString]);

    return <div>{formattedTime}</div>;
};


// const CommentSection = ({tasksData, employeeList}) => {
//
//     const loginUserData = getDataById(employeeList, getUserData._id);
//
//     const updatedComments = tasksData && tasksData[appKeys.comments] ? tasksData[appKeys.comments].map((c) => ({
//         ...c,
//         sent: true,
//     })) : [];
//
//     const [showAllComments, setShowAllComments] = useState(false);
//     const [comments, setComments] = useState(updatedComments);
//     const hasScrolledRef = useRef(false);
//     const scrollContainerRef = useRef(null);
//     const [activeReplyId, setActiveReplyId] = useState(null);
//
//     useEffect(() => {
//         const interval = setInterval(() => {
//             if (!hasScrolledRef.current && scrollContainerRef.current) {
//                 scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
//                 hasScrolledRef.current = true;
//             }
//         }, 100);
//
//         return () => clearInterval(interval);
//     }, []);
//
//     useEffect(() => {
//         const container = scrollContainerRef.current;
//         if (container) {
//             container.scrollTop = container.scrollHeight;
//         }
//     }, [comments]);
//
//     async function handleSendComment(text, parentId = null) {
//         const newComment = {
//             comment: text,
//             commentTime: Date.now(),
//             parentId,
//             sent: false,
//             tempId: Date.now(),
//         };
//
//         setComments((prev) => [...prev, newComment]);
//
//         try {
//
//             await apiCall({
//                 method: HttpMethod.POST,
//                 url: `${endpoints.postTaskComment}${tasksData["_id"]}`,
//                 data: newComment,
//                 setIsLoading: false,
//                 showSuccessMessage: false,
//                 successCallback: (data) => {
//                     const updatedComments = data?.data.comments.map((c) => ({
//                         ...c,
//                         sent: true,
//                     }));
//
//                     setComments(updatedComments || tasksData[appKeys.comments])
//                 },
//             });
//
//         } catch (error) {
//             setComments((prev) =>
//                 prev.map((c) =>
//                     c.tempId === newComment.tempId ? {...c, sent: false, failed: true} : c
//                 )
//             );
//             console.error('Failed to send comment');
//         }
//     }
//
//     async function handleLikeDisLikeComment(commentId, type) {
//         try {
//             const newComment = {
//                 commentId: commentId,
//                 [type]: getLocalData(loginDataKeys._id)
//             };
//             await apiCall({
//                 method: HttpMethod.POST,
//                 url: `${endpoints.postTaskComment}${tasksData["_id"]}`,
//                 data: newComment,
//                 setIsLoading: false,
//                 showSuccessMessage: false,
//                 successCallback: (data) => {
//                     setComments(data?.data.comments || tasksData[appKeys.comments])
//                 },
//             });
//
//         } catch (error) {
//             console.error('Failed to send comment');
//         }
//     }
//
//     const convertToTreeData = (comments) => {
//         const idMap = {};
//         const tree = [];
//
//         comments.forEach((comment, idx) => {
//             idMap[comment._id] = {
//                 title: renderCommentNode(comment, idx, comments),
//                 key: comment._id,
//                 children: [],
//             };
//         });
//
//         comments.forEach((comment) => {
//             if (comment.parentCommentId && idMap[comment.parentCommentId]) {
//                 idMap[comment.parentCommentId].children.push(idMap[comment._id]);
//             } else {
//                 tree.push(idMap[comment._id]);
//             }
//         });
//
//         return tree;
//     };
//
//     const renderCommentNode = (c, idx, msgs) => {
//         const sender = getDataById(employeeList, c.commentBy);
//         const isMyMessage = c.commentBy.toString() === loginUserData._id.toString();
//         const displayName = sender?.fullName || '';
//         const profilePhoto = sender?.profilePhoto || '';
//         const initials = getTwoCharacterFromName(displayName);
//         const isFirstInGroup = idx === 0 || msgs[idx - 1].commentBy !== c.commentBy;
//
//         return (
//             <div
//                 key={c.tempId || idx}
//                 style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '7px' }}
//             >
//                 {isFirstInGroup ? (
//                     <div
//                         style={{
//                             width: 30,
//                             height: 30,
//                             borderRadius: '50%',
//                             backgroundColor: getDarkColor(initials),
//                             display: 'flex',
//                             alignItems: 'center',
//                             justifyContent: 'center',
//                             fontWeight: 'bold',
//                             fontSize: 14,
//                             color: '#fff',
//                             margin: 5,
//                             overflow: 'hidden',
//                         }}
//                     >
//                         {profilePhoto ? (
//                             <img
//                                 src={profilePhoto}
//                                 alt={displayName}
//                                 style={{ width: '100%', height: '100%', objectFit: 'cover' }}
//                             />
//                         ) : (
//                             initials
//                         )}
//                     </div>
//                 ) : (
//                     <div style={{ width: 40 }} />
//                 )}
//                 <div style={{ flex: 1 }}>
//                     <div style={{ marginBottom: 4, fontSize: 13, fontWeight: 550, color: 'black' }}>
//                         {displayName}
//                         <span
//                             style={{
//                                 marginLeft: '15px',
//                                 fontSize: '11px',
//                                 fontWeight: 450,
//                                 color: '#4e4e4e',
//                             }}
//                         >
//                               <MessageTime dateString={c.commentTime} />
//                             </span>
//                     </div>
//                     {Array.isArray(c.attachments) && c.attachments.length > 0 && (
//                         <Image.PreviewGroup>
//                             {c.attachments
//                                 .filter((att) => att.attachmentType.startsWith('image'))
//                                 .map((att, index) => (
//                                     <Image
//                                         key={index}
//                                         src={att.url}
//                                         style={{ marginRight: 8, marginBottom: 8, maxWidth: '150px' }}
//                                     />
//                                 ))}
//                         </Image.PreviewGroup>
//                     )}
//                     <div dangerouslySetInnerHTML={{ __html: c.comment }} style={{ marginBottom: 4 }} />
//                     {activeReplyId === c._id && (
//                         <div style={{ marginTop: 10 }}>
//                             <Editor
//                                 onClickSendButton={(text) => {
//                                     handleSendComment(text, c._id);
//                                     setActiveReplyId(null);
//                                 }}
//                             />
//                         </div>
//                     )}
//                 </div>
//
//                 <Popover
//                     trigger="click"
//                     placement="bottom"
//                     content={
//                         <div
//                             className="replayButtonUi"
//                             onClick={() =>
//                                 setActiveReplyId((prevId) => (prevId === c._id ? null : c._id))
//                             }
//                             style={{ cursor: 'pointer' }}
//                         >
//                             <MessageSquare className="blackIconStyle" style={{ marginRight: 10 }} />
//                             Reply
//                         </div>
//                     }
//                 >
//                     <MoreVertical className="moreIconStyle" style={{ marginLeft: 10, cursor: 'pointer' }} />
//                 </Popover>
//             </div>
//         );
//     };
//
//     const groupMessagesByDate = (comments) => {
//         const groups = {};
//
//         comments.forEach(comment => {
//             const date = new Date(comment.commentTime);
//             const now = new Date();
//
//             const todayStr = now.toDateString();
//             const yesterday = new Date();
//             yesterday.setDate(yesterday.getDate() - 1);
//             const yesterdayStr = yesterday.toDateString();
//
//             let label = '';
//             if (date.toDateString() === todayStr) label = 'Today';
//             else if (date.toDateString() === yesterdayStr) label = 'Yesterday';
//             else label = new Intl.DateTimeFormat('en-GB', {
//                     day: '2-digit',
//                     month: 'long',
//                     year: 'numeric',
//                 }).format(date);
//
//             if (!groups[label]) groups[label] = [];
//             groups[label].push(comment);
//         });
//
//         return groups;
//     };
//
//     const getFlattenedMessages = () => {
//         const groupedMessages = groupMessagesByDate(comments);
//         const allMessages = [];
//         Object.entries(groupedMessages).forEach(([dateLabel, msgs]) => {
//             msgs.forEach((msg) => {
//                 allMessages.push({
//                     ...msg,
//                     dateLabel,
//                 });
//             });
//         });
//
//         return allMessages.sort((a, b) => new Date(a.commentTime) - new Date(b.commentTime));
//     };
//
//     const allFlattenedMessages = getFlattenedMessages();
//     const visibleMessages = showAllComments ? allFlattenedMessages : allFlattenedMessages.slice(-5);
//
//     const groupedVisibleMessages = visibleMessages.reduce((acc, msg) => {
//         if (!acc[msg.dateLabel]) acc[msg.dateLabel] = [];
//         acc[msg.dateLabel].push(msg);
//         return acc;
//     }, {});
//
//     return (
//         <div>
//             <Editor onClickSendButton={handleSendComment} span={24}/>
//             <SpaceBox space={10}/>
//             <Divider span={24}/>
//             <SpaceBox space={10}/>
//             {comments.length > 0 ? <Column span={24}>
//                 <div style={{
//                     gap: "10px",
//                     display: "flex",
//                     alignItems: "center",
//                 }}>
//                     <AppText
//                         text={`Comments`}
//                         fontSize={14}
//                         fontWeight={550}
//                         color={appColor.black}
//                     />
//                     <div style={{
//                         padding: "0px 10px",
//                         backgroundColor: appColor.primary,
//                         fontWeight: "500",
//                         fontSize: "12px",
//                         borderRadius: "50px",
//                         color: "white"
//                     }}>
//                         {comments.length}
//                     </div>
//                 </div>
//                 <div
//                     ref={scrollContainerRef}
//                     style={{
//                         flex: 1,
//                         overflowY: "auto",
//                         // padding: "1rem",
//                         // marginBottom: "10px",
//                         // backgroundColor: "#f9f9f9",
//                         display: "flex",
//                         flexDirection: "column",
//                     }}
//                 >
//                     {Object.entries(groupedVisibleMessages).reverse().map(([dateLabel, msgs]) => (
//                         <div key={dateLabel}>
//                             <Divider style={{
//                                 fontSize: "13px",
//                                 fontWeight: "550",
//                                 color: "black",
//                                 borderColor: '#cfcfcf'
//                             }}>{dateLabel}</Divider>
//                             {msgs.reverse().map((c, idx) => {
//                                 const sender = getDataById(employeeList, c.commentBy);
//                                 const parentId = c?.parentId || null;
//                                 const displayName = sender?.fullName || "";
//                                 const profilePhoto = sender?.profilePhoto || "";
//                                 const initials = getTwoCharacterFromName(displayName);
//
//                                 const isFindLike = c?.likes?.find(id => id === getLocalData(loginDataKeys._id)) || false;
//                                 const isFindDislike = c?.dislikes?.find(id => id === getLocalData(loginDataKeys._id)) || false;
//
//                                 const isFirstInGroup =
//                                     idx === 0 || msgs[idx - 1].commentBy !== c.commentBy;
//
//                                 return (
//                                     <div>
//                                         <div
//                                             key={c.tempId || idx}
//                                             style={{
//                                                 display: "flex",
//                                                 alignItems: "flex-start",
//                                                 marginBottom: "7px",
//                                                 // flexDirection: isMyMessage ? "row-reverse" : "row",
//                                                 flexDirection: "row",
//                                             }}
//                                         >
//                                             {isFirstInGroup ? (
//                                                 <div
//                                                     style={{
//                                                         width: 30,
//                                                         height: 30,
//                                                         borderRadius: "50%",
//                                                         backgroundColor: getDarkColor(initials),
//                                                         overflow: "hidden",
//                                                         display: "flex",
//                                                         alignItems: "center",
//                                                         justifyContent: "center",
//                                                         fontWeight: "bold",
//                                                         fontSize: 14,
//                                                         color: "#fff",
//                                                         margin: 5,
//                                                     }}
//                                                 >
//                                                     {profilePhoto ? (
//                                                         <img
//                                                             src={profilePhoto}
//                                                             alt={displayName}
//                                                             style={{
//                                                                 width: "100%",
//                                                                 height: "100%",
//                                                                 objectFit: "cover"
//                                                             }}
//                                                         />
//                                                     ) : (
//                                                         initials
//                                                     )}
//                                                 </div>
//                                             ) : <div style={{width: 40}}/>}
//                                             <div
//                                                 className="messageContainer"
//                                             >
//                                                 <div
//                                                     style={{
//                                                         marginBottom: "4px",
//                                                         fontSize: "13px",
//                                                         fontWeight: "550",
//                                                         color: "black",
//                                                         display: "flex",
//                                                         alignItems: "center"
//                                                     }}
//                                                 >{displayName}<span
//                                                     style={{
//                                                         marginLeft: "15px",
//                                                         fontSize: "11px",
//                                                         fontWeight: "450",
//                                                         color: "#4e4e4e"
//                                                     }}
//                                                 >
//                                                                         <MessageTime dateString={c.commentTime}/>
//                                                                     </span>
//                                                 </div>
//                                                 {Array.isArray(c.attachments) && c.attachments.length > 0 && (
//                                                     <div style={{marginTop: "5px"}}>
//                                                         <Image.PreviewGroup
//                                                             preview={{
//                                                                 onChange: (current, prev) =>
//                                                                     console.log(`current index: ${current}, prev index: ${prev}`),
//                                                             }}
//                                                         >
//                                                             {c.attachments
//                                                                 .filter((att) => att.attachmentType.startsWith("image"))
//                                                                 .map((att, index) => (
//                                                                     <Image
//                                                                         key={index}
//                                                                         // width={100}
//                                                                         src={att.url}
//                                                                         style={{
//                                                                             marginRight: 8,
//                                                                             marginBottom: 8,
//                                                                             maxWidth: "150px"
//                                                                         }}
//                                                                     />
//                                                                 ))}
//                                                         </Image.PreviewGroup>
//                                                     </div>
//                                                 )}
//                                                 <div
//                                                     dangerouslySetInnerHTML={{__html: c.comment}}
//                                                     style={{marginBottom: "4px"}}
//                                                 />
//                                                 <div className="commentManageRow">
//                                                     <div className="commentLikeManageRow">
//                                                         <div className="commentBtn" onClick={() => handleLikeDisLikeComment(c._id, "like")}>
//                                                             <LikeFilled style={{ color: isFindLike ? appColor.primary : appColor.secondary }} />
//                                                             <div>{c.likes?.length || 0}</div>
//                                                         </div>
//                                                         <div className="commentBtn" onClick={() => handleLikeDisLikeComment(c._id, "dislike")}>
//                                                             <DislikeFilled style={{ color: isFindDislike ? appColor.primary : appColor.secondary }} />
//                                                             <div>{c.dislikes?.length || 0}</div>
//                                                         </div>
//                                                     </div>
//                                                     <div className="commentBtn" onClick={() => setActiveReplyId(c.tempId || c._id)}>
//                                                         <MessageFilled style={{color: appColor.secondary}} />
//                                                         <div>Reply</div>
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                         {activeReplyId === (c.tempId || c._id) && (
//                                             <div style={{ marginLeft: 40, marginTop: 8, marginBottom: 10 }}>
//                                                 <Editor
//                                                     onClickSendButton={(text) => {
//                                                         handleSendComment(text, c._id);
//                                                         setActiveReplyId(null);
//                                                     }}
//                                                 />
//                                             </div>
//                                         )}
//                                     </div>
//                                 );
//                             })}
//                         </div>
//                     ))}
//                     <div className="chatShowHideButton" onClick={() => setShowAllComments(!showAllComments)}>
//                         {!showAllComments && comments.length > 5 ? "View All Comments" : "Hide Comments"}
//                     </div>
//                 </div>
//                 <Divider/>
//             </Column> : null}
//         </div>
//     );
// };



