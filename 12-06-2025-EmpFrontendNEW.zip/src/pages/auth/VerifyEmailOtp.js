import React, { useEffect, useState } from "react";
import { Button, Form, Input } from "antd";
import { useLocation, useNavigate } from "react-router-dom";
import { Loader } from "../../components/Loader";
import Container from "../../components/common/Container";
import imagePaths from "../../assets/assetsPaths";
import Card from "../../components/common/Card";
import AppText from "../../components/common/AppText";
import appString from "../../utils/appString";
import appColor from "../../utils/appColors";
import SpaceBox from "../../components/common/SpaceBox";
import {forgetPassVerifyOtpApi} from "../../api/apiUtils";

export default function VerifyEmailOtp() {
  const [isLoading, setIsLoading] = useState(false);
  const location = useLocation();
  const { emailAddress } = location.state || {};

  const [formValues, setFormValues] = useState({});

  const onChange = (text) => {
    formValues.otp = text;
    setFormValues(formValues);
  };

  useEffect(() => {
    formValues.emailAddress = emailAddress;
    setFormValues(formValues);
  }, []);

  const onInput = (value) => {
  };

  const sharedProps = {
    onChange,
    onInput,
  };

  const navigate = useNavigate();

  const handleSubmit = () => {
    forgetPassVerifyOtpApi({
      formValues: formValues,
      setIsLoading: setIsLoading,
      navigate: navigate,
    });
  };

  return (
    <>
      {isLoading ? <Loader /> : ""}
      <Container
        padding="15px"
        width="100vw"
        height="100vh"
        backgroundColor="white"
        backgroundImage={imagePaths.bgImage}
        backgroundSize="cover"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        <Card
          width="22rem"
          padding="20px"
          elevation="0px 7px 29px 0px rgba(100, 100, 111, 0.2)"
        >
          <AppText
            text={appString.verifyEmailOtp}
            fontSize="20px"
            fontWeight="600"
            color={appColor.primary}
          />
          <AppText
            text={appString.verifyEmailOtpDes}
            fontSize="14px"
            color={appColor.black}
          />
          <SpaceBox space={5} />
          <Form.Item name="otp">
            <Input.OTP type="number" {...sharedProps} />
          </Form.Item>
          <SpaceBox space={2} />
          <Button
            className="btnStyle"
            block
            type="primary"
            htmlType="submit"
            onClick={handleSubmit}
          >
            {appString.verifyOtp}
          </Button>
        </Card>
      </Container>
    </>
  );
}
