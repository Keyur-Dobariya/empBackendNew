import React, {useEffect, useState} from "react";
import {
    Plus,
    Search,
    Edit, Trash2
} from "react-feather";
import {
    Checkbox, Col,
    Popconfirm, Row,
    Table,
    Tooltip
} from "antd";
import dayjs from "dayjs";
import {
    deleteBasicSalaryApi
} from "../../api/apiUtils";
import {SearchTextFieldNew} from "../../components/formField/DynamicForm";
import {
    decryptValue,
} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import BasicSalaryAddUpdateModel from "../../model/BasicSalaryAddUpdateModel";
import {antTag} from "../../common/colorTag";
import {isAdmin} from "../../utils/utils";
import {AppDataFields, useAppData} from "../../AppDataContext";

const BasicSalaryPage = () => {
    const {activeUsersData, basicSalaryData, updateAppDataField} = useAppData();
    const [isShowAmounts, setIsShowAmounts] = useState(false);
    const [isAddBasicSalaryModelOpen, setAddBasicSalaryModelOpen] = useState(false);
    const [isBasicSalaryEditing, setIsBasicSalaryEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [basicSalaryRecord, setBasicSalaryRecord] = useState(basicSalaryData);
    const [selectedBasicSalaryRecord, setSelectedBasicSalaryRecord] = useState({});

    useEffect(() => {
        setBasicSalaryRecord(basicSalaryData);
    }, [basicSalaryData]);

    const handleDataConditionWise = (data) => {
        updateAppDataField(AppDataFields.basicSalaryData, data?.data);
    };

    const handleBasicSalaryAddClick = () => {
        setAddBasicSalaryModelOpen(true);
        setSelectedBasicSalaryRecord({});
    };

    const handleEditClick = (value) => {
        setIsBasicSalaryEditing(true);
        setSelectedBasicSalaryRecord(value);
        setAddBasicSalaryModelOpen(true);
    };

    const handleDeleteBasicSalaryApi = async (event) => {
        await deleteBasicSalaryApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddBasicSalaryModelOpen(false);
                handleDataConditionWise(data)
            },
        });
    };

    const leaveTableColumn = [
        {
            title: appString.fullName,
            dataIndex: appKeys.user,
            key: 'user.fullName',
            render: (text, record) => record.user ? record.user.fullName : '',
        },
        {
            title: appString.basicSalary,
            dataIndex: appKeys.basicSalary,
            key: appKeys.basicSalary,
            render: (basicSalary) => {
                console.log("dxfgdsfgd", basicSalary)
                return antTag(!isShowAmounts ? "***" : decryptValue(basicSalary), "green");
            },
        },
        {
            title: appString.code,
            dataIndex: appKeys.code,
            key: appKeys.code,
            render: (code) => {
                return antTag(!isShowAmounts ? "***" : code, "blue");
            },
        },
        {
            title: appString.startDate,
            dataIndex: appKeys.startDate,
            key: appKeys.startDate,
            render: (startDate) => {
                return startDate ? dayjs(startDate).format("YYYY-MM-DD") : '-';
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            hidden: !isAdmin(),
            render: (_, record) => {
                return activeUsersData?.length >= 1 ? (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            <div
                                style={{marginRight: 25, cursor: "pointer"}}
                                onClick={() => handleEditClick(record)}
                            >
                                <Tooltip title={appString.edit}>
                                    <Edit className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                            <Popconfirm
                                title={appString.deleteConfirmation}
                                onConfirm={() => handleDeleteBasicSalaryApi(record)}
                                style={{margin: "0"}}
                            >
                                <div style={{marginRight: 25, cursor: "pointer"}}>
                                    <Tooltip title={appString.delete} placement="bottom">
                                        <Trash2 className="deleteIconStyle"/>
                                    </Tooltip>
                                </div>
                            </Popconfirm>
                        </div>
                    </>
                ) : null;
            },
        },
    ];

    return (
        <>
            <div className="taskBoardContainer">
                <Row gutter={[16, 16]} style={{margin: "15px 0px"}}>
                    <Col xs={24} sm={24} md={8} lg={8}>
                        <SearchTextFieldNew
                            field={{
                                name: "search",
                                placeholder: "Search Data",
                                prefix: <Search/>,
                                onChange: (e) => {
                                    const searchText = e.target.value.toLowerCase();
                                    const filteredData = basicSalaryData?.filter((record) => {
                                        return record.user.fullName?.toLowerCase().includes(searchText);
                                    });
                                    setBasicSalaryRecord(filteredData);
                                },
                            }}
                        />
                    </Col>
                    <Col xs={24} sm={24} md={16} lg={16}>
                        <Row
                            gutter={[16, 16]}
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                                flexDirection: "row",
                            }}
                        >
                            <Col style={{display: "flex", alignItems: "center"}}>
                                <Checkbox
                                    checked={isShowAmounts}
                                    onChange={(e) => setIsShowAmounts(e.target.checked)}
                                    style={{display: "flex", alignItems: "center"}}
                                >
                                    <div>Show Amounts</div>
                                </Checkbox>
                            </Col>
                            <Col style={{display: "flex", alignItems: "center"}}>
                                <div
                                    className="addUpdateCommonBtn"
                                    onClick={handleBasicSalaryAddClick}
                                    style={{
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "8px",
                                        marginTop: "0px",
                                    }}
                                >
                                    <Plus/>
                                    <div>Add Basic Salary</div>
                                </div>
                            </Col>
                        </Row>
                    </Col>
                </Row>
                <Table
                    rowKey={(record) => record._id}
                    columns={leaveTableColumn}
                    dataSource={basicSalaryRecord}
                    scroll={{x: "max-content"}}
                    loading={isLoading}
                />
            </div>
            {isAddBasicSalaryModelOpen && (
                <BasicSalaryAddUpdateModel
                    isModelOpen={isAddBasicSalaryModelOpen}
                    setIsModelOpen={setAddBasicSalaryModelOpen}
                    basicSalaryData={selectedBasicSalaryRecord}
                    isEditing={isBasicSalaryEditing}
                    setIsEditing={setIsBasicSalaryEditing}
                    onSuccessCallback={handleDataConditionWise}
                />
            )}
        </>
    );
};

export default BasicSalaryPage;