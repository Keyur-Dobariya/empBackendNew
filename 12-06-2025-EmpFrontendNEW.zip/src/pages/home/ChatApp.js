import React, {useEffect, useState, useRef} from "react";
import {
    List,
    Avatar,
    Badge,
    Input,
    Button,
    Collapse,
    message as antdMessage,
    Spin,
    Tooltip, Image, Divider, Col, Popover, Upload, Modal, Form, Select, Space,
} from "antd";
import {
    SearchOutlined,
    SmileOutlined,
    PhoneFilled,
    VideoCameraFilled,
    CheckCircleFilled,
    CloseCircleOutlined,
    ClockCircleFilled,
    SendOutlined,
    LikeFilled,
    DislikeFilled,
    MessageFilled,
    UpOutlined,
    DownOutlined,
    SmileFilled,
    PaperClipOutlined,
    UploadOutlined,
    UsergroupAddOutlined,
    LoadingOutlined,
    PlusOutlined,
    CloseOutlined,
    DeleteFilled,
    DeleteOutlined,
} from "@ant-design/icons";
import {Check, Heart, MoreHorizontal, MoreVertical, Plus, Search, Smile} from "react-feather";
import axios from "axios";
import {endpoints, environment} from "../../api/apiEndpoints";
import {AppDataFields, useAppData} from "../../AppDataContext";
import {FullScreenLoader} from "../../components/Loader";
import {getDarkColor} from "../../utils/colorMapper";
import appColor from "../../utils/appColors";
import {convertCamelCase, getTwoCharacterFromName} from "../../components/CommonComponents";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import dayjs from "dayjs";
import {uploadType, UserActiveStatus} from "../../utils/enum";
import {
    formatMessageTimeReal,
    getDataById,
    getFileExtension,
    getFileIcon, isAudioExtension,
    isImageExtension,
    isVideoExtension
} from "../../utils/utils";
import assetsPaths from "../../assets/assetsPaths";
import appKeys from "../../utils/appKeys";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import Editor from "../../components/Editor";
import SpaceBox from "../../components/common/SpaceBox";
import Column from "../../components/common/Column";
import AppText from "../../components/common/AppText";
import {SearchTextFieldNew} from "../../components/formField/DynamicForm";
import imagePaths from "../../assets/assetsPaths";
import EmojiPicker from "emoji-picker-react";

import {Typography} from 'antd';

const {Option} = Select;

const {TextArea} = Input;
const {Text} = Typography;

const apiAction = {
    getRooms: "getRooms",
    getMessages: "getMessages",
    sendMessage: "sendMessage",
    createGroup: "createGroup",
    createRoom: "createRoom",
    markMessagesAsRead: "markMessagesAsRead",
    getRoomWithMessages: "getRoomWithMessages",
};
const currentUserId = getLocalData(loginDataKeys._id);

const children = "tracker_upload (1)_1749712319953.zip";

const ChatApp = () => {
    const {usersData, updateAppDataField} = useAppData();
    const [roomsLoading, setRoomsLoading] = useState(false);
    const [profileUploadLoading, setProfileUploadLoading] = useState(false);
    const [usersLoading, setUsersLoading] = useState(false);
    const [messagesLoading, setMessagesLoading] = useState(false);
    const [roomsData, setRoomsData] = useState([]);
    const [selectedRoom, setSelectedRoom] = useState({
        fullName: null,
        emailAddress: null,
        profilePhoto: null,
        _id: null,
        roomId: null,
    });
    const [messages, setMessages] = useState([]); // Store messages for the selected room
    const [input, setInput] = useState(""); // Message input state
    const [sending, setSending] = useState(false);
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);

    const messagesEndRef = useRef(null);
    const textareaRef = useRef(null);

    const [form] = Form.useForm();
    const [fileList, setFileList] = useState([]);
    const [isGroupCreateModelOpen, setGroupCreateModelOpen] = useState(false);

    const availableUsers = usersData.filter(user => user._id !== currentUserId);

    const handleUpload = async (file) => {
        try {
            const formData = new FormData();
            formData.append("file", file);

            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.upload,
                data: formData,
                setIsLoading: setProfileUploadLoading,
                isMultipart: true,
                showSuccessMessage: false,
                successCallback: (data) => {
                    setFileList([{
                        uid: file.uid,
                        name: file.name,
                        status: 'done',
                        url: data.data.url,
                        attachmentType: data.data.attachmentType,
                    }]);
                },
            });

        } catch (error) {
            console.log("error->", error);
        }
    };

    const handleRemove = async () => {
        try {
            const bodyData = {
                fileUrl: fileList[0].url,
            }
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.delete,
                data: bodyData,
                setIsLoading: setProfileUploadLoading,
                showSuccessMessage: false,
                successCallback: (data) => {
                    setFileList([]);
                },
            });
        } catch (error) {
            console.log("error->", error);
        }
    };

    const uploadProps = {
        onRemove: handleRemove,
        beforeUpload: handleUpload,
        fileList,
        listType: "picture-circle",
    };

    useEffect(() => {
        const evtSource = new EventSource(endpoints.employeesChange);

        evtSource.onmessage = (event) => {
            if (event.data) {
                updateAppDataField(AppDataFields.usersData, JSON.parse(event.data) || usersData);
            }
        };

        evtSource.addEventListener('end', () => {
            evtSource.close();
        });

        return () => evtSource.close();
    }, [usersData, updateAppDataField]);

    // const fetchRooms = async () => {
    //     await apiCall({
    //         method: HttpMethod.GET,
    //         url: endpoints.getRoomsList,
    //         setIsLoading: setRoomsLoading,
    //         showSuccessMessage: false,
    //         successCallback: (data) => {
    //             setRoomsData(data?.data || []);
    //         },
    //     });
    // };

    const fetchRooms = async () => {
        await apiCall({
            method: HttpMethod.GET,
            // url: `${endpoints.chatApi}?action=${apiAction.getRooms}`,
            url: `${endpoints.chatApi}?action=${apiAction.getRoomWithMessages}`,
            setIsLoading: setRoomsLoading,
            showSuccessMessage: false,
            successCallback: (data) => {
                setRoomsData(data?.data || []);
            },
        });
    };

    useEffect(() => {
        const eventSource = new EventSource(endpoints.chatUpdates);

        eventSource.onmessage = (event) => {
            const roomId = selectedRoom?.roomId;
            const updatedData = JSON.parse(event.data);
            console.log('Received chat updates:', updatedData);

            if (updatedData?.messagesData) {
                const updatedArray = roomsData.map((item) => {
                    const updatedItem = updatedData?.messagesData.find((data) => data._id === item._id);
                    return updatedItem ? updatedItem : item;
                });
                setRoomsData(updatedArray);
            }

            if (roomId && updatedData?.messages?.[roomId]) {
                setMessages(updatedData.messages[roomId].messages);
            }
        };

        eventSource.onerror = (error) => {
            console.error('SSE error:', error);
            eventSource.close();
        };

        return () => {
            eventSource.close();
        };
    }, [currentUserId, selectedRoom?.roomId]);

    const createChatRoom = async (body) => {
        await apiCall({
            method: HttpMethod.POST,
            url: endpoints.chatApi,
            data: body,
            setIsLoading: setMessagesLoading,
            showSuccessMessage: false,
            successCallback: (data) => {
                setRoomsData([...roomsData, data.data]);
                setSelectedRoom({
                    fullName: data.data.members.find(m => m._id !== currentUserId)?.fullName || "Unnamed User",
                    emailAddress: data.data.members.find(m => m._id !== currentUserId)?.emailAddress || "Unnamed User",
                    profilePhoto: data.data.members.find(m => m._id !== currentUserId)?.profilePhoto,
                    _id: data.data.members.find(m => m._id !== currentUserId)?._id,
                    roomId: data.data?._id,
                });
                handleModelClose();
            },
        });
    };

    const fetchMessages = async (roomId) => {
        if (!roomId) return;
        await apiCall({
            method: HttpMethod.GET,
            url: `${endpoints.chatApi}?action=${apiAction.getMessages}&roomId=${roomId}`,
            setIsLoading: setMessagesLoading,
            showSuccessMessage: false,
            successCallback: (data) => {
                setMessages(data.data.messages.reverse());
            },
        });
    };

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({behavior: "smooth"});
    };

    useEffect(() => {
        fetchRooms();
    }, []);

    useEffect(() => {
        if (selectedRoom.roomId) {
            fetchMessages(selectedRoom.roomId);
        } else {
            setMessages([]);
        }
    }, [selectedRoom.roomId]);

    const handleEmojiSelect = (emoji) => {
        setInput(input + emoji);
        setShowEmojiPicker(false);
        textareaRef.current.focus();
    };

    const usersInChatRooms = new Set();
    roomsData.forEach(room => {
        if (!room.isGroup) {
            const otherMember = room.members.find(member => member._id !== currentUserId);
            if (otherMember) {
                usersInChatRooms.add(otherMember._id);
            }
        }
    });

    const filteredContactsData = usersData.filter(user =>
        user._id !== currentUserId && !usersInChatRooms.has(user._id)
    );

    const filteredPinnedData = roomsData.filter(room =>
        room && room.userMeta.isPinned
    );

    const statusIconStyle = (color) => ({
        fontSize: 11,
        color: color ?? appColor.statusAvailable,
        position: "absolute",
        top: 29,
        right: 5,
        backgroundColor: "white",
        borderRadius: "50%",
        border: "1px solid white",
    });

    const statusIcon = (status) => {
        if (status === UserActiveStatus.available) {
            return <CheckCircleFilled style={statusIconStyle(appColor.statusAvailable)}/>;
        }
        if (status === UserActiveStatus.notAvailable) {
            return <CloseCircleOutlined style={statusIconStyle(appColor.secondary)}/>;
        }
        return <ClockCircleFilled style={statusIconStyle(appColor.statusAway)}/>;
    };

    const handleModelClose = () => {
        setGroupCreateModelOpen(false);
    }

    if (!usersData) {
        return <FullScreenLoader/>;
    }

    return (
        <>
            <div className="chatBoxContainer">
                <div className="chatRoomListBox">
                    <div className="chatBoxHeaderTitle">
                        <div>Messages</div>
                        <Tooltip title="Create Group">
                            <UsergroupAddOutlined className="chatBoxHeaderIcon"
                                                  onClick={() => setGroupCreateModelOpen(true)}/>
                        </Tooltip>
                    </div>
                    <div className="chatBoxSearchbar">
                        <SearchTextFieldNew
                            field={{
                                name: "search",
                                placeholder: "Search Data",
                                prefix: <Search/>,
                                onChange: (e) => {
                                    const searchText = e.target.value.toLowerCase();

                                },
                            }}
                            isFilled={true}
                        />
                    </div>
                    <Collapse
                        defaultActiveKey={["pin", "messages", "contacts"]}
                        expandIconPosition="right"
                        className="chatCollapse"
                        bordered={false}
                    >
                        <Collapse.Panel style={{
                            border: "none",
                            display: filteredPinnedData && filteredPinnedData.length > 0 ? 'block' : 'none'
                        }} header="📌 Pin Chat" key="pin">
                            <List
                                className="chatUserList"
                                itemLayout="horizontal"
                                dataSource={filteredPinnedData}
                                loading={roomsLoading}
                                renderItem={(room) => {
                                    return <RoomItem usersData={usersData} data={room} selectedRoom={selectedRoom}
                                                     setSelectedRoom={setSelectedRoom} onRoomClick={(data) => {
                                        setSelectedRoom(data);
                                    }}/>
                                }}
                            />
                        </Collapse.Panel>
                        <Collapse.Panel
                            style={{border: "none", display: roomsData && roomsData.length > 0 ? 'block' : 'none'}}
                            header="💬 Message" key="messages">
                            <List
                                className="chatUserList"
                                itemLayout="horizontal"
                                dataSource={roomsData}
                                loading={roomsLoading}
                                renderItem={(room) => {
                                    return <RoomItem usersData={usersData} data={room} selectedRoom={selectedRoom}
                                                     setSelectedRoom={setSelectedRoom} onRoomClick={(data) => {
                                        setSelectedRoom(data);
                                    }}/>
                                }}
                            />
                        </Collapse.Panel>
                        <Collapse.Panel style={{
                            border: "none",
                            display: filteredContactsData && filteredContactsData.length > 0 ? 'block' : 'none'
                        }} header="📱 Contact" key="contacts">
                            <List
                                className="chatUserList"
                                itemLayout="horizontal"
                                dataSource={filteredContactsData}
                                loading={usersLoading}
                                renderItem={(user) => {
                                    return <RoomItem usersData={usersData} data={user} isRoom={false}
                                                     selectedRoom={selectedRoom} setSelectedRoom={setSelectedRoom}
                                                     onRoomClick={(data) => {
                                                         console.log("data=>", data)
                                                         setSelectedRoom(data);
                                                         console.log("selectedRoom=>", selectedRoom)
                                                     }}/>
                                }}
                            />
                        </Collapse.Panel>
                    </Collapse>
                </div>
                {selectedRoom.fullName ? (
                    <div className="chatMessageContainer">
                        <div className="chatBoxHeader">
                            <div className="selectedChatRow">
                                <Badge
                                    count={statusIcon(getDataById(usersData, selectedRoom._id)?.status || UserActiveStatus.notAvailable)}
                                >
                                    <Tooltip title={selectedRoom.fullName}>
                                        <Avatar
                                            size={35}
                                            src={selectedRoom.profilePhoto || null}
                                            style={{
                                                backgroundColor: !selectedRoom.profilePhoto ? getDarkColor(selectedRoom.fullName) : undefined,
                                                color: appColor.white,
                                                cursor: "pointer",
                                                fontSize: "13px",
                                                fontWeight: "550",
                                                border: "none",
                                            }}
                                        >
                                            {!selectedRoom.profilePhoto && getTwoCharacterFromName(selectedRoom.fullName)}
                                        </Avatar>
                                    </Tooltip>
                                </Badge>
                                <div style={{marginLeft: "12px", flex: 1}}>
                                    <div>{selectedRoom.fullName}</div>
                                    <div style={{fontSize: "11px", color: "#888", fontWeight: 450}}>
                                        {getDataById(usersData, selectedRoom._id)?.status || UserActiveStatus.notAvailable}
                                    </div>
                                </div>
                            </div>
                            <div className="selectedChatRowIcons">
                                <div className="chatIcon">
                                    <Tooltip title="Voice Call">
                                        <PhoneFilled rotate={90}/>
                                    </Tooltip>
                                </div>
                                <div className="chatIcon">
                                    <Tooltip title="Video Call">
                                        <VideoCameraFilled/>
                                    </Tooltip>
                                </div>
                            </div>
                        </div>
                        {selectedRoom.roomId ? (
                            <MessageSection messagesData={messages} employeeList={usersData}
                                            messagesLoading={messagesLoading}
                                            currentUserId={currentUserId} selectedRoom={selectedRoom}/>
                        ) : (
                            <div className="startConversationImage">
                                <img src={imagePaths.emojiHey}/>
                                <Button type="primary" onClick={async () => {
                                    const body = {
                                        otherUserId: selectedRoom._id,
                                        action: apiAction.createRoom,
                                    };
                                    await createChatRoom(body);
                                }} style={{height: "40px", borderRadius: "50px"}}>Start Conversation</Button>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="startConversationContainer">
                        <img src={assetsPaths.chatIcon} alt="chat"/>
                    </div>
                )}
            </div>
            <Modal
                title="Create Group Chat"
                open={isGroupCreateModelOpen}
                onCancel={handleModelClose}
                onClose={handleModelClose}
                confirmLoading={messagesLoading}
                onOk={async () => {
                    const body = {
                        action: apiAction.createGroup,
                        userIds: form.getFieldValue("members"),
                        isGroup: true,
                        groupName: form.getFieldValue("groupName"),
                        groupPhoto: fileList[0].url,
                    };
                    await createChatRoom(body);
                }}
            >
                <Form
                    form={form}
                    layout="vertical"
                    style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        flexDirection: "column",
                        alignSelf: "center"
                    }}
                >
                    <Form.Item
                        name="groupPhoto"
                    >
                        <Upload {...uploadProps}>
                            {profileUploadLoading ? (
                                <Spin indicator={<LoadingOutlined spin/>}/>
                            ) : (
                                fileList.length > 0 ? null : (
                                    <button
                                        style={{
                                            border: 0,
                                            background: "none",
                                        }}
                                        type="button"
                                    >
                                        <PlusOutlined/>
                                        <div style={{marginTop: 8}}>Upload</div>
                                    </button>
                                )
                            )}
                        </Upload>
                    </Form.Item>
                    <Form.Item
                        label="Group Name"
                        name="groupName"
                        style={{width: '100%'}}
                        rules={[{required: true, message: 'Group name is required'}]}
                    >
                        <Input style={{height: '40px'}} placeholder="Enter group name"/>
                    </Form.Item>
                    <Form.Item
                        label="Members"
                        name="members"
                        style={{width: '100%'}}
                        rules={[{required: true, message: 'Please select at least 2 members'}]}
                    >
                        <Select
                            mode="multiple"
                            className="chatGroupMemberSelect"
                            style={{width: '100%', minHeight: '40px'}}
                            placeholder="Select members"
                            showSearch
                            filterOption={(input, option) =>
                                option.label.toLowerCase().includes(input.toLowerCase())
                            }
                            tagRender={({label, value, closable, onClose}) => {
                                const user = availableUsers.find(u => u._id === value);
                                return (
                                    <div
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            margin: 5,
                                            padding: '2px 6px',
                                            background: '#f0f0f0',
                                            borderRadius: 10,
                                            height: 33,
                                        }}
                                    >
                                        <Avatar
                                            size="small"
                                            src={user?.profilePhoto || null}
                                            style={{
                                                backgroundColor: !user?.profilePhoto ? getDarkColor(user?.fullName) : undefined,
                                                color: appColor.white,
                                                cursor: "pointer",
                                                fontSize: "13px",
                                                fontWeight: "550",
                                                border: "none",
                                                marginRight: "5px"
                                            }}
                                        >
                                            {!user?.profilePhoto && getTwoCharacterFromName(user?.fullName)}
                                        </Avatar>
                                        <span style={{marginRight: 6}}>{user?.fullName}</span>
                                        {closable && (
                                            <CloseOutlined onClick={onClose} style={{cursor: 'pointer'}}/>
                                        )}
                                    </div>
                                );
                            }}
                        >
                            {availableUsers.map(user => (
                                <Option
                                    key={user._id}
                                    value={user._id}
                                    label={user.fullName}
                                >
                                    <Space>
                                        <Avatar
                                            size="small"
                                            src={user?.profilePhoto || null}
                                            style={{
                                                backgroundColor: !user?.profilePhoto ? getDarkColor(user?.fullName) : undefined,
                                                color: appColor.white,
                                                cursor: "pointer",
                                                fontSize: "13px",
                                                fontWeight: "550",
                                                border: "none",
                                            }}
                                        >
                                            {!user?.profilePhoto && getTwoCharacterFromName(user?.fullName)}
                                        </Avatar>
                                        <span>{user.fullName}</span>
                                    </Space>
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>
                </Form>
            </Modal>
        </>
    );
};

export const MessageSection = ({messagesData, employeeList, messagesLoading, currentUserId, selectedRoom}) => {
    const {updateAppDataField} = useAppData();

    const updatedMessages = messagesData && messagesData.length > 0
        ? messagesData.map((m) => ({...m, sent: true}))
        : [];

    const [messages, setMessages] = useState(updatedMessages);
    const scrollContainerRef = useRef(null);
    const [activeReplyId, setActiveReplyId] = useState(null);
    const [inputValue, setInputValue] = useState("");
    const [isHovered, setIsHovered] = useState(false);
    const [popoverVisible, setPopoverVisible] = useState(false);

    const handleEmojiClick = (emoji) => {
        setInputValue(prev => prev + emoji.emoji);
        setPopoverVisible(false);
    };

    useEffect(() => {
        const updatedMessages = messagesData && messagesData.length > 0
            ? messagesData.map((m) => ({...m, sent: true}))
            : [];
        setMessages(updatedMessages);
    }, [messagesData]);

    useEffect(() => {
        const evtSource = new EventSource(endpoints.tasksChange);

        evtSource.onmessage = (event) => {
            if (event.data) {
                const parsedData = JSON.parse(event.data);
                updateAppDataField(AppDataFields.taskBoardData, parsedData);

                for (const statusKey in parsedData) {
                    const tasksInStatus = parsedData[statusKey];
                    const task = tasksInStatus.find(task => task.taskId === messagesData.taskId);
                    if (task) {
                        const updatedMessages = task && task[appKeys.comments]
                            ? task[appKeys.comments].map((c) => ({...c, sent: true}))
                            : [];
                        setMessages(updatedMessages);
                    }
                }
            }
        };

        evtSource.addEventListener('end', () => {
            evtSource.close();
        });

        return () => evtSource.close();
    }, [messagesData.taskId, updateAppDataField]);

    useEffect(() => {
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
        }
    }, [messages]);


    const groupMessagesByParent = (comments) => {
        const commentMap = {};
        const threadedMessages = [];

        comments.forEach(comment => {
            comment.children = [];
            commentMap[comment._id] = comment;
        });

        comments.forEach(comment => {
            if (comment.parentId && commentMap[comment.parentId]) {
                commentMap[comment.parentId].children.push(comment);
            } else {
                threadedMessages.push(comment);
            }
        });

        return threadedMessages;
    };

    const groupMessagesByDate = (comments) => {
        const groups = {};

        comments.forEach(comment => {
            const date = new Date(comment.createdAt);
            const now = new Date();

            const todayStr = now.toDateString();
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = yesterday.toDateString();

            let label = '';
            if (date.toDateString() === todayStr) label = 'Today';
            else if (date.toDateString() === yesterdayStr) label = 'Yesterday';
            else label = new Intl.DateTimeFormat('en-GB', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                }).format(date);

            if (!groups[label]) groups[label] = [];
            groups[label].push(comment);
        });

        return groups;
    };

    async function handleSendComment(message, files, parentId = null) {
        if (!message && (!files || files.length <= 0)) {
            return;
        }

        let messageType = 'text';

        if (files && files.length > 0) {
            const hasImage = files.every(file => isImageExtension(file.fileUrl));
            const hasVideo = files.every(file => isVideoExtension(file.fileUrl));
            const hasAudio = files.every(file => isAudioExtension(file.fileUrl));

            if (hasImage) {
                messageType = 'image';
            } else if (hasVideo) {
                messageType = 'video';
            } else if (hasAudio) {
                messageType = 'audio';
            } else {
                messageType = 'file';
            }
        }

        console.log('Message Type:', messageType);

        const newComment = {
            action: apiAction.sendMessage,
            message: message,
            attachments: files,
            messageType: messageType,
            roomId: selectedRoom.roomId,
            sender: currentUserId,
            createdAt: Date.now(),
            sent: false,
            tempId: Date.now(),
            parentId: activeReplyId || parentId,
        };

        setMessages((prev) => [...prev, newComment]);
        setActiveReplyId(null);

        try {
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.chatApi,
                data: newComment,
                setIsLoading: false,
                showSuccessMessage: false,
                successCallback: (data) => {
                    const updatedMessages = data?.data.messages.map((c) => ({
                        ...c,
                        sent: true,
                    }));
                    setMessages(updatedMessages || messagesData);
                },
            });
        } catch (error) {
            setMessages((prev) =>
                prev.map((c) =>
                    c.tempId === newComment.tempId ? {...c, sent: false, failed: true} : c
                )
            );
            console.error('Failed to send comment');
        }
    }

    const getFlattenedMessages = () => {
        const allMessages = messages.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        const threadedMessages = groupMessagesByParent(allMessages);
        const groupedMessages = groupMessagesByDate(threadedMessages);
        const allMessagesData = [];

        Object.entries(groupedMessages).forEach(([dateLabel, msgs]) => {
            msgs.forEach((msg) => {
                allMessagesData.push({
                    ...msg,
                    dateLabel,
                });
            });
        });

        return allMessagesData.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
    };

    const allFlattenedMessages = getFlattenedMessages();

    const groupedVisibleMessages = allFlattenedMessages.reduce((acc, msg) => {
        if (!acc[msg.dateLabel]) acc[msg.dateLabel] = [];
        acc[msg.dateLabel].push(msg);
        return acc;
    }, {});

    const RenderComment = ({message, level = 0, idx, msgs}) => {
        const sender = getDataById(employeeList, message.sender._id || message.sender);
        const displayName = sender?.fullName || "Unknown";
        const profilePhoto = sender?.profilePhoto || "";
        const initials = getTwoCharacterFromName(displayName);
        const isMe = sender._id === currentUserId;
        const isFirstInGroup =
            idx === 0 || msgs[idx - 1].sender._id !== message.sender._id;

        // const images = message.attachments.filter(att => isImageExtension(att.fileUrl));
        // const otherFiles = message.attachments.filter(att => !isImageExtension(att.fileUrl));

        return (
            <div className="commentWrapper" style={{position: 'relative'}}>
                {level > 0 && (
                    <div className="replyThreadLine"/>
                )}
                <div style={{marginLeft: level * 40, position: 'relative', zIndex: 1}}>
                    {!isMe && <div style={{
                        marginLeft: 45,
                        marginBottom: "3px"
                    }}>
                        {isFirstInGroup ? <span className="senderName">{displayName}</span> : null}
                    </div>}
                    <div className={`messageItem ${isMe ? "messageSent" : "messageReceived"}`}>
                        {!isMe && <div>
                            {isFirstInGroup ? <div className="avatar"
                                                   style={{
                                                       backgroundColor: getDarkColor(initials),
                                                   }}
                            >
                                {profilePhoto ? (
                                    <img
                                        src={profilePhoto}
                                        alt={displayName}
                                        style={{
                                            width: '100%',
                                            height: '100%',
                                            objectFit: 'cover',
                                        }}
                                    />
                                ) : (
                                    initials
                                )}
                            </div> : <div style={{
                                width: 30,
                                height: 30,
                            }}></div>}
                        </div>}
                        <div>
                            {Array.isArray(message.attachments) && message.attachments.length > 0 ? (
                                <div style={{display: "flex", flexDirection: "column", gap: "20px"}}>
                                    {message.attachments.every(att => isImageExtension(att.fileType)) ? (
                                        <div className="attachments">
                                            <Image.PreviewGroup>
                                                {message.attachments.map((att, index) => (
                                                    <Image
                                                        title={att.fileName}
                                                        key={index}
                                                        src={att.fileUrl}
                                                        width={230}
                                                        style={{maxHeight: 230}}
                                                    />
                                                ))}
                                            </Image.PreviewGroup>
                                        </div>
                                    ) : (
                                        <div>
                                            {message.attachments.map((att, index) => (
                                                <div key={index} className="attachments" title={att.fileName}>
                                                    {isImageExtension(att.fileUrl) ? (
                                                        <Image
                                                            src={att.fileUrl}
                                                            width={230}
                                                            style={{maxHeight: 230}}
                                                        />
                                                    ) : (
                                                        <>
                                                            <img src={getFileIcon(att.fileUrl)} alt="file" width={45}
                                                                 height={45}/>
                                                            <div style={{flex: 1, gap: 3}}>
                                                                <EllipsisMiddle children={att.fileName}/>
                                                                <div style={{fontSize: '11px', color: '#999'}}>
                                                                    {getFileExtension(att.fileUrl).toUpperCase()} &bull; {new Date(message.createdAt).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                                                                </div>
                                                            </div>
                                                            <MoreHorizontal
                                                                onClick={() => {

                                                                }}
                                                                style={{
                                                                    color: appColor.primary,
                                                                    fontSize: '15px',
                                                                    cursor: 'pointer'
                                                                }}
                                                            />
                                                        </>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            ) : null}
                            {message.message ? <div
                                className="messageContainer messageText"
                                dangerouslySetInnerHTML={{__html: message.message}}
                            /> : null}
                            {/*<div className="messageActions">*/}
                            {/*    <Button*/}
                            {/*        type="text"*/}
                            {/*        size="small"*/}
                            {/*        onClick={() => {*/}
                            {/*            setActiveReplyId(comment._id);*/}
                            {/*            setExpandedMessages((prev) => ({ ...prev, [comment._id]: true }));*/}
                            {/*        }}*/}
                            {/*    >*/}
                            {/*        Reply*/}
                            {/*    </Button>*/}
                            {/*</div>*/}
                        </div>
                        <span className="messageTime">
                            {new Date(message.createdAt).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})}
                                </span>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="messageMainContainer">
            <div className="messageSectionContainer" ref={scrollContainerRef}>
                {messagesLoading ?
                    <div style={{flex: 1, display: "flex", justifyContent: "center", alignItems: "center"}}>
                        <Spin tip="Loading messages..." style={{marginTop: 30}}/>
                    </div> : <div className="chatMessageArea">
                        {messages.length > 0 ? (
                            <Col span={24}>
                                {Object.entries(groupedVisibleMessages).map(([dateLabel, msgs]) => (
                                    <div key={dateLabel} className="messageGroup">
                                        <div className="dateSeparator">
                                            <div className="dateLabelUi">
                                                {dateLabel}
                                            </div>
                                        </div>
                                        {msgs.map((message, idx) => (
                                            <RenderComment key={message._id} message={message} idx={idx} msgs={msgs}/>
                                        ))}
                                    </div>
                                ))}
                            </Col>
                        ) : (
                            <div className="noMessages">No messages yet.</div>
                        )}
                    </div>}
            </div>
            <ChatInput setInputValue={setInputValue} inputValue={inputValue} handleSendComment={handleSendComment}/>
        </div>
    );
};

const ChatInput = ({
                       inputValue,
                       setInputValue,
                       handleSendComment,
                   }) => {
    const [popoverVisible, setPopoverVisible] = useState(false);
    const [isHovered, setIsHovered] = useState(false);
    const [isUploading, setIsUploading] = useState(false);

    const [pendingFiles, setPendingFiles] = useState([]);

    const handleUpload = async (files) => {
        setIsUploading(true);
        try {
            const formData = new FormData();

            files.forEach(file => {
                formData.append("file[]", file);
            });
            formData.append("type", uploadType.chatting);

            const response = await apiCall({
                method: HttpMethod.POST,
                url: endpoints.uploadMultiFiles,
                data: formData,
                setIsLoading: () => {
                },
                isMultipart: true,
                showSuccessMessage: false,
                successCallback: (data) => {
                    setIsUploading(false);
                    handleSendComment(inputValue, data?.data || [])
                    setPendingFiles([]);
                },
            });
        } catch (error) {
            console.log("Error uploading files:", error);
        } finally {
            setIsUploading(false);
        }
    };

    const handleRemove = async (file) => {
        try {
            const bodyData = {filename: file.fileName, type: file.folderType};
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.deleteFile,
                data: bodyData,
                setIsLoading: () => {
                },
                showSuccessMessage: false,
                successCallback: () => {

                },
            });
        } catch (error) {
            console.log("Error deleting file:", error);
        }
    };

    const beforeUpload = (file) => {
        setPendingFiles((prevFiles) => [...prevFiles, file]);
        return false;
    };

    const handleKeyDown = async (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSendComment(inputValue);
            setInputValue(null);
        }
    };

    const handleChange = (e) => {
        const value = e.target.value;
        const lines = value.split("\n");
        if (lines.length <= 5) {
            setInputValue(value);
        }
    };

    const handleEmojiClick = (emoji) => {
        setInputValue((prev) => prev + emoji.emoji);
    };

    const formatBytes = (bytes) => {
        if (bytes === 0) return '0 B';
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
    };

    return (
        <div className="editorContainer">
            {pendingFiles && pendingFiles.length > 0 ? (
                <div className="chatAttachmentContainer">
                    {pendingFiles.map((file) => {
                        const isImage = isImageExtension(file);
                        const fileSrc = typeof file === 'string' ? file : URL.createObjectURL(file);

                        return (
                            <div key={file.uid} className="attachmentItem" title={file.name}>
                                {isImage ? (
                                    <Image
                                        className="attachmentItemImage"
                                        src={fileSrc}
                                        width={45}
                                        height={45}
                                    />
                                ) : (
                                    <img src={getFileIcon(file)} alt="file" width={45} height={45}/>
                                )}
                                <div style={{flex: 1, gap: 3}}>
                                    <EllipsisMiddle children={file.name}/>
                                    <div style={{fontSize: '11px', color: '#999'}}>
                                        {getFileExtension(file).toUpperCase()} &bull; {formatBytes(file.size)}
                                    </div>
                                </div>
                                {isUploading ? <Spin indicator={<LoadingOutlined spin/>}/> : <Tooltip title="Remove">
                                    <DeleteOutlined
                                        onClick={() =>
                                            setPendingFiles(prevFiles =>
                                                prevFiles.filter(prevFile => prevFile.uid !== file.uid)
                                            )
                                        }
                                        style={{
                                            color: appColor.danger,
                                            fontSize: '16px',
                                            cursor: 'pointer'
                                        }}
                                    />
                                </Tooltip>}
                            </div>
                        );
                    })}
                </div>
            ) : null}
            <Input
                rootClassName="editorContainerField"
                value={inputValue}
                onChange={handleChange}
                onKeyDown={handleKeyDown}
                placeholder="Type a message"
                rows={1}
                maxLength={200}
                prefix={
                    <Popover
                        content={
                            <EmojiPicker onEmojiClick={handleEmojiClick} /*customEmojis={[
                                {
                                    names: ['Dog'],
                                    imgUrl:
                                        'https://cdn.jsdelivr.net/gh/ealush/emoji-picker-react@custom_emojis_assets/dog.png',
                                    id: 'dog'
                                }
                            ]}*//>
                        }
                        title="Pick an Emoji"
                        trigger="click"
                        open={popoverVisible}
                        onOpenChange={(newVisible) => setPopoverVisible(newVisible)}
                    >
                        {isHovered ? (
                            <SmileFilled
                                className="fieldIcon"
                                onMouseLeave={() => setIsHovered(false)}
                                style={{marginRight: "8px"}}
                            />
                        ) : (
                            <SmileOutlined
                                className="fieldIcon"
                                onMouseEnter={() => setIsHovered(true)}
                                style={{marginRight: "8px"}}
                            />
                        )}
                    </Popover>
                }
                suffix={
                    <div style={{display: "flex", justifyContent: "center", alignItems: "center"}}>
                        <Upload
                            showUploadList={false}
                            beforeUpload={beforeUpload}
                            pastable
                            multiple
                        >
                            <Tooltip title="Select Files">
                                <PaperClipOutlined className="fieldIcon"/>
                            </Tooltip>
                        </Upload>
                        <div
                            style={{
                                height: "25px",
                                width: "1px",
                                backgroundColor: "#c1c1c1",
                                margin: "0px 15px",
                            }}
                        ></div>
                        <Badge count={pendingFiles.length} size="small" offset={[-7, 7]}>
                            <Tooltip title="Send">
                                <Button
                                    icon={<SendOutlined/>}
                                    disabled={isUploading}
                                    className="fieldIcon"
                                    onClick={async () => {
                                        if (pendingFiles.length > 0) {
                                            await handleUpload(pendingFiles);
                                        } else {
                                            handleSendComment(inputValue, [])
                                        }
                                        setInputValue(null);
                                    }}
                                    type="text"
                                />
                            </Tooltip>
                        </Badge>
                    </div>
                }
            />
        </div>
    );
};

const EllipsisMiddle = ({children}) => {
    const fileNameWithExtension = children.split('/').pop();
    const extensionLength = fileNameWithExtension.split('.').pop().length;
    const start = children.slice(0, children.length - extensionLength);
    const suffix = children.slice(-extensionLength).trim();
    return (
        <Text ellipsis={{suffix}}>
            {start}
        </Text>
    );
};

const RoomItem = ({usersData, data, isRoom = true, selectedRoom, setSelectedRoom}) => {

    let memberId = !isRoom ? data._id : null;
    let displayName = !isRoom ? data.fullName : null;
    let emailAddress = !isRoom ? data.emailAddress : null;
    let displayPhoto = !isRoom ? data.profilePhoto : null;
    let status = !isRoom ? data.status : UserActiveStatus.notAvailable;

    if (isRoom) {
        if (data.isGroup) {
            displayName = data.groupName || "Unnamed Group";
            displayPhoto = data.groupPhoto;
        } else {
            const otherMember = data.members.find(
                (member) => member._id !== currentUserId
            );
            memberId = otherMember?._id || null;
            displayName = otherMember?.fullName || "Unnamed User";
            emailAddress = otherMember?.emailAddress || "Unnamed User";
            displayPhoto = otherMember?.profilePhoto;
            status = getDataById(usersData, otherMember?._id)?.status || UserActiveStatus.notAvailable;
        }
    }

    const lastMessage = data.lastMessage?.message
        ? `${data.lastMessage.message.substring(0, 30)}${data.lastMessage.message.length > 30 ? "..." : ""}`
        : "No messages yet";

    const lastMessageTime = data.lastMessage?.messageTime
        ? dayjs(data.lastMessage.messageTime).format("h:mm A")
        : null;

    const getMessageWithIcon = (messageType) => {
        switch (messageType) {
            case 'image':
                return `📸 Image`;
            case 'video':
                return `🎥 Video`;
            case 'audio':
                return `🎶 Audio`;
            case 'file':
                return `📝 File️`;
            case 'text':
                return messageType;
            default:
                return messageType;
        }
    };

    const statusIconStyle = (color) => ({
        fontSize: 11,
        color: color ?? appColor.statusAvailable,
        position: "absolute",
        top: 29,
        right: 5,
        backgroundColor: "white",
        borderRadius: "50%",
        border: "1px solid white",
    });

    const statusIcon = (status) => {
        if (status === UserActiveStatus.available) {
            return <CheckCircleFilled style={statusIconStyle(appColor.statusAvailable)}/>;
        }
        if (status === UserActiveStatus.notAvailable) {
            return <CloseCircleOutlined style={statusIconStyle(appColor.secondary)}/>;
        }
        return <ClockCircleFilled style={statusIconStyle(appColor.statusAway)}/>;
    };

    return <div
        key={data._id}
        className={`chatListItem ${selectedRoom.roomId === data._id ? "chatListSelectedItem" : ""}`}
        onClick={() => {
            setSelectedRoom({
                fullName: displayName,
                emailAddress: emailAddress,
                profilePhoto: displayPhoto,
                _id: memberId,
                roomId: isRoom ? data._id : null,
            });
        }}
    >
        <Badge count={statusIcon(status)}>
            <Tooltip title={displayName}>
                <Avatar
                    size={35}
                    src={displayPhoto || null}
                    style={{
                        backgroundColor: !displayPhoto ? getDarkColor(displayName) : undefined,
                        color: appColor.white,
                        cursor: "pointer",
                        fontSize: "13px",
                        fontWeight: "550",
                        border: "none",
                    }}
                >
                    {!displayPhoto && getTwoCharacterFromName(displayName)}
                </Avatar>
            </Tooltip>
        </Badge>
        <div style={{marginLeft: "12px", flex: 1}}>
            <div style={{
                fontSize: "12px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                color: "#888",
                fontWeight: 450,
                marginBottom: "3px"
            }}>
                {displayName}
                {isRoom && selectedRoom.roomId !== data._id && data?.messagesData?.unreadMessages && data?.messagesData?.unreadMessages > 0 ? (
                    <Badge size="small" count={data?.messagesData?.unreadMessages}/>
                ) : null}
            </div>
            <div style={{
                fontSize: "12px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                color: "#888",
                fontWeight: 450
            }}>
                {isRoom ? <span>{getMessageWithIcon(lastMessage)}</span> : <span>{status}</span>}
                {lastMessageTime && (
                    <span style={{float: "right", marginLeft: "8px"}}>
            {lastMessageTime}
        </span>
                )}
            </div>
        </div>
    </div>;
};

export default ChatApp;