import React, {useEffect, useState} from "react";
import "./Dashboard.css";
import {Col, DatePicker, Row, Table} from "antd";
import AppText from "../../components/common/AppText";
import appColor from "../../utils/appColors";
import {
    empReportTableColumn,
} from "../../dataTable/employeeTableColumn";
import {ApprovalStatus} from "../../utils/enum";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import {
    getLocalData,
    loginDataKeys,
} from "../../dataStorage/DataPref";
import EmployeeListContent from "./navContents/EmployeeListContent";
import {useAppData} from "../../AppDataContext";
import {
    Clock,
    GitHub,
    Layers,
    Map,
    PenTool,
    Pocket,
    Smile,
    UserMinus,
    UserPlus,
    Users
} from "react-feather";
import {isAdmin, rangePresets} from "../../utils/utils";
import {getDarkColor} from "../../utils/colorMapper";
import {FullScreenLoader} from "../../components/Loader";

const {RangePicker} = DatePicker;

const Dashboard = () => {
    const {dashboardData, usersData, attendancesData} = useAppData();

    const [employeeData, setEmployeesData] = useState();
    const [empReportData, setEmpReportData] = useState(attendancesData);
    const [startDate, setStartDate] = useState();
    const [endDate, setEndDate] = useState();

    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        if (isAdmin()) {
            const filteredEmployees = usersData ? usersData.filter(
                (record) =>
                    record.approvalStatus !== ApprovalStatus.Approved ||
                    !record.isActive
            ) : [];
            setEmployeesData(filteredEmployees);
        }
    }, [usersData]);

    const getEmpReportData = async () => {
        try {
            const baseUrl = `${endpoints.userWiseAttendanceData}${getLocalData(
                loginDataKeys._id
            )}`;
            let queryParams = [];

            if (startDate) {
                queryParams.push(`startDate=${startDate}`);
            }
            if (endDate) {
                queryParams.push(`endDate=${endDate}`);
            }

            const finalUrl =
                queryParams.length > 0
                    ? `${baseUrl}?${queryParams.join("&")}`
                    : baseUrl;

            await apiCall({
                method: HttpMethod.GET,
                url: finalUrl,
                setIsLoading,
                showSuccessMessage: false,
                successCallback: (data) => {
                    setEmpReportData(data?.data);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    };

    // useEffect(() => {
    //     if (!isAdmin()) {
    //         getEmpReportData();
    //     }
    // }, [startDate, endDate]);

    const formatHours = (milliseconds) => {
        const hours = Math.floor(milliseconds / 3600000);
        const minutes = Math.floor((milliseconds % 3600000) / 60000);
        const seconds = Math.floor((milliseconds % 60000) / 1000);
        return `${isNaN(hours) ? 0 : hours}h ${isNaN(minutes) ? 0 : minutes}m`;
    };

    const columns = empReportTableColumn();

    const onRangeChange = (dates, dateStrings) => {
        if (dates) {
            setStartDate(dateStrings[0]);
            setEndDate(dateStrings[1]);
            getEmpReportData();
        }
    };

    const commonGridBox = ({title, value, color, icon}) => {
        return (
            <Col xs={12} sm={12} md={8} lg={4}>
                <div className="dashGridBox">
                    <div className="dashGridBoxIconRow">
                        <div className="dashGridBoxIcon" style={{backgroundColor: color}}>
                            {icon}
                        </div>
                        <div className="dashGridBoxValue" style={{color: color}}>{value}</div>
                    </div>
                    <div className="dashGridBoxTitle">{title}</div>
                </div>
            </Col>
        );
    }

    if (!dashboardData) return <FullScreenLoader/>;

    return (
        <>
            <div>
                {isAdmin() ? <Row gutter={[16, 16]}>
                    {commonGridBox({
                        title: "Total Employees",
                        value: dashboardData?.employeeUsers || 0,
                        color: getDarkColor("A"),
                        icon: <Users className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Total Admins",
                        value: dashboardData?.adminUsers || 0,
                        color: getDarkColor("V"),
                        icon: <Users className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Today Present",
                        value: dashboardData?.todayPresent || 0,
                        color: getDarkColor("C"),
                        icon: <UserPlus className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Today Absent",
                        value: dashboardData?.todayAbsent || 0,
                        color: getDarkColor("D"),
                        icon: <UserMinus className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "No. Of Clients",
                        value: dashboardData?.noOfClients || 0,
                        color: getDarkColor("E"),
                        icon: <Smile className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "No. Of Projects",
                        value: dashboardData?.noOfProjects || 0,
                        color: getDarkColor("F"),
                        icon: <GitHub className="gridBoxIcon"/>
                    })}
                </Row> : <Row gutter={[16, 16]}>
                    {commonGridBox({
                        title: "Today Working Hours",
                        value: formatHours(dashboardData?.todayWorkingHours),
                        color: getDarkColor("A"),
                        icon: <Clock className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Weekly Hours",
                        value: formatHours(dashboardData?.weeklyHours),
                        color: getDarkColor("V"),
                        icon: <PenTool className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Monthly Hours",
                        value: formatHours(dashboardData?.monthlyHours),
                        color: getDarkColor("C"),
                        icon: <Layers className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Monthly Late Arrival",
                        value: formatHours(dashboardData?.monthlyLateArrivalHours),
                        color: getDarkColor("D"),
                        icon: <Pocket className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Monthly Overtime Hours",
                        value: formatHours(dashboardData?.monthlyOvertimeHours),
                        color: getDarkColor("E"),
                        icon: <Smile className="gridBoxIcon"/>
                    })}
                    {commonGridBox({
                        title: "Monthly Absent Count",
                        value: dashboardData?.monthlyAbsentCount,
                        color: getDarkColor("F"),
                        icon: <Map className="gridBoxIcon"/>
                    })}
                </Row>
                }
                <div style={{marginTop: "20px"}}>
                    {isAdmin() && (
                        <EmployeeListContent
                            isInDashboard={true}
                            formTitle="Approval Pending Employees"
                            empData={employeeData}
                        />
                    )}
                    {!isAdmin() ? (
                        <div className="listBox">
                            <Row gutter={[16, 16]} style={{ display: "flex", justifyContent: "space-between", gap: "10px", margin: "15px 0px" }}>
                                <Col xs={24} sm={11} md={8} lg={8}>
                                    <AppText
                                        text="Your Attendance Report"
                                        fontSize={17}
                                        fontWeight={550}
                                        color={appColor.primary}
                                    />
                                </Col>
                                <Col xs={24} sm={10} md={8} lg={7} xl={6} xxl={5}>
                                    <RangePicker
                                        presets={rangePresets}
                                        onChange={onRangeChange}
                                        style={{ height: "40px", width: "100%" }}
                                    />
                                </Col>
                            </Row>
                            <div>
                                <Table
                                    columns={columns}
                                    dataSource={[...empReportData].reverse()}
                                    scroll={{ x: "max-content" }}
                                    loading={isLoading}
                                />
                            </div>
                        </div>
                    ) : null}
                </div>
            </div>
        </>
    );
};

export default Dashboard;
