import React, {useEffect, useRef, useState} from "react";
import {DragDropContext, Droppable, Draggable} from "@hello-pangea/dnd";
import imagePaths from "../../assets/assetsPaths";
import {
    Tag as TagIcon,
    Calendar,
    Check,
    ChevronsUp,
    Filter,
    Plus,
    ShoppingCart,
    User,
    Search,
    XCircle, CheckCircle, Edit, Trash2, Eye, ToggleLeft, ToggleRight
} from "react-feather";
import appColor from "../../utils/appColors";
import {
    Avatar,
    Button, Checkbox, Col,
    DatePicker,
    Divider, Form, Input, Modal,
    Popconfirm,
    Popover, Row,
    Select,
    Spin,
    Switch,
    Table,
    Tag,
    Tooltip
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    ApprovalStatus,
    DateTimeFormat, eventLeaveTypeMenuList, eventTypeMenuList,
    getIconByKey,
    getLabelByKey, leaveCategoryLabel, leaveLabelKeys, leaveTypeLabel,
    projectTypeLabel, reportTypeKey, reportTypeLabels,
    taskColumnStatusLabel,
    taskPriorityLabel, taskStatusLabel,
} from "../../utils/enum";
import {CalendarOutlined, CheckOutlined, UserOutlined} from "@ant-design/icons";
import dayjs from "dayjs";
import {
    deleteLeaveApi,
    deleteProjectApi,
    deleteUserApi,
    getLeaveList,
    getProjectList, getPunchReportList, getSalaryReportList,
    getTasksList,
    getUsersList
} from "../../api/apiUtils";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import {UserRole} from './../../utils/enum';
import {SearchTextField} from "../../components/formField/DynamicForm";
import {convertCamelCase, decryptValue, showToast, useIsMobileView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import LeaveAddUpdateModel from "../../model/LeaveAddUpdateModel";
import {antTag, colorTag} from "../../common/colorTag";

import AppTextFormField, {InputType} from "../../components/common/AppTextFormField";
import SalaryReportAddUpdateModel from "../../model/SalaryReportAddUpdateModel";
import {Navigate, useLocation, useParams} from "react-router-dom";
import {isAdmin} from "../../utils/utils";
import {useAppData} from "../../AppDataContext";
import {FullScreenLoader} from "../../components/Loader";

const {Option} = Select;
const {RangePicker} = DatePicker;

const SalaryReportPage = () => {
    const {activeUsersData} = useAppData();

    const [isShowAmounts, setIsShowAmounts] = useState(false);
    const [isAddSalaryReportModelOpen, setAddSalaryReportModelOpen] = useState(false);
    const [isSalaryReportEditing, setIsSalaryReportEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [salaryReportRecord, setSalaryReportRecord] = useState([]);
    const [publishRecord, setPublishRecord] = useState({
        month: null,
        year: null,
        isPublished: true,
    });
    const [salaryReportFullRecord, setSalaryReportFullRecord] = useState([]);
    const [selectedSalaryReportRecord, setSelectedSalaryReportRecord] = useState({});

    const now = new Date();
    const prevMonth = now.getMonth();
    const defaultMonth = prevMonth === 0 ? 12 : prevMonth;
    const defaultYear = prevMonth === 0 ? now.getFullYear() - 1 : now.getFullYear();

    const defaultMonthDayjs = dayjs(`${defaultYear}-${String(defaultMonth).padStart(2, '0')}`, 'YYYY-MM');
    const defaultYearDayjs = dayjs(defaultYear, 'YYYY');

    let isPublished = false;

    const [filters, setFilters] = useState({
        reportType: reportTypeKey.punchWise,
        user: isAdmin() ? null : getLocalData(loginDataKeys._id),
        year: defaultYear,
        month: defaultMonth,
    });

    const getQueryParams = () => {
        const params = new URLSearchParams();
        if (filters.reportType) params.append('reportType', filters.reportType);
        if (filters.user) params.append('user', filters.user);
        if (filters.year) params.append('year', filters.year);
        if (filters.month) params.append('month', filters.month);
        return params.toString();
    };

    React.useEffect(() => {
        const query = getQueryParams();
        getSalaryReportData(query);
    }, [filters]);

    const getSalaryReportData = (filterQuery) => {
        getSalaryReportList({
            filterQuery: filterQuery,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setPublishRecord({
                    month: data.month,
                    year: data.year,
                    isPublished: isAdmin() ? data.isPublished : true
                })
                handleDataConditionWise(data.data, false);
            },
        });
    };

    const handleDataConditionWise = (data, isSearchField) => {
        const filteredSalaryReport = isAdmin() ? data : data.filter((leave) => leave.user._id === getLocalData(loginDataKeys._id));
        const filterSalaryReportRecord = filteredSalaryReport.filter((leave) => leave.isUnexpected !== true);
        setSalaryReportRecord(filterSalaryReportRecord);
        if (!isSearchField) {
            setSalaryReportFullRecord(filteredSalaryReport);
        }
    };

    const handleSalaryReportAddClick = () => {
        setAddSalaryReportModelOpen(true);
        setSelectedSalaryReportRecord({});
    };

    const handleEditClick = (value) => {
        setIsSalaryReportEditing(true);

        const params = new URLSearchParams(getQueryParams());
        const json = {};
        for (const [key, value] of params.entries()) {
            json[key] = isNaN(value) ? value : Number(value);
        }

        setSelectedSalaryReportRecord({
            ...value,
            query: json,
            leaveData: value.leaveList,
            punchData: value.punchList
        });
        setAddSalaryReportModelOpen(true);
    };

    const leaveTableColumn = [
        {
            title: appString.fullName,
            dataIndex: appKeys.user,
            key: 'user.fullName',
            hidden: !isAdmin(),
            render: (text, record) => record.user ? record.user.fullName : '',
        },
        {
            title: appString.reportTime,
            dataIndex: appKeys.date,
            key: appKeys.date,
            render: (date) => {
                const dateStr = new Date(date);
                const month = dateStr.toLocaleString("en-US", {month: "long"});
                return `${month}-${dateStr.getFullYear()}`;
            },
        },
        {
            title: appString.reportType,
            dataIndex: appKeys.reportType,
            key: appKeys.reportType,
            render: (reportType) => {
                return antTag(
                    getLabelByKey(reportType, reportTypeLabels), "blue"
                );
            },
        },
        {
            title: appString.basicSalary,
            dataIndex: appKeys.basicSalary,
            key: appKeys.basicSalary,
            render: (basicSalary) => {
                console.log("basicSalary", basicSalary)
                return antTag(
                    !isShowAmounts ? "***" : decryptValue(basicSalary) || "0", "purple"
                );
            },
        },
        // {
        //     title: appString.totalMissingMinutes,
        //     dataIndex: appKeys.totalMissingMinutes,
        //     key: appKeys.totalMissingMinutes,
        //     render: (totalMissingMinutes) => {
        //         return totalMissingMinutes ? antTag(
        //             formatMinutes(totalMissingMinutes), "red"
        //         ) : '-';
        //     },
        // },
        {
            title: appString.totalDeductMinutes,
            dataIndex: appKeys.totalDeductMinutes,
            key: appKeys.totalDeductMinutes,
            render: (totalDeductMinutes) => {
                return totalDeductMinutes ? antTag(
                    formatMinutes(totalDeductMinutes), "red"
                ) : '-';
            },
        },
        {
            title: appString.deductionAmount,
            dataIndex: appKeys.deductionAmount,
            key: appKeys.deductionAmount,
            render: (deductionAmount) => {
                return antTag(
                    !isShowAmounts ? "***" : decryptValue(deductionAmount) || "0", "red"
                );
            },
        },
        {
            title: appString.bonus,
            dataIndex: appKeys.bonus,
            key: appKeys.bonus,
            render: (bonus) => {
                return antTag(
                    !isShowAmounts ? "***" : decryptValue(bonus) || "0", "green"
                );
            },
        },
        {
            title: appString.netSalary,
            dataIndex: appKeys.netSalary,
            key: appKeys.netSalary,
            render: (netSalary) => {
                return antTag(
                    !isShowAmounts ? "***" : decryptValue(netSalary) || "0", "blue"
                );
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            render: (_, record) => {
                return (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            {
                                <div
                                    style={{marginRight: 25, cursor: "pointer"}}
                                    onClick={() => handleEditClick(record)}
                                >
                                    <Tooltip title={appString.edit}>
                                        {publishRecord.isPublished ? <Eye className="commonIconStyle"/> :
                                            <Edit className="commonIconStyle"/>}
                                    </Tooltip>
                                </div>
                            }
                        </div>
                    </>
                );
            },
        },
    ];

    function formatMinutes(minutes) {
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        let formatted = '';
        if (hours > 0) {
            formatted += `${hours}h`;
        }
        if (remainingMinutes > 0) {
            formatted += ` ${remainingMinutes}m`;
        }

        if (!formatted && remainingMinutes === 0) {
            formatted = `${remainingMinutes}m`;
        }

        return formatted.trim();  // Remove extra spaces if any
    }

    const handleAddUpdateClientApi = async () => {
        const params = new URLSearchParams(getQueryParams());
        const json = {};
        for (const [key, value] of params.entries()) {
            json[key] = isNaN(value) ? value : Number(value);
        }

        const body = {
            reportType: filters.reportType,
            month: filters.month,
            year: filters.year,
            query: json,
        }

        try {
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.publishSalaryReport,
                data: body,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    setPublishRecord({
                        month: data.month,
                        year: data.year,
                        isPublished: isAdmin() ? data.isPublished : true
                    })
                    handleDataConditionWise(data.data, false);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    if (!activeUsersData) return <FullScreenLoader/>;

    return (
        <>
            <div className="listContainer">

                <div style={{margin: "15px 5px"}}>
                    <Row gutter={[16, 16]}>
                        <Col xs={12} sm={6} md={4} lg={isAdmin() ? 2 : 4}>
                            <Checkbox checked={isShowAmounts} onChange={(e) => setIsShowAmounts(e.target.checked)}>
                                Show Amounts
                            </Checkbox>
                        </Col>
                        {isAdmin() ? <Col xs={24} sm={12} md={8} lg={6}>
                            <SearchTextField
                                field={{
                                    name: "search",
                                    placeholder: "Search Salary Report",
                                    prefix: <Search/>,
                                    style: {margin: 0, width: "100%", height: "38px"},
                                    onChange: (e) => {
                                        const searchText = e.target.value.toLowerCase();
                                        const filteredData = salaryReportFullRecord?.filter((record) => {
                                            return (
                                                record.user?.fullName.toLowerCase().includes(searchText) ||
                                                record.leaveType?.toLowerCase().includes(searchText) ||
                                                record.leaveCategory?.toLowerCase().includes(searchText) ||
                                                record.reason?.toLowerCase().includes(searchText) ||
                                                record.rejectedReason?.toLowerCase().includes(searchText)
                                            );
                                        });
                                        handleDataConditionWise(filteredData, true);
                                    },
                                }}
                            />
                        </Col> : null}
                        {isAdmin() ? <Col xs={24} sm={12} md={8} lg={4}>
                            <Select
                                placeholder="Select User"
                                allowClear
                                style={{width: "100%", height: '40px'}}
                                showSearch
                                onChange={(key) => {
                                    setFilters(prev => ({...prev, user: key}));
                                }}
                                filterOption={(input, option) =>
                                    option?.label?.toLowerCase().includes(input.toLowerCase())
                                }
                            >
                                {activeUsersData.map(employee => (
                                    <Option key={employee._id} value={employee._id}
                                            label={employee.fullName}>
                                        <div
                                            style={{display: "flex", alignItems: "center", gap: "10px"}}
                                        >
                                            <Avatar
                                                src={employee.profilePhoto || imagePaths.profile_placeholder}
                                                size="small"/>
                                            {employee.fullName}
                                        </div>
                                    </Option>))}
                            </Select>
                        </Col> : null}
                        {isAdmin() ? <Col xs={12} sm={6} md={8} lg={2}>
                            <Select
                                size="small"
                                placeholder="Report Type"
                                style={{width: "100%", height: "40px", borderRadius: 10}}
                                defaultValue={filters.reportType}
                                onChange={(value) => {
                                    setFilters(prev => ({...prev, reportType: value}));
                                }}
                            >
                                {reportTypeLabels.map((item) => (
                                    <Option disabled={item.key === reportTypeKey.trackingWise} key={item.key}
                                            value={item.key}>
                                        <div>{item.label}</div>
                                    </Option>
                                ))}
                            </Select>
                        </Col> : null}
                        {isAdmin() ? <Col xs={12} sm={6} md={10} lg={4}>
                            <DatePicker defaultValue={dayjs(`${defaultYear}`, 'YYYY')} allowClear={false} onChange={(date, dateString) => {
                                setFilters(prev => ({...prev, year: date ? date.year() : null}));
                            }} picker="year" style={{width: "100%", height: "40px"}}/>
                        </Col> : null}
                        {isAdmin() ? <Col xs={12} sm={6} md={10} lg={4}>
                            <DatePicker defaultValue={defaultMonthDayjs} allowClear={false} onChange={(date, dateString) => {
                                setFilters(prev => ({...prev, month: date ? date.month() + 1 : null}));
                            }} picker="month" format="MMMM" style={{width: "100%", height: "40px"}}/>
                        </Col> : null}
                        {!publishRecord.isPublished ? <Col xs={12} sm={6} md={4} lg={2}>
                            <Popconfirm
                                title="Report Publish"
                                description="Are you sure to publish selected month salary report?"
                                okText="Yes"
                                cancelText="No"
                                onConfirm={handleAddUpdateClientApi}
                            >
                                <Button type="primary" disabled={isLoading}
                                        style={{width: "100%", height: "40px", borderRadius: 10}}>
                                    Publish
                                </Button>
                            </Popconfirm>
                        </Col> : null}
                    </Row>
                </div>
                <Table
                    rowKey={(record) => record._id}
                    columns={leaveTableColumn}
                    dataSource={[...salaryReportRecord]}
                    scroll={{x: "max-content"}}
                    loading={isLoading}
                />
            </div>
            {isAddSalaryReportModelOpen && (
                <SalaryReportAddUpdateModel
                    isModelOpen={isAddSalaryReportModelOpen}
                    setIsModelOpen={setAddSalaryReportModelOpen}
                    employeeList={activeUsersData}
                    reportData={selectedSalaryReportRecord}
                    isEditing={isSalaryReportEditing}
                    setIsEditing={setIsSalaryReportEditing}
                    onSuccessCallback={(data) => {
                        handleDataConditionWise(data.data, false);
                    }}
                />
            )}
        </>
    );
};

export default SalaryReportPage;