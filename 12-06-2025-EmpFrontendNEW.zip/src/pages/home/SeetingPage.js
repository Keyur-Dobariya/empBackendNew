import React, {useEffect, useState} from "react";
import {
    Button,
    Col,
    Form,
    Input,
    InputNumber,
    Row,
    Select,
    Space,
    Spin,
    Switch,
    Table,
    Tabs,
    TimePicker,
    Tooltip
} from "antd";
import {endpoints} from "../../api/apiEndpoints";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {useLoading} from "../..";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";

import appKeys from "../../utils/appKeys";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {InputType} from "../../components/common/AppTextFormField";
import appString from "../../utils/appString";
import {convertCamelCase} from "../../components/CommonComponents";
import {AppDataFields, useAppData} from "../../AppDataContext";
import {antTag} from "../../common/colorTag";
import {Edit} from "react-feather";
import {useLocation} from "react-router-dom";
const { Option } = Select;
const timeFormat = "HH:mm";

dayjs.extend(customParseFormat);

export default function SettingPage() {
    const location = useLocation();
    const { tabCount } = location.state || {};
    const {settings, updateAppDataField} = useAppData();
    const [settingData, setSettingData] = useState(settings);
    const {setIsLoading} = useLoading();

    const [data, setData] = useState([]);
    const [editingRow, setEditingRow] = useState(null);
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [month, setMonth] = useState(dayjs().format("MM"));
    const [year, setYear] = useState(dayjs().format("YYYY"));

    useEffect(() => {
        setSettingData(settings);
    }, [settings]);

    const getDailyTime = async (month, year, setLoading, successCallback) => {
        return apiCall({
            method: HttpMethod.GET,
            url: `${endpoints.getDailyTime}?month=${month}&year=${year}`,
            setIsLoading: setLoading,
            showSuccessMessage: false,
            successCallback,
        });
    };

    const updateDailyTime = async (id, data, setLoading, successCallback) => {
        return apiCall({
            method: HttpMethod.POST,
            url: `${endpoints.updateTime}/${id}`,
            data,
            setIsLoading: setLoading,
            successCallback,
        });
    };

    const insertYearlyData = async (setLoading, successCallback) => {
        return apiCall({
            method: HttpMethod.POST,
            url: endpoints.insertYearlyData,
            setIsLoading: setLoading,
            successCallback,
        });
    };

    const fetchData = async () => {
        await getDailyTime(month, year, setLoading, (res) => {
            const mappedData = res.data.map((item) => ({
                ...item,
                startTimeMoment: item.startTime ? dayjs(item.startTime, timeFormat) : null,
                endTimeMoment: item.endTime ? dayjs(item.endTime, timeFormat) : null,
            }));
            setData(mappedData);
        });
    };

    useEffect(() => {
        fetchData();
    }, [month, year]);

    const onEdit = (record) => {
        form.setFieldsValue({
            startTimeMoment: record.startTime ? dayjs(record.startTime, timeFormat) : null,
            endTimeMoment: record.endTime ? dayjs(record.endTime, timeFormat) : null,
            breakAllow: record.breakAllow,
        });
        setEditingRow(record._id);
    };

    const onSave = async () => {
        const values = await form.validateFields();
        const payload = {
            startTime: values.startTimeMoment?.format(timeFormat) || null,
            endTime: values.endTimeMoment?.format(timeFormat) || null,
            breakAllow: values.breakAllow,
        };

        await updateDailyTime(editingRow, payload, setLoading, () => {
            setEditingRow(null);
            fetchData();
        });
    };

    const formatTotalHour = (decimalHour) => {
        const hours = Math.floor(decimalHour);
        const minutes = Math.round((decimalHour - hours) * 60);
        return `${hours}h ${minutes}m`;
    };

    const columns = [
        {
            title: "Date",
            dataIndex: "date",
        },
        {
            title: "Start Time",
            dataIndex: "startTime",
            render: (_, record) =>
                editingRow === record._id ? (
                    <Form.Item name="startTimeMoment" noStyle>
                        <TimePicker format={timeFormat} />
                    </Form.Item>
                ) : (
                    record.startTime ? record.startTime : '-'
                ),
        },
        {
            title: "End Time",
            dataIndex: "endTime",
            render: (_, record) =>
                editingRow === record._id ? (
                    <Form.Item name="endTimeMoment" noStyle>
                        <TimePicker format={timeFormat} />
                    </Form.Item>
                ) : (
                    record.endTime ? record.endTime : '-'
                ),
        },
        {
            title: "Break",
            dataIndex: "breakAllow",
            render: (breakAllow, record) =>
                editingRow === record._id ? (
                    <Form.Item name="breakAllow" valuePropName="checked" noStyle>
                        <Switch />
                    </Form.Item>
                ) : antTag(
                    breakAllow ? 'Yes' : 'No',
                    breakAllow ? "green" : "red"
                ),
        },
        {
            title: "Leave",
            dataIndex: "isLeaveOnDay",
            render: (isLeaveOnDay) => {
                return isLeaveOnDay ? antTag(
                    isLeaveOnDay ? 'Yes' : 'No',
                    isLeaveOnDay ? "red" : "green"
                ) : '-';
            },
        },
        {
            title: "Total Hours",
            dataIndex: "totalHour",
            render: (totalHour) => {
                return antTag(
                    formatTotalHour(totalHour),
                    "blue"
                );
            },
        },
        {
            title: "Actions",
            render: (_, record) =>
                editingRow === record._id ? (
                    <span>
            <Button type="link" onClick={onSave}>
              Update
            </Button>
            <Button type="link" onClick={() => setEditingRow(null)}>
              Cancel
            </Button>
          </span>
                ) : (
                    <div
                        style={{marginRight: 25, cursor: "pointer"}}
                        onClick={() => onEdit(record)}
                    >
                        <Tooltip title={appString.edit}>
                            <Edit className="commonIconStyle"/>
                        </Tooltip>
                    </div>
                ),
        },
    ];

    const updateAppSetting = async () => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.updateSetting,
                data: settingData,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    const responseData = data?.data;
                    updateAppDataField(AppDataFields.settings, responseData);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    };

    const handleSettingsFieldsChange = (field, value) => {
        setSettingData((prevData) => ({
            ...prevData,
            appSettings: {
                ...prevData.appSettings,
                [field]: value,
            },
        }));
    };

    const handleMonthlyTotalHoursChange = (field, value) => {
        setSettingData((prevData) => ({
            ...prevData,
            monthlyTotalHours: {
                ...prevData.monthlyTotalHours,
                [field]: value,
            },
        }));
    };

    useEffect(() => {
    }, [settingData]);

    const months = {
        january: "january",
        february: "february",
        march: "march",
        april: "april",
        may: "may",
        june: "june",
        july: "july",
        august: "august",
        september: "september",
        october: "october",
        november: "november",
        december: "december",
    };

    const appSettingTabUi = () => {
        return (
            <div className="settingPage">
                <div style={{display: "flex", justifyContent: "space-between", alignItems: "center"}}>
                    <div style={{fontSize: "16px", fontWeight: "600", color: "black"}}>App Setting</div>
                    <Button type="primary" onClick={updateAppSetting}>Update Settings</Button>
                </div>
                <div className="settingGridBox">
                    <div className="settingPageTitle">Admin Settings</div>
                    <Row gutter={[16, 16]}>
                        <Col xs={24} sm={12} md={8} lg={6}>
                            <div>
                                <div className="seetingLabel">{appString.adminEmail}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode="email"
                                    value={settingData[appKeys.appSettings]?.adminEmail}
                                    placeholder="Email Address"
                                    onInput={(e) => {
                                        handleSettingsFieldsChange(appKeys.adminEmail, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                    </Row>
                </div>
                <div className="settingGridBox">
                    <div className="settingPageTitle">Office Time Settings</div>
                    <Row gutter={[16, 16]}>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{appString.officeStartTime}</div>
                                <TimePicker
                                    className="settingPageField"
                                    use12Hours
                                    value={settingData[appKeys.appSettings]?.officeStartTime ? dayjs(settingData[appKeys.appSettings]?.officeStartTime, "h:mm a") : null}
                                    title="Select Office Start Time"
                                    format="h:mm a"
                                    onChange={(time, timeString) =>
                                        handleSettingsFieldsChange(appKeys.officeStartTime, timeString)
                                    }
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{appString.officeEndTime}</div>
                                <TimePicker
                                    className="settingPageField"
                                    use12Hours
                                    value={settingData[appKeys.appSettings]?.officeEndTime ? dayjs(settingData[appKeys.appSettings]?.officeEndTime, "h:mm a") : null}
                                    title="Select Office End Time"
                                    format="h:mm a"
                                    onChange={(time, timeString) =>
                                        handleSettingsFieldsChange(appKeys.officeEndTime, timeString)
                                    }
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{appString.breakDuration}</div>
                                <Input
                                    className="settingPageField"
                                    maxLength={3}
                                    inputMode="numeric"
                                    value={settingData[appKeys.appSettings]?.breakDuration}
                                    placeholder="Break Duration"
                                    onInput={(e) => {
                                        let value = e.target.value.replace(/[^\d]/g, "");
                                        e.target.value = value;
                                        handleSettingsFieldsChange(appKeys.breakDuration, value);
                                    }}
                                />
                            </div>
                        </Col>
                    </Row>
                </div>
                <div className="settingGridBox">
                    <div className="settingPageTitle">Screenshot Settings</div>
                    <Row gutter={[16, 16]}>
                        <Col xs={24} sm={12} md={8} lg={6}>
                            <div>
                                <div className="seetingLabel">{appString.screenshotTime}</div>
                                <Input
                                    className="settingPageField"
                                    maxLength={3}
                                    inputMode="numeric"
                                    placeholder="Screenshot Capture Time"
                                    value={settingData[appKeys.appSettings]?.screenshotTime}
                                    onInput={(e) => {
                                        let value = e.target.value.replace(/[^\d]/g, "");
                                        e.target.value = value;
                                        handleSettingsFieldsChange(appKeys.screenshotTime, value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={24} sm={12} md={8} lg={6}>
                            <div>
                                <div className="seetingLabel">{appString.isTakeScreenShot}</div>
                                <Switch
                                    loading={false}
                                    checked={settingData[appKeys.appSettings]?.isTakeScreenShot}
                                    onChange={(checked) => {
                                        handleSettingsFieldsChange(appKeys.isTakeScreenShot, checked);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={24} sm={12} md={8} lg={6}>
                            <div>
                                <div className="seetingLabel">{appString.showScreenShot}</div>
                                <Switch
                                    loading={false}
                                    checked={settingData[appKeys.appSettings]?.showScreenShot}
                                    onChange={(checked) => {
                                        handleSettingsFieldsChange(appKeys.showScreenShot, checked);
                                    }}
                                />
                            </div>
                        </Col>
                    </Row>
                </div>
                <div className="settingGridBox">
                    <div className="settingPageTitle">Leave Settings</div>
                    <Row gutter={[16, 16]}>
                        <Col xs={24} sm={12} md={8} lg={6}>
                            <div>
                                <div className="seetingLabel">{appString.yearlyPaidLeave}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode="email"
                                    value={settingData[appKeys.appSettings]?.yearlyPaidLeave}
                                    placeholder="Yearly Paid Leave"
                                    onInput={(e) => {
                                        handleSettingsFieldsChange(appKeys.yearlyPaidLeave, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={24} sm={12} md={8} lg={6}>
                            <div>
                                <div className="seetingLabel">{appString.monthlyMaxPaidLeave}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode="email"
                                    value={settingData[appKeys.appSettings]?.monthlyMaxPaidLeave}
                                    placeholder="Monthly Paid Leave"
                                    onInput={(e) => {
                                        handleSettingsFieldsChange(appKeys.monthlyMaxPaidLeave, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                    </Row>
                </div>
                <div className="settingGridBox">
                    <div className="settingPageTitle">Monthly Total Hours</div>
                    <Row gutter={[16, 16]}>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.january)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode="numeric"
                                    value={settingData[appKeys.monthlyTotalHours]?.january || ''}
                                    placeholder={`${convertCamelCase(months.january)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.january, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.february)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.february}
                                    placeholder={`${convertCamelCase(months.february)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.february, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.march)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.march}
                                    placeholder={`${convertCamelCase(months.march)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.march, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.april)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.april}
                                    placeholder={`${convertCamelCase(months.april)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.april, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.may)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.may}
                                    placeholder={`${convertCamelCase(months.may)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.may, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.june)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.june}
                                    placeholder={`${convertCamelCase(months.june)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.june, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.july)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.july}
                                    placeholder={`${convertCamelCase(months.july)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.july, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.august)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.august}
                                    placeholder={`${convertCamelCase(months.august)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.august, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.september)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.september}
                                    placeholder={`${convertCamelCase(months.september)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.september, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.october)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.october}
                                    placeholder={`${convertCamelCase(months.october)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.october, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.november)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.november}
                                    placeholder={`${convertCamelCase(months.november)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.november, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                        <Col xs={12} sm={8} md={6} lg={4}>
                            <div>
                                <div className="seetingLabel">{convertCamelCase(months.december)}</div>
                                <Input
                                    className="settingPageField"
                                    inputMode={InputType.Number}
                                    value={settingData[appKeys.monthlyTotalHours]?.december}
                                    placeholder={`${convertCamelCase(months.december)} Hours`}
                                    onInput={(e) => {
                                        handleMonthlyTotalHoursChange(months.december, e.target.value);
                                    }}
                                />
                            </div>
                        </Col>
                    </Row>
                </div>
            </div>
        );
    }

    const dailyTimeTabUi = () => {
        return (
            <Spin spinning={loading}>
                <div style={{ marginBottom: 16, display: "flex", justifyContent: "end" }}>
                    <Select value={month} onChange={setMonth} style={{ width: 100, marginRight: 8 }}>
                        {Array.from({ length: 12 }, (_, i) => {
                            const val = String(i + 1).padStart(2, "0");
                            return <Option key={val} value={val}>{val}</Option>;
                        })}
                    </Select>

                    <Select value={year} onChange={setYear} style={{ width: 100, marginRight: 8 }}>
                        {[2024, 2025, 2026].map((y) => (
                            <Option key={y} value={String(y)}>{y}</Option>
                        ))}
                    </Select>

                    <Button onClick={() => insertYearlyData(setLoading, fetchData)} type="primary">
                        Insert Yearly Data
                    </Button>
                </div>

                <Form form={form} component={false}>
                    <Table
                        dataSource={data}
                        columns={columns}
                        rowKey="_id"
                        pagination={{ pageSize: 31 }}
                        scroll={{ x: "100%" }}
                    />
                </Form>
            </Spin>
        );
    }

    const tabItems = [
        {
            key: '1',
            label: 'App Setting',
            children: appSettingTabUi(),
        },
        {
            key: '2',
            label: 'Daily Time',
            children: dailyTimeTabUi(),
        },
    ];

    return (
        <>
            <div className="appSettingPage">
                <Tabs defaultActiveKey={tabCount || 0} items={tabItems} onChange={key => {
                    // console.log(key);
                }}/>
            </div>
        </>
    );
}
