import React, { useEffect, useRef, useState } from "react";
import "./Dashboard.css";
import { Button, Progress, Tooltip } from "antd";
import Column from "./../../components/common/Column";
import Row from "./../../components/common/Row";
import AppText from "../../components/common/AppText";
import appColor from "../../utils/appColors";
import Image from "../../components/common/Image";
import imagePaths from "../../assets/assetsPaths";
import SpaceBox from "../../components/common/SpaceBox";
import Container from "../../components/common/Container";
import { getLocalData, loginDataKeys } from "../../dataStorage/DataPref";
import { endpoints, environment } from "../../api/apiEndpoints";
import apiCall, { HttpMethod } from "../../api/apiServiceProvider";
import { useLoading } from "../..";
import { format } from "date-fns";
import appString from "../../utils/appString";
// import io from "socket.io-client";

const TrackingComponent = ({ isElectron, trackingData }) => {
  const { setIsLoading } = useLoading();
  const OFFICE_TIME = 9 * 3600000;
  const progressBarSize = isElectron ? 130 : 110;
  const now = Date.now();
  const currentDateFormat = "hh:mm a - MMM dd, yyyy";
  const [attendanceData, setAttendanceData] = useState({});
  const [currentDateTime, setCurrentDateTime] = useState(0);
  const [breakTimer, setBreakTimer] = useState(0);
  const [totalTimer, setTotalTimer] = useState(0);
  const [formattedBreakTime, setFormattedBreakTime] = useState("0h 0m 0s");
  const [formattedTotalTime, setFormattedTotalTime] = useState("0h 0m 0s");
  const [punchInAtTime, setPunchInAtTime] = useState("None");

  // http://35.160.120.126:5202
  // const socket = io(environment.socketUrl);
  //
  // useEffect(() => {
  //   socket.on("connect", () => {
  //   });
  //
  //   socket.on("attendanceData", (data) => {
  //     if (getLocalData(loginDataKeys._id) === data.userId) {
  //       setAttendanceData(data);
  //       trackingData(data);
  //     }
  //   });
  //
  //   socket.on("disconnect", () => {
  //   });
  //
  //   return () => {
  //     socket.disconnect();
  //   };
  // }, []);

  useEffect(() => {
    getTodayAttendanceApi();
  }, []);

  useEffect(() => {
    let timer;
    timer = setInterval(() => {
      setCurrentDateTime(format(Date.now(), currentDateFormat));
      if (attendanceData.isPunchIn) {
        setTotalTimer(totalCalculation(attendanceData));
      }
      if (attendanceData.isBreakIn) {
        setBreakTimer(breakCalculation(attendanceData));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [attendanceData]);

  useEffect(() => {
    setFormattedBreakTime(formatTime(breakTimer));
    setFormattedTotalTime(formatTime(totalTimer));
    if (attendanceData.punchInAt) {
      setPunchInAtTime(format(Number(attendanceData.punchInAt), "hh:mm a"));
    }
  }, [attendanceData, totalTimer, breakTimer]);

  const getTodayAttendanceApi = async () => {
    try {
      await apiCall({
        method: HttpMethod.GET,
        url: `${endpoints.getTodayAttendance}/${getLocalData(
          loginDataKeys._id
        )}`,
        showSuccessMessage: false,
        setIsLoading: setIsLoading,
        successCallback: (data) => {
          const responseData = data["data"];

          trackingData(responseData);

          setAttendanceData(responseData);

          const userData = {
            userId: getLocalData(loginDataKeys._id),
            jwtToken: getLocalData(loginDataKeys.jwtToken),
          };
    
          // socket.emit("userData", userData);
          // socket.emit("attendanceData", responseData);

          setBreakTimer(responseData.breakHours);
          setTotalTimer(responseData.totalHours);

          if (responseData.punchInAt) {
            setPunchInAtTime(format(Number(responseData.punchInAt), "hh:mm a"));
          }
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  };

  const breakCalculation = (data) => {
    return Date.now() - data.lastBreakInTime + Number(data.breakHours);
  };

  const totalCalculation = (data) => {
    return Date.now() - data.lastPunchInTime + Number(data.totalHours);
  };

  const callAttendanceApi = async ({ data }) => {
    try {
      const userId = getLocalData(loginDataKeys._id);

      const requestData = {
        userId: userId,
        ...data,
      };

      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.addAttendance,
        data: requestData,
        showSuccessMessage: false,
        setIsLoading: setIsLoading,
        successCallback: async (data) => {
          const responseData = data["data"];
          setAttendanceData(responseData);
          trackingData(responseData);
          // socket.emit("attendanceData", responseData);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  };

  const handlePunchInOut = async () => {
    let postData;
    if (attendanceData.isPunchIn) {
      postData = {
        punchOutTime: Date.now(),
      };
    } else {
      postData = {
        punchInTime: Date.now(),
      };
    }
    callAttendanceApi({ data: postData });
  };

  const handleBreakInOut = async () => {
    let postData;
    if (attendanceData.isBreakIn) {
      postData = {
        breakOutTime: Date.now(),
      };
    } else {
      postData = {
        breakInTime: Date.now(),
      };
    }
    callAttendanceApi({ data: postData });
  };

  const getPercentage = (time) => {
    return ((time / OFFICE_TIME) * 100).toFixed(2);
  };

  const formatTime = (milliseconds) => {
    const hours = Math.floor(milliseconds / 3600000);
    const minutes = Math.floor((milliseconds % 3600000) / 60000);
    const seconds = Math.floor((milliseconds % 60000) / 1000);
    return `${hours}h ${minutes}m ${seconds}s`;
  };

  return (
    <>
      <Container padding="0px" height={isElectron ? "80vh" : "100%"}>
        <Container
          width="100%"
          height="100%"
          padding="15px 20px"
          borderColor={appColor.primary}
          borderWidth={attendanceData.isPunchIn ? 1 : 0}
          backgroundColor={
            attendanceData.isPunchIn ? `${appColor.primary}10` : appColor.white
          }
        >
          <Column
            justifyContent="center"
            alignItems="center"
            style={{
              justifyContent: "space-between",
              height: "100%",
            }}
          >
            <Container width="100%">
              <Column>
                <AppText
                  text={appString.attendance}
                  fontSize="12px"
                  fontWeight="450"
                  textAlign="center"
                  color={appColor.secondary}
                />
                <AppText
                  text={currentDateTime}
                  fontSize="14px"
                  fontWeight="550"
                  textAlign="center"
                  color={appColor.black}
                />
                <SpaceBox space={2} />
                <div
                  style={{
                    display: "none",
                    justifyContent: "space-between",
                  }}
                >
                  <Row alignItems="center">
                    <Image
                      path={imagePaths.fingerprintIcon}
                      iconColor={appColor.primary}
                      width="12px"
                      height="12px"
                      backgroundColor={appColor.transparant}
                      isTransparentBg={true}
                      borderRadius={0}
                      padding={0}
                    />
                    <SpaceBox space={2} />
                    <AppText
                      text={`${punchInAtTime}`}
                      fontSize="13px"
                      fontWeight="550"
                      color={appColor.primary}
                    />
                  </Row>
                  <Row alignItems="center">
                    <Image
                      path={imagePaths.breakIcon}
                      iconColor={appColor.danger}
                      width="14px"
                      height="14px"
                      isTransparentBg={true}
                      backgroundColor={appColor.transparant}
                      borderRadius={0}
                      padding={0}
                    />
                    <SpaceBox space={2} />
                    <AppText
                      text={formattedBreakTime}
                      fontSize="13px"
                      fontWeight="550"
                      color={appColor.danger}
                    />
                  </Row>
                </div>
              </Column>
            </Container>
            <SpaceBox space={2} />
            <Container
              width={progressBarSize}
              height={progressBarSize}
              backgroundColor={appColor.white}
              borderRadius={100}
            >
              <Progress
                percent={getPercentage(
                  attendanceData.punchInAt
                    ? Date.now() - attendanceData.punchInAt
                    : 0
                )}
                type="circle"
                size={progressBarSize}
                strokeWidth={8}
                strokeColor={
                  attendanceData.isBreakIn ? appColor.danger : appColor.primary
                }
                format={(percent) => (
                  <Column alignItems="center">
                    <AppText
                      text={appString.totalHours}
                      fontSize={11}
                      fontWeight="400"
                      color={appColor.secondary}
                    />
                    <AppText
                      text={formattedTotalTime}
                      fontSize={13}
                      fontWeight="550"
                      color={appColor.black}
                    />
                  </Column>
                )}
              />
            </Container>
            <SpaceBox space={3} />
            <Container width={"100%"}>
              <Column alignItems="center">
                <Row alignItems="center">
                  <Image
                    path={imagePaths.fingerprintIcon}
                    iconColor={appColor.primary}
                    width="12px"
                    height="12px"
                    backgroundColor={appColor.transparant}
                    isTransparentBg={true}
                    borderRadius={0}
                    padding={0}
                  />
                  <SpaceBox space={2} />
                  <AppText
                    text={`Punch In At: ${punchInAtTime}`}
                    fontSize="13px"
                    fontWeight="550"
                    color={appColor.primary}
                  />
                </Row>
                <SpaceBox space={1} />
                <Row alignItems="center">
                  <Image
                    path={imagePaths.breakIcon}
                    iconColor={appColor.danger}
                    width="14px"
                    height="14px"
                    isTransparentBg={true}
                    backgroundColor={appColor.transparant}
                    borderRadius={0}
                    padding={0}
                  />
                  <SpaceBox space={2} />
                  <AppText
                    text={`Break Hours: ${formattedBreakTime}`}
                    fontSize="13px"
                    fontWeight="550"
                    color={appColor.danger}
                  />
                </Row>
                <SpaceBox space={4} />
                <Container width="100%">
                  <Row alignItems="center" justifyContent="space-evenly">
                    <Button
                      type="primary"
                      style={{
                        width: "100%",
                        height: "37px",
                        margin: "0",
                        fontWeight: "550",
                      }}
                      onClick={handlePunchInOut}
                    >
                      {attendanceData.isPunchIn ? "Punch Out" : "Punch In"}
                    </Button>
                    <SpaceBox space={3} />
                    <Button
                      type="primary"
                      style={{
                        width: "100%",
                        height: "37px",
                        margin: "0",
                        color: appColor.white,
                        fontWeight: "550",
                      }}
                      onClick={handleBreakInOut}
                    >
                      {attendanceData.isBreakIn ? "Break Out" : "Break In"}
                    </Button>
                  </Row>
                </Container>
              </Column>
            </Container>
          </Column>
        </Container>
      </Container>
    </>
  );
};

export default TrackingComponent;
