import React, { useState, useEffect } from "react";
import axios from "axios";
import {endpoints} from "../../api/apiEndpoints";

const languages = [
    { code: "en", name: "English" },
    { code: "gu", name: "Gujarati" },
    { code: "hi", name: "Hindi" },
    { code: "fr", name: "French" },
    // add more as needed
];

const TranslateDemo = () => {
    const [from, setFrom] = useState("en");
    const [to, setTo] = useState("gu");
    const [text, setText] = useState("");
    const [result, setResult] = useState("");

    const translateText = async () => {
        try {
            const response = await axios.post(endpoints.translate, {
                text,
                from,
                to,
            });
            setResult(response.data.translatedText);
        } catch (err) {
            setResult("Translation failed");
        }
    };

    return (
        <div>
            <h2>Free Translator</h2>
            <select value={from} onChange={(e) => setFrom(e.target.value)}>
                {languages.map((l) => (
                    <option key={l.code} value={l.code}>
                        {l.name}
                    </option>
                ))}
            </select>
            <span> → </span>
            <select value={to} onChange={(e) => setTo(e.target.value)}>
                {languages.map((l) => (
                    <option key={l.code} value={l.code}>
                        {l.name}
                    </option>
                ))}
            </select>
            <br />
            <textarea
                rows={4}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter text"
            />
            <br />
            <button onClick={translateText}>Translate</button>
            <p><strong>Translated:</strong> {result}</p>
        </div>
    );
};

export default TranslateDemo;
