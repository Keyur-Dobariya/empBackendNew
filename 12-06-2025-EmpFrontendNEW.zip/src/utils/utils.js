import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {UserRole} from "./enum";
import dayjs from "dayjs";
import extIcons from "../assets/fileExtIcons/extIcons";

export const isAdmin = () => {
    return getLocalData(loginDataKeys.role) === UserRole.Admin;
};

export const getDataById = (dataList, dataId) => {
    return dataList.find((data) => data._id === dataId);
};

export const rangePresets = [
    {
        label: 'Last 7 Days',
        value: [dayjs().add(-7, 'd'), dayjs()],
    },
    {
        label: 'Last 14 Days',
        value: [dayjs().add(-14, 'd'), dayjs()],
    },
    {
        label: 'Last 30 Days',
        value: [dayjs().add(-30, 'd'), dayjs()],
    },
    {
        label: 'Last 90 Days',
        value: [dayjs().add(-90, 'd'), dayjs()],
    },
];

export const formatMessageTimeReal = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();

    const diffMs = now - date;

    const diffMinutes = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMinutes < 1) return 'Just now';

    if (diffMinutes < 60) {
        return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`;
    }

    if (diffHours < 24) {
        return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    }

    const time = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return `${date.toLocaleDateString('en-GB')} ${time}`;
};

export const formatMessageTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();

    const diffMs = now - date;
    const diffMinutes = Math.floor(diffMs / 60000);

    if (diffMinutes === 0) return 'Just now';

    const isToday = date.toDateString() === now.toDateString();

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const isYesterday = date.toDateString() === yesterday.toDateString();

    const time = date.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});

    if (isToday) return time;
    if (isYesterday) return `Yesterday ${time}`;

    return `${date.toLocaleDateString('en-GB')} ${time}`;
};

export const getFileExtension = (input) => {
    let filename = '';

    if (typeof input === 'string') {
        filename = input.split('?')[0].split('#')[0]; // Clean URL
    } else if (input instanceof File) {
        filename = input.name;
    } else {
        return '';
    }

    return filename.includes('.') ? filename.split('.').pop().toLowerCase() : '';
};

export const getFileIcon = (input) => {
    const extension = getFileExtension(input);
    return extIcons[extension] || extIcons.file;
};

export const isImageExtension = (input) => {
    const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tif', 'tiff', 'svg'];
    const extension = getFileExtension(input);
    return imageExtensions.includes(extension);
};

export const isVideoExtension = (input) => {
    const videoExtensions = ['mp4', 'avi', 'mkv', 'mov', 'flv', 'wmv', 'webm'];
    const extension = getFileExtension(input);
    return videoExtensions.includes(extension);
};

export const isAudioExtension = (input) => {
    const audioExtensions = ['mp3', 'wav', 'ogg', 'aac', 'flac', 'm4a', 'wma'];
    const extension = getFileExtension(input);
    return audioExtensions.includes(extension);
};