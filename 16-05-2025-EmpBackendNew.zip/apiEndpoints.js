const apiBaseUrl = "https://tracker.teqheal.com/";

const environment = {
  apiBaseUrl: apiBaseUrl,
};

module.exports = environment;