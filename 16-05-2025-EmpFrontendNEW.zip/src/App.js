import React, {useEffect, useState} from "react";
import "./AntdStyle.css";
import "./App.css";

import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import SignUp from "./pages/auth/SignUp";
import Login from "./pages/auth/Login";
import SendEmailOtp from "./pages/auth/SendEmailOtp";
import VerifyEmailOtp from "./pages/auth/VerifyEmailOtp";
import ForgotPassword from "./pages/auth/ForgotPassword";
import HomeContent from "./pages/home/navContents/HomeContent";
import NoPage from './pages/NoPage';
import appColor from "./utils/appColors";
import { getLocalData, loginDataKeys } from "./dataStorage/DataPref";
import ElectronDashboard from "./pages/home/ElectronDashboard";
import ViewFullEmployeeDetails from "./pages/home/navContents/ViewFullEmployeeDetails";
import TaskBoard from "./pages/home/TaskBoard";
import NewDashboard from "./pages/home/NewDashboard";
import Dashboard from "./pages/home/Dashboard";
import EmployeeListContent from "./pages/home/navContents/EmployeeListContent";
import MyProfilePage from "./pages/home/MyProfilePage";
import SeetingPage from "./pages/home/SeetingPage";
import routes from "./common/routes";
import TodayReport from "./pages/home/TodayReport";
import HolidayPage from "./pages/home/HolidayPage";
import ProjectPage from "./pages/home/ProjectPage";
import LeavePage from "./pages/home/LeavePage";
import ClientPage from "./pages/home/ClientPage";
import BasicSalaryPage from "./pages/home/BasicSalaryPage";
import SalaryReportPage from "./pages/home/SalaryReportPage";
import PunchReportPage from "./pages/home/PunchReportPage";
import {UserRole} from "./utils/enum";
import OneSignal from "react-onesignal";
import ProtectedSalaryPage from "./pages/home/ProtectedSalaryReportPage";
import NavigationInitializer from "./NavigationInitializer";
import DrawerPage from "./pages/home/DrawerPage";
import apiCall, {HttpMethod} from "./api/apiServiceProvider";
import {endpoints} from "./api/apiEndpoints";
import {useAppData} from "./AppDataContext";
import {FullScreenLoader} from "./components/Loader";

// npm install javascript-obfuscator -g

const isAuthenticated = () => {
  return getLocalData(loginDataKeys.isLogin) === "true";
};

const isElectron = () => {
  return getLocalData(loginDataKeys.isElectron) === "true";
};

const ProtectedRoute = ({ element }) => {
  return isAuthenticated() ? element : <Navigate to="/login" replace />;
};

const AdminRoute = ({ element }) => {
  return getLocalData(loginDataKeys.role) === UserRole.Admin ? element : <Navigate to={routes.dashboard} replace />;
};

const ElectronRoute = () => {
  return isElectron() ? <ElectronDashboard /> : <HomeContent />;
};

const setCSSVariables = (colors) => {
  const root = document.documentElement;

  Object.keys(colors).forEach((key) => {
    root.style.setProperty(`--${key}`, colors[key]);
  });
};


function App() {
  useEffect(() => {
    setCSSVariables(appColor);
  }, []);

  useEffect(() => {
    OneSignal.init({
      appId: "5228ee13-2fd7-49db-a028-2c22188522c8",
      notifyButton: {
        enable: true,
      },
      allowLocalhostAsSecureOrigin: true,
    });
  }, []);

  const appDataContext = useAppData();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchMasterData = async () => {
      try {
        const response = await apiCall({
          method: HttpMethod.GET,
          url: endpoints.getMasterData,
          setIsLoading: setIsLoading,
          showSuccessMessage: false,
        });

        if (response?.data) {
          appDataContext.setAllMasterData(response.data);
        }
      } catch (error) {
        console.error("Failed to fetch master data:", error);
      }
    };

    fetchMasterData();
  }, []);

  if (isLoading) return <FullScreenLoader />;

  return (
      <>
        <BrowserRouter>
          <NavigationInitializer />
          <Routes>
            <Route path="/signup" element={<SignUp />} />
            <Route path="/login" element={<Login />} />
            <Route path="/sendEmailOtp" element={<SendEmailOtp />} />
            <Route path="/verifyEmailOtp" element={<VerifyEmailOtp />} />
            <Route path="/forgotPassword" element={<ForgotPassword />} />
            <Route path="/dd" element={<DrawerPage />} />

            <Route path={routes.dashboard} element={<ProtectedRoute element={<HomeContent />} />}>
              <Route index element={<Dashboard />} />
              <Route path={routes.employees.replace("/", "")} element={<AdminRoute element={<EmployeeListContent />} />} />
              <Route path={routes.myProfile.replace("/", "")} element={<MyProfilePage />} />
              <Route path={routes.settings.replace("/", "")} element={<AdminRoute element={<SeetingPage />} />} />
              <Route path={routes.tasks.replace("/", "")} element={<TaskBoard />} />
              <Route path={routes.todayReport.replace("/", "")} element={<AdminRoute element={<TodayReport />} />} />
              <Route path={routes.calendar.replace("/", "")} element={<HolidayPage />} />
              <Route path={routes.project.replace("/", "")} element={<ProjectPage />} />
              <Route path={routes.leave.replace("/", "")} element={<LeavePage isReportPage={false} />} />
              <Route path={routes.basicSalary.replace("/", "")} element={<AdminRoute element={<BasicSalaryPage />} />} />
              <Route path={routes.client.replace("/", "")} element={<ClientPage />} />
              <Route path={routes.leaveReport.replace("/", "")} element={<LeavePage isReportPage={true} />} />
              <Route path={routes.punchReport.replace("/", "")} element={<PunchReportPage />} />
              <Route path={routes.salaryReport.replace("/", "")} element={<AdminRoute element={<SalaryReportPage />} />} />
              <Route path={routes.salaryReport.replace("/", "") + "/:verificationKey"} element={<ProtectedSalaryPage />} />
            </Route>

            {/* <Route path="users/:id" element={<UserDetails />} /> */}
            {/* <Route path="/dashboard" element={<ProtectedRoute element={<HomeContent />} />} /> */}
            <Route path="/electronDashboard" element={<ElectronDashboard />} />
            {/* <Route path="/empDetails" element={<ProtectedRoute element={<ViewFullEmployeeDetails />} />} /> */}
            <Route path={routes.employeeDetails} element={<AdminRoute element={<ViewFullEmployeeDetails />} />} />
            <Route path="/newDash" element={<NewDashboard />} />
            <Route path="*" element={<NoPage />} />
          </Routes>
        </BrowserRouter>
      </>
  );
}

export default App;
