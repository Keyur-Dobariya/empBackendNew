import {Tag} from "antd";
import {formatMilliseconds} from "./DateFormat";

const colorTag = (value, color) => {
    return (
        <Tag color={color} style={{fontWeight: "bold", width: "70px", textAlign: "center"}}>
            {value ? formatMilliseconds(value) : "00:00:00"}
        </Tag>
    );
}

const antTag = (value, color) => {
    return (
        <Tag color={color} style={{fontWeight: "550", textAlign: "center"}}>
            {value ? value : "-"}
        </Tag>
    );
}

export {colorTag, antTag};
