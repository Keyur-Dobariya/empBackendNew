import React from "react";
import {DatePicker, Form, Input, Select, Switch} from "antd";
import dayjs from "dayjs";
import {DateTimeFormat} from "../../utils/enum";

const AppTextFormField = ({
                              key,
                              name,
                              rules,
                              label,
                              width,
                              hasFeedback,
                              layout,
                              type,
                              minRows,
                              minLength,
                              maxLength,
                              inputMode,
                              isRequired,
                              prefix,
                              suffix,
                              iconSize,
                              placeholder,
                              value,
                              defaultValue,
                              onChange,
                              disabled,
                              style,
                              className,
                              selectOptions,
                              onApprovalStatusSelect,
                              switchChecked,
                              onSwitchChange,
                              onDateSelect,
                              dateFormat,
                              onInput,
                              selectMode,
                              disabledDate,
                              defaultPickerValue,
                              showSearch,
                          }) => {
    const defaultHeight = 40;
    const defaultBorderRadius = "10px";

    const handleInput = (e) => {
        const input = e.target;
        if (maxLength && input.value.length > maxLength) {
            input.value = input.value.slice(0, maxLength);
        }
        if (onInput) {
            onInput(e);
        }
    };

    return (
        <Form.Item
            key={key || name}
            name={name || label}
            rules={[...(rules || []), {required: isRequired || false, message: `${label} is required`}]}
            hasFeedback={hasFeedback || true}
            label={label}
            style={{width: width || "100%"}}
            layout={layout || "vertical"}
        >
            {(() => {
                const textFieldProps = {
                    prefix: prefix ? React.cloneElement(prefix, {
                        style: {paddingInlineEnd: 5},
                        size: iconSize || 21,
                    }) : null,
                    minLength: minLength,
                    maxLength: maxLength,
                    inputMode: inputMode,
                    suffix: suffix,
                    disabled: disabled,
                    placeholder: placeholder,
                    type: type || InputType.Text,
                    style: {
                        ...style,
                        borderRadius: defaultBorderRadius,
                        height: type !== InputType.TextArea ? defaultHeight : null,
                    },
                    className: className,
                    value: value,
                    onChange: onChange,
                    onInput: handleInput,
                };

                if (type === InputType.Select) {
                    return (
                        <Select
                            showSearch={showSearch}
                            mode={selectMode || SelectMode.Single}
                            placeholder={placeholder || `Select ${label}`}
                            onChange={onApprovalStatusSelect}
                            value={value}
                            disabled={disabled}
                            allowClear
                            maxTagCount={"responsive"}
                            defaultValue={defaultValue}
                            style={{height: defaultHeight}}
                        >
                            {selectOptions?.map((option) => (
                                <Select.Option key={option.value} value={option.label}>
                                    {option.label}
                                </Select.Option>
                            ))}
                        </Select>
                    );
                }

                if (type === InputType.Switch) {
                    return (
                        <Switch
                            loading={false}
                            checked={switchChecked || false}
                            onChange={onSwitchChange}
                            style={{margin: "9px 0px"}}
                        />
                    );
                }

                if (type === InputType?.DatePicker) {
                    const formattedValue = value ? dayjs(value, DateTimeFormat.DDMMYYYY) : null;
                    const formattedDefaultValue = defaultValue ? dayjs(defaultValue, DateTimeFormat.DDMMYYYY) : null;
                    return (
                        <DatePicker
                            onChange={onDateSelect}
                            placeholder={placeholder || `Select ${label}`}
                            style={{
                                height: defaultHeight,
                                width: "100%",
                                borderRadius: defaultBorderRadius,
                            }}
                            value={formattedValue}
                            defaultValue={formattedDefaultValue}
                            format={DateTimeFormat.DDMMYYYY}
                            disabledDate={disabledDate}
                            defaultPickerValue={defaultPickerValue}
                        />
                    );
                }

                return type === InputType.Password ? (
                    <Input.Password {...textFieldProps} />
                ) : type === InputType.TextArea ? (
                    <Input.TextArea {...textFieldProps} minLength={minLength || 100}
                                    autoSize={{minRows: minRows || 2}}/>
                ) : (
                    <Input {...textFieldProps} />
                );
            })()}
        </Form.Item>
    );
};

export const SelectMode = {
    Single: "single",
    Multiple: "multiple",
}

export const InputType = {
    Text: "text",
    Password: "password",
    Email: "email",
    TextArea: "area",
    Number: "number",
    Search: "search",
    Tel: "tel",
    URL: "url",
    Date: "date",
    Time: "time",
    DateTime: "datetime-local",
    Month: "month",
    Week: "week",
    Color: "color",
    File: "file",
    Hidden: "hidden",
    Range: "range",
    Radio: "radio",
    Checkbox: "checkbox",
    Switch: "switch",
    Select: "select",
    DatePicker: "datePicker",
};

export default AppTextFormField;
