import React from 'react';
import PropTypes from 'prop-types';

// Column component for vertical layout
const Column = ({ children, justifyContent, alignItems, spacing, style, className }) => {
  const columnStyle = {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: justifyContent || 'flex-start',
    alignItems: alignItems || 'stretch',
    gap: spacing || '0', // gap between children
    ...style,
  };

  return <div className={className} style={columnStyle}>{children}</div>;
};

// Prop validation
Column.propTypes = {
  children: PropTypes.node.isRequired,
  justifyContent: PropTypes.string,
  alignItems: PropTypes.string,
  spacing: PropTypes.string,
  style: PropTypes.object,
  className: PropTypes.string,
};

Column.defaultProps = {
  justifyContent: 'flex-start',
  alignItems: 'stretch',
  spacing: '0',
  style: {},
  className: '',
};

export default Column;
