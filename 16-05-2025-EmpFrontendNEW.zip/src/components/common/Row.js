import React from 'react';
import PropTypes from 'prop-types';

// Row component for horizontal layout
const Row = ({ children, justifyContent, alignItems, spacing, style, className }) => {
  const rowStyle = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: justifyContent || 'flex-start',
    alignItems: alignItems || 'stretch',
    gap: spacing || '0', // gap between children
    ...style,
  };

  return <div className={className} style={rowStyle}>{children}</div>;
};

// Prop validation
Row.propTypes = {
  children: PropTypes.node.isRequired,
  justifyContent: PropTypes.string,
  alignItems: PropTypes.string,
  spacing: PropTypes.string,
  style: PropTypes.object,
  className: PropTypes.string,
};

Row.defaultProps = {
  justifyContent: 'flex-start',
  alignItems: 'stretch',
  spacing: '0',
  style: {},
  className: '',
};

export default Row;
