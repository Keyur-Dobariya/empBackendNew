import React from 'react';
import PropTypes from 'prop-types';

const SpaceBox = ({
  children,
  space,
  spaceX,
  spaceY,
  top,
  right,
  bottom,
  left,
  horizontal,
  vertical,
  style,
  className,
}) => {
  const spaceStyle = {
    padding: space || 0,
    margin: space || 0,
    paddingTop: top || vertical || space || 0,
    paddingRight: right || horizontal || space || 0,
    paddingBottom: bottom || vertical || space || 0,
    paddingLeft: left || horizontal || space || 0,
    marginTop: top || vertical || space || 0,
    marginRight: right || horizontal || space || 0,
    marginBottom: bottom || vertical || space || 0,
    marginLeft: left || horizontal || space || 0,
    gap: `${spaceY || 0} ${spaceX || 0}`,
    ...style,
  };

  return (
    <div className={`${className} space-box`} style={spaceStyle}>
      {children}
    </div>
  );
};

SpaceBox.propTypes = {
  children: PropTypes.node.isRequired,
  space: PropTypes.string,
  spaceX: PropTypes.string,
  spaceY: PropTypes.string,
  top: PropTypes.string,
  right: PropTypes.string,
  bottom: PropTypes.string,
  left: PropTypes.string,
  horizontal: PropTypes.string,
  vertical: PropTypes.string,
  style: PropTypes.object,
  className: PropTypes.string,
};

SpaceBox.defaultProps = {
  space: 0,
  spaceX: 0,
  spaceY: 0,
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
  horizontal: 0,
  vertical: 0,
  style: {},
  className: '',
};

export default SpaceBox;
