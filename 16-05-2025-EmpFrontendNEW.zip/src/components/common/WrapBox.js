import React from 'react';
import { Row, Col } from 'antd';

const WrapBox = ({ children, gutter = 25 }) => {
  const childrenArray = React.Children.toArray(children);
  
  return (
    <Row gutter={gutter}>
      {childrenArray.map((child, index) => {
        const span = child.props.span || 12;
        
        return (
          <Col key={index} span={window.innerWidth <= 810 ? 24 : span}>
            {child}
          </Col>
        );
      })}
    </Row>
  );
};

export default WrapBox; 