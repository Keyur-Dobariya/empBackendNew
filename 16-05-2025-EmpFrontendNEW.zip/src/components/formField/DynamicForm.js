import React from "react";
import { Form, Input } from "antd";

const DynamicForm = ({ form, formConfig, onFieldChange }) => {
  const handleChange = (changedValues, allValues) => {
    if (onFieldChange) {
      onFieldChange(allValues);
    }
  };

  return (
    <Form
      form={form}
      name="dynamic_form"
      onFinish={(values) => {
        
      }}
      onValuesChange={handleChange}
      initialValues={{ remember: true }}
    >
      {formConfig.map((field, index) => (
        <Form.Item
          key={index}
          name={field.name}
          rules={field.rules}
          hasFeedback
        >
          {field.type === "password" ? (
            <Input.Password
              prefix={React.cloneElement(field.prefix, {
                className: field.iconClass,
                style: prefixIconStyle.overlay,
                size: 21,
              })}
              minLength={field.minLength}
              maxLength={field.maxLength}
              inputMode={field.inputMode}
              suffix={field.suffix}
              placeholder={field.placeholder}
              type={field.type || "text"}
              style={inputFieldStyle.overlay}
              className={field.inputClass}
              value={field.value}
            />
          ) : (
            <Input
              prefix={React.cloneElement(field.prefix, {
                className: field.iconClass,
                style: prefixIconStyle.overlay,
                size: 21,
              })}
              minLength={field.minLength}
              maxLength={field.maxLength}
              inputMode={field.inputMode}
              suffix={field.suffix}
              placeholder={field.placeholder}
              type={field.type || "text"}
              style={inputFieldStyle.overlay}
              className={field.inputClass}
              value={field.value}
            />
          )}
        </Form.Item>
      ))}
    </Form>
  );
};

export const SimpleTextField = ({ field }) => {
  return (
    <Form.Item
      key={field.name}
      name={field.name}
      rules={field.rules}
      layout="vertical"
      label={field.label}
      hasFeedback
    >
      {field.type === "password" ? (
        <Input.Password
          prefix={React.cloneElement(field.prefix, {
            className: field.iconClass,
            style: prefixIconStyle.overlay,
            size: 21,
          })}
          minLength={field.minLength}
          maxLength={field.maxLength}
          inputMode={field.inputMode}
          suffix={field.suffix}
          disabled={field.disabled}
          placeholder={field.placeholder}
          type={field.type || "text"}
          style={inputFieldStyle.overlay}
          className={field.inputClass}
          value={field.value}
        />
      ) : field.type === "area" ? (
        <Input.TextArea
          prefix={React.cloneElement(field.prefix, {
            className: field.iconClass,
            style: prefixIconStyle.overlay,
            size: 21,
          })}
          minLength={field.minLength || 100}
          maxLength={field.maxLength}
          inputMode={field.inputMode}
          suffix={field.suffix}
          disabled={field.disabled}
          placeholder={field.placeholder}
          type={field.type || "text"}
          style={inputFieldAreaStyle.overlay}
          className={field.inputClass}
          value={field.value}
        />
      ) : (
        <Input
          prefix={React.cloneElement(field.prefix, {
            className: field.iconClass,
            style: prefixIconStyle.overlay,
            size: 21,
          })}
          minLength={field.minLength}
          maxLength={field.maxLength}
          inputMode={field.inputMode}
          suffix={field.suffix}
          disabled={field.disabled}
          placeholder={field.placeholder}
          type={field.type || "text"}
          style={inputFieldStyle.overlay}
          className={field.inputClass}
          value={field.value}
        />
      )}
    </Form.Item>
  );
};

export const SearchTextField = ({ field }) => {
  return (
    <Form.Item
      key={field.name}
      name={field.name}
      rules={field.rules}
      style={field.style}
    >
      <Input
          prefix={React.cloneElement(field.prefix, {
            className: field.iconClass,
            style: prefixIconStyle.overlay,
            size: 21,
          })}
          minLength={field.minLength}
          maxLength={field.maxLength}
          inputMode={field.inputMode}
          suffix={field.suffix}
          disabled={field.disabled}
          placeholder={field.placeholder}
          type={field.type || "text"}
          style={inputFieldStyle.overlay}
          className={field.inputClass}
          value={field.value}
          onChange={field.onChange}
        />
    </Form.Item>
  );
};

const prefixIconStyle = {
  overlay: {
    paddingInlineEnd: 5,
  },
};

const inputFieldStyle = {
  overlay: {
    height: 40,
    borderRadius: "10px",
  },
};

const inputFieldAreaStyle = {
  overlay: {
    borderRadius: "10px",
  },
};

export default DynamicForm;
