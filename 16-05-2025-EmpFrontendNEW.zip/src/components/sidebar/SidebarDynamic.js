import React from "react";
import PropTypes from "prop-types";
import Row from "./Row";
import Column from "./Column";
import Card from "./Card";
import Image from "./Image";
import AppText from "./AppText";
import SpaceBox from "./SpaceBox";

const Sidebar = ({
  isShrinkView,
  profileImage,
  profileName,
  profileRole,
  menuItems,
  backgroundColor,
  textColor,
}) => {
  const sidebarStyles = {
    display: "flex",
    flexDirection: "column",
    height: "100vh", // Full height
    width: isShrinkView ? "80px" : "280px" || "250px", // Default width or passed as prop
    backgroundColor: backgroundColor || "#2c3e50", // Default background color
    padding: "20px",
    position: "fixed", // Fix the sidebar to the left of the page
    transition: "width 0.3s ease-in-out", // Smooth transition for dynamic width
    overflowY: "auto", // Enable scroll if content overflows
    boxShadow: "rgba(0, 0, 0, 0.1) 0px 10px 50px",
    color: textColor || "#fff", // Default text color
    fontFamily: `'Montserrat', Helvetica, Arial, serif`,
  };

  // Profile section card style
  const profileCardStyles = {
    backgroundColor: "#34495e",
    padding: "15px",
    marginBottom: "20px",
    borderRadius: "8px",
  };

  // Menu item card style
  const menuItemCardStyles = {
    backgroundColor: "#34495e",
    padding: "10px 15px",
    marginBottom: "10px",
    borderRadius: "8px",
  };

  // Scrollbar styles using class names and inline CSS
  const scrollStyles = {
    maxHeight: "400px", // Set a max height for scrolling container
    overflowY: "auto", // Enable vertical scrolling
    paddingRight: "5px", // For padding on right side to avoid scroll overlap
  };

  return (
    <Row
      className="sidebar-container"
      justifyContent="flex-start"
      alignItems="flex-start"
      style={sidebarStyles}
    >
      <Column style={{ width: "100%" }}>
        {/* Profile Section */}
        <Card
          elevation={true}
          height="auto"
          width="100%"
          padding="15px"
          style={profileCardStyles}
        >
          <Column justifyContent="center" alignItems="center">
            <Image
              source={profileImage}
              alt="Profile Image"
              width="80px"
              height="80px"
              style={{ borderRadius: "50%" }}
            />
            <SpaceBox space="10px" />
            <AppText
              text={profileName}
              fontSize="18px"
              color={textColor || "#fff"}
              fontWeight="bold"
              textAlign="center"
            />
            <AppText
              text={profileRole}
              fontSize="14px"
              color="#bdc3c7"
              textAlign="center"
            />
          </Column>
        </Card>
        <SpaceBox space="20px" /> {/* Spacer */}
        {/* Menu Section */}
        <Column style={scrollStyles}>
          {menuItems.map((item, index) => (
            <Card
              key={index}
              elevation={false}
              width="100%"
              padding="15px"
              style={menuItemCardStyles}
            >
              <AppText
                text={item.name}
                fontSize="16px"
                color={item.color || "#ecf0f1"}
                isLink={true}
                onClick={item.onClick}
              />
            </Card>
          ))}
        </Column>
      </Column>
    </Row>
  );
};

// Prop validation for Sidebar component
Sidebar.propTypes = {
  profileImage: PropTypes.string.isRequired, // Profile image URL
  profileName: PropTypes.string.isRequired, // Profile name
  profileRole: PropTypes.string.isRequired, // Profile role (e.g., Admin, User)
  menuItems: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired, // Menu item name
      color: PropTypes.string, // Optional color for the menu item text
      onClick: PropTypes.func.isRequired, // Click event handler
    })
  ).isRequired, // Array of menu items
  sidebarWidth: PropTypes.string, // Custom width for sidebar
  backgroundColor: PropTypes.string, // Sidebar background color
  textColor: PropTypes.string, // Text color for profile and menu items
};

// Default props
Sidebar.defaultProps = {
  sidebarWidth: "250px",
  backgroundColor: "#2c3e50",
  textColor: "#fff",
};

export default Sidebar;
