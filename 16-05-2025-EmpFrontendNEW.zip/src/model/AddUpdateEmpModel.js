import React, { useState, useEffect, useRef } from "react";
import { Button, DatePicker, Form, Image, message, Modal, Upload } from "antd";
import {
  confirmPasswordFieldRules,
  passwordFieldRules,
} from "../config/formConfig";
import {
  checkImageExists,
  generateEmployeeCode,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import { LoadingOutlined, PlusOutlined } from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {
  InputType,
  SelectMode,
} from "../components/common/AppTextFormField";
import WrapBox from "../components/common/WrapBox";
import Row from "../components/common/Row";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import { getLocalData, loginDataKeys } from "../dataStorage/DataPref";
import { useLoading } from "..";
import { endpoints } from "../api/apiEndpoints";
import apiCall, { HttpMethod } from "../api/apiServiceProvider";
import {
  ApprovalStatus,
  BloodGroup,
  DateTimeFormat,
  Gender,
  Technology,
  UserRole,
} from "../utils/enum";
import { Loader } from "../components/Loader";
import dayjs from "dayjs";
import imagePaths from "../assets/assetsPaths";

const newEmpCode = generateEmployeeCode();

export default function AddUpdateEmpModel({
  isModelOpen,
  setIsModelOpen,
  employeeData,
  isEditing,
  onSuccessCallback,
  isModel = false,
}) {
  // const { setIsLoading } = useLoading();
  const [isLoading, setIsLoading] = useState(false);
  const [form] = Form.useForm();
  const [empRecord, setEmpRecord] = useState(employeeData || {});

  const [userActive, setUserActive] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState([]);
  const [loading, setImageUploadLoading] = useState(false);
  const containerRef = useRef(null);

  let technologyList = [];

  const disabledDate = (current) => {
    const minAllowedDate = dayjs().subtract(15, "year");
    return current && current.isAfter(minAllowedDate, "day");
  };

  const defaultPickerValue = dayjs().subtract(15, "year");

  useEffect(() => {
    if (isEditing && employeeData) {
      form.resetFields();
      setUserActive(employeeData.isActive || false);
      setEmpRecord(employeeData);
      if (employeeData.profilePhoto) {
        setFileList([
          {
            uid: "1",
            name: "image.png",
            url: !checkImageExists(employeeData.profilePhoto) ? imagePaths.profile_placeholder : employeeData.profilePhoto,
          },
        ]);
      }

      const formattedDob = employeeData.dateOfBirth
        ? dayjs(employeeData.dateOfBirth)
        : null;

      const formattedDateOfJoining = employeeData.dateOfJoining
        ? dayjs(employeeData.dateOfJoining)
        : null;

      const formattedDateOfLeaving = employeeData.dateOfLeaving
        ? dayjs(employeeData.dateOfLeaving)
        : null;

        // technologyList = employeeData.technology || [];

        // form.setFieldsValue({
        //   technology: technologyList,
        // });
      

      const formData = {
        ...employeeData,
        dateOfBirth: formattedDob,
        dateOfJoining: formattedDateOfJoining,
        dateOfLeaving: formattedDateOfLeaving,
        technology: employeeData.technology.filter(entry => entry !== ''),
      };

      form.setFieldsValue(formData);
    }
  }, [employeeData, isEditing, form]);

  const handleEditCancel = () => {
    setIsModelOpen(false);
    form.resetFields();
    if (containerRef.current) {
      containerRef.current.scrollTop = 0;
    }
  };

  const handleFieldChange = (changedValues, allValues) => {
    form.setFieldsValue(allValues);
    if (allValues.password) {
      form.validateFields(["confirmPassword"]);
    }
  };

  const handleAddUpdateUserApi = async (event) => {
    try {
      await form.validateFields([
        "approvalStatus",
        "fullName",
        "mobileNumber",
        "emergencyContactNo",
        "emailAddress",
        "gender",
        "dateOfBirth",
        "bloodGroup",
        "address",
        "aadharCardNo",
        "panCardNo",
        ...(isEditing ? [] : ["password", "confirmPassword"]),
      ]);

      const formData = new FormData();
      const formValues = form.getFieldsValue();
      
      if (formValues.dateOfBirth) {
        formValues.dateOfBirth = new Date(formValues.dateOfBirth).toISOString();
      }

      if (!isEditing) {
        formValues.employeeCode = newEmpCode;
      }

      for (const [key, value] of Object.entries(formValues)) {
        if (value !== undefined && value !== null) {
          formData.append(key, value.toString());
        }
      }

      if (form.getFieldValue(appKeys.profilePhoto)) {
        formData.append(
          "profilePhoto",
          form.getFieldValue(appKeys.profilePhoto)
        );
      }

      formData.append("employeeCode", empRecord?.employeeCode || newEmpCode);

      try {
        await apiCall({
          method: HttpMethod.POST,
          url: !isEditing
            ? endpoints.addUser
            : `${endpoints.updateRecord}${event._id}`,
          data: formData,
          isMultipart: true,
          setIsLoading: setIsLoading,
          successCallback: (data) => {
            if (isModel) {
              setIsModelOpen(false);
            }
            onSuccessCallback();
          },
        });
      } catch (error) {
        console.error("API Call Failed:", error);
      }
    } catch (error) {
      console.error("Form validation failed:", error);
      message.error("Please fill in all required fields correctly");
    }
  };

  const onGenderSelect = (value) => {
    form.setFieldsValue({
      gender: value,
    });
  };

  const onBloodGroupSelect = (value) => {
    form.setFieldsValue({
      bloodGroup: value,
    });
  };
  
  const onDobSelect = (date, dateString) => {
    form.setFieldsValue({
      dateOfBirth: date,
    });
  };

  const onDateOfJoiningSelect = (date, dateString) => {
    form.setFieldsValue({
      dateOfJoining: date,
    });
  };

  const onDateOfLeavingSelect = (date, dateString) => {
    form.setFieldsValue({
      dateOfLeaving: date,
    });
  };

  const getBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });

  const handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    setPreviewImage(file.url || file.preview);
    setPreviewOpen(true);
  };

  const uploadButton = (
    <button
      style={{
        border: 0,
        background: "none",
      }}
      type="button"
    >
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div
        style={{
          marginTop: 8,
        }}
      >
        Upload
      </div>
    </button>
  );

  const customRequest =
    (id) =>
    ({ file, onSuccess, onError }) => {
      form.setFieldsValue({
        [appKeys.profilePhoto]: file,
      });

      setImageUploadLoading(true);

      setTimeout(() => {
        const uploadedImageUrl = URL.createObjectURL(file);

        setFileList([
          {
            uid: "1",
            name: "image.png",
            url: uploadedImageUrl,
          },
        ]);

        setImageUploadLoading(false);
        onSuccess();
      }, 1000);
    };

  const handleUserStatusChange = async (checked) => {
    setUserActive(checked);
    const updatedValues = { ...form.getFieldsValue(), isActive: checked };
    form.setFieldsValue(updatedValues);
  };

  useEffect(()=>{
  },[form])

  const formUi = () => {
    return (
      <>
        {isLoading ? <Loader /> : ""}
        <Column justifyContent="center" alignItems="center">
          <Form
            form={form}
            name="EmpAddUpdateModel"
            layout="vertical"
            //   disabled={true}
            onValuesChange={handleFieldChange}
            initialValues={isEditing ? {} : form.getFieldsValue()}
            style={{
              marginRight: 15,
              marginTop: 15,
              alignContent: "center",
            }}
          >
            <Row justifyContent="center">
              <Upload
                name={appKeys.profilePhoto}
                className="avatar-uploader"
                listType="picture-circle"
                fileList={fileList}
                showUploadList={{
                  showPreviewIcon: true,
                  showRemoveIcon: true,
                }}
                onPreview={handlePreview}
                onRemove={() => {
                  setFileList([]);
                }}
                customRequest={customRequest(empRecord?._id)}
                multiple={false}
              >
                {fileList.length > 0 ? null : uploadButton}
              </Upload>
              {previewImage && (
                <Image
                  wrapperStyle={{
                    display: "none",
                  }}
                  preview={{
                    visible: previewOpen,
                    onVisibleChange: (visible) => setPreviewOpen(visible),
                    afterOpenChange: (visible) =>
                      !visible && setPreviewImage(""),
                  }}
                  src={previewImage}
                />
              )}
            </Row>
            <SpaceBox space={5} />
            <WrapBox>
              {getLocalData(loginDataKeys.role) === "Admin" ? <AppTextFormField
                name={appKeys.approvalStatus}
                label={appString.approvalStatus}
                type={InputType.Select}
                isRequired={true}
                selectOptions={[
                  {
                    label: ApprovalStatus.Approved,
                    value: ApprovalStatus.Approved,
                  },
                  {
                    label: ApprovalStatus.Pending,
                    value: ApprovalStatus.Pending,
                  },
                  {
                    label: ApprovalStatus.Rejected,
                    value: ApprovalStatus.Rejected,
                  },
                ]}
              /> : null}
              {getLocalData(loginDataKeys.role) === "Admin" ? <AppTextFormField
                name={appKeys.isActive}
                label={appString.userActiveStatus}
                type={InputType.Switch}
                switchChecked={
                  userActive
                }
                onSwitchChange={handleUserStatusChange}
              /> : null}
              <Column span={24}>
                <AppText
                  text={appString.personalDetails + ` :`}
                  fontSize={15}
                  fontWeight={500}
                  color={appColor.black}
                />
                <SpaceBox space={3} />
              </Column>
              <AppTextFormField
                name={appKeys.fullName}
                label={appString.fullName}
                isRequired={true}
                type={InputType.Text}
                placeholder={appString.fullName}
                value={empRecord?.fullName}
              />
              <AppTextFormField
                name={appKeys.dateOfBirth}
                label={appString.dateOfBirth}
                isRequired={true}
                type={InputType.DatePicker}
                placeholder={appString.dateOfBirth}
                defaultValue={form.getFieldValue(appKeys.dateOfBirth)}
                onDateSelect={onDobSelect}
                disabledDate={disabledDate}
                defaultPickerValue={defaultPickerValue}
              />
              <AppTextFormField
                name={appKeys.mobileNumber}
                label={appString.mobileNumber}
                isRequired={true}
                type={InputType.Number}
                maxLength={10}
                placeholder={appString.mobileNumber}
                value={form.getFieldValue(appKeys.mobileNumber)}
              />
              <AppTextFormField
                name={appKeys.emergencyContactNo}
                label={appString.emergencyContact}
                isRequired={true}
                type={InputType.Number}
                maxLength={10}
                placeholder={appString.emergencyContact}
                value={form.getFieldValue(appKeys.emergencyContactNo)}
              />
              <AppTextFormField
                name={appKeys.emailAddress}
                label={appString.emailAddress}
                isRequired={true}
                type={InputType.Email}
                placeholder={appString.emailAddress}
                value={form.getFieldValue(appKeys.emailAddress)}
              />
              <AppTextFormField
                name={appKeys.technology}
                label={appString.technology}
                type={InputType.Select}
                selectMode={SelectMode.Multiple}
                selectOptions={Technology}
                value={form.getFieldValue(appKeys.technology)}
                defaultValue={form.getFieldValue(appKeys.technology)}
              />
              <AppTextFormField
                name={appKeys.gender}
                label={appString.gender}
                isRequired={true}
                type={InputType.Select}
                value={form.getFieldValue(appKeys.gender)}
                selectOptions={[
                  { label: Gender.Male, value: Gender.Male },
                  { label: Gender.Female, value: Gender.Female },
                  { label: Gender.Other, value: Gender.Other },
                ]}
                onGenderSelect={onGenderSelect}
              />
              <AppTextFormField
                name={appKeys.bloodGroup}
                label={appString.bloodGroup}
                type={InputType.Select}
                value={form.getFieldValue(appKeys.bloodGroup)}
                selectOptions={[
                  { label: BloodGroup.APositive, value: BloodGroup.APositive },
                  { label: BloodGroup.ANegative, value: BloodGroup.ANegative },
                  { label: BloodGroup.BPositive, value: BloodGroup.BPositive },
                  { label: BloodGroup.BNegative, value: BloodGroup.BNegative },
                  { label: BloodGroup.OPositive, value: BloodGroup.OPositive },
                  { label: BloodGroup.ONegative, value: BloodGroup.ONegative },
                  {
                    label: BloodGroup.ABPositive,
                    value: BloodGroup.ABPositive,
                  },
                  {
                    label: BloodGroup.ABNegative,
                    value: BloodGroup.ABNegative,
                  },
                ]}
                onBloodGroupSelect={onBloodGroupSelect}
              />
              <AppTextFormField
                name={appKeys.skills}
                label={appString.skills}
                type={InputType.TextArea}
                placeholder={appString.skills}
                value={form.getFieldValue(appKeys.skills)}
                span={24}
              />
              <AppTextFormField
                name={appKeys.address}
                label={appString.address}
                type={InputType.TextArea}
                placeholder={appString.address}
                value={form.getFieldValue(appKeys.address)}
                span={24}
              />
              <AppTextFormField
                name={appKeys.pincode}
                label={appString.pincode}
                type={InputType.Number}
                maxLength={6}
                placeholder={appString.pincode}
                value={form.getFieldValue(appKeys.pincode)}
              />
              {getLocalData(loginDataKeys.role) === UserRole.Employee ? null : <AppTextFormField
                name={appKeys.role}
                label={appString.role}
                type={InputType.Select}
                disabled={
                  getLocalData(loginDataKeys.role) === UserRole.Employee
                    ? true
                    : false
                }
                value={form.getFieldValue(appKeys.role)}
                selectOptions={[
                  { label: UserRole.Admin, value: UserRole.Admin },
                  { label: UserRole.Employee, value: UserRole.Employee },
                ]}
              />}
              {!isEditing && (
                <AppTextFormField
                  name={appKeys.password}
                  label={appString.password}
                  type={InputType.Password}
                  rules={passwordFieldRules}
                  isRequired={true}
                  placeholder={appString.password}
                  value={form.getFieldValue(appKeys.password)}
                />
              )}
              {!isEditing && (
                <AppTextFormField
                  name={appKeys.confirmPassword}
                  label={appString.confirmPassword}
                  type={InputType.Password}
                  rules={confirmPasswordFieldRules(form)}
                  isRequired={true}
                  placeholder={appString.confirmPassword}
                  value={form.getFieldValue(appKeys.confirmPassword)}
                />
              )}
              <Column span={24}>
                <AppText
                  text={appString.financialDetails + ` :`}
                  fontSize={15}
                  fontWeight={500}
                  color={appColor.black}
                />
                <SpaceBox space={3} />
              </Column>
              <AppTextFormField
                name={appKeys.aadharNumber}
                label={appString.aadharNumber}
                type={InputType.Number}
                maxLength={12}
                placeholder={appString.aadharNumber}
                value={form.getFieldValue(appKeys.aadharNumber)}
              />
              <AppTextFormField
                name={appKeys.panNumber}
                label={appString.panNumber}
                type={InputType.Text}
                maxLength={10}
                placeholder={appString.panNumber}
                value={form.getFieldValue(appKeys.panCardNo)}
              />
              <AppTextFormField
                name={appKeys.bankAccountNumber}
                label={appString.bankAccountNumber}
                type={InputType.Number}
                maxLength={20}
                placeholder={appString.bankAccountNumber}
                value={form.getFieldValue(appKeys.bankAccountNumber)}
              />
              <AppTextFormField
                name={appKeys.ifscCode}
                label={appString.ifscCode}
                type={InputType.Text}
                placeholder={appString.ifscCode}
                value={form.getFieldValue(appKeys.ifscCode)}
              />
              <AppTextFormField
                name={appKeys.dateOfJoining}
                label={appString.dateOfJoining}
                type={InputType.DatePicker}
                placeholder={appString.dateOfJoining}
                value={form.getFieldValue(appKeys.dateOfJoining)}
                onDobSelect={onDateOfJoiningSelect}
              />
              {getLocalData(loginDataKeys.role) === "Admin" ? <AppTextFormField
                name={appKeys.dateOfLeaving}
                label={appString.dateOfLeaving}
                type={InputType.DatePicker}
                placeholder={appString.dateOfLeaving}
                value={form.getFieldValue(appKeys.dateOfLeaving)}
                onDobSelect={onDateOfLeavingSelect}
              /> : null}
            </WrapBox>
          </Form>
          {!isModel && (
            <Button
              type="primary"
              onClick={() => {
                handleAddUpdateUserApi(empRecord);
              }}
              style={{ margin: "0", width: "200px" }}
            >
              Update Profile
            </Button>
          )}
          {!isModel && <SpaceBox space="5px" />}
        </Column>
      </>
    );
  };

  return (
    <>
      {isModel ? (
        <Modal
          title={
            <Row justifyContent="left" alignItems="center">
              <AppText
                text={
                  isEditing ? appString.editEmployee : appString.addEmployee
                }
                fontSize={16}
                fontWeight={500}
                color={appColor.black}
              />
              <SpaceBox space={2} />
              <AppText
                text={`( ${empRecord?.employeeCode || newEmpCode} )`}
                fontSize={14}
                fontWeight={500}
                color={appColor.primary}
              />
            </Row>
          }
          maskClosable={false}
          centered
          open={isModelOpen}
          width={700}
          onOk={() => {
            handleAddUpdateUserApi(empRecord);
          }}
          onCancel={handleEditCancel}
          onClose={handleEditCancel}
          okText={isEditing ? appString.edit : appString.add}
        >
          {
            <div
              className="container-with-scrollbar"
              ref={containerRef}
              style={{
                maxHeight: "75vh",
                overflowY: "auto",
                alignItems: "center",
              }}
            >
              {formUi()}
            </div>
          }
        </Modal>
      ) : (
        formUi()
      )}
    </>
  );
}
