import React, {useState, useEffect, useRef} from "react";
import {
    Avatar, Button, DatePicker, Dropdown, Form, Radio, Input, message, Modal, Select, Tag, TimePicker, Tooltip, Upload
} from "antd";
import {
    confirmPasswordFieldRules, passwordFieldRules,
} from "../config/formConfig";
import {
    checkImageExists, decryptValue, generateEmployeeCode, getTwoCharacterFromName,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import {CloseCircleOutlined, FileOutlined, LoadingOutlined, PlusOutlined, UploadOutlined} from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {
    InputType, SelectMode,
} from "../components/common/AppTextFormField";
import WrapBox from "../components/common/WrapBox";
import Row from "../components/common/Row";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {useLoading} from "..";
import {endpoints} from "../api/apiEndpoints";
import apiCall, {HttpMethod} from "../api/apiServiceProvider";
import {
    leaveTypeLabel,
    UserRole, dayTypeLabel, leaveCategoryLabel, leaveHalfDayTypeLabel, leaveLabelKeys, leaveStatusLabel,
} from "../utils/enum";
import {Loader} from "../components/Loader";
import imagePaths from "../assets/assetsPaths";
import dayjs from "dayjs";
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';

dayjs.extend(isSameOrBefore);

const {Option} = Select;

export default function BasicSalaryAddUpdateModel({
                                                      isModelOpen,
                                                      setIsModelOpen,
                                                      employeeList,
                                                      basicSalaryData,
                                                      isEditing,
                                                      setIsEditing,
                                                      onSuccessCallback,
                                                  }) {
    const [isLoading, setIsLoading] = useState(false);
    const [form] = Form.useForm();
    const containerRef = useRef(null);

    const defaultBasicSalaryValues = {
        [appKeys.user]: basicSalaryData[appKeys.user] ? basicSalaryData[appKeys.user].userId : null,
        [appKeys.startDate]: basicSalaryData[appKeys.startDate] ? dayjs(basicSalaryData[appKeys.startDate]) : null,
        [appKeys.basicSalary]: decryptValue(basicSalaryData[appKeys.basicSalary]) || null,
        [appKeys.code]: basicSalaryData[appKeys.code] || null,
    };

    const [basicSalaryValues, setBasicSalaryValues] = useState(defaultBasicSalaryValues);
    const [isAfter3Days, setIsAfter3Days] = useState(true);

    useEffect(() => {
        if (isEditing) {
            form.setFieldsValue(basicSalaryValues);
            setBasicSalaryValues(basicSalaryValues);
        }
    }, []);

    const resetBasicSalaryValues = () => {
        setBasicSalaryValues(defaultBasicSalaryValues);
        form.resetFields();
        if (containerRef.current) {
            containerRef.current.scrollTop = 0;
        }
    };

    const handleEditCancel = () => {
        setIsModelOpen(false);
        setIsEditing(false);
        resetBasicSalaryValues();
    };

    const handleFieldChange = (changedValues, allValues) => {
        form.setFieldsValue(allValues);
        setBasicSalaryValues((prev) => ({
            ...prev,
            [appKeys.basicSalary]: allValues[appKeys.basicSalary],
            [appKeys.code]: allValues[appKeys.code],
        }));
    };

    const handleAddUpdateBasicSalaryApi = async () => {
        try {
            await form.validateFields([
                appKeys.user,
                appKeys.basicSalary,
                appKeys.code,
                appKeys.startDate,
            ]);

            const payload = {
                ...basicSalaryValues,
                [appKeys.startDate]: basicSalaryValues[appKeys.startDate] ? dayjs(basicSalaryValues[appKeys.startDate]).format("YYYY-MM-DD") : null,
            };

            setIsLoading(true);

            await apiCall({
                method: HttpMethod.POST,
                url: isEditing ? `${endpoints.addUpdateBasicSalary}/${basicSalaryData["_id"]}` : endpoints.addUpdateBasicSalary,
                data: payload,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    handleEditCancel();
                    onSuccessCallback(data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const formUi = () => {
        return (<>
            {isLoading ? <Loader/> : ""}
            <Column justifyContent="center" alignItems="center">
                <Form
                    form={form}
                    name="EmpAddUpdateModel"
                    layout="vertical"
                    onValuesChange={handleFieldChange}
                    style={{
                        marginTop: 15, width: "100%", alignContent: "center", overflowX: "hidden",
                    }}
                >
                    <WrapBox>
                        {getLocalData(loginDataKeys.role) === UserRole.Admin ?
                            <Form.Item name={appKeys.user} label={"User"}
                                       rules={[{required: true, message: 'Please select User!'}]} span={24}>
                                <Select
                                    placeholder="Select User"
                                    allowClear
                                    style={{height: '40px'}}
                                    showSearch
                                    value={basicSalaryValues[appKeys.user]}
                                    onChange={(key) => {
                                        setBasicSalaryValues((prev) => ({
                                            ...prev,
                                            [appKeys.user]: key,
                                        }));
                                    }}
                                    filterOption={(input, option) =>
                                        option?.label?.toLowerCase().includes(input.toLowerCase())
                                    }
                                >
                                    {employeeList.map(employee => (
                                        <Option key={employee.userId} value={employee.userId}
                                                label={employee.fullName}>
                                            <div
                                                style={{display: "flex", alignItems: "center", gap: "10px"}}
                                            >
                                                <Avatar
                                                    src={employee.profilePhoto || imagePaths.profile_placeholder}
                                                    size="small"/>
                                                {employee.fullName}
                                            </div>
                                        </Option>))}
                                </Select>
                            </Form.Item> : null}
                        <AppTextFormField
                            name={appKeys.basicSalary}
                            label={appString.basicSalary}
                            type={InputType.Number}
                            isRequired={true}
                            placeholder={appString.basicSalary}
                            value={basicSalaryValues[appKeys.basicSalary]}
                            span={24}
                        />
                        <AppTextFormField
                            name={appKeys.code}
                            label={appString.code}
                            type={InputType.Text}
                            isRequired={true}
                            placeholder={appString.code}
                            value={basicSalaryValues[appKeys.code]}
                            span={24}
                            onInput={(e) => {
                                let value = e.target.value.toUpperCase();
                                e.target.value = value;
                            }}
                        />
                        <Form.Item name={appKeys.startDate} label={"Start Date"} rules={[{required: true}]}
                                   span={24}>
                            <DatePicker defaultValue={basicSalaryValues[appKeys.startDate]}
                                        value={basicSalaryValues[appKeys.startDate]}
                                        style={{height: '40px', width: "100%"}}
                                        allowClear={false}
                                        onChange={(date, dateString) => {
                                            setBasicSalaryValues((prev) => ({
                                                ...prev,
                                                [appKeys.startDate]: dateString,
                                            }));
                                        }}/>
                        </Form.Item>
                    </WrapBox>
                </Form>
            </Column>
        </>);
    };

    return (<>
        {isModelOpen && (<Modal
            title={isEditing ? "Edit Basic Salary" : "Add Basic Salary"}
            maskClosable={false}
            centered
            open={isModelOpen}
            width={450}
            onOk={() => {
                handleAddUpdateBasicSalaryApi();
            }}
            onCancel={handleEditCancel}
            onClose={handleEditCancel}
            okText={"Save"}
        >
            {<div
                className="container-with-scrollbar"
                ref={containerRef}
                style={{
                    width: "100%", maxHeight: "75vh", overflow: "auto", alignItems: "center",
                }}
            >
                {formUi()}
            </div>}
        </Modal>)}
    </>);
}