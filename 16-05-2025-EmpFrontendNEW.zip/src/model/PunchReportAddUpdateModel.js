import React, {useState, useEffect, useRef} from "react";
import {
    Avatar, Button, Dropdown, Form, Radio, Input, message, Modal, Select, Tag, TimePicker, Tooltip, Upload
} from "antd";
import {
    confirmPasswordFieldRules, passwordFieldRules,
} from "../config/formConfig";
import {
    checkImageExists, generateEmployeeCode, getTwoCharacterFromName, showToast,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import {
    CloseCircleOutlined,
    FileOutlined,
    InboxOutlined,
    LoadingOutlined,
    PlusOutlined,
    UploadOutlined
} from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {
    InputType, SelectMode,
} from "../components/common/AppTextFormField";
import WrapBox from "../components/common/WrapBox";
import Row from "../components/common/Row";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {useLoading} from "..";
import {endpoints} from "../api/apiEndpoints";
import apiCall, {HttpMethod} from "../api/apiServiceProvider";
import {
    leaveTypeLabel,
    UserRole, dayTypeLabel, leaveCategoryLabel, leaveHalfDayTypeLabel, leaveLabelKeys, leaveStatusLabel,
} from "../utils/enum";
import {Loader} from "../components/Loader";
import imagePaths from "../assets/assetsPaths";
import dayjs from "dayjs";
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';

dayjs.extend(isSameOrBefore);

const {Option} = Select;
const {Dragger} = Upload;

export default function PunchReportAddUpdateModel({
                                                      isModelOpen,
                                                      setIsModelOpen,
                                                      employeeList,
                                                      clientData,
                                                      isEditing,
                                                      setIsEditing,
                                                      onSuccessCallback,
                                                  }) {
    const [isLoading, setIsLoading] = useState(false);
    const [form] = Form.useForm();
    const containerRef = useRef(null);

    const [punchReportValue, setPunchReportValue] = useState(null);

    const [fileList, setFileList] = useState([]);

    useEffect(() => {
        if (isEditing) {
            form.setFieldsValue(punchReportValue);
            setPunchReportValue(punchReportValue);
        }
    }, []);

    const resetPunchReportValues = () => {
        // setPunchReportValue(defaultClientValues);
        form.resetFields();
        if (containerRef.current) {
            containerRef.current.scrollTop = 0;
        }
    };

    const handleEditCancel = () => {
        setIsModelOpen(false);
        setIsEditing(false);
        resetPunchReportValues();
    };

    const handleFieldChange = (changedValues, allValues) => {
        form.setFieldsValue(allValues);
        setPunchReportValue((prev) => ({
            ...prev,
            [appKeys.clientName]: allValues[appKeys.clientName],
        }));
    };

    const handleAddUpdateClientApi = async () => {
        try {
            await form.validateFields([
                appKeys.user,
                "sheet",
            ]);

            if(!form.getFieldValue("sheet")) {
                showToast("error", "Please upload sheet first")
            }

            const formData = new FormData();

            formData.append(
                "sheet",
                form.getFieldValue("sheet")
            );

            formData.append("userId", punchReportValue[appKeys.user]);

            await apiCall({
                method: HttpMethod.POST,
                url: !isEditing
                    ? endpoints.punchSheetUploadAndGetData
                    : `${endpoints.updateRecord}`,
                data: formData,
                isMultipart: true,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    setIsModelOpen(false);
                    onSuccessCallback(data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const formUi = () => {
        return (<>
            {isLoading ? <Loader/> : ""}
            <Column justifyContent="center" alignItems="center">
                <Form
                    form={form}
                    name="EmpAddUpdateModel"
                    layout="vertical"
                    onValuesChange={handleFieldChange}
                    style={{
                        marginTop: 15, width: "100%", alignContent: "center", overflowX: "hidden",
                    }}
                >
                    <WrapBox>
                        <Form.Item name={appKeys.user} label={"User"}
                                   rules={[{required: true, message: 'Please select User!'}]} span={24}>
                            <Select
                                placeholder="Select User"
                                allowClear
                                style={{height: '40px'}}
                                showSearch
                                // value={leaveValues[appKeys.user]}
                                onChange={(key) => {
                                    setPunchReportValue((prev) => ({
                                        ...prev,
                                        [appKeys.user]: key,
                                    }));
                                }}
                                filterOption={(input, option) =>
                                    option?.label?.toLowerCase().includes(input.toLowerCase())
                                }
                            >
                                {employeeList.map(employee => (
                                    <Option key={employee.userId} value={employee.userId}
                                            label={employee.fullName}>
                                        <div
                                            style={{display: "flex", alignItems: "center", gap: "10px"}}
                                        >
                                            <Avatar
                                                src={employee.profilePhoto || imagePaths.profile_placeholder}
                                                size="small"/>
                                            {employee.fullName}
                                        </div>
                                    </Option>))}
                            </Select>
                        </Form.Item>
                        <Form.Item name="sheet" label={"Upload Punch Sheet"}
                                   rules={[{required: true, message: 'Upload Punch Sheet'}]} span={24}>
                            <Upload name="sheet"
                                    multiple={false}
                                    fileList={fileList}
                                    onRemove={() => {
                                        setFileList([]);
                                    }}
                                    customRequest={({ file, onSuccess }) => {
                                        form.setFieldsValue({
                                            "sheet": file,
                                        });

                                        const uploadedImageUrl = URL.createObjectURL(file);

                                        setFileList([
                                            {
                                                uid: "1",
                                                name: file.name,
                                                url: uploadedImageUrl,
                                            },
                                        ]);

                                        onSuccess();
                                    }}>
                                <Button icon={<UploadOutlined />}>Click to Upload</Button>
                            </Upload>
                        </Form.Item>
                    </WrapBox>
                </Form>
            </Column>
        </>);
    };

    return (<>
        {isModelOpen && (<Modal
            title={isEditing ? "Edit Client" : "Add Client"}
            maskClosable={false}
            centered
            open={isModelOpen}
            width={450}
            onOk={() => {
                handleAddUpdateClientApi();
            }}
            onCancel={handleEditCancel}
            onClose={handleEditCancel}
            okText={"Save"}
        >
            {<div
                className="container-with-scrollbar"
                ref={containerRef}
                style={{
                    width: "100%", maxHeight: "75vh", overflow: "auto", alignItems: "center",
                }}
            >
                {formUi()}
            </div>}
        </Modal>)}
    </>);
}