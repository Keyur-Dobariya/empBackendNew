import React, {useState, useEffect, useRef} from "react";
import {
    Avatar,
    Button,
    DatePicker,
    Dropdown,
    Form,
    Image, Input,
    message,
    Modal, Popconfirm, Select,
    Tag,
    TimePicker,
    Tooltip,
    Upload
} from "antd";
import {
    confirmPasswordFieldRules,
    passwordFieldRules,
} from "../config/formConfig";
import {
    checkImageExists,
    generateEmployeeCode,
    getTwoCharacterFromName,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import {
    CloseCircleOutlined,
    DeleteOutlined,
    FileOutlined,
    LoadingOutlined,
    PlusOutlined,
    UploadOutlined
} from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {
    InputType,
    SelectMode,
} from "../components/common/AppTextFormField";
import WrapBox from "../components/common/WrapBox";
import Row from "../components/common/Row";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {useLoading} from "..";
import {endpoints} from "../api/apiEndpoints";
import apiCall, {HttpMethod} from "../api/apiServiceProvider";
import {
    ApprovalStatus,
    BloodGroup,
    DateTimeFormat,
    Gender,
    getIconByKey,
    getKeyByLabel,
    getLabelByKey,
    taskCategoryLabel,
    taskColumnLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
    taskStatusLabel,
    Technology,
    UserRole,
} from "../utils/enum";
import {Loader} from "../components/Loader";
import dayjs from "dayjs";
import imagePaths from "../assets/assetsPaths";
import axios from "axios";
import * as logs from "sass";
import {X} from "react-feather";
import {deleteTaskApi} from "../api/apiUtils";

const {Option} = Select;

const getUserById = (userList, userId) => {
    const user = userList.find((user) => user.userId === userId);
    return user;
};

export default function TaskAddUpdateModel({
                                               isModelOpen,
                                               setIsModelOpen,
                                               employeeList,
                                               tasksData,
                                               projectData,
                                               clientRecord,
                                               setProjectData,
                                               setClientRecord,
                                               isEditing,
                                               setIsEditing,
                                               onSuccessCallback,
                                           }) {

    const getProjectById = (projectList, id) => {
        return projectList ? projectList.find((project) => project._id === id) : null;
    };

    const getClientByName = (list, id) => {
        return list ? list.find((project) => project._id === id) : null;
    };

    const parseDate = (dateString) => {
        if (!dateString) return null;

        const isoParsed = dayjs(dateString);
        if (isoParsed.isValid()) return isoParsed;

        const customParsed = dayjs(dateString, "DD-MM-YYYY hh:mm:ss A");
        if (customParsed.isValid()) return customParsed;

        return null; // If both fail
    };

    const [isLoading, setIsLoading] = useState(false);
    const [isButtonLoading, setIsButtonLoading] = useState(false);
    const [showHistoryModel, setShowHistoryModel] = useState(false);
    const [form] = Form.useForm();
    const [projectForm] = Form.useForm();
    const containerRef = useRef(null);

    const [isAddProjectOpen, setIsAddProjectOpen] = useState(false);
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [fileList, setFileList] = useState([]);
    const [newFileList, setNewFileList] = useState([]);

    const [projectValues, setProjectValues] = useState({});

    const [selectedClient, setSelectedClient] = useState(null);
    const [filteredProjects, setFilteredProjects] = useState([]);

    const taskAssigneeSort = Array.isArray(tasksData[appKeys.taskAssignee])
        ? tasksData[appKeys.taskAssignee]
            .filter(assignee => assignee && assignee.userId)
            .map(assignee => getUserById(employeeList, assignee.userId))
            .filter(Boolean)
        : [getUserById(employeeList, getLocalData(loginDataKeys._id))];

    useEffect(() => {
        if(tasksData[appKeys.clientName]) {
            const clientDetail = getClientByName(clientRecord, tasksData[appKeys.clientName]);
            setSelectedClient(clientDetail ? clientDetail._id : null);
            const projects = clientDetail ? clientDetail.projects : [];
            setFilteredProjects(projects);
        }
    }, []);

    const defaultTaskValues = {
        [appKeys.projectName]: tasksData[appKeys.projectName] ? getProjectById(projectData, tasksData[appKeys.projectName])?._id : undefined,
        [appKeys.taskTitle]: tasksData[appKeys.taskTitle] || "",
        [appKeys.taskDescription]: tasksData[appKeys.taskDescription] || "",
        [appKeys.taskStatus]: tasksData[appKeys.taskStatus] || getKeyByLabel(taskColumnLabel.ToDo, taskColumnStatusLabel),
        [appKeys.taskPriority]: tasksData[appKeys.taskPriority] || taskPriorityLabel[0].key,
        [appKeys.taskCategory]: tasksData[appKeys.taskCategory] || "development",
        [appKeys.taskAssignee]: taskAssigneeSort,
        [appKeys.taskLabels]: tasksData[appKeys.taskLabels] || "toDo",
        [appKeys.taskStartDate]: parseDate(tasksData[appKeys.taskStartDate]),
        [appKeys.taskEndDate]: parseDate(tasksData[appKeys.taskEndDate]),
        // [appKeys.taskStartDate]: tasksData[appKeys.taskStartDate] && dayjs(tasksData[appKeys.taskStartDate]).isValid()
        //     ? dayjs(tasksData[appKeys.taskStartDate])
        //     : null,
        // [appKeys.taskEndDate]: tasksData[appKeys.taskEndDate] && dayjs(tasksData[appKeys.taskEndDate]).isValid()
        //     ? dayjs(tasksData[appKeys.taskEndDate])
        //     : null,
        [appKeys.taskEstimatedTime]: tasksData[appKeys.taskEstimatedTime] || null,
        [appKeys.taskAttachments]: tasksData[appKeys.taskAttachments] || [],
        [appKeys.clientName]: tasksData[appKeys.clientName] ? getClientByName(clientRecord, tasksData[appKeys.clientName])?._id : null,
        [appKeys.taskAddedBy]: tasksData[appKeys.taskAddedBy] || getLocalData(loginDataKeys._id),
        "createdAt": tasksData["createdAt"] || null,
    };

    const [tasksValues, setTasksValues] = useState(defaultTaskValues);

    const getVisibleProjects = () => {
        const role = getLocalData(loginDataKeys.role);
        const userId = getLocalData(loginDataKeys._id);

        return projectData.filter((project) => {
            const isTeamMembers = project.teamMembers.some((member) => member.userId === userId);
            const isTeamLeader = project.teamLeader.some((member) => member.userId === userId);
            const isTeamManager = project.teamManager.some((member) => member.userId === userId);

            return role === UserRole.Admin || isTeamMembers || isTeamLeader || isTeamManager;
        });
    };

    const visibleProjects = getVisibleProjects();

    const clientList = visibleProjects.reduce((acc, project) => {
        if (!acc.includes(project.clientName)) {
            acc.push(project.clientName);
        }
        return acc;
    }, []);

    useEffect(() => {
        if (selectedClient) {
            // const projects = visibleProjects.filter(p => p.clientName === selectedClient);
            const clientDetail = getProjectById(clientRecord, selectedClient);
            if (clientDetail) {
                const projects = clientDetail ? clientDetail.projects : [];
                setFilteredProjects(projects);
            }
        }
    }, [selectedClient]);

    useEffect(() => {
        if (isEditing) {
            form.setFieldsValue(tasksValues);

            const taskAttachmentsLive = tasksData[appKeys.taskAttachments]?.map((attachment, index) => ({
                uid: `${Date.now()}_${index}`,
                name: attachment.url?.split('/').pop() || 'file.png',
                url: attachment.url,
            })) || [];

            setFileList(taskAttachmentsLive);

            setTasksValues((prev) => ({
                ...prev,
                [appKeys.taskAttachments]: taskAttachmentsLive,
            }));
            setSelectedClient(tasksData[appKeys.clientName]);

        }
    }, []);

    const resetTaskValues = () => {
        setTasksValues(defaultTaskValues);
        form.resetFields();
        if (containerRef.current) {
            containerRef.current.scrollTop = 0;
        }
    };

    const handleEditCancel = () => {
        setIsModelOpen(false);
        setIsEditing(false);
        resetTaskValues();
    };

    const handleProjectFieldChange = (changedValues, allValues) => {
        projectForm.setFieldsValue(allValues);
        setProjectValues((prev) => ({
            ...prev,
            [appKeys.clientName]: allValues[appKeys.clientName],
            [appKeys.projectName]: allValues[appKeys.projectName],
            [appKeys.projectDescription]: allValues[appKeys.projectDescription],
            [appKeys.teamMembers]: [getUserById(employeeList, getLocalData(loginDataKeys._id))],
        }));
    };

    const handleFieldChange = (changedValues, allValues) => {
        form.setFieldsValue(allValues);
        if (isEditing) {
            setTasksValues((prev) => ({
                ...prev,
                [appKeys.clientName]: allValues[appKeys.clientName],
                [appKeys.projectName]: allValues[appKeys.projectName],
                [appKeys.taskTitle]: allValues[appKeys.taskTitle],
                [appKeys.taskDescription]: allValues[appKeys.taskDescription],
            }));
        } else {
            setTasksValues((prev) => ({
                ...prev,
                [appKeys.clientName]: allValues[appKeys.clientName],
                [appKeys.projectName]: allValues[appKeys.projectName],
                [appKeys.taskTitle]: allValues[appKeys.taskTitle],
                [appKeys.taskDescription]: allValues[appKeys.taskDescription],
                [appKeys.taskAddedBy]: getLocalData(loginDataKeys._id),
            }));
        }
    };

    const handleSelectUser = (user) => {

        if (!tasksValues.taskAssignee.some((u) => u.userId === user.userId)) {
            setTasksValues((prev) => ({
                ...prev,
                taskAssignee: [...prev.taskAssignee, user],
            }));
        }
    };

    const handleRemoveUser = (userId) => {
        setTasksValues((prev) => ({
            ...prev,
            taskAssignee: prev.taskAssignee.filter((user) => user.userId !== userId),
        }));
    };

    const menu = {
        items: employeeList.map((user) => ({
            key: user._id,
            label: (
                <div
                    onClick={() => handleSelectUser(user)}
                    style={{display: "flex", alignItems: "center", gap: "10px"}}
                >
                    <Avatar src={user.profilePhoto || imagePaths.profile_placeholder} size="small"/>
                    {user.fullName}
                </div>
            ),
        })),
    };

    const handleAddUpdateProjectApi = async () => {
        try {
            setIsButtonLoading(true);
            await projectForm.validateFields([appKeys.projectName, appKeys.clientName]);

            await apiCall({
                method: HttpMethod.POST,
                url: !isEditing ? endpoints.updateProject : `${endpoints.updateProject}/${projectData["_id"]}`,
                data: projectValues,
                setIsLoading: setIsButtonLoading,
                successCallback: (data) => {
                    setProjectData(data.data);
                    setClientRecord(data.clients);
                    setIsAddProjectOpen(false);
                    setProjectValues({});
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsButtonLoading(false);
        }
    };

    const handleAddUpdateTaskApi = async () => {
        try {
            setIsLoading(true);
            await form.validateFields([
                appKeys.clientName,
                appKeys.taskTitle,
                appKeys.taskDescription,
                appKeys.taskStartDate,
                appKeys.taskEndDate,
            ]);

            let uploadedAttachments = [];

            if (newFileList.length > 0) {

                const formData = new FormData();
                newFileList.forEach((file) => {
                    formData.append("taskAttachment", file);
                });

                await apiCall({
                    method: HttpMethod.POST,
                    url: endpoints.uploadFiles,
                    data: formData,
                    isMultipart: true,
                    setIsLoading: setIsLoading,
                    successCallback: (data) => {
                        if (data.data) {
                            uploadedAttachments = data.data;
                        }
                    },
                });
            }

            const existingAttachments = tasksValues[appKeys.taskAttachments] || [];
            const allAttachments = [...existingAttachments, ...uploadedAttachments];


            const finalTaskData = {
                ...tasksValues,
                [appKeys.projectName]: tasksValues[appKeys.projectName] || "",
                // [appKeys.taskStartDate]: tasksValues[appKeys.taskStartDate] ? dayjs(tasksValues[appKeys.taskStartDate]) : null,
                // [appKeys.taskEndDate]: tasksValues[appKeys.taskEndDate] ? dayjs(tasksValues[appKeys.taskEndDate]) : null,
                [appKeys.taskAttachments]: allAttachments,
            };

            await apiCall({
                method: HttpMethod.POST,
                url: !isEditing
                    ? endpoints.updateTask
                    : `${endpoints.updateTask}/${tasksData["_id"]}`,
                data: finalTaskData,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    handleEditCancel();
                    onSuccessCallback(data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleClickShowHistory = () => {
        setShowHistoryModel(true);
    }

    const handleCloseShowHistory = () => {
        setShowHistoryModel(false);
    }

    var __awaiter =
        (this && this.__awaiter) ||
        function (thisArg, _arguments, P, generator) {
            function adopt(value) {
                return value instanceof P
                    ? value
                    : new P(function (resolve) {
                        resolve(value);
                    });
            }

            return new (P || (P = Promise))(function (resolve, reject) {
                function fulfilled(value) {
                    try {
                        step(generator.next(value));
                    } catch (e) {
                        reject(e);
                    }
                }

                function rejected(value) {
                    try {
                        step(generator['throw'](value));
                    } catch (e) {
                        reject(e);
                    }
                }

                function step(result) {
                    result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
                }

                step((generator = generator.apply(thisArg, _arguments || [])).next());
            });
        };

    const getBase64 = file =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });

    const handlePreview = file =>
        __awaiter(void 0, void 0, void 0, function* () {
            if (!file.url && !file.preview) {
                file.preview = yield getBase64(file.originFileObj);
            }
            setPreviewImage(file.url || file.preview);
            setPreviewOpen(true);
        });

    const handleChange = ({fileList: newFileList}) => {
        const originFiles = newFileList
            .map(file => file.originFileObj)
            .filter(file => !!file);
        setFileList(newFileList);

        setNewFileList(originFiles);

        const existingAttachments = newFileList.filter(file => file.url); // already uploaded files
        const newAttachments = originFiles;

        setTasksValues((prev) => ({
            ...prev,
            [appKeys.taskAttachments]: existingAttachments,
        }));
    }

    const handleBeforeUpload = (file) => {
        return false;
    };

    const uploadButton = (
        <button style={{border: 0, background: 'none'}} type="button">
            <PlusOutlined/>
            <div style={{marginTop: 8}}>Upload</div>
        </button>
    );

    const formUi = () => {
        return (
            <>
                {isLoading ? <Loader/> : ""}
                <Column justifyContent="center" alignItems="center">
                    <Form
                        form={form}
                        name="EmpAddUpdateModel"
                        layout="vertical"
                        onValuesChange={handleFieldChange}
                        style={{
                            marginTop: 15,
                            marginRight: 10,
                            alignContent: "center",
                            overflowX: "hidden",
                        }}
                    >
                        <WrapBox>
                            <Form.Item name={appKeys.clientName}
                                       label={appString.clientName} rules={[
                                {
                                    required: true,
                                    message: "Client Selection Required"
                                }
                            ]}>
                                <Select
                                    placeholder="Select Client"
                                    allowClear
                                    style={{height: '40px'}}
                                    showSearch
                                    value={selectedClient}
                                    onChange={(value) => {
                                        setSelectedClient(value);
                                        form.setFieldsValue({[appKeys.projectName]: undefined}); // clear project on client change
                                    }}
                                    filterOption={(input, option) =>
                                        option.children.toLowerCase().includes(input.toLowerCase())
                                    }
                                >
                                    {clientRecord.map(client => (
                                        <Option key={client._id} value={client._id}>{client.clientName}</Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item name={appKeys.projectName} label={appString.projectName}
                                       style={{marginBottom: 0}}>
                                <Select
                                    placeholder="Select Project"
                                    disabled={!selectedClient}
                                    style={{height: '40px'}}
                                    showSearch
                                    filterOption={(input, option) =>
                                        option.children.toLowerCase().includes(input.toLowerCase())
                                    }
                                >
                                    {filteredProjects.map(project => (
                                        <Option key={project._id} value={project._id}>
                                            {project.projectName}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            {/*{!isAddProjectOpen ?*/}
                            {/*    <div style={{display: "flex", justifyContent: "end", alignItems: "end"}} span={24}>*/}
                            {/*        <div style={{*/}
                            {/*            // width: "150px",*/}
                            {/*            fontSize: "13px",*/}
                            {/*            fontWeight: "500",*/}
                            {/*            cursor: "pointer",*/}
                            {/*            color: appColor.primary,*/}
                            {/*            margin: "10px 10px 10px 5px",*/}
                            {/*            textAlign: "end"*/}
                            {/*        }} onClick={() => {*/}
                            {/*            setIsAddProjectOpen(!isAddProjectOpen);*/}
                            {/*            setProjectValues({});*/}
                            {/*            projectForm.resetFields();*/}
                            {/*        }}>Add New Project*/}
                            {/*        </div>*/}
                            {/*    </div> : null}*/}
                            {isAddProjectOpen ? <div className={"addProjectBox"} span={24}>
                                <Form
                                    form={projectForm}
                                    name="ProjectModel"
                                    layout="vertical"
                                    onValuesChange={handleProjectFieldChange}
                                >
                                    <WrapBox>
                                        <div style={{
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            marginBottom: 10
                                        }} span={24}>
                                            <div style={{
                                                fontSize: "13px",
                                                fontWeight: "600",
                                                color: appColor.primary
                                            }}>Add New Project
                                            </div>
                                            <div>
                                                <X style={{cursor: "pointer"}} size={20} onClick={() => {
                                                    setIsAddProjectOpen(!isAddProjectOpen);
                                                    setProjectValues({});
                                                    projectForm.resetFields();
                                                }}/>
                                            </div>
                                        </div>
                                        <AppTextFormField
                                            name={appKeys.clientName}
                                            label={appString.clientName}
                                            type={InputType.Text}
                                            isRequired={true}
                                            placeholder={appString.clientName}
                                            value={tasksValues[appKeys.clientName]}
                                            span={12}
                                        />
                                        <AppTextFormField
                                            name={appKeys.projectName}
                                            label={appString.projectName}
                                            type={InputType.Text}
                                            isRequired={true}
                                            placeholder={appString.projectName}
                                            value={tasksValues[appKeys.projectName]}
                                            span={12}
                                        />
                                        <AppTextFormField
                                            name={appKeys.projectDescription}
                                            label={appString.projectDescription}
                                            type={InputType.TextArea}
                                            placeholder={appString.projectDescription}
                                            value={tasksValues[appKeys.projectDescription]}
                                            span={24}
                                        />
                                        <div span={24} style={{display: "flex", justifyContent: "flex-end"}}>
                                            <Button type={"primary"} loading={isButtonLoading} onClick={() => {
                                                handleAddUpdateProjectApi();
                                            }}>Save Project</Button>
                                        </div>
                                    </WrapBox>
                                </Form>
                            </div> : null}
                            <AppTextFormField
                                name={appKeys.taskTitle}
                                label={appString.taskTitle}
                                type={InputType.Text}
                                isRequired={true}
                                placeholder={appString.taskTitle}
                                value={tasksValues[appKeys.taskTitle]}
                                span={24}
                            />
                            <AppTextFormField
                                name={appKeys.taskDescription}
                                label={appString.taskDescription}
                                type={InputType.TextArea}
                                isRequired={true}
                                minRows={4}
                                placeholder={appString.taskDescription}
                                value={tasksValues[appKeys.taskDescription]}
                                span={24}
                            />
                            <Column span={24}>
                                <div className="categoryAssigneeRow">
                                    <AppText
                                        text={`Fields:`}
                                        fontSize={15}
                                        fontWeight={500}
                                        color={appColor.black}
                                    />
                                    {
                                        getLocalData(loginDataKeys.role) === UserRole.Admin && tasksData.taskHistory && tasksData.taskHistory.length > 0 ? (
                                            <div className="showHistoryBtn" onClick={handleClickShowHistory}>
                                                🔍 Show History
                                            </div>
                                        ) : null
                                    }
                                </div>
                                <SpaceBox space={3}/>
                                <div className="taskFieldContainer">
                                    <div className="taskFieldRow">
                                        <div className="taskFieldLabel">
                                            📌 Task Status
                                        </div>
                                        <div className="taskFieldValue">
                                            <Dropdown menu={{
                                                items: taskColumnStatusLabel, onClick: ({key}) => {
                                                    setTasksValues((prev) => ({...prev, [appKeys.taskStatus]: key}));
                                                }
                                            }} trigger={["click"]}>
                                                <div
                                                    className="taskFieldValueSelectorItem">{getLabelByKey(tasksValues[appKeys.taskStatus], taskColumnStatusLabel)}</div>
                                            </Dropdown>
                                        </div>
                                    </div>
                                    <div className="taskFieldRow">
                                        <div className="taskFieldLabel">
                                            ⏳ Task Start/End
                                        </div>
                                        <div className="taskFieldValue">
                                            <Form.Item
                                                className="custom-form-item"
                                                name={appKeys.taskStartDate}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: "Start date is required",
                                                    },
                                                ]}
                                                style={{marginBottom: "0px"}}
                                            >
                                                <DatePicker
                                                    className="taskFieldValueSelectorItem"
                                                    format={"DD-MM-YYYY hh:mm:ss A"}
                                                    showTime={
                                                        {
                                                            format: "HH:mm",
                                                        }
                                                    }
                                                    // use12Hours
                                                    placeholder="Start Date"
                                                    value={tasksValues[appKeys.taskStartDate] ? dayjs(tasksValues[appKeys.taskStartDate], 'DD-MM-YYYY hh:mm:ss A') : null}
                                                    onChange={(time, timeString) => {
                                                        setTasksValues((prev) => ({
                                                            ...prev,
                                                            [appKeys.taskStartDate]: timeString
                                                        }));
                                                    }}
                                                />
                                            </Form.Item>

                                            <Form.Item
                                                className="custom-form-item"
                                                name={appKeys.taskEndDate}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: "End date is required",
                                                    },
                                                ]}
                                                style={{marginBottom: "0px"}}
                                            >
                                                <DatePicker
                                                    className="taskFieldValueSelectorItem"
                                                    format={"DD-MM-YYYY hh:mm:ss A"}
                                                    showTime={
                                                        {
                                                            format: "HH:mm",
                                                        }
                                                    }
                                                    // use12Hours
                                                    placeholder="End Date"
                                                    value={tasksValues[appKeys.taskEndDate] ? dayjs(tasksValues[appKeys.taskEndDate], 'DD-MM-YYYY hh:mm:ss A') : null}
                                                    onChange={(time, timeString) => {
                                                        setTasksValues((prev) => ({
                                                            ...prev,
                                                            [appKeys.taskEndDate]: timeString
                                                        }));
                                                    }}
                                                />
                                            </Form.Item>
                                        </div>
                                    </div>
                                    {/*<div className="taskFieldRow">*/}
                                    {/*    <div className="taskFieldLabel">*/}
                                    {/*        🏷️ Labels*/}
                                    {/*    </div>*/}
                                    {/*    <div className="taskFieldValue">*/}
                                    {/*        <Dropdown menu={{*/}
                                    {/*            items: taskStatusLabel, onClick: ({key}) => {*/}
                                    {/*                setTasksValues((prev) => ({...prev, [appKeys.taskLabels]: key}));*/}
                                    {/*            }*/}
                                    {/*        }} trigger={["click"]}>*/}
                                    {/*            <div*/}
                                    {/*                className="taskFieldValueSelectorItem">{getLabelByKey(tasksValues[appKeys.taskLabels], taskStatusLabel)}</div>*/}
                                    {/*        </Dropdown>*/}
                                    {/*    </div>*/}
                                    {/*</div>*/}
                                    <div className="taskFieldRow">
                                        <div className="taskFieldLabel">
                                            👥 Assignees
                                        </div>
                                        <div className="taskFieldValue">
                                            <div style={{display: "flex", alignItems: "center", gap: "5px"}}>
                                                {tasksValues[appKeys.taskAssignee].map((user) => {
                                                    return (user && user.userId ? <Tooltip key={user.userId}
                                                                                           title={getUserById(employeeList, user.userId)?.fullName || "Unknown User"}>
                                                        <div style={{
                                                            position: "relative",
                                                            display: "inline-block"
                                                        }}>
                                                            {/* <Avatar src={user.profilePhoto || imagePaths.profile_placeholder} /> */}
                                                            <Avatar
                                                                src={user.profilePhoto || null}
                                                                style={{
                                                                    backgroundColor: appColor.primaryTrans,
                                                                    color: appColor.primary,
                                                                    fontWeight: "600",
                                                                    border: "none"
                                                                }}
                                                            >
                                                                {getTwoCharacterFromName(user.fullName)}
                                                            </Avatar>
                                                            {
                                                                user.userId !== tasksValues.taskAddedBy ? (
                                                                    <CloseCircleOutlined
                                                                        onClick={() => handleRemoveUser(user.userId)}
                                                                        style={{
                                                                            position: "absolute",
                                                                            top: 0,
                                                                            right: 0,
                                                                            fontSize: "13px",
                                                                            color: "red",
                                                                            cursor: "pointer",
                                                                            background: "white",
                                                                            borderRadius: "50%",
                                                                        }}
                                                                    />
                                                                ) : null
                                                            }
                                                        </div>
                                                    </Tooltip> : null);
                                                })}
                                                {
                                                    <Dropdown menu={menu} trigger={["click"]} dropdownRender={menu => (
                                                        <div style={{maxHeight: '200px', overflowY: 'auto'}}>
                                                            {menu}
                                                        </div>
                                                    )}>
                                                        <Button shape="circle" icon={<PlusOutlined/>}/>
                                                    </Dropdown>
                                                }
                                            </div>
                                        </div>
                                    </div>
                                    <div className="taskFieldRow">
                                        <div className="taskFieldLabel">
                                            🔥 Priority
                                        </div>
                                        <div className="taskFieldValue">
                                            <Dropdown menu={{
                                                items: taskPriorityLabel, onClick: ({key}) => {
                                                    setTasksValues((prev) => ({...prev, [appKeys.taskPriority]: key}));
                                                }
                                            }} trigger={["click"]}>
                                                <div
                                                    className="taskFieldValueSelectorItem">{getIconByKey(tasksValues[appKeys.taskPriority], taskPriorityLabel)}{getLabelByKey(tasksValues[appKeys.taskPriority], taskPriorityLabel)}</div>
                                            </Dropdown>
                                        </div>
                                    </div>
                                    <div className="taskFieldRow">
                                        <div className="taskFieldLabel">
                                            📂 Category
                                        </div>
                                        <div className="taskFieldValue">
                                            <Dropdown menu={{
                                                items: taskCategoryLabel, onClick: ({key}) => {
                                                    setTasksValues((prev) => ({...prev, [appKeys.taskCategory]: key}));
                                                }
                                            }} trigger={["click"]}>
                                                <div
                                                    className="taskFieldValueSelectorItem">{getLabelByKey(tasksValues[appKeys.taskCategory], taskCategoryLabel)}</div>
                                            </Dropdown>
                                        </div>
                                    </div>
                                    {/*<div className="taskFieldRow">*/}
                                    {/*    <div className="taskFieldLabel">*/}
                                    {/*        ⏱️ Estimated Time*/}
                                    {/*    </div>*/}
                                    {/*    <div className="taskFieldValue">*/}
                                    {/*        <TimePicker*/}
                                    {/*            className="taskFieldValueSelectorItem"*/}
                                    {/*            defaultValue={tasksValues[appKeys.taskEstimatedTime] ? dayjs(tasksValues[appKeys.taskEstimatedTime], 'HH:mm') : null}*/}
                                    {/*            format={'HH:mm'}*/}
                                    {/*            showNow={false}*/}
                                    {/*            onChange={(time, timeString) => {*/}
                                    {/*                setTasksValues((prev) => ({*/}
                                    {/*                    ...prev,*/}
                                    {/*                    [appKeys.taskEstimatedTime]: timeString*/}
                                    {/*                }));*/}
                                    {/*            }}*/}
                                    {/*            placeholder="Duration"/>*/}
                                    {/*    </div>*/}
                                    {/*</div>*/}
                                    {isEditing ? <div className="taskFieldRow">
                                        <div className="taskFieldLabel">
                                            📅 Created At
                                        </div>
                                        <div className="taskFieldValue">
                                            <div style={{
                                                fontSize: "12px",
                                                fontWeight: "500",
                                                fontStyle: "italic"
                                            }}>{dayjs(tasksValues["createdAt"]).format("DD, MMM YYYY [at] hh:mm A")}</div>
                                        </div>
                                    </div> : null}
                                    <div className="taskFieldRow" style={{borderBottom: "none"}}>
                                        <div className="taskFieldLabel">📑 Attachment</div>
                                        <div className="taskFieldValue">
                                            <div className="taskFieldValueAttachment">
                                                <Upload
                                                    key={"image"}
                                                    listType="picture-card"
                                                    fileList={fileList}
                                                    beforeUpload={handleBeforeUpload}
                                                    onPreview={handlePreview}
                                                    onChange={handleChange}
                                                    multiple
                                                >
                                                    {uploadButton}
                                                </Upload>
                                                {previewImage && (
                                                    <Image
                                                        wrapperStyle={{display: 'none'}}
                                                        preview={{
                                                            visible: previewOpen,
                                                            onVisibleChange: visible => setPreviewOpen(visible),
                                                            afterOpenChange: visible => !visible && setPreviewImage(''),
                                                        }}
                                                        src={previewImage}
                                                    />
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Column>
                        </WrapBox>
                    </Form>
                    <SpaceBox space="5px"/>
                </Column>
            </>
        );
    };

    const handleDeleteTaskApi = () => {
        deleteTaskApi({
            id: tasksData._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                handleEditCancel();
                onSuccessCallback(data);
            },
        });
    };

    return (
        <>
            {isModelOpen && (
                <Modal
                    title={isEditing ? "Edit Task" : "Add Task"}
                    maskClosable={false}
                    centered
                    open={isModelOpen}
                    width={700}
                    footer={
                    <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", gap: "10px"}}>
                        {isEditing && getLocalData(loginDataKeys.role) === UserRole.Admin && (
                            <Tooltip title="Delete Task">
                                <Popconfirm
                                    title={appString.deleteConfirmation}
                                    onConfirm={handleDeleteTaskApi}
                                    style={{margin: "0"}}
                                >
                                    <Button color="danger" variant="solid">
                                        Delete
                                    </Button>
                                </Popconfirm>
                            </Tooltip>
                        )}
                        <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", gap: "10px"}}>
                            <Button color="default" variant="outlined" onClick={handleEditCancel}>
                                Cancel
                            </Button>
                            <Button color="primary" variant="solid" onClick={handleAddUpdateTaskApi}>
                                Save
                            </Button>
                        </div>
                    </div>
                    }
                    // onOk={() => {
                    //     handleAddUpdateTaskApi();
                    // }}
                    onCancel={handleEditCancel}
                    onClose={handleEditCancel}
                    okText={"Save"}
                >
                    {
                        <div
                            className="container-with-scrollbar"
                            ref={containerRef}
                            style={{
                                width: "100%",
                                maxHeight: "75vh",
                                overflow: "auto",
                                alignItems: "center",
                            }}
                        >
                            {formUi()}
                        </div>
                    }
                </Modal>
            )
            }
            {showHistoryModel && (
                <Modal
                    title="Task History"
                    maskClosable={false}
                    centered
                    open={showHistoryModel}
                    width={500}
                    onOk={() => {
                        handleClickShowHistory();
                    }}
                    onCancel={handleCloseShowHistory}
                    onClose={handleCloseShowHistory}
                    okText={"Save"}
                    footer={null}
                >
                    {
                        <div
                            className="container-with-scrollbar"
                            ref={containerRef}
                            style={{
                                maxHeight: "75vh",
                                overflowY: "auto",
                                alignItems: "center",
                            }}
                        >
                            <TaskHistory taskHistory={tasksData.taskHistory} employeeList={employeeList}/>
                        </div>
                    }
                </Modal>
            )
            }
        </>
    );
}

const formatDate = (date) => {
    return dayjs(date).format('DD-MM-YYYY HH:mm:ss');
};

const stageWiseColor = (stage) => {
    switch (stage) {
        case taskColumnLabel.ToDo:
            return appColor.primary;
        case taskColumnLabel.InProgress:
            return appColor.info;
        case taskColumnLabel.Testing:
            return appColor.warning;
        case taskColumnLabel.OnHold:
            return appColor.secondary;
        case taskColumnLabel.Completed:
            return appColor.success;
        case taskColumnLabel.Reopened:
            return appColor.danger;
        default:
            return "#FFFFFF";
    }
};

const priorityWiseColor = (priorityKey) => {
    const priority = taskPriorityLabel.find((p) => p.key === priorityKey);
    return priority ? priority.color : "#FFFFFF";
};

const TaskHistory = ({taskHistory, employeeList}) => {
    const groupedHistory = [];

    taskHistory.forEach((historyItem, index) => {
        if (index === 0 || historyItem.changedBy !== taskHistory[index - 1].changedBy) {
            groupedHistory.push({
                user: getUserById(employeeList, historyItem.changedBy),
                changes: [historyItem],
            });
        } else {
            groupedHistory[groupedHistory.length - 1].changes.push(historyItem);
        }
    });

    return (
        <div className="task-history-container">
            {groupedHistory.map((group, index) => {
                return (
                    <div key={index} className="task-history-group">
                        {group.user ? <div style={{display: "flex", alignItems: "center", gap: "10px"}}>
                            {
                                group.user.profilePhoto ? <Avatar src={group.user.profilePhoto}/> :
                                    <Avatar style={{
                                        backgroundColor: appColor.primary,
                                        color: appColor.white
                                    }}>{getTwoCharacterFromName(group.user.fullName)}</Avatar>
                            }
                            <div className="taskCardTitle">
                                <strong>{group.user.fullName}</strong> made {group.changes.length} changes<br/>{}</div>
                        </div> : null}
                        <div className="statusMainRow">
                            {group.changes.map((change, i) => {

                                if (change.fieldName === appKeys.taskTitle) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Title: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskDescription) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Description: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskStartDate) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Start Date: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskEndDate) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>End Date: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskEstimatedTime) {
                                    return (
                                        <div>
                                            <div className="statusRow" key={i}>
                                                <strong>Estimated Time: </strong>
                                                <span className="d-inline">
                        Change from "<em>{change.oldValue}</em>" to "<em>{change.newValue}</em>"
                      </span>
                                            </div>
                                            <div className="timeRow">
                                                at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskStatus) {
                                    const oldLabel = getLabelByKey(change.oldValue, taskColumnStatusLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskColumnStatusLabel);
                                    const oldLabelColor = `${stageWiseColor(oldLabel)}`;
                                    const newLabelColor = `${stageWiseColor(newLabel)}`;

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Status: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${oldLabelColor}20`,
                                                    color: oldLabelColor,
                                                    fontSize: "12px"
                                                }}>{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${newLabelColor}20`,
                                                    color: newLabelColor,
                                                    fontSize: "12px"
                                                }}>{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskCategory) {
                                    const oldLabel = getLabelByKey(change.oldValue, taskCategoryLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskCategoryLabel);

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Category: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.danger}20`,
                                                    color: appColor.danger,
                                                    fontSize: "12px"
                                                }}>{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.success}20`,
                                                    color: appColor.success,
                                                    fontSize: "12px"
                                                }}>{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskPriority) {
                                    const oldLabelIcon = getIconByKey(change.oldValue, taskPriorityLabel);
                                    const newLabelIcon = getIconByKey(change.newValue, taskPriorityLabel);
                                    const oldLabel = getLabelByKey(change.oldValue, taskPriorityLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskPriorityLabel);
                                    const oldLabelColor = priorityWiseColor(change.oldValue);
                                    const newLabelColor = priorityWiseColor(change.newValue);

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Priority: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${oldLabelColor}20`,
                                                    color: oldLabelColor,
                                                    fontSize: "12px"
                                                }}>{oldLabelIcon}{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${newLabelColor}20`,
                                                    color: newLabelColor,
                                                    fontSize: "12px"
                                                }}>{newLabelIcon}{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }

                                if (change.fieldName === appKeys.taskLabels) {
                                    const oldLabel = getLabelByKey(change.oldValue, taskStatusLabel);
                                    const newLabel = getLabelByKey(change.newValue, taskStatusLabel);

                                    return (
                                        <div>
                                            <div className="statusRow" key={i}><strong>Label: </strong>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.danger}20`,
                                                    color: appColor.danger,
                                                    fontSize: "12px"
                                                }}>{oldLabel}</Tag>
                                                <div style={{marginRight: "10px"}}>→</div>
                                                <Tag style={{
                                                    backgroundColor: `${appColor.success}20`,
                                                    color: appColor.success,
                                                    fontSize: "12px"
                                                }}>{newLabel}</Tag>
                                            </div>
                                            <div className="timeRow">
                                                Changed at {formatDate(change.changeTime)}
                                            </div>
                                        </div>
                                    );
                                }
                            })}
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

