import React, {useEffect, useRef, useState} from "react";
import {DragDropContext, Droppable, Draggable} from "@hello-pangea/dnd";
import imagePaths from "../../assets/assetsPaths";
import {
    Tag as TagIcon,
    Calendar,
    Check,
    ChevronsUp,
    Filter,
    Plus,
    ShoppingCart,
    User,
    Search,
    XCircle, CheckCircle, Edit, Trash2, Eye, ToggleLeft, ToggleRight
} from "react-feather";
import appColor from "../../utils/appColors";
import {
    Avatar,
    Button, Checkbox,
    DatePicker,
    Divider, Form, Modal,
    Popconfirm,
    Popover,
    Select,
    Spin,
    Switch,
    Table,
    Tag,
    Tooltip
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    ApprovalStatus,
    getLabelByKey, leaveCategoryLabel, leaveLabelKeys, leaveTypeLabel,
    projectTypeLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
} from "../../utils/enum";
import {CalendarOutlined, CheckOutlined, UserOutlined} from "@ant-design/icons";
import dayjs from "dayjs";
import {
    deleteBasicSalaryApi,
    deleteProjectApi,
    deleteUserApi,
    getBasicSalaryList,
    getProjectList,
    getTasksList,
    getUsersList
} from "../../api/apiUtils";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import {UserRole} from './../../utils/enum';
import {SearchTextField} from "../../components/formField/DynamicForm";
import {convertCamelCase, decryptValue, useIsMobileView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import BasicSalaryAddUpdateModel from "../../model/BasicSalaryAddUpdateModel";
import {antTag, colorTag} from "../../common/colorTag";
import WrapBox from "../../components/common/WrapBox";
import AppTextFormField, {InputType} from "../../components/common/AppTextFormField";

const {Option} = Select;
const {RangePicker} = DatePicker;

const BasicSalaryPage = () => {

    const [isShowAmounts, setIsShowAmounts] = useState(false);
    const [isAddBasicSalaryModelOpen, setAddBasicSalaryModelOpen] = useState(false);
    const [isBasicSalaryEditing, setIsBasicSalaryEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [basicSalaryRecord, setBasicSalaryRecord] = useState([]);
    const [basicSalaryFullRecord, setBasicSalaryFullRecord] = useState([]);
    const [selectedBasicSalaryRecord, setSelectedBasicSalaryRecord] = useState({});
    const [employeeRecord, setEmployeeRecord] = useState([]);

    useEffect(() => {
        getEmployeeData();
        getBasicSalaryData();
    }, []);

    const getEmployeeData = () => {
        getUsersList({
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                const filteredEmployees = data["data"].filter(
                    (record) =>
                        record.approvalStatus === ApprovalStatus.Approved ||
                        record.isActive
                );

                const selectedFields = filteredEmployees.map((employee) => ({
                    userId: employee._id,
                    fullName: employee.fullName,
                    emailAddress: employee.emailAddress,
                    profilePhoto: employee.profilePhoto,
                }));

                setEmployeeRecord(selectedFields);
            },
        });
    };

    const getBasicSalaryData = () => {
        getBasicSalaryList({
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                handleDataConditionWise(data.data);
            },
        });
    };

    const handleDataConditionWise = (data) => {
        setBasicSalaryRecord(data);
        setBasicSalaryFullRecord(data);
    };

    const handleBasicSalaryAddClick = () => {
        setAddBasicSalaryModelOpen(true);
        setSelectedBasicSalaryRecord({});
    };

    const handleEditClick = (value) => {
        setIsBasicSalaryEditing(true);
        setSelectedBasicSalaryRecord(value);
        setAddBasicSalaryModelOpen(true);
    };

    const handleDeleteBasicSalaryApi = async (event) => {
        deleteBasicSalaryApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddBasicSalaryModelOpen(false);
                setBasicSalaryRecord(data.data);
                setBasicSalaryFullRecord(data.data);
            },
        });
    };

    const leaveTableColumn = [
        {
            title: appString.fullName,
            dataIndex: appKeys.user,
            key: 'user.fullName',
            render: (text, record) => record.user ? record.user.fullName : '',
        },
        {
            title: appString.basicSalary,
            dataIndex: appKeys.basicSalary,
            key: appKeys.basicSalary,
            render: (basicSalary) => {
                return antTag(!isShowAmounts ? "***" : decryptValue(basicSalary), "green");
            },
        },
        {
            title: appString.code,
            dataIndex: appKeys.code,
            key: appKeys.code,
            render: (code) => {
                return antTag(!isShowAmounts ? "***" : code, "blue");
            },
        },
        {
            title: appString.startDate,
            dataIndex: appKeys.startDate,
            key: appKeys.startDate,
            render: (startDate) => {
                return startDate ? dayjs(startDate).format("YYYY-MM-DD") : '-';
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            hidden: getLocalData(loginDataKeys.role) !== UserRole.Admin,
            render: (_, record) => {
                return employeeRecord?.length >= 1 ? (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            <div
                                style={{marginRight: 25, cursor: "pointer"}}
                                onClick={() => handleEditClick(record)}
                            >
                                <Tooltip title={appString.edit}>
                                    <Edit className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                            <Popconfirm
                                title={appString.deleteConfirmation}
                                onConfirm={() => handleDeleteBasicSalaryApi(record)}
                                style={{margin: "0"}}
                            >
                                <div style={{marginRight: 25, cursor: "pointer"}}>
                                    <Tooltip title={appString.delete} placement="bottom">
                                        <Trash2 className="deleteIconStyle"/>
                                    </Tooltip>
                                </div>
                            </Popconfirm>
                        </div>
                    </>
                ) : null;
            },
        },
    ];

    const extrafieldCommon = (title, value) => {
        return value ? <div className="extraFieldRow">
            <div className="extraFieldRowTitle">{title}:</div>
            <div className="extraFieldRowValue">{value}</div>
        </div> : null;
    }

    return (
        <>
            {isLoading ? (
                <div
                    style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                    }}
                >
                    <Spin tip="Loading"/>
                </div>
            ) : (
                <div className="taskBoardContainer">
                    <div className="taskBoardHeader">
                        <div className="taskheaderTitle">Basic Salary List</div>
                        <div className="taskheaderManageSection">
                            {/*<SearchTextField*/}
                            {/*    field={{*/}
                            {/*        name: "search",*/}
                            {/*        placeholder: "Search BasicSalary",*/}
                            {/*        prefix: <Search/>,*/}
                            {/*        style: {margin: 0, width: "300px", height: "38px"},*/}
                            {/*        onChange: (e) => {*/}
                            {/*            const searchText = e.target.value.toLowerCase();*/}
                            {/*            const filteredData = basicSalaryFullRecord?.filter((record) => {*/}
                            {/*                return (*/}
                            {/*                    record.projectId?.toLowerCase().includes(searchText) ||*/}
                            {/*                    record.projectName?.toLowerCase().includes(searchText) ||*/}
                            {/*                    record.projectDescription?.toLowerCase().includes(searchText) ||*/}
                            {/*                    record.clientName?.toLowerCase().includes(searchText) ||*/}
                            {/*                    record.projectType?.toLowerCase().includes(searchText) ||*/}
                            {/*                    record.tags?.toLowerCase().includes(searchText)*/}
                            {/*                );*/}
                            {/*            });*/}
                            {/*            setBasicSalaryRecord(filteredData);*/}
                            {/*        },*/}
                            {/*    }}*/}
                            {/*/>*/}

                            <Checkbox checked={isShowAmounts} onChange={(e) => setIsShowAmounts(e.target.checked)}>
                                Show Amounts
                            </Checkbox>
                            <div className="addTaskButton" onClick={handleBasicSalaryAddClick}>
                                <Plus className="whiteIconStyle"/>
                                <div>Add Basic Salary</div>
                            </div>
                        </div>
                    </div>
                    <Table
                        rowKey={(record) => record._id}
                        columns={leaveTableColumn}
                        dataSource={basicSalaryRecord}
                        scroll={{x: "max-content"}}
                    />
                </div>
            )}
            {isAddBasicSalaryModelOpen && (
                <BasicSalaryAddUpdateModel
                    isModelOpen={isAddBasicSalaryModelOpen}
                    setIsModelOpen={setAddBasicSalaryModelOpen}
                    employeeList={employeeRecord}
                    basicSalaryData={selectedBasicSalaryRecord}
                    isEditing={isBasicSalaryEditing}
                    setIsEditing={setIsBasicSalaryEditing}
                    onSuccessCallback={(data) => {
                        handleDataConditionWise(data.data);
                    }}
                />
            )}
        </>
    );
};

export default BasicSalaryPage;