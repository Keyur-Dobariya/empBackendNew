import React, {useEffect, useRef, useState} from "react";
import {DragDropContext, Droppable, Draggable} from "@hello-pangea/dnd";
import imagePaths from "../../assets/assetsPaths";
import {
    Tag as TagIcon,
    Calendar,
    Check,
    ChevronsUp,
    Filter,
    Plus,
    ShoppingCart,
    User,
    Search,
    XCircle, CheckCircle, Edit, Trash2, Eye
} from "react-feather";
import appColor from "../../utils/appColors";
import {
    Avatar,
    Button,
    DatePicker,
    Divider,
    Popconfirm,
    Popover,
    Select,
    Spin,
    Switch,
    Table,
    Tag,
    Tooltip
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    ApprovalStatus,
    DateTimeFormat,
    getIconByKey,
    getLabelByKey,
    projectTypeLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
} from "../../utils/enum";
import {CalendarOutlined, CheckOutlined, UserOutlined} from "@ant-design/icons";
import dayjs from "dayjs";
import {
    deleteClientApi,
    deleteProjectApi,
    deleteUserApi,
    getClientList,
    getProjectList,
    getTasksList,
    getUsersList
} from "../../api/apiUtils";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import ProjectAddUpdateModel from "../../model/ProjectAddUpdateModel";
import {UserRole} from './../../utils/enum';
import {SearchTextField} from "../../components/formField/DynamicForm";
import {useIsMobileView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import ClientAddUpdateModel from "../../model/ClientAddUpdateModel";

const {Option} = Select;
const {RangePicker} = DatePicker;

const ClientPage = () => {

    const [isAddClientModelOpen, setAddClientModelOpen] = useState(false);
    const [isClientEditing, setIsClientEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [isTableLoading, setIsTableLoading] = useState(false);
    const [loadingClientId, setLoadingClientId] = useState(null);
    const [clientRecord, setClientRecord] = useState([]);
    const [clientFullRecord, setClientFullRecord] = useState([]);
    const [selectedClientRecord, setSelectedClientRecord] = useState({});
    const [employeeRecord, setEmployeeRecord] = useState([]);

    useEffect(() => {
        getEmployeeData();
        getClientsData();
    }, []);

    const getEmployeeData = () => {
        getUsersList({
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                const filteredEmployees = data["data"].filter(
                    (record) =>
                        record.approvalStatus === ApprovalStatus.Approved ||
                        record.isActive
                );

                const selectedFields = filteredEmployees.map((employee) => ({
                    userId: employee._id,
                    fullName: employee.fullName,
                    emailAddress: employee.emailAddress,
                    profilePhoto: employee.profilePhoto,
                }));

                setEmployeeRecord(selectedFields);
            },
        });
    };

    const getClientsData = () => {
        getClientList({
            setIsLoading: setIsTableLoading,
            successCallback: (data) => {
                handleDataConditionWise(data.data);
            },
        });
    };

    const handleDataConditionWise = (data) => {
        const filteredData = getLocalData(loginDataKeys.role) === UserRole.Admin ? data : data.filter((data) => data.addedBy === getLocalData(loginDataKeys._id));
        setClientRecord(filteredData);
        setClientFullRecord(filteredData);
    };

    const handleAddUpdateTaskApi = async (_id, data) => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.updateClient}/${_id}`,
                data: data,
                setIsLoading: false,
                successCallback: (data) => {
                    handleDataConditionWise(data.data);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        } finally {
            setLoadingClientId(null);
        }
    };

    const handleTaskAddClick = () => {
        setAddClientModelOpen(true);
        setSelectedClientRecord({});
    };

    const handleEditClick = (value) => {
        setIsClientEditing(true);
        setSelectedClientRecord(value);
        setAddClientModelOpen(true);
    };

    const handleDeleteClientApi = async (event) => {
        deleteClientApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddClientModelOpen(false);
                handleDataConditionWise(data.data);
            },
        });
    };

    const projectTableColumn = [
        {
            title: appString.clientName,
            dataIndex: appKeys.clientName,
            key: appKeys.clientName,
        },
        {
            title: appString.createdAt,
            dataIndex: appKeys.createdAt,
            key: appKeys.createdAt,
            render: (createdAt) => {
                return dayjs(createdAt).format("DD, MMM YYYY [at] hh:mm a");
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            render: (_, record) => {
                return employeeRecord?.length >= 1 ? (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            <div
                                style={{marginRight: 25, cursor: "pointer"}}
                                onClick={() => handleEditClick(record)}
                            >
                                <Tooltip title={appString.edit}>
                                    <Edit className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                            <Popconfirm
                                title={appString.deleteConfirmation}
                                onConfirm={() => handleDeleteClientApi(record)}
                                style={{margin: "0"}}
                            >
                                <div style={{marginRight: 25, cursor: "pointer"}}>
                                    <Tooltip title={appString.delete} placement="bottom">
                                        <Trash2 className="deleteIconStyle"/>
                                    </Tooltip>
                                </div>
                            </Popconfirm>
                        </div>
                    </>
                ) : null;
            },
        },
    ];

    return (
        <>
            {isLoading ? (
                <div
                    style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                    }}
                >
                    <Spin tip="Loading"/>
                </div>
            ) : (
                <div className="taskBoardContainer">
                    <div className="taskBoardHeader">
                        <div className="taskheaderTitle">Clients List</div>
                        <div className="taskheaderManageSection">
                            <SearchTextField
                                field={{
                                    name: "search",
                                    placeholder: "Search Client",
                                    prefix: <Search/>,
                                    style: {margin: 0, width: "300px", height: "38px"},
                                    onChange: (e) => {
                                        const searchText = e.target.value.toLowerCase();
                                        const filteredData = clientFullRecord?.filter((record) => {
                                            return (
                                                record.projectId?.toLowerCase().includes(searchText) ||
                                                record.projectName?.toLowerCase().includes(searchText) ||
                                                record.projectDescription?.toLowerCase().includes(searchText) ||
                                                record.clientName?.toLowerCase().includes(searchText) ||
                                                record.projectType?.toLowerCase().includes(searchText) ||
                                                record.tags?.toLowerCase().includes(searchText)
                                            );
                                        });
                                        setClientRecord(filteredData);
                                    },
                                }}
                            />
                            <div className="addTaskButton" onClick={handleTaskAddClick}>
                                <Plus className="whiteIconStyle"/>
                                <div>Add Client</div>
                            </div>
                        </div>
                    </div>
                    <Table
                        columns={projectTableColumn}
                        dataSource={[...clientRecord]}
                        scroll={{x: "max-content"}}
                        loading={isTableLoading}
                    />
                </div>
            )}
            {isAddClientModelOpen && (
                <ClientAddUpdateModel
                    isModelOpen={isAddClientModelOpen}
                    setIsModelOpen={setAddClientModelOpen}
                    employeeList={employeeRecord}
                    clientData={selectedClientRecord}
                    isEditing={isClientEditing}
                    setIsEditing={setIsClientEditing}
                    onSuccessCallback={(data) => {
                        handleDataConditionWise(data.data);
                    }}
                />
            )}
        </>
    );
};

export default ClientPage;