import React, { useEffect, useState } from "react";
import "./Dashboard.css";
import {Col, DatePicker, Row, Skeleton, Table} from "antd";
// import Column from "./../../components/common/Column";
// import Row from "./../../components/common/Row";
import AppText from "../../components/common/AppText";
import appColor from "../../utils/appColors";
import Image from "../../components/common/Image";
import imagePaths from "../../assets/assetsPaths";
import SpaceBox from "../../components/common/SpaceBox";
import Card from "../../components/common/Card";
import {
  empReportTableColumn,
  employeeTableColumn,
} from "../../dataTable/employeeTableColumn";
import { getAllEmployees } from "../../api/apiUtils";
import TrackingComponent from "./TrackingComponent";
import { Grid, GridItem } from "../../components/common/GridSystem";
import Container from "../../components/common/Container";
import { format } from "date-fns";
import Timeline from "../../components/Timeline";
import { ApprovalStatus } from "../../utils/enum";
import apiCall, { HttpMethod } from "../../api/apiServiceProvider";
import { endpoints } from "../../api/apiEndpoints";
import {
  getLocalData,
  loginDataKeys,
  storeLoginData,
} from "../../dataStorage/DataPref";
import EmployeeListContent from "./navContents/EmployeeListContent";
import dayjs from "dayjs";
import {useAppData} from "../../AppDataContext";
import {
  Box,
  Clock,
  FileMinus,
  GitHub,
  Layers,
  Map,
  PenTool,
  PieChart, Pocket,
  Smile,
  UserMinus,
  UserPlus,
  Users
} from "react-feather";
import {isAdmin} from "../../utils/utils";
import {getDarkColor, getLightColor} from "../../utils/colorMapper";
import {UserOutlined} from "@ant-design/icons";
import Column from "../../components/common/Column";
const { RangePicker } = DatePicker;

const Dashboard = () => {
  const [employeeData, setEmployeesData] = useState();
  const [empReportData, setEmpReportData] = useState();
  const [startDate, setStartDate] = useState();
  const [endDate, setEndDate] = useState();
  const [adminDashboardData, setAdminDashboardData] = useState([]);
  const [employeeDashboardData, setEmployeeDashboardData] = useState([]);

  const [attendanceData, setAttendanceData] = useState({});

  const [dateRange, setDateRange] = useState({
    startHour: null,
    endHour: null,
  });

  const [tasks, setTasks] = useState([]);

  const [taskRows, setTaskRows] = useState([]);

  const [startHour, setStartHour] = useState(9);
  const [endHour, setEndHour] = useState(24);
  const [totalHours, setTotalHours] = useState(14);

  const hourWidth = 250;

  const [isLoading, setIsLoading] = useState(false);

  const colors = [
    "#28b463",
    "#a93226",
    "#7d3c98",
    "#2471a3",
    "#2e86c1",
    "#cb4335",
    "#17a589",
    "#884ea0",
    "#138d75",
    "#d4ac0d",
    "#229954",
    "#ca6f1e",
    "#d68910",
    "#273746",
    "#2e4053",
    "#ba4a00",
    "#839192",
    "#707b7c",
    appColor.primary,
  ];

  useEffect(() => {
    getRandomColor();
  }, []);

  const { dashboardData } = useAppData();

  // const { adminDashboard, updateAppDataField } = useAppData();
  //
  // const handleUserUpdate = (newUserData) => {
  //   updateAppDataField("adminDashboard", newUserData);
  //   console.log("updated adminDashboard", adminDashboard)
  // };

  const getRandomColor = () => {
    const randomIndex = Math.floor(Math.random() * colors.length);
    return colors[randomIndex];
  };

  const getTaskPosition = (time) => {
    const date = new Date(time);
    const hours = date.getHours() + date.getMinutes() / 60;
    return (hours - startHour) * hourWidth;
  };

  const getTaskWidth = (start, end) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const duration = (endDate - startDate) / (1000 * 60 * 60);
    return duration * hourWidth;
  };

  const groupedTasks = () => {
    const rows = [];
    let currentRow = [];
    if (!tasks || tasks.length === 0) {
      return rows;
    }

    tasks.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
    currentRow = tasks;
    if (currentRow.length > 0) {
      rows.push(currentRow);
    }
    return rows;
  };

    const getEmployeeData = () => {
      getAllEmployees({
        setIsLoading: setIsLoading,
        successCallback: (data) => {
          const filteredEmployees = data["data"].filter(
            (record) =>
              record.approvalStatus !== ApprovalStatus.Approved ||
              !record.isActive
          );
  
          setEmployeesData(filteredEmployees);
        },
      });
    };

  // const getEmployeeData = () => {
  //   getAllEmployees({
  //     // setEmployeesData: setEmployeesData,
  //     successCallback: (data) => {
  //       // const filteredEmployees = data["data"].filter(
  //       //   (record) => record.approvalStatus === ApprovalStatus.Approved && record.isActive
  //       // );
  //       const filteredEmployees = data["data"].filter(
  //         (record) =>
  //           record.approvalStatus !== ApprovalStatus.Approved ||
  //           !record.isActive
  //       );
  //       // const firstFiveEmployees = data["data"].slice(0, 5);
  //       setEmployeesData(filteredEmployees);
  //     },
  //   });
  // };

  const getEmpReportData = async () => {
    try {
      const baseUrl = `${endpoints.userWiseAttendanceData}${getLocalData(
        loginDataKeys._id
      )}`;
      let queryParams = [];

      if (startDate) {
        queryParams.push(`startDate=${startDate}`);
      }
      if (endDate) {
        queryParams.push(`endDate=${endDate}`);
      }

      const finalUrl =
        queryParams.length > 0
          ? `${baseUrl}?${queryParams.join("&")}`
          : baseUrl;

      await apiCall({
        method: HttpMethod.GET,
        url: finalUrl,
        setIsLoading,
        showSuccessMessage: false,
        successCallback: (data) => {
          setEmpReportData(data["data"]);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  };

  const getAdminDashboardData = async () => {
    try {
      await apiCall({
        method: HttpMethod.GET,
        url: endpoints.adminDashboard,
        setIsLoading,
        showSuccessMessage: false,
        successCallback: (data) => {
          setAdminDashboardData(data["data"]);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  };

  const getEmployeeDashboardData = async () => {
    try {
      await apiCall({
        method: HttpMethod.GET,
        url: `${endpoints.empDashboard}${getLocalData(loginDataKeys._id)}`,
        setIsLoading,
        showSuccessMessage: false,
        successCallback: (data) => {
          setEmployeeDashboardData(data["data"]);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  };

  useEffect(() => {
    if (getLocalData(loginDataKeys.role) === "Admin") {
      getEmployeeData();
      getAdminDashboardData();
    } else {
      getEmployeeDashboardData();
      // getEmpReportData();
    }
  }, []);

  useEffect(() => {
    if (
      attendanceData &&
      attendanceData.tasks &&
      Array.isArray(attendanceData.tasks)
    ) {
      const updatedTasks = attendanceData.tasks.map((task) => {
        const newTask = {
          ...task,
          startTime: new Date(task.startTime).toISOString().slice(0, 16),
          endTime: new Date(task.endTime).toISOString().slice(0, 16),
          color: getRandomColor(), // Assign a random color
        };
        return newTask;
      });
      setTasks(updatedTasks);
    } else {
      setTasks([]);
    }
  }, [attendanceData]);

  useEffect(() => {
    const rows = groupedTasks();
    setTaskRows(rows);
  }, [tasks]);

  useEffect(() => { }, [attendanceData, startHour, endHour, totalHours]);

  useEffect(() => {
    if (getLocalData(loginDataKeys.role) === "Employee") {
      getEmpReportData();
    }
  }, [startDate, endDate]);

  const formatHours = (milliseconds) => {
    const hours = Math.floor(milliseconds / 3600000);
    const minutes = Math.floor((milliseconds % 3600000) / 60000);
    const seconds = Math.floor((milliseconds % 60000) / 1000);
    return `${isNaN(hours) ? 0 : hours}h`;
  };

  const columns = empReportTableColumn();

  const onRangeChange = (dates, dateStrings) => {
    if (dates) {
      setStartDate(dateStrings[0]);
      setEndDate(dateStrings[1]);
      getEmpReportData();
    }
  };

  const rangePresets = [
    {
      label: 'Last 7 Days',
      value: [dayjs().add(-7, 'd'), dayjs()],
    },
    {
      label: 'Last 14 Days',
      value: [dayjs().add(-14, 'd'), dayjs()],
    },
    {
      label: 'Last 30 Days',
      value: [dayjs().add(-30, 'd'), dayjs()],
    },
    {
      label: 'Last 90 Days',
      value: [dayjs().add(-90, 'd'), dayjs()],
    },
  ];

  const commonGridBox = ({title, value, color, icon}) => {
    return (
        <Col xs={12} sm={12} md={8} lg={4}>
          <div className="dashGridBox">
            <div className="dashGridBoxIconRow">
              <div className="dashGridBoxIcon" style={{backgroundColor: color}}>
                {icon}
              </div>
              <div className="dashGridBoxValue" style={{color: color}}>{value}</div>
            </div>
            <div className="dashGridBoxTitle">{title}</div>
          </div>
        </Col>
    );
  }

  return (
    <>
      <div>
        {isAdmin() ? <Row gutter={[16, 16]}>
          {commonGridBox({title: "Total Employees", value: dashboardData.employeeUsers || 0, color: getDarkColor("A"), icon: <Users className="gridBoxIcon"/>})}
          {commonGridBox({title: "Total Admins", value: dashboardData.adminUsers || 0, color: getDarkColor("V"), icon: <Users className="gridBoxIcon"/>})}
          {commonGridBox({title: "Today Present", value: dashboardData.todayPresent || 0, color: getDarkColor("C"), icon: <UserPlus className="gridBoxIcon"/>})}
          {commonGridBox({title: "Today Absent", value: dashboardData.todayAbsent || 0, color: getDarkColor("D"), icon: <UserMinus className="gridBoxIcon"/>})}
          {commonGridBox({title: "No. Of Clients", value: dashboardData.noOfClients || 0, color: getDarkColor("E"), icon: <Smile className="gridBoxIcon"/>})}
          {commonGridBox({title: "No. Of Projects", value: dashboardData.noOfProjects || 0, color: getDarkColor("F"), icon: <GitHub className="gridBoxIcon"/>})}
        </Row> : <Row gutter={[16, 16]}>
          {commonGridBox({title: "Today Working Hours", value: formatHours(employeeDashboardData.todayWorkingHours), color: getDarkColor("A"), icon: <Clock className="gridBoxIcon"/>})}
          {commonGridBox({title: "Weekly Hours", value: formatHours(employeeDashboardData.weeklyHours), color: getDarkColor("V"), icon: <PenTool className="gridBoxIcon"/>})}
          {commonGridBox({title: "Monthly Hours", value: formatHours(employeeDashboardData.monthlyHours), color: getDarkColor("C"), icon: <Layers className="gridBoxIcon"/>})}
          {commonGridBox({title: "Monthly Late Arrival", value: formatHours(employeeDashboardData.monthlyLateArrivalHours), color: getDarkColor("D"), icon: <Pocket className="gridBoxIcon"/>})}
          {commonGridBox({title: "Monthly Overtime Hours", value: formatHours(employeeDashboardData.monthlyOvertimeHours), color: getDarkColor("E"), icon: <Smile className="gridBoxIcon"/>})}
          {commonGridBox({title: "Monthly Absent Count", value: employeeDashboardData.monthlyAbsentCount, color: getDarkColor("F"), icon: <Map className="gridBoxIcon"/>})}
        </Row>
        }
        {/*    <Grid>*/}
        {/*  <GridItem>*/}
        {/*    {boxItem({*/}
        {/*      countText: formatHours(employeeDashboardData.weeklyHours),*/}
        {/*      mainIcon: imagePaths.clockIcon,*/}
        {/*      boxHeader: "Weekly Working Hours",*/}
        {/*      statusIcon: imagePaths.increaseIcon,*/}
        {/*      statusIconColor: appColor.green,*/}
        {/*      dailyStatus: "-10% Less than yesterday",*/}
        {/*    })}*/}
        {/*  </GridItem>*/}
        {/*  <GridItem>*/}
        {/*    {boxItem({*/}
        {/*      countText: formatHours(employeeDashboardData.monthlyHours),*/}
        {/*      mainIcon: imagePaths.absentIcon,*/}
        {/*      boxHeader: "Monthly Working Hours",*/}
        {/*      statusIcon: imagePaths.decreaseIcon,*/}
        {/*      statusIconColor: appColor.red,*/}
        {/*      dailyStatus: "+3% Increase than yesterday",*/}
        {/*    })}*/}
        {/*  </GridItem>*/}
        {/*  <GridItem>*/}
        {/*    {boxItem({*/}
        {/*      countText: formatHours(*/}
        {/*          employeeDashboardData.monthlyLateArrivalHours*/}
        {/*      ),*/}
        {/*      mainIcon: imagePaths.lateArrivalLogo,*/}
        {/*      boxHeader: "Monthly Late Arrival",*/}
        {/*      statusIcon: imagePaths.decreaseIcon,*/}
        {/*      statusIconColor: appColor.red,*/}
        {/*      dailyStatus: "+3% Increase than yesterday",*/}
        {/*    })}*/}
        {/*  </GridItem>*/}
        {/*  <GridItem>*/}
        {/*    {boxItem({*/}
        {/*      countText: formatHours(*/}
        {/*          employeeDashboardData.monthlyOvertimeHours*/}
        {/*      ),*/}
        {/*      mainIcon: imagePaths.earlyLogo,*/}
        {/*      boxHeader: "Monthly Overtime Hours",*/}
        {/*      statusIcon: imagePaths.increaseIcon,*/}
        {/*      statusIconColor: appColor.green,*/}
        {/*      dailyStatus: "-10% Less than yesterday",*/}
        {/*    })}*/}
        {/*  </GridItem>*/}
        {/*</Grid>*/}
        <div style={{ marginTop: "20px" }}>
          {getLocalData(loginDataKeys.role) === "Admin" && (
              <EmployeeListContent
                  isInDashoard={true}
                  formTitle="Approval Pending Employees"
                  empData={employeeData}
              />
          )}
          {getLocalData(loginDataKeys.role) === "Employee" ? (
              <div className="listBox">
                <div style={{justifyContent: "space-between", display: "flex"}}>
                  <AppText
                      text="Your Attendance Report"
                      fontSize={17}
                      fontWeight={550}
                      color={appColor.primary}
                      style={{ margin: "15px 0px 20px 10px" }}
                  />
                  <RangePicker presets={rangePresets} onChange={onRangeChange} style={{ margin: "10px" }} />
                </div>
                <div>
                  <Table
                      columns={columns}
                      dataSource={empReportData}
                      scroll={{
                        x: "max-content",
                      }}
                  />
                </div>
              </div>
          ) : null}
        </div>
      </div>
      {/*<Container margin="10px 0px" padding={"20px 0px"} width={"100%"} maxWidth={"100% !important"} className={"dashboard-container"}>*/}
      {/*  {isLoading ? (*/}
      {/*    <div className="dashboard-container">*/}
      {/*      /!* <Spin size="large" /> *!/*/}
      {/*      <Grid>*/}
      {/*        <GridItem>*/}
      {/*          <Card >*/}
      {/*            <Skeleton className={"skt-card"} active avatar shape/>*/}
      {/*          </Card>*/}
      {/*        </GridItem>*/}
      {/*        <GridItem>*/}
      {/*          <Card>*/}
      {/*            <Skeleton className={"skt-card"} active avatar shape />*/}
      {/*          </Card>*/}
      {/*        </GridItem>*/}
      {/*        <GridItem>*/}
      {/*          <Card>*/}
      {/*            <Skeleton className={"skt-card"} active avatar shape />*/}
      {/*          </Card>*/}
      {/*        </GridItem>*/}
      {/*        <GridItem>*/}
      {/*          <Card>*/}
      {/*            <Skeleton className={"skt-card"} active avatar shape />*/}
      {/*          </Card>*/}
      {/*        </GridItem>*/}
      {/*      </Grid>*/}
      {/*      <div style={{ margin: "13px" }}>*/}
      {/*        <Skeleton.Button active={true} style={{ width: "100%", height: 300, }} block={true} />*/}
      {/*      </div>*/}
      {/*    </div>*/}
      {/*  ) : (*/}
      {/*    <>*/}
      {/*      {getLocalData(loginDataKeys.role) === "Employee" && (*/}
      {/*        <Grid>*/}
      {/*          /!* <GridItem rowspan={2}>*/}
      {/*            <TrackingComponent*/}
      {/*              isElectron={false}*/}
      {/*              trackingData={(trackingData) => {*/}
      {/*                setAttendanceData(trackingData);*/}

      {/*                const backendDate = new Date(trackingData.punchInAt);*/}

      {/*                const startDate = new Date(backendDate);*/}
      {/*                startDate.setHours(*/}
      {/*                  startDate.getHours().toString().padStart(2, "0"),*/}
      {/*                  0,*/}
      {/*                  0,*/}
      {/*                  0*/}
      {/*                );*/}

      {/*                const endDate = new Date(backendDate);*/}
      {/*                endDate.setHours(23, 59, 59, 999);*/}

      {/*                setStartHour(startDate.getHours());*/}
      {/*                setEndHour(endDate.getHours());*/}
      {/*                setTotalHours(endHour - startHour);*/}

      {/*                // getEmpReportData();*/}
      {/*              }}*/}
      {/*            />*/}
      {/*          </GridItem> *!/*/}
      {/*          /!* <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: formatHours(employeeDashboardData.todayWorkingHours),*/}
      {/*              mainIcon: imagePaths.absentIcon,*/}
      {/*              boxHeader: "Today Working Hours",*/}
      {/*              statusIcon: imagePaths.plusIcon,*/}
      {/*              statusIconColor: appColor.green,*/}
      {/*              dailyStatus: "2 new employees added!",*/}
      {/*            })}*/}
      {/*          </GridItem> *!/*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: formatHours(employeeDashboardData.weeklyHours),*/}
      {/*              mainIcon: imagePaths.clockIcon,*/}
      {/*              boxHeader: "Weekly Working Hours",*/}
      {/*              statusIcon: imagePaths.increaseIcon,*/}
      {/*              statusIconColor: appColor.green,*/}
      {/*              dailyStatus: "-10% Less than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: formatHours(employeeDashboardData.monthlyHours),*/}
      {/*              mainIcon: imagePaths.absentIcon,*/}
      {/*              boxHeader: "Monthly Working Hours",*/}
      {/*              statusIcon: imagePaths.decreaseIcon,*/}
      {/*              statusIconColor: appColor.red,*/}
      {/*              dailyStatus: "+3% Increase than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: formatHours(*/}
      {/*                employeeDashboardData.monthlyLateArrivalHours*/}
      {/*              ),*/}
      {/*              mainIcon: imagePaths.lateArrivalLogo,*/}
      {/*              boxHeader: "Monthly Late Arrival",*/}
      {/*              statusIcon: imagePaths.decreaseIcon,*/}
      {/*              statusIconColor: appColor.red,*/}
      {/*              dailyStatus: "+3% Increase than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: formatHours(*/}
      {/*                employeeDashboardData.monthlyOvertimeHours*/}
      {/*              ),*/}
      {/*              mainIcon: imagePaths.earlyLogo,*/}
      {/*              boxHeader: "Monthly Overtime Hours",*/}
      {/*              statusIcon: imagePaths.increaseIcon,*/}
      {/*              statusIconColor: appColor.green,*/}
      {/*              dailyStatus: "-10% Less than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          /!* <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: employeeDashboardData.monthlyAbsentCount,*/}
      {/*              mainIcon: imagePaths.timeOffIcon,*/}
      {/*              boxHeader: "This Month Absent Count",*/}
      {/*              statusIcon: imagePaths.increaseIcon,*/}
      {/*              statusIconColor: appColor.primary,*/}
      {/*              dailyStatus: "2% Increase than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem> *!/*/}
      {/*          /!* <GridItem colspan={4}>*/}
      {/*      {startHour !== null ? (*/}
      {/*        <Container padding="10px 20px">*/}
      {/*          <Timeline*/}
      {/*            startHour={startHour}*/}
      {/*            totalHours={totalHours}*/}
      {/*            taskRows={taskRows}*/}
      {/*            hourWidth={hourWidth}*/}
      {/*          />*/}
      {/*        </Container>*/}
      {/*      ) : (*/}
      {/*        "Please punch in first"*/}
      {/*      )}*/}
      {/*    </GridItem> *!/*/}
      {/*        </Grid>*/}
      {/*      )}*/}
      {/*      <SpaceBox space={5} />*/}
      {/*      {getLocalData(loginDataKeys.role) === "Admin" && (*/}
      {/*        <Grid>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: adminDashboardData.totalEmployees,*/}
      {/*              mainIcon: imagePaths.usersIcon,*/}
      {/*              boxHeader: "Total Employees",*/}
      {/*              statusIcon: imagePaths.plusIcon,*/}
      {/*              statusIconColor: appColor.green,*/}
      {/*              dailyStatus: "2 new employees added!",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: adminDashboardData.totalTodayPresent,*/}
      {/*              mainIcon: imagePaths.clockIcon,*/}
      {/*              boxHeader: "Today Total Present",*/}
      {/*              statusIcon: imagePaths.increaseIcon,*/}
      {/*              statusIconColor: appColor.green,*/}
      {/*              dailyStatus: "-10% Less than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: adminDashboardData.totalTodayAbsent,*/}
      {/*              mainIcon: imagePaths.absentIcon,*/}
      {/*              boxHeader: "Today Total Absent",*/}
      {/*              statusIcon: imagePaths.decreaseIcon,*/}
      {/*              statusIconColor: appColor.red,*/}
      {/*              dailyStatus: "+3% Increase than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*          <GridItem>*/}
      {/*            {boxItem({*/}
      {/*              countText: adminDashboardData.totalTodayLateArrival,*/}
      {/*              mainIcon: imagePaths.lateArrivalLogo,*/}
      {/*              boxHeader: "Today Late Arrival",*/}
      {/*              statusIcon: imagePaths.decreaseIcon,*/}
      {/*              statusIconColor: appColor.red,*/}
      {/*              dailyStatus: "+3% Increase than yesterday",*/}
      {/*            })}*/}
      {/*          </GridItem>*/}
      {/*        </Grid>*/}
      {/*      )}*/}

      {/*  <div className="container" style={{ marginTop: "20px" }}>*/}
      {/*    {getLocalData(loginDataKeys.role) === "Admin" && (*/}
      {/*      <EmployeeListContent*/}
      {/*        isInDashoard={true}*/}
      {/*        formTitle="Approval Pending Employees"*/}
      {/*        empData={employeeData}*/}
      {/*      />*/}
      {/*    )}*/}
      {/*    {getLocalData(loginDataKeys.role) === "Employee" ? (*/}
      {/*      <div className="listBox">*/}
      {/*        <Row justifyContent="space-between">*/}
      {/*          <AppText*/}
      {/*            text="Your Attendance Report"*/}
      {/*            fontSize={17}*/}
      {/*            fontWeight={550}*/}
      {/*            color={appColor.primary}*/}
      {/*            style={{ margin: "15px 0px 20px 10px" }}*/}
      {/*          />*/}
      {/*          <RangePicker presets={rangePresets} onChange={onRangeChange} style={{ margin: "10px" }} />*/}
      {/*        </Row>*/}
      {/*        <div>*/}
      {/*          <Table*/}
      {/*            columns={columns}*/}
      {/*            dataSource={empReportData}*/}
      {/*            scroll={{*/}
      {/*              x: "max-content",*/}
      {/*            }}*/}
      {/*          />*/}
      {/*        </div>*/}
      {/*      </div>*/}
      {/*    ) : null}*/}
      {/*  </div>*/}
      {/*  </>)}*/}
      {/*</Container>*/}
    </>
  );
};

export const boxItem = ({
  countText,
  mainIcon,
  iconColor = appColor.primary,
  statusIcon,
  statusIconColor,
  boxHeader,
  dailyStatus,
}) => {
  return (
    <Container
      padding={"20px"}
      width={"100%"}
      height={"100%"}
      display={"flex"}
      justifyContent={"center"}
    >
      <div style={{display: "flex", justifyContent: "center", alignItems: "center"}}>
        <Image
          path={mainIcon}
          iconColor={iconColor}
          width="45px"
          height="45px"
          backgroundColor={appColor.mainBg}
          borderRadius={100}
          padding={10}
        />
        <SpaceBox space={5} />
        <Column justifyContent="center">
          <AppText
            text={countText}
            fontSize="25px"
            fontWeight="500"
            color={appColor.black}
          />
          <AppText
            text={boxHeader}
            fontSize="14px"
            fontWeight="500"
            color={appColor.lightBlack}
          />
          {/* <Row>
              <Image
                path={statusIcon}
                iconColor={statusIconColor}
                width="18px"
                height="18px"
                backgroundColor={statusIconColor}
                borderRadius={100}
                padding={3}
                opacity={0.1}
              />
              <SpaceBox space={2} />
              <AppText text={dailyStatus} fontSize="13px" color={appColor.text} />
            </Row> */}
        </Column>
      </div>
    </Container>
  );
};

export default Dashboard;
