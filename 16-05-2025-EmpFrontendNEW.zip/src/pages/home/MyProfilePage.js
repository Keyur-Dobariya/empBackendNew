import React, { useEffect, useState } from "react";
import { endpoints } from "../../api/apiEndpoints";
import apiCall, { HttpMethod } from "../../api/apiServiceProvider";
import { getLocalData, loginDataKeys } from "../../dataStorage/DataPref";
import AddUpdateEmpModel from "../../model/AddUpdateEmpModel";
import { Button, Form, Tabs } from "antd";
import Container from "../../components/common/Container";
import Card from "../../components/common/Card";
import Column from "../../components/common/Column";
import SpaceBox from "../../components/common/SpaceBox";
import appKeys from "../../utils/appKeys";
import appString from "../../utils/appString";
import AppTextFormField, {
  InputType,
} from "../../components/common/AppTextFormField";
import {
  confirmPasswordFieldRules,
  passwordFieldRules,
} from "../../config/formConfig";
import { changePasswordApi } from "../../api/apiUtils";
import { useNavigate } from "react-router-dom";
import { useLoading } from "../..";
import { Loader } from "../../components/Loader";

export default function MyProfilePage() {
  const [employeeData, setEmployeesData] = useState();
  const [isLoading, setIsLoading] = useState(false);
  // const { setIsLoading } = useLoading();
  const [activeTab, setActiveTab] = useState("1");
  const [form] = Form.useForm();

  useEffect(() => {
    getUserProfile();
  }, []);

  const getUserProfile = async () => {
    setIsLoading(true);
    try {
      await apiCall({
        method: HttpMethod.GET,
        url: `${endpoints.userProfile}${getLocalData(loginDataKeys._id)}`,
        showSuccessMessage: false,
        // setIsLoading: setIsLoading,
        successCallback: (data) => {
          const responseData = data["data"];
          setEmployeesData(responseData);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
      setIsLoading(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTabChange = (key) => {
    setActiveTab(key);
  };

  const items = [
    {
      key: "1",
      label: "My Profile",
    },
    {
      key: "2",
      label: "Change Password",
    },
  ];

  const handleSubmit = () => {
    changePasswordApi({
      form: form,
      setIsLoading: setIsLoading,
    });
  };

  return (
    <>
      {isLoading ? (
        <Loader />
      ) : (
        <Card padding="20px 20px" height="100%">
          <Tabs
            defaultActiveKey="1"
            items={items}
            tabPosition="top"
            onChange={handleTabChange}
          />
          <div
            style={{
              maxHeight: "calc(100vh - 180px)",
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            {activeTab === "1" && (
              <Column justifyContent={"center"} alignItems={"center"}>
                <AddUpdateEmpModel
                  employeeData={employeeData}
                  isEditing={true}
                  onSuccessCallback={getUserProfile}
                  isModel={false}
                />
                {/* <Button
              type="primary"
              onClick={() => {
                setActiveTab("3");
              }}
              style={{ margin: "0", width: "200px" }}
            >
              Update Profile
            </Button>
            <SpaceBox space="5px" /> */}
              </Column>
            )}
            {activeTab === "2" && (
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: "100px",
                }}
              >
                <div
                  style={{
                    border: "1px solid rgb(223, 223, 223)",
                    padding: "20px",
                    borderRadius: "10px",
                    width: "40%",
                  }}
                >
                  <Form
                    form={form}
                    name="EmpAddUpdateModel"
                    layout="vertical"
                    //   disabled={true}
                    // onValuesChange={handleFieldChange}
                    // initialValues={isEditing ? {} : form.getFieldsValue()}
                    style={{
                      marginRight: 15,
                      marginTop: 15,
                      alignContent: "center",
                    }}
                  >
                    <AppTextFormField
                      name="oldPassword"
                      label={appString.oldPassword}
                      type={InputType.Password}
                      rules={passwordFieldRules}
                      isRequired={true}
                      placeholder={appString.oldPassword}
                    />
                    <AppTextFormField
                      name={appKeys.newPassword}
                      label={appString.newPassword}
                      type={InputType.Password}
                      rules={passwordFieldRules}
                      isRequired={true}
                      placeholder={appString.newPassword}
                    />
                    <AppTextFormField
                      name={appKeys.confirmPassword}
                      label={appString.confirmPassword}
                      type={InputType.Password}
                      rules={confirmPasswordFieldRules(form)}
                      isRequired={true}
                      placeholder={appString.confirmPassword}
                    />
                    <div style={{ display: "flex", justifyContent: "right" }}>
                      <Button
                        type="primary"
                        onClick={handleSubmit}
                        style={{ margin: "10px 0px", width: "200px" }}
                      >
                        Change Password
                      </Button>
                    </div>
                  </Form>
                </div>
              </div>
            )}
          </div>
        </Card>
      )}
    </>
  );
}
