import React, { useState, useEffect } from "react";
import {
  DesktopOutlined,
  FileOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { Breadcrumb, Button, Layout, Menu, theme } from "antd";

const { Header, Content, Footer, Sider } = Layout;

function getItem(label, key, icon, children, isShow) {
  return {
    key,
    icon,
    children,
    label,
    isShow,
  };
}

const items = [
  getItem("Dashboard", "dashboard", <PieChartOutlined />),
  getItem("Employees", "employees", <DesktopOutlined />),
  getItem("Projects", "projects", <DesktopOutlined />),
  getItem("Tasks", "tasks", <DesktopOutlined />),
  getItem("My Profile", "myProfile", <DesktopOutlined />),
  getItem("LogOut", "logout", <DesktopOutlined />),
  //   getItem("Employees", "employees", <UserOutlined />, [
  //     getItem("Tom", "3"),
  //     getItem("Bill", "4"),
  //     getItem("Alex", "5"),
  //   ]),
];

const NewDashboard = () => {
  const [collapsed, setCollapsed] = useState(window.innerWidth < 768);
  const [selectedContent, setSelectedContent] = useState("dashboard");

  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  // Function to render content based on selected menu
  const renderContent = () => {
    switch (selectedContent) {
      case "dashboard":
        return <h2>Welcome to Dashboard</h2>;
      case "employees":
        return <h2>Employee List</h2>;
      case "projects":
        return <h2>Project List</h2>;
      case "tasks":
        return <h2>Tasks Board</h2>;
      case "myProfile":
        return <h2>My Profile</h2>;
      case "logout":
        return <h2>Logout</h2>;
      default:
        return <h2>Welcome to Dashboard</h2>;
    }
  };

  return (
    <Layout>
      <Sider
        trigger={null}
        collapsible
        collapsed={collapsed}
        style={{ background: colorBgContainer }}
      >
        
        <Menu
          theme="light"
          defaultSelectedKeys={["dashboard"]}
          mode="inline"
          items={items}
          onClick={(e) => setSelectedContent(e.key)} // Update content on click
        />
      </Sider>
      <Layout>
        <Header
          style={{
            padding: 0,
            background: colorBgContainer,
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{
              fontSize: "16px",
              width: 64,
              height: 64,
            }}
          />
        </Header>
        <Content
          style={{
            margin: "24px 16px",
            padding: 24,
            minHeight: 280,
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
          }}
        >
          {renderContent()}
        </Content>
      </Layout>
    </Layout>
  );
};

export default NewDashboard;
