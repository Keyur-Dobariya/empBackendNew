import React, {useEffect, useRef, useState} from "react";
import {DragDropContext, Droppable, Draggable} from "@hello-pangea/dnd";
import imagePaths from "../../assets/assetsPaths";
import {
    Tag as TagIcon,
    Calendar,
    Check,
    ChevronsUp,
    Filter,
    Plus,
    ShoppingCart,
    User,
    Search,
    XCircle, CheckCircle, Edit, Trash2, Eye
} from "react-feather";
import appColor from "../../utils/appColors";
import {
    Avatar,
    Button,
    DatePicker,
    Divider,
    Popconfirm,
    Popover,
    Select,
    Spin,
    Switch,
    Table,
    Tag,
    Tooltip
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    ApprovalStatus,
    DateTimeFormat,
    getIconByKey,
    getLabelByKey,
    projectTypeLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
} from "../../utils/enum";
import {CalendarOutlined, CheckOutlined, UserOutlined} from "@ant-design/icons";
import dayjs from "dayjs";
import {
    deleteProjectApi,
    deleteUserApi,
    getClientList,
    getProjectList,
    getTasksList,
    getUsersList
} from "../../api/apiUtils";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import ProjectAddUpdateModel from "../../model/ProjectAddUpdateModel";
import {UserRole} from './../../utils/enum';
import {SearchTextField} from "../../components/formField/DynamicForm";
import {useIsMobileView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";

const {Option} = Select;
const {RangePicker} = DatePicker;

const ProjectPage = () => {

    const [isAddProjectModelOpen, setAddProjectModelOpen] = useState(false);
    const [isProjectEditing, setIsProjectEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [isTableLoading, setIsTableLoading] = useState(false);
    const [loadingProjectId, setLoadingProjectId] = useState(null);
    const [clientRecord, setClientRecord] = useState([]);
    const [projectRecord, setProjectRecord] = useState([]);
    const [projectFullRecord, setProjectFullRecord] = useState([]);
    const [selectedProjectRecord, setSelectedProjectRecord] = useState({});
    const [employeeRecord, setEmployeeRecord] = useState([]);

    useEffect(() => {
        getEmployeeData();
        getClientsData();
        getProjectsData();
    }, []);

    const getEmployeeData = () => {
        getUsersList({
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                const filteredEmployees = data["data"].filter(
                    (record) =>
                        record.approvalStatus === ApprovalStatus.Approved ||
                        record.isActive
                );

                const selectedFields = filteredEmployees.map((employee) => ({
                    userId: employee._id,
                    fullName: employee.fullName,
                    emailAddress: employee.emailAddress,
                    profilePhoto: employee.profilePhoto,
                }));

                setEmployeeRecord(selectedFields);
            },
        });
    };

    const getClientsData = () => {
        getClientList({
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setClientRecord(data.data);
            },
        });
    };

    const getProjectsData = () => {
        getProjectList({
            setIsLoading: setIsTableLoading,
            successCallback: (data) => {
                handleDataConditionWise(data.data);
            },
        });
    };

    const handleDataConditionWise = (data) => {
        const filteredData = getLocalData(loginDataKeys.role) === UserRole.Admin ? data : data.filter((project) => project.addedBy === getLocalData(loginDataKeys._id));
        setProjectRecord(filteredData);
        setProjectFullRecord(filteredData);
    };

    const handleAddUpdateTaskApi = async (_id, data) => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.updateProject}/${_id}`,
                data: data,
                setIsLoading: false,
                successCallback: (data) => {
                    handleDataConditionWise(data.data);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        } finally {
            setLoadingProjectId(null);
        }
    };

    const handleTaskAddClick = () => {
        setAddProjectModelOpen(true);
        setSelectedProjectRecord({});
    };

    const handleProjectStatusChange = (record, checked) => {
        const body = {
            isActive: checked,
            userId: getLocalData(loginDataKeys._id),
        };

        setLoadingProjectId(record._id);

        handleAddUpdateTaskApi(record._id, body);
    }

    const handleEditClick = (value) => {
        setIsProjectEditing(true);
        setSelectedProjectRecord(value);
        setAddProjectModelOpen(true);
    };

    const handleDeleteProjectApi = async (event) => {
        deleteProjectApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddProjectModelOpen(false);
                handleDataConditionWise(data.data);
            },
        });
    };

    const projectTableColumn = [
        {
            title: appString.projectName,
            dataIndex: appKeys.projectName,
            key: appKeys.projectName,
        },
        // {
        //     title: appString.clientName,
        //     dataIndex: appKeys.clientName,
        //     key: appKeys.clientName,
        // },
        {
            title: appString.projectType,
            dataIndex: appKeys.projectType,
            key: appKeys.projectType,
            hidden: getLocalData(loginDataKeys.role) !== UserRole.Admin,
            render: (projectType) => {
                if (!projectType) return "";
                return getLabelByKey(projectType, projectTypeLabel);
            },
        },
        {
            title: appString.projectStatus,
            dataIndex: appKeys.projectStatus,
            key: appKeys.projectStatus,
            hidden: getLocalData(loginDataKeys.role) !== UserRole.Admin,
            render: (projectStatus) => {
                if (!projectStatus) return "";
                return getLabelByKey(projectStatus, taskColumnStatusLabel);
            },
        },
        {
            title: appString.projectPriority,
            dataIndex: appKeys.projectPriority,
            key: appKeys.projectPriority,
            hidden: getLocalData(loginDataKeys.role) !== UserRole.Admin,
            render: (projectPriority) => {
                if (!projectPriority) return "";
                return (
                    <div style={{display: "flex", alignItems: "center"}}>
                        {getIconByKey(projectPriority, taskPriorityLabel)}
                        {getLabelByKey(projectPriority, taskPriorityLabel)}
                    </div>
                );
            },
        },
        {
            title: "Active",
            dataIndex: appKeys.isActive,
            key: appKeys.isActive,
            width: 120,
            hidden: getLocalData(loginDataKeys.role) !== UserRole.Admin,
            render: (_, record) => {
                return (
                    <Switch
                        loading={loadingProjectId === record._id}
                        checked={record.isActive}
                        onChange={(checked) => handleProjectStatusChange(record, checked)}
                    />
                );
            },
        },
        {
            title: appString.createdAt,
            dataIndex: appKeys.createdAt,
            key: appKeys.createdAt,
            render: (createdAt) => {
                return dayjs(createdAt).format("DD, MMM YYYY [at] hh:mm a");
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            render: (_, record) => {
                return employeeRecord?.length >= 1 ? (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            <div
                                style={{marginRight: 25, cursor: "pointer"}}
                                onClick={() => handleEditClick(record)}
                            >
                                <Tooltip title={appString.edit}>
                                    <Edit className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                            <Popconfirm
                                title={appString.deleteConfirmation}
                                onConfirm={() => handleDeleteProjectApi(record)}
                                style={{margin: "0"}}
                            >
                                <div style={{marginRight: 25, cursor: "pointer"}}>
                                    <Tooltip title={appString.delete} placement="bottom">
                                        <Trash2 className="deleteIconStyle"/>
                                    </Tooltip>
                                </div>
                            </Popconfirm>
                        </div>
                    </>
                ) : null;
            },
        },
    ];

    return (
        <>
            {isLoading ? (
                <div
                    style={{
                        width: "100%",
                        height: "100%",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                    }}
                >
                    <Spin tip="Loading"/>
                </div>
            ) : (
                <div className="taskBoardContainer">
                    <div className="taskBoardHeader">
                        <div className="taskheaderTitle">Projects List</div>
                        <div className="taskheaderManageSection">
                            <SearchTextField
                                field={{
                                    name: "search",
                                    placeholder: "Search Project",
                                    prefix: <Search/>,
                                    style: {margin: 0, width: "300px", height: "38px"},
                                    onChange: (e) => {
                                        const searchText = e.target.value.toLowerCase();
                                        const filteredData = projectFullRecord?.filter((record) => {
                                            return (
                                                record.projectId?.toLowerCase().includes(searchText) ||
                                                record.projectName?.toLowerCase().includes(searchText) ||
                                                record.projectDescription?.toLowerCase().includes(searchText) ||
                                                record.clientName?.toLowerCase().includes(searchText) ||
                                                record.projectType?.toLowerCase().includes(searchText) ||
                                                record.tags?.toLowerCase().includes(searchText)
                                            );
                                        });
                                        setProjectRecord(filteredData);
                                    },
                                }}
                            />
                            <div className="addTaskButton" onClick={handleTaskAddClick}>
                                <Plus className="whiteIconStyle"/>
                                <div>Add Project</div>
                            </div>
                        </div>
                    </div>
                    <Table
                        columns={projectTableColumn}
                        dataSource={[...projectRecord]}
                        scroll={{x: "max-content"}}
                        loading={isTableLoading}
                    />
                </div>
            )}
            {isAddProjectModelOpen && (
                <ProjectAddUpdateModel
                    isModelOpen={isAddProjectModelOpen}
                    setIsModelOpen={setAddProjectModelOpen}
                    employeeList={employeeRecord}
                    clientData={clientRecord}
                    projectData={selectedProjectRecord}
                    isEditing={isProjectEditing}
                    setIsEditing={setIsProjectEditing}
                    onSuccessCallback={(data) => {
                        handleDataConditionWise(data.data);
                    }}
                />
            )}
        </>
    );
};

export default ProjectPage;