import React, {useEffect} from "react";
import {useLocation, useNavigate} from "react-router-dom";
import {convertDateTime, formatMilliseconds} from "../../common/DateFormat";
import {Avatar, DatePicker, Modal, Space, Spin, Table, Tag, Tooltip} from "antd";
import dayjs from 'dayjs';
import EmpScreenshotModel from "../../model/EmpScreenshotModel";
import appColor from "../../utils/appColors";
import {colorTag} from "../../common/colorTag";
import AppText from "../../components/common/AppText";
import {Eye, User} from "react-feather";
import {format} from 'date-fns';
import routes from "../../common/routes";
import {useLoading} from "../..";
import {endpoints} from "../../api/apiEndpoints";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";

export default function TodayReport() {
    const [data, setData] = React.useState([]);
    const [selectedDate, setSelectedDate] = React.useState(null);
    // const [loading, setLoading] = React.useState(false);
    const {setIsLoading} = useLoading();
    const [screenshots, setScreenshots] = React.useState([]);
    const [selectedId, setSelectedId] = React.useState(null);

    const location = useLocation();
    const {employeeDetails} = location.state || {};
    let id = employeeDetails?._id

    const navigate = useNavigate();
    const [open, setOpen] = React.useState(false);
    const [detailModelOpen, setDetailModelOpen] = React.useState(false);
    const [detailModelOpenFlag, setDetailModelOpenFlag] = React.useState(false);
    const [selectedAttendanceData, setSelectedAttendanceData] = React.useState({});

    const showLoading = ({screenshots, id}) => {
        setOpen(true);
        setScreenshots([...screenshots]);
        setSelectedId(id)
    };

    const columns = [
        {
            title: 'User Name',
            dataIndex: 'userData',
            key: 'userData.fullName',
            render: (text, record) => record.userData ? record.userData.fullName : '',
        },
        {
            title: "Total Hours",
            dataIndex: "totalHours",
            key: "totalHours",
            render: (_, record) => {
                return colorTag(
                    record.totalHours,
                    appColor.primary
                );
            },
        },
        {
            title: "Working Hours",
            dataIndex: "workingHours",
            key: "workingHours",
            render: (_, record) => {
                return colorTag(
                    record.workingHours,
                    appColor.success
                );
            },
        },
        {
            title: "Break Hours",
            dataIndex: "breakHours",
            key: "breakHours",
            render: (breakHours) => {
                return colorTag(breakHours, appColor.danger);
            },
        },
        {
            title: "Late Arrival",
            dataIndex: "lateArrival",
            key: "lateArrival",
            render: (lateArrival) => {
                return colorTag(lateArrival, appColor.warning);
            },
        },
        {
            title: "Overtime",
            dataIndex: "overtime",
            key: "overtime",
            render: (overtime) => {
                return colorTag(overtime, appColor.info);
            },
        },
        {
            title: 'Screenshots',
            key: 'screenshots',
            render: (_, record) => {
                let screenshots = record?.screenshots;
                let attendanceID = record?._id;

                return (
                    <>
                        <Avatar.Group max={{count: 4}}>
                            {screenshots && screenshots.length > 0 ? (
                                screenshots.slice(0, 4).map((image, index) => (
                                        <>
                                            <Avatar key={index} src={image?.image} onClick={() => showLoading({
                                                screenshots: screenshots,
                                                id: attendanceID
                                            })}
                                                    style={{cursor: "pointer"}}/>
                                        </>
                                    )
                                )
                            ) : (
                                <Tooltip title="No screenshots available">
                                    <Avatar
                                        style={{
                                            backgroundColor: "#f56a00",
                                        }}
                                    >
                                        N/A
                                    </Avatar>
                                </Tooltip>
                            )}
                        </Avatar.Group>
                    </>
                )
            },
        },
        {
            title: "Event Count",
            dataIndex: "keyPressCount",
            key: "keyPressCount",
            render: (_, record) => {
                return (
                    <AppText
                        text={`${record.keyPressCount ? record.keyPressCount : "0"
                        } keyboard hits  •  ${record.mouseEventCount ? record.mouseEventCount : "0"
                        } mouse clicks`}
                        color={appColor.primary}
                        fontSize={14}
                        fontWeight={550}
                    />
                );
            },
        },
        {
            title: "View",
            dataIndex: "keyPressCount",
            key: "keyPressCount",
            width: 50,
            render: (_, record) => {
                return (
                    <>
                        <div className="d-flex" style={{gap: 10}}>
                            <div className="mr-10"
                                 style={{cursor: "pointer"}}
                                 onClick={() => handleViewClick(record)}
                            >
                                <Tooltip title={"View Attendance Detail"}>
                                    <Eye className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                            <div
                                style={{cursor: "pointer"}}
                                onClick={() => handleViewClick2(record)}
                            >
                                <Tooltip title={"View Employee Detail"}>
                                    <User className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                        </div>
                    </>
                );
            },
        },
    ];

    const handleViewClick = (record) => {
        setOpen(false);
        setDetailModelOpen(true);
        setDetailModelOpenFlag(true);

        setSelectedAttendanceData(record);
    };

    const handleViewClick2 = (record) => {
        navigate(routes.employeeDetails, {state: {employeeDetails: record.userData}});
    };

    const fetchEmployeeData = async () => {
        const baseUrl = endpoints.getTodayAttendance;
        let queryParams = [];

        if (selectedDate) {
            queryParams.push(`date=${selectedDate}`);
        }

        const finalUrl =
            queryParams.length > 0
                ? `${baseUrl}?${queryParams.join("&")}`
                : baseUrl;
        try {
            await apiCall({
                method: HttpMethod.GET,
                url: finalUrl,
                setIsLoading,
                showSuccessMessage: false,
                successCallback: (data) => {
                    setData(data.data);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    };

    useEffect(() => {
        fetchEmployeeData();
    }, [id, selectedDate]);

    const disabledDate = (current) => {
        return current.isAfter(new Date(), "day");
    };

    const details = detailModelOpen ? [
        {
            title: "Employee Name",
            value: selectedAttendanceData.userData.fullName,
            style: {borderTop: "none", borderRadius: "10px 10px 0 0"},
        },
        {title: "Attendance Date", value: convertDateTime(selectedAttendanceData.createdAt)},
        {title: "PunchIn At", value: format(selectedAttendanceData.punchInAt, "hh:mm a")},
        {
            title: "Total Hours",
            value: selectedAttendanceData.totalHours ? formatMilliseconds(selectedAttendanceData.totalHours) : "00:00:00",
        },
        {
            title: "Working Hours",
            value: selectedAttendanceData.workingHours ? formatMilliseconds(selectedAttendanceData.workingHours) : "00:00:00",
        },
        {
            title: "Punching Time",
            value:
                selectedAttendanceData.punchTime.length > 0 ? (
                    selectedAttendanceData.punchTime.map((punchItem, index) => (
                        <div key={index}>
                            {format(new Date(punchItem.punchInTime), "hh:mm a")} to{" "}
                            {punchItem.punchOutTime ? format(new Date(punchItem.punchOutTime), "hh:mm a") : "Tracker Running"}
                        </div>
                    ))
                ) : (
                    "Haven't taken a break yet"
                ),
        },
        {
            title: "Break Time",
            value:
                selectedAttendanceData.breakTime.length > 0 ? (
                    selectedAttendanceData.breakTime.map((breakItem, index) => (
                        <div key={index}>
                            {format(new Date(breakItem.breakInTime), "hh:mm a")} to{" "}
                            {breakItem.breakOutTime ? format(new Date(breakItem.breakOutTime), "hh:mm a") : "Currently in break"}
                        </div>
                    ))
                ) : (
                    "Haven't taken a break yet"
                ),
        },
        {
            title: "Break Hours",
            value: selectedAttendanceData.breakHours ? formatMilliseconds(selectedAttendanceData.breakHours) : "00:00:00",
        },
        {
            title: "Overtime Hours",
            value: selectedAttendanceData.overtime ? formatMilliseconds(selectedAttendanceData.overtime) : "00:00:00",
        },
        {
            title: "Late Arrival Hours",
            value: selectedAttendanceData.lateArrival ? formatMilliseconds(selectedAttendanceData.lateArrival) : "00:00:00",
        },
        {
            title: "Key Press Count",
            value: `${selectedAttendanceData.keyPressCount ? selectedAttendanceData.keyPressCount : "0"}`,
        },
        {
            title: "Mouse Click Count",
            value: `${selectedAttendanceData.mouseEventCount ? selectedAttendanceData.mouseEventCount : "0"}`,
        },
        {
            title: "Screenshots Count",
            value: selectedAttendanceData.screenshots && selectedAttendanceData.screenshots.length > 0 ? (
                <>
                    {selectedAttendanceData.screenshots.length} {" "}
                    <span
                        style={{color: "blue", textDecoration: "underline", cursor: "pointer"}}
                        onClick={() => {
                            setDetailModelOpen(false);
                            showLoading({
                                screenshots: selectedAttendanceData.screenshots,
                                id: selectedAttendanceData._id
                            })
                        }}
                    >
                        (View Screenshots)
                    </span>
                </>
            ) : ("No Screenshots available"),
            style: {borderBottom: "none", borderRadius: "0 0 10px 10px"},
        }
    ] : [];

    const onChange = (date, dateString) => {
        setSelectedDate(dateString);
    };

    return (
        <>
            <EmpScreenshotModel open={open} loading={false} setOpen={setOpen} screenshots={screenshots}
                                setScreenshots={setScreenshots} empID={selectedId} onClose={() => {
                if (detailModelOpenFlag) {
                    setDetailModelOpen(true);
                }
            }}/>
            {detailModelOpen ? <Modal
                title="Attendance Record"
                width="35rem"
                maskClosable={true}
                centered
                open={detailModelOpen}
                okButtonProps={{style: {display: "none"}}}
                cancelButtonProps={{style: {display: "none"}}}
                onCancel={() => {
                    setDetailModelOpen(false);
                    setDetailModelOpenFlag(false);
                }}
                onClose={() => {
                    setDetailModelOpen(false);
                    setDetailModelOpenFlag(false);
                }}
                okText=""
            >
                <div className="detailDiv">
                    {details.map((item, index) => (
                        <div
                            className="detailRow"
                            key={index}
                            style={{
                                backgroundColor: index % 2 === 0 ? "#ffffff" : "#f5f5f5",
                                ...(item.style || {}), // Preserve existing styles if any
                            }}
                        >
                            <div className="detailRowTitle">{item.title}:</div>
                            <div className="detailRowValue">{item.value}</div>
                        </div>
                    ))}
                </div>
            </Modal> : null}
            <div className="profile-container">

                <div className="info-section">

                    <div className="info-header">
                        <h5>Today Record</h5>
                        <DatePicker onChange={onChange}
                                    disabledDate={(current) => {
                                        return current && current > dayjs().endOf('day');
                                    }}/>
                    </div>

                    {/* {(loading && !data) ? (
                        <Spin size="large" style={{ display: "block", textAlign: "center", margin: "20px 0" }} />
                    ) : ( */}
                    <Table columns={columns} dataSource={data} pagination={false}/>
                    {/* )} */}

                </div>
            </div>
        </>
    );
}
