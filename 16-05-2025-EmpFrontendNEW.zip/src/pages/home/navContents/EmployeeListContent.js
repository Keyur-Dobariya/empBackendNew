import React, { useState, useEffect } from "react";
import { Button, DatePicker, FloatButton, Table } from "antd";
import { Search, UserPlus } from "react-feather";
import {
  deleteUserApi,
  getAllEmployees,
  userApprovalUpdateApi,
} from "../../../api/apiUtils";
import { employeeTableColumn } from "../../../dataTable/employeeTableColumn";
import {
  generateEmployeeCode,
  useIsMobileView,
} from "../../../components/CommonComponents";
import { SearchTextField } from "../../../components/formField/DynamicForm";
import AddUpdateEmpModel from "../../../model/AddUpdateEmpModel";
import { ApprovalStatus } from "../../../utils/enum";
import { useLoading } from "../../..";
import appKeys from "../../../utils/appKeys";
import appColor from "../../../utils/appColors";
import appString from "../../../utils/appString";
import AppText from "../../../components/common/AppText";
import { Navigate, useNavigate } from "react-router-dom";
import SpaceBox from "../../../components/common/SpaceBox";
import EmpDetailModel from "../../../model/EmpDetailModel";
import { endpoints } from "../../../api/apiEndpoints";
import apiCall, { HttpMethod } from "../../../api/apiServiceProvider";
import dayjs from "dayjs";
import Row from "../../../components/common/Row";
import routes from "../../../common/routes";
const { RangePicker } = DatePicker;

export default function EmployeeListContent({
  isInDashoard = false,
  formTitle = "",
  empData,
}) {
  const isMobileView = useIsMobileView();
  const { setIsLoading } = useLoading();

  const [isFetched, setIsFetched] = useState(false);
  const [employeeData, setEmployeesData] = useState([]);
  const [allEmployeeData, setAllEmployeesData] = useState(empData || []);
  const [isEditing, setIsEditing] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);
  const [employeeCode, setEmployeeCode] = useState(generateEmployeeCode());

  const navigate = useNavigate();

  useEffect(() => {
    if (empData) {
      setEmployeesData(empData);
      setAllEmployeesData(empData?.reverse());
    }

    if (!isFetched && !isInDashoard) {
      getEmployeeData();
      setIsFetched(true);
    }
  }, [empData, isFetched, isInDashoard]);

  // useEffect(() => {
  //   setEmployeesData(empData);
  //   if (!isFetched) {
  //     if (!isInDashoard) {
  //       getEmployeeData();
  //     } else {
  //       setEmployeesData(empData);
  //       setAllEmployeesData(empData?.reverse());
  //     }
  //     setIsFetched(true);
  //   }
  // }, [empData]);

  // useEffect(() => {
  //   setEmployeesData(allEmployeeData);
  // }, [allEmployeeData]);

  const getEmployeeData = () => {
    getAllEmployees({
      setIsLoading: setIsLoading,
      successCallback: (data) => {
        let filteredEmployees;
        if (isInDashoard) {
          filteredEmployees = data?.data?.filter(
            (record) =>
              record.approvalStatus !== ApprovalStatus.Approved ||
              !record.isActive
          );
        } else {
          filteredEmployees = data?.data?.filter(
            (record) =>
              record.approvalStatus === ApprovalStatus.Approved
          );
        }
        setEmployeesData(filteredEmployees);
        setAllEmployeesData([...filteredEmployees].reverse());
      },
    });
  };

  const showEditModal = async () => {
    const newEmployeeCode = generateEmployeeCode();
    setEmployeeCode(newEmployeeCode);
    setIsEditing(false);
    setIsEditModalOpen(true);
  };

  const handleEditClick = (value) => {
    setIsEditing(true);
    setEditingRecord(value);
    setIsEditModalOpen(true);
  };

  const handleDeleteUserApi = async (event) => {
    deleteUserApi({
      id: event._id,
      setIsLoading: setIsLoading,
      successCallback: () => {
        setIsEditModalOpen(false);
        getEmployeeData();
      },
    });
  };

  const handleApproveUserApi = async (event) => {
    userApprovalUpdateApi({
      id: event._id,
      data: {
        approvalStatus: ApprovalStatus.Approved,
      },
      setIsLoading: setIsLoading,
      successCallback: () => {
        getEmployeeData();
      },
    });
  };

  const handleRejectUserApi = async (event) => {
    userApprovalUpdateApi({
      id: event._id,
      data: {
        approvalStatus: "Rejected",
      },
      setIsLoading: setIsLoading,
      successCallback: () => {
        getEmployeeData();
      },
    });
  };

  const handleUserStatusChange = async (event, checked) => {
    userApprovalUpdateApi({
      id: event._id,
      data: {
        isActive: checked,
      },
      setIsLoading: setIsLoading,
      successCallback: () => {
        getEmployeeData();
      },
    });
  };


  const handleViewClick = async (event) => {
    setEditingRecord(event);
    navigate(routes.employeeDetails, { state: { employeeDetails: event } });
    // setIsDetailModalOpen(true);
  };

  const columns = employeeTableColumn({
    employeeData: employeeData,
    handleEditClick: handleEditClick,
    handleDeleteClick: handleDeleteUserApi,
    handleApproveClick: handleApproveUserApi,
    handleRejectClick: handleRejectUserApi,
    handleUserStatusChange: handleUserStatusChange,
    handleViewClick: handleViewClick,
    // hiddenColumns: isInDashoard ? [] : [appKeys.approvalStatus],
  });

  return (
    <>
      <div className="listBox" style={{ overflowX: "auto" }}>
        {!isInDashoard ? (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              margin: "15px 15px",
            }}
          >
            <SearchTextField
              field={{
                name: "search",
                placeholder: "Search Data",
                prefix: <Search />,
                style: { margin: 0, width: isMobileView ? "100%" : "300px" },
                onChange: (e) => {
                  const searchText = e.target.value.toLowerCase();
                  const filteredData = allEmployeeData?.filter((record) => {
                    return (
                      record.employeeCode?.toLowerCase().includes(searchText) ||
                      record.fullName?.toLowerCase().includes(searchText) ||
                      record.emailAddress?.toLowerCase().includes(searchText) ||
                      record.mobileNumber?.toLowerCase().includes(searchText) ||
                      record.userRole?.toLowerCase().includes(searchText) ||
                      record.approvalStatus?.toLowerCase().includes(searchText)
                    );
                  });
                  setEmployeesData(filteredData);
                },
              }}
            />
            {!isMobileView ? (
              <Button
                type="primary"
                onClick={showEditModal}
                style={{ margin: "0" }}
              >
                Add Employee
              </Button>
            ) : null}
          </div>
        ) : null}
        {isInDashoard ? (
          <AppText
            text={formTitle}
            fontSize={17}
            fontWeight={550}
            color={appColor.primary}
            style={{ margin: "15px 0px 20px 10px" }}
          />
        ) : null}
        <div>
          <Table
            columns={columns}
            dataSource={[...employeeData]}
            scroll={{ x: "max-content" }}
            pagination={false}
          />
        </div>
      </div>
      {isMobileView ? (
        <FloatButton
          icon={<UserPlus />}
          type="primary"
          style={{ marginRight: "24px", width: "50px", height: "50px" }}
          onClick={showEditModal}
        />
      ) : null}
      {isEditModalOpen ? (
        <AddUpdateEmpModel
          isModelOpen={isEditModalOpen}
          setIsModelOpen={setIsEditModalOpen}
          employeeData={editingRecord}
          isEditing={isEditing}
          onSuccessCallback={getEmployeeData}
          isModel={true}
        />
      ) : null}
      {isDetailModalOpen ? (
        <EmpDetailModel
          isModelOpen={isDetailModalOpen}
          setIsModelOpen={setIsDetailModalOpen}
          employeeData={editingRecord}
        />
      ) : null}
    </>
  );
}
