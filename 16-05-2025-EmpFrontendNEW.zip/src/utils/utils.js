import { getLocalData, loginDataKeys } from "../dataStorage/DataPref";
import { UserRole } from "./enum";

export const isAdmin = () => {
    return getLocalData(loginDataKeys.role) === UserRole.Admin;
};