// const isDevMode = process.env.REACT_APP_IS_DEV === "true";
const isDevMode = true;

// firebase target:apply hosting default whogetsa
// firebase deploy --only hosting:devtracker
// firebase deploy --only hosting:default


const environment = {
  apiBaseUrl: isDevMode ? process.env.REACT_APP_API_BASE_URL_DEV : process.env.REACT_APP_API_BASE_URL_PROD,
  webUrl: isDevMode ? process.env.REACT_APP_WEB_URL_DEV : process.env.REACT_APP_WEB_URL_PROD,
  socketUrl: isDevMode ? process.env.REACT_APP_SOCKET_URL_DEV : process.env.REACT_APP_SOCKET_URL_PROD,
  isDev: isDevMode,
};

const endpoints = {
  uploadImageApi: `https://tracker.teqheal.com/upload.php`,
  getMasterData: `${environment.apiBaseUrl}/api/getMasterData`,
  login: `${environment.apiBaseUrl}/auth/login`,
  signUp: `${environment.apiBaseUrl}/auth/signUp`,
  forgetPassSendOtp: `${environment.apiBaseUrl}/auth/forgetPassSendOtp`,
  forgetPassVerifyOtp: `${environment.apiBaseUrl}/auth/forgetPassVerifyOtp`,
  forgetPassword: `${environment.apiBaseUrl}/auth/forgetPassword`,
  changePassword: `${environment.apiBaseUrl}/auth/changePassword/`,
  getAllUsers: `${environment.apiBaseUrl}/api/getAllUsers`,// For full detail
  getUsersList: `${environment.apiBaseUrl}/api/getUsersList`,// For small detail
  addUpdateUser: `${environment.apiBaseUrl}/api/addUpdateUser/`,
  deleteUser: `${environment.apiBaseUrl}/api/deleteUser/`,
  uploadSingleFile: `${environment.apiBaseUrl}/api/upload`,
  addAttendance: `${environment.apiBaseUrl}/api/addAttendance`,
  empDashboard: `${environment.apiBaseUrl}/api/empDashboard/`,
  getTodayAttendance: `${environment.apiBaseUrl}/api/getTodayAttendance`,
  userProfile: `${environment.apiBaseUrl}/api/userProfile/`,
  adminDashboard: `${environment.apiBaseUrl}/api/adminDashboard`,
  userWiseAttendanceData: `${environment.apiBaseUrl}/api/userWiseAttendanceData/`,
  deleteScreenshot: `${environment.apiBaseUrl}/api/deleteScreenshot`,
  updateSetting: `${environment.apiBaseUrl}/updateSetting`,
  getAppSetting: `${environment.apiBaseUrl}/getAppSetting`,
  addTask: `${environment.apiBaseUrl}/api/addTask`,
  updateTask: `${environment.apiBaseUrl}/api/updateTask`,
  deleteTask: `${environment.apiBaseUrl}/api/deleteTask/`,
  getGroupTask: `${environment.apiBaseUrl}/api/getGroupTask`,
  taskReorder: `${environment.apiBaseUrl}/api/taskReorder`,
  getAllTasks: `${environment.apiBaseUrl}/api/getAllTasks`,
  getAllEventHolidays: `${environment.apiBaseUrl}/api/getAllEventHolidays`,
  addEvent: `${environment.apiBaseUrl}/api/addEvent`,
  updateEvent: `${environment.apiBaseUrl}/api/updateEvent/`,
  deleteEvent: `${environment.apiBaseUrl}/api/deleteEvent/`,
  uploadFiles: `${environment.apiBaseUrl}/api/uploadFiles`,
  getProject: `${environment.apiBaseUrl}/api/getProject`,
  addProject: `${environment.apiBaseUrl}/api/addProject`,
  updateProject: `${environment.apiBaseUrl}/api/updateProject`,
  deleteProject: `${environment.apiBaseUrl}/api/deleteProject/`,
  getClient: `${environment.apiBaseUrl}/api/getClient`,
  addClient: `${environment.apiBaseUrl}/api/addClient`,
  updateClient: `${environment.apiBaseUrl}/api/updateClient/`,
  deleteClient: `${environment.apiBaseUrl}/api/deleteClient/`,
  getLeaves: `${environment.apiBaseUrl}/api/allLeaveList`,
  empLeaveList: `${environment.apiBaseUrl}/api/empLeaveList`,
  deleteLeave: `${environment.apiBaseUrl}/api/deleteLeave/`,
  // addLeave: `${environment.apiBaseUrl}/api/addLeave`,
  addLeave: `${environment.apiBaseUrl}/api/addUpdateLeave`,
  updateLeave: `${environment.apiBaseUrl}/api/updateLeave/`,
  leaveStatusChange: `${environment.apiBaseUrl}/api/leaveStatusChange/`,
  basicSalaryList: `${environment.apiBaseUrl}/api/basicSalaryList`,
  addUpdateBasicSalary: `${environment.apiBaseUrl}/api/addUpdateBasicSalary/`,
  deleteBasicSalary: `${environment.apiBaseUrl}/api/deleteBasicSalary/`,
  generateSalaryReports: `${environment.apiBaseUrl}/api/generateSalaryReports?`,
  updateSalaryReport: `${environment.apiBaseUrl}/api/updateSalaryReport`,
  // punchSheetUploadAndGetData: `${environment.apiBaseUrl}/api/punchSheetUploadAndGetData`,
  punchSheetUploadAndGetData: `${environment.apiBaseUrl}/api/punchSheetUploadAndGetData`,
  getPunchReportsList: `${environment.apiBaseUrl}/api/getPunchReportsList?`,
  updatePunchReports: `${environment.apiBaseUrl}/api/updatePunchReports/`,
  allLeaveLength: `${environment.apiBaseUrl}/api/allLeaveLength?`,
  publishSalaryReport: `${environment.apiBaseUrl}/api/publishSalaryReport`,
  getUserWiseReport: `${environment.apiBaseUrl}/api/getUserWiseReport`,
  salaryCodeVerify: `${environment.apiBaseUrl}/api/salaryCodeVerify`,
};

export { environment, endpoints };