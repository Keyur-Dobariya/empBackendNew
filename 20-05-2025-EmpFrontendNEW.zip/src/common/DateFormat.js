function convertDateTime(isoString) {
    if (!isoString) return '';
    const date = new Date(isoString);
    const day = String(date.getUTCDate()).padStart(2, '0');
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const year = date.getUTCFullYear();
    return `${day}-${month}-${year}`;
}

function formatMilliseconds(ms) {
    if (ms <= 0 || isNaN(ms)) return "00:00:00";
    let totalSeconds = Math.floor(ms / 1000);
    let hours = Math.floor(totalSeconds / 3600);
    let minutes = Math.floor((totalSeconds % 3600) / 60);
    let seconds = totalSeconds % 60;

    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
  
    const options = {
      month: "short",
      year: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true, // Enables AM/PM format
    };
  
    const formattedDate = date.toLocaleString("en-US", options);
    const [month, day, year, time, period] = formattedDate.replace(",", "").split(" ");
  
    return `${month} ${day}, ${year} ${time} ${period} `;
  };

export { convertDateTime, formatMilliseconds, formatTimestamp }