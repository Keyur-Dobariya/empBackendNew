const routes = {
    dashboard: "/",
    employees: "/employees-list",
    myProfile: "/my-profile",
    settings: "/settings",
    tasks: "/tasks",
    leave: "/leave",
    leaveReport: "/leave-report",
    todayReport: "/today-report",
    salaryReport: "/salary-report",
    punchReport: "/punch-report",
    calendar: "/calendar",
    client: "/client",
    project: "/project",
    basicSalary: "/basic-salary",
    employeeDetails: "/employee-details",
};

export default routes;
