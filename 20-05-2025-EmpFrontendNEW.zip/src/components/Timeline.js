import React from "react";
import { format } from "date-fns";

const Timeline = ({ startHour, totalHours, taskRows, hourWidth }) => {
  const getTaskPosition = (time) => {
    const date = new Date(time);
    const hours = date.getHours() + date.getMinutes() / 60;
    return (hours - startHour) * hourWidth;
  };

  const getTaskWidth = (start, end) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const duration = (endDate - startDate) / (1000 * 60 * 60);
    return duration * hourWidth;
  };

  return (
    <div
      className=" container-with-scrollbar"
      style={{
        flexGrow: 1,
        position: "relative",
        overflowX: "auto",
        paddingBottom: "10px",
        width: "100%",
        margin: "0 auto",
      }}
    >
      <div style={{}}>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "start",
            overflowX: "auto",
            width: `${totalHours * hourWidth}px`,
            height: "21px",
          }}
        >
          {Array.from({ length: totalHours }, (_, i) => (
            <div
              key={i}
              style={{
                textAlign: "start",
                fontWeight: "bold",
                minWidth: `${hourWidth}px`,
                fontSize: "14px",
                fontWeight: "500",
              }}
            >
              {`${startHour + i}:00`}
            </div>
          ))}
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "start",
            overflowX: "auto",
            width: `${totalHours * hourWidth}px`,
            height: "22px",
          }}
        >
          {Array.from({ length: totalHours }, (_, i) => (
            <div
              key={i}
              style={{
                textAlign: "start",
                fontWeight: "bold",
                minWidth: `${hourWidth}px`,
                fontSize: "10px",
                paddingBottom: "3px",
                fontWeight: "600",
                borderBottom: "1px solid #ccc",
              }}
            >
              {"|"}
            </div>
          ))}
        </div>
      </div>
      <div style={{ position: "relative" }}>
        {taskRows && taskRows.length > 0 ? (
          taskRows.map((row, rowIndex) => (
            <div
              key={rowIndex}
              style={{
                height: "80px",
                position: "relative",
              }}
            >
              {row.map((task) => (
                <div
                  key={task._id}
                  style={{
                    position: "absolute",
                    left: getTaskPosition(task.startTime),
                    width: getTaskWidth(task.startTime, task.endTime),
                    backgroundColor: task.color || "#4caf50",
                    color: "white",
                    padding: "5px 10px",
                    height: "83px",
                    border: "2px solid white",
                    borderRadius: "15px",
                    minWidth: "50px",
                    marginTop: "2px",
                    textAlign: "center",
                    overflow: "hidden",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "start",
                  }}
                  title={task.description}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.backgroundColor = task.color
                      ? darkenColor(task.color)
                      : "#45a049")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.backgroundColor =
                      task.color || "#4caf50")
                  }
                >
                  {task.title}
                  <br />
                  <small style={{ fontSize: "12px", fontWeight: "400" }}>
                    {format(new Date(task.startTime), "h:mm a")} -{" "}
                    {format(new Date(task.endTime), "h:mm a")}
                  </small>
                </div>
              ))}
            </div>
          ))
        ) : (
          <div style={{ textAlign: "center", padding: "20px" }}>
            No tasks available
          </div>
        )}
      </div>
    </div>
  );
};

const darkenColor = (hex) => {
  let color = hex.replace("#", "");
  if (color.length === 3) {
    color = color
      .split("")
      .map((c) => c + c)
      .join("");
  }
  const r = Math.max(0, parseInt(color.slice(0, 2), 16) - 30);
  const g = Math.max(0, parseInt(color.slice(2, 4), 16) - 30);
  const b = Math.max(0, parseInt(color.slice(4, 6), 16) - 30);
  return `#${r.toString(16).padStart(2, "0")}${g
    .toString(16)
    .padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
};

export default Timeline;