import {Popover, Tooltip} from "antd";
import React, {useEffect, useState} from "react";
import {ChevronDown, ChevronRight} from "react-feather";

const SingleTab = ({item, isActive, isShrink, activeTabNew, handleClick}) => {

    const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);

    useEffect(() => {
        if (isShrink) {
            setIsSubMenuOpen(false)
        }
    }, [isShrink]);

    return (
        <div>
            <Tooltip title={isShrink ? item.name : ""}>
                <TabContentCommon item={item} isActive={activeTabNew === item.name} isSubMenu={false}
                                  isShrink={isShrink} handleClick={() => {
                    if (item.subMenu) {
                        if (isShrink) {
                        } else {
                            setIsSubMenuOpen(!isSubMenuOpen);
                        }
                    } else {
                        handleClick(item);
                    }
                }}/>
            </Tooltip>
            {item.subMenu && isSubMenuOpen && (
                <div className="subMenu">
                    {item.subMenu.filter((subItem) => subItem.isShow === true)
                        .map((subItem) => (
                        <TabContentCommon item={subItem} isActive={activeTabNew === subItem.name} isSubMenu={false}
                                          isShrink={isShrink} handleClick={() => {
                            handleClick(subItem)
                        }}/>
                    ))}
                </div>
            )}
        </div>
    );
};

const TabContentCommon = ({item, isActive, isShrink, isSubMenu, handleClick}) => {
    return (
        <div
            onClick={() => {
                handleClick(item)
            }}
            className={`sbTabItemWrapper ${
                isActive ? "sbTabItemWrapperClose" : "sbTabItemWrapperOpen"
            } sbTabItemWrapperHover`}
        >
            <div
                className={`${isActive ? "sbTabItemIconClose" : "sbTabItemIconOpen"}`}
            >
                {item.icon}
            </div>
            <p
                className={`sbTabItemText ${
                    isShrink ? "sbTabItemTextClose" : "sbTabItemTextOpen"
                } ${isActive ? "sbTabItemTextActive" : "sbTabItemTextDisactive"}`}
            >
                {item.name}
                {item.subMenu && (
                    <ChevronRight
                        className={`arrowIcon ${isSubMenu ? "arrowOpen" : "arrowClosed"}`}
                    />
                )}
            </p>
        </div>
    );
};

export default SingleTab;
