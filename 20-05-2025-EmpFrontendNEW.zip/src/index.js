import React, { createContext, useContext, useState } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { ToastContainer } from "react-toastify";
import { Loader } from "./components/Loader";
import { Rnd } from "react-rnd";
import {ConfigProvider, message, notification} from "antd";
import appColor from "./utils/appColors";
import {setGlobalMessageApi} from "./components/CommonComponents";
import {AppDataProvider} from "./AppDataContext";


export const LoadingContext = createContext({
  isLoading: false,
  setIsLoading: () => {},
});

export const ToastContext = createContext({
  showToast: (type, message) => {},
});

export const useToast = () => useContext(ToastContext);

export const useLoading = () => useContext(LoadingContext);

function Root() {
  const [isLoading, setIsLoading] = useState(false);

  const themeConfig = {
    token: {
      colorPrimary: appColor.primary,
      // colorInfo: "#14407c",
      // colorSuccess: "#52c41a",
      // colorWarning: "#faad14",
      // colorError: "#ff4d4f",
      borderRadius: 10,
      // fontSizeBase: 16,
    },
  };

  const [messageApi, contextHolder] = message.useMessage();
  // const [messageApi, contextHolder] = notification.useNotification();

  setGlobalMessageApi(messageApi);

  return (
    <ConfigProvider theme={themeConfig}>
      <LoadingContext.Provider value={{ isLoading, setIsLoading }}>
        {isLoading ? <Loader /> : ""}
        {/*<ToastContainer />*/}
        {contextHolder}
        <AppDataProvider>
          <App />
        </AppDataProvider>
      </LoadingContext.Provider>
    </ConfigProvider>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Root />);
