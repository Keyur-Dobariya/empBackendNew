import React, { useEffect, useState } from "react";
import { Button, Form } from "antd";
import DynamicForm from "../../components/formField/DynamicForm";
import { useNavigate } from "react-router-dom";
import { emailFieldConfig, passwordFieldConfig } from "../../config/formConfig";
import { Loader } from "../../components/Loader";
import { loginApi } from "../../api/apiUtils";
import Container from "../../components/common/Container";
import imagePaths from "../../assets/assetsPaths";
import Card from "../../components/common/Card";
import AppText from "../../components/common/AppText";
import appString from "../../utils/appString";
import appColor from "../../utils/appColors";
import SpaceBox from "../../components/common/SpaceBox";
import Column from "../../components/common/Column";
import Row from "../../components/common/Row";
import { useLoading } from "../..";
import apiCall, { HttpMethod } from "../../api/apiServiceProvider";
import { endpoints, environment } from "../../api/apiEndpoints";
import { loginDataKeys } from "../../dataStorage/DataPref";
import { showToast } from "../../components/CommonComponents";

export default function Login() {
  const navigate = useNavigate();
  const { setIsLoading } = useLoading();
  const [form] = Form.useForm();
  const [formValues, setFormValues] = useState({});

  const initialConfig = [emailFieldConfig(), passwordFieldConfig()];

  useEffect(() => {
    window.history.pushState(null, null);
    window.onpopstate = function () {
      window.history.go(1);
    };

    if (environment.isDev === true) {
      const formData = {
        emailAddress: "keyur.teqheal@gmail.com",
        password: "Admin@123",
      };

      form.setFieldsValue(formData);
      setFormValues(formData);
    }

    return () => {
      // Cleanup function if needed
    };
  }, []);

  const handleFieldChange = (values) => {
    setFormValues(values);
  };

  const handleForgotPassword = () => {
    navigate("/sendEmailOtp", {
      state: { emailAddress: formValues.emailAddress },
    });
  };

  const handleSubmit = async () => {
    try {
      await form.validateFields([
        "emailAddress",
        "password",
      ]);
      loginApi({
        form: form,
        formValues: formValues,
        setIsLoading: setIsLoading,
        navigate: navigate,
      });
    } catch (error) {
      console.error("Form validation failed:", error);
    }
  };

  const handleSignUpClick = () => {
    navigate("/signUp");
  };

  return (
    <Container
      padding="15px"
      width="100vw"
      height="100vh"
      backgroundColor="white"
      backgroundImage={imagePaths.bgImage}
      backgroundSize="cover"
      display="flex"
      justifyContent="center"
      alignItems="center"
    >
      <Card
        width="22rem"
        padding="20px"
        elevation="0px 7px 29px 0px rgba(100, 100, 111, 0.2)"
      >
        <AppText
          text={appString.loginTitle}
          fontSize="24px"
          fontWeight="600"
          color={appColor.primary}
        />
        <AppText
          text={appString.loginDes}
          fontSize="14px"
          color={appColor.black}
        />
        <SpaceBox space={5} />
        <DynamicForm
          formConfig={initialConfig}
          form={form}
          onFieldChange={handleFieldChange}
        />
        <Column alignItems="end">
          <AppText
            text={`${appString.forgotPassword}?`}
            fontSize="14px"
            fontWeight={600}
            color={appColor.primary}
            textAlign="right"
            isLink={true}
            onClick={handleForgotPassword}
          />
        </Column>
        <SpaceBox space={5} />
        <Button
          className="btnStyle"
          block
          type="primary"
          htmlType="submit"
          onClick={handleSubmit}
        >
          {appString.login}
        </Button>
        <SpaceBox space={5} />
        <Row alignItems="center" justifyContent="center">
          <AppText text={appString.dontHaveAccount} fontSize="14px" />
          <SpaceBox space={1} />
          <AppText
            text={appString.signUp}
            fontSize="15px"
            fontWeight={600}
            color={appColor.primary}
            isLink={true}
            onClick={handleSignUpClick}
          />
        </Row>
      </Card>
    </Container>
  );
}
