import React, { useState } from "react";
import { Button, Form } from "antd";
import { User } from "react-feather";
import DynamicForm from "../../components/formField/DynamicForm";
import { useNavigate } from "react-router-dom";
import {
  confirmPasswordFieldConfig,
  emailFieldConfig,
  mobileFieldConfig,
  passwordFieldConfig,
} from "../../config/formConfig";
import { Loader } from "../../components/Loader";
import Container from "../../components/common/Container";
import imagePaths from "../../assets/assetsPaths";
import Card from "../../components/common/Card";
import AppText from "../../components/common/AppText";
import appString from "../../utils/appString";
import appColor from "../../utils/appColors";
import SpaceBox from "../../components/common/SpaceBox";
import Row from "../../components/common/Row";
import { signupApi } from "../../api/apiUtils";

export default function SignUp() {
  const [isLoading, setIsLoading] = useState(false);
  const [form] = Form.useForm();
  const [formValues, setFormValues] = useState({});

  const initialConfig = [
    {
      name: "fullName",
      placeholder: "Full Name",
      prefix: <User />,
      rules: [{ required: true, message: "Please enter your full name!" }],
    },
    emailFieldConfig(),
    mobileFieldConfig(),
    passwordFieldConfig(),
    confirmPasswordFieldConfig(form),
  ];

  const handleFieldChange = (values) => {
    setFormValues(values);
    if (values.password) {
      form.validateFields(["confirmPassword"]);
    }
  };

  const navigate = useNavigate();

  const handleSubmit = async () => {
    try {
      await form.validateFields([
        "fullName",
        "emailAddress",
        "mobileNumber",
        "password",
        "confirmPassword",
      ]);
      signupApi({
        form: form,
        formValues: formValues,
        setIsLoading: setIsLoading,
        navigate: navigate,
      });
    } catch (error) {
      console.error("Form validation failed:", error);
    }
  };

  return (
    <>
      {isLoading ? <Loader /> : ""}
      <Container
        padding="15px"
        width="100vw"
        height="100vh"
        backgroundColor="white"
        backgroundImage={imagePaths.bgImage}
        backgroundSize="cover"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        <Card
          width="22rem"
          padding="20px"
          elevation="0px 7px 29px 0px rgba(100, 100, 111, 0.2)"
        >
          <AppText
            text={appString.signUp}
            fontSize="24px"
            fontWeight="600"
            color={appColor.primary}
          />
          <AppText
            text={appString.signUpDes}
            fontSize="14px"
            color={appColor.black}
          />
          <SpaceBox space={5} />
          <DynamicForm
            formConfig={initialConfig}
            form={form}
            onFieldChange={handleFieldChange}
          />
          <SpaceBox space={2} />
          <Button
            className="btnStyle"
            block
            type="primary"
            htmlType="submit"
            onClick={handleSubmit}
          >
            {appString.signUp}
          </Button>
          <SpaceBox space={5} />
          <Row alignItems="center" justifyContent="center">
            <AppText text={appString.alreadyHaveAccount} fontSize="14px" />
            <SpaceBox space={1} />
            <AppText
              text={appString.login}
              fontSize="15px"
              fontWeight={600}
              color={appColor.primary}
              isLink={true}
              onClick={() => {
                navigate("/login");
              }}
            />
          </Row>
        </Card>
      </Container>
    </>
  );
}
