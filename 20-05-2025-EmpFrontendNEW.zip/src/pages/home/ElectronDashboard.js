import React, { useEffect, useRef, useState } from "react";
import {
  Avatar,
  Carousel,
  Dropdown,
  FloatButton,
  Form,
  Modal,
  Tooltip,
} from "antd";
import {
  ArrowLeft,
  PlusCircle,
  PlusSquare,
  SkipBack,
  User,
} from "react-feather";
import {
  getLocalData,
  loginDataKeys,
  storeLoginData,
} from "../../dataStorage/DataPref";
import {
  checkImageExists,
  getTwoCharacterFromName,
  showToast,
} from "../../components/CommonComponents";
import "../../components/sidebar/Sidebar.css";
import { useLocation, useNavigate } from "react-router-dom";
import AppText from "../../components/common/AppText";
import SpaceBox from "../../components/common/SpaceBox";
import { LogOut, Settings } from "react-feather";
import appColor from "../../utils/appColors";

import Card from "../../components/common/Card";
import Column from "../../components/common/Column";
import Container from "../../components/common/Container";
import Row from "../../components/common/Row";
import TrackingComponent from "./TrackingComponent";
import { LeftOutlined } from "@ant-design/icons";
import appKeys from "../../utils/appKeys";
import AppTextFormField, {
  InputType,
} from "../../components/common/AppTextFormField";
import appString from "../../utils/appString";
import apiCall, { HttpMethod } from "../../api/apiServiceProvider";
import { endpoints } from "../../api/apiEndpoints";
import { useLoading } from "../..";
import { format } from "date-fns";
import imagePaths from "../../assets/assetsPaths";

const ElectronDashboard = () => {
  // const location = useLocation();
  // const queryParams = new URLSearchParams(location.search);
  // const userId = queryParams.get("userId");
  // const jwtToken = queryParams.get("jwtToken");

  const navigate = useNavigate();
  const { setIsLoading } = useLoading();
  const [logoutModelOpen, setLogoutModelOpen] = useState(false);
  const [taskAddModelOpen, setTaskAddModelOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const carouselRef = useRef(null);

  const onChange = (currentSlide) => {
    setCurrentSlide(currentSlide);
  };
  const [attendanceData, setAttendanceData] = useState({});

  const [form] = Form.useForm();

  const handleFieldChange = (changedValues, allValues) => {
    form.setFieldsValue(allValues);
  };

  useEffect(() => {
    getTodayAttendanceApi();
  }, []);

  const getTodayAttendanceApi = async () => {
    try {
      await apiCall({
        method: HttpMethod.GET,
        url: `${endpoints.getTodayAttendance}/${getLocalData(loginDataKeys._id)}`,
        showSuccessMessage: false,
        setIsLoading: setIsLoading,
        successCallback: (data) => {
          const responseData = data["data"];
          setAttendanceData(responseData);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  };

  const callAttendanceApi = async ({ data }) => {
    try {
      const userId = getLocalData(loginDataKeys._id);

      const requestData = {
        userId: userId,
        ...data,
      };

      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.addAttendance,
        data: requestData,
        showSuccessMessage: true,
        setIsLoading: setIsLoading,
        successCallback: async (data) => {
          const responseData = data["data"];
          setAttendanceData(responseData);
          setTaskAddModelOpen(false);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
      setTaskAddModelOpen(false);
    }
  };

  const formateTime = (time) => {
    return format(time, "hh:mm a");
  };

  return (
    <>
      <Container width={"100%"} height="100%">
        <Column>
          <Card
            height="60px"
            margin="10px"
            borderRadius="10px"
            padding="10px 10px"
          >
            <Row justifyContent="space-between" alignItems="center">
              <Row>
                {currentSlide === 1 ? (
                  <div
                    style={{
                      width: 20,
                      height: 20,
                      marginRight: 5,
                      alignSelf: "center",
                      cursor: "pointer",
                    }}
                    onClick={() => {
                      carouselRef.current.prev();
                    }}
                  >
                    <Tooltip title="Go Back">
                      <ArrowLeft className="normalIconStyle" size="100%" />
                    </Tooltip>
                  </div>
                ) : null}
                {getLocalData(loginDataKeys.profilePhoto) ? (
                  <Avatar
                    size={40}
                    className="avatarImageStyle"
                    src={
                      <img
                        src={!checkImageExists(getLocalData(loginDataKeys.profilePhoto)) ? imagePaths.profile_placeholder : getLocalData(loginDataKeys.profilePhoto)}
                        alt="avatar"
                      />
                    }
                  />
                ) : (
                  <Avatar size={40} className="avatarTxtStyle">
                    {getTwoCharacterFromName(
                      getLocalData(loginDataKeys.fullName)
                    )}
                  </Avatar>
                )}
                <SpaceBox space={2} />
                <Column>
                  <AppText
                    text={getLocalData(loginDataKeys.fullName)}
                    fontSize={14}
                    fontWeight={600}
                    color={appColor.primary}
                  />
                  <AppText
                    text={getLocalData(loginDataKeys.role)}
                    fontSize={12.5}
                    fontWeight={450}
                    color={appColor.secondary}
                  />
                </Column>
              </Row>
              <Row>
                {currentSlide === 0 ? (
                  <div
                    style={{
                      width: 22,
                      height: 22,
                      cursor: "pointer",
                    }}
                    onClick={() => carouselRef.current.next()}
                  >
                    <Tooltip title="Add Task">
                      <PlusCircle
                        className="successIconStyle"
                        size="100%"
                        color={appColor.success}
                      />
                    </Tooltip>
                  </div>
                ) : null}
                <SpaceBox space={3} />
                <div
                  style={{
                    width: 20,
                    height: 20,
                    cursor: "pointer",
                  }}
                  onClick={() => setLogoutModelOpen(true)}
                >
                  <Tooltip title="LogOut">
                    <LogOut
                      className="deleteIconStyle"
                      size="100%"
                      color={appColor.danger}
                    />
                  </Tooltip>
                </div>
              </Row>
            </Row>
          </Card>
          <Card
            borderRadius={10}
            padding={"0px"}
            margin="0px 10px 10px 10px"
            height="80vh"
          >
            <Carousel
              ref={carouselRef}
              afterChange={onChange}
              style={{ height: "80vh", margin: "0px", padding: "0px" }}
              dots={false}
            >
              <TrackingComponent
                height="80vh"
                isElectron={true}
                trackingData={(data) => {
                  setAttendanceData(data);
                }}
              />
              <Container height={"80vh"} padding={"0px"}>
                <Container
                  width="100%"
                  height="50px"
                  padding="10px 10px 10px 15px"
                >
                  <Row justifyContent={"space-between"} alignItems={"center"}>
                    <AppText
                      text="Todays Tasks"
                      fontSize={15}
                      fontWeight={550}
                      color={appColor.primary}
                    />
                    <Container
                      width="90px"
                      height="30px"
                      backgroundColor={appColor.primary}
                      borderRadius={10}
                      display={"flex"}
                      justifyContent={"center"}
                      alignItems={"center"}
                      cursor={"pointer"}
                      onClick={() => {
                        setTaskAddModelOpen(true);
                      }}
                    >
                      <AppText
                        text="Add Task"
                        fontSize={13}
                        fontWeight={450}
                        style={{ cursor: "pointer" }}
                        color={appColor.white}
                      />
                    </Container>
                  </Row>
                </Container>
                {attendanceData &&
                attendanceData.tasks &&
                Array.isArray(attendanceData.tasks)
                  ? attendanceData.tasks.map((item, index) => (
                      <div
                        style={{
                          width: "100%",
                          padding: "10px 15px",
                          borderBottom: "1px solid #f0f0f0",
                        }}
                      >
                        <AppText
                          text={item.title}
                          fontSize={14}
                          fontWeight={500}
                          color={appColor.black}
                        />
                        <AppText
                          text={item.description}
                          fontSize={11}
                          fontWeight={400}
                          color={appColor.secondary}
                        />
                        <AppText
                          text={
                            item.endTime
                              ? `${formateTime(item.startTime)} - ${formateTime(
                                  item.endTime
                                )}`
                              : "Working on this task"
                          }
                          fontSize={12}
                          fontWeight={400}
                          color={appColor.primary}
                        />
                      </div>
                    ))
                  : null}
              </Container>
            </Carousel>
          </Card>
        </Column>
      </Container>
      <Modal
        title="Add New Task"
        width="100%"
        maskClosable={true}
        centered
        closeIcon={false}
        open={taskAddModelOpen}
        onOk={() => {
          callAttendanceApi({ data: form.getFieldsValue() });
        }}
        onCancel={() => {
          setTaskAddModelOpen(false);
        }}
        onClose={() => {
          setTaskAddModelOpen(false);
        }}
        okText="Add"
      >
        <Form
          form={form}
          name="EmpAddUpdateModel"
          layout="vertical"
          onValuesChange={handleFieldChange}
          initialValues={form.getFieldsValue()}
          style={{
            // marginRight: 15,
            // marginTop: 15,
            alignContent: "center",
          }}
        >
          <AppTextFormField
            name={appKeys.taskTitle}
            label={appString.taskTitle}
            type={InputType.Text}
            placeholder={appString.taskTitle}
            value={form.getFieldValue(appKeys.taskTitle)}
            span={24}
          />
          <AppTextFormField
            name={appKeys.taskDescription}
            label={appString.taskDescription}
            type={InputType.TextArea}
            placeholder={appString.taskDescription}
            value={form.getFieldValue(appKeys.taskDescription)}
            span={24}
          />
        </Form>
      </Modal>

      <Modal
        title="Confirmation!"
        width="auto"
        maskClosable={true}
        centered
        closeIcon={false}
        open={logoutModelOpen}
        onOk={() => {
          setLogoutModelOpen(false);
          localStorage.clear();
          navigate("/login");
        }}
        onCancel={() => {
          setLogoutModelOpen(false);
        }}
        onClose={() => {
          setLogoutModelOpen(false);
        }}
        okText="LogOut"
      >
        <AppText
          text="Are you sure you want to log out? All your data will be lost."
          fontSize={14}
        />
        <SpaceBox space={5} />
      </Modal>
    </>
  );
};

export default ElectronDashboard;
