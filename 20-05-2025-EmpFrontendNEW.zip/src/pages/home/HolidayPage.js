import React, {useEffect, useRef, useState} from "react";
import "./CalendarStyles.css";
import {Plus, X} from "react-feather";
import {
    Modal,
    Tooltip,
    Button,
    Form,
    Tag,
    DatePicker,
    Popover,
    Popconfirm,
    Divider,
    Switch
} from "antd";
import appColor from "../../utils/appColors";
import dayjs from "dayjs";
import {
    DeleteOutlined,
    EditOutlined,
    InfoCircleOutlined,
    PushpinFilled,
    PushpinOutlined
} from "@ant-design/icons";
import {
    eventLeaveTypeMenuList,
    eventTypeMenuList,
    getKeyByLabel,
    getLabelByKey,
} from "../../utils/enum";
import {endpoints} from "../../api/apiEndpoints";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import WrapBox from "../../components/common/WrapBox";
import AppTextFormField, {InputType} from "../../components/common/AppTextFormField";
import {isAdmin} from "../../utils/utils";
import {AppDataFields, useAppData} from "../../AppDataContext";

export default function HolidayPage() {
    const {eventsData, updateAppDataField} = useAppData();

    const months = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    const [isLoading, setIsLoading] = useState(false);
    const [events, setEvents] = useState({});
    const thisYear = new Date().getFullYear();
    const [currentYear, setCurrentYear] = useState(thisYear);
    const [selectedDateKey, setSelectedDateKey] = useState(null);
    const [isEditing, setIsEditing] = useState(null);
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const [openFromDateClick, setOpenFromDateClick] = useState(false);
    const [isLeaveOnDay, setIsLeaveOnDay] = useState(false);
    const [form] = Form.useForm();
    const [pinnedMonth, setPinnedMonth] = useState(() => {
        const stored = localStorage.getItem("pinnedMonth");
        return stored ? JSON.parse(stored) : null;
    });

    const [multiSelectedDates, setMultiSelectedDates] = useState([]);
    const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);

    useEffect(() => {
        setEvents(processEvents(eventsData, new Date().getFullYear()));
    }, [eventsData]);

    const setEventRecord = (data) => {
        updateAppDataField(AppDataFields.eventsData, data);
    }

    const processEvents = (rawEvents, currentYear) => {
        const result = {};

        rawEvents.forEach(event => {
            const date = new Date(event.eventDate);
            const month = date.getMonth();
            const day = date.getDate();

            if (event.eventType === "birthday") {
                const birthYear = date.getFullYear();
                for (let year = birthYear; year <= currentYear; year++) {
                    const key = `${year}-${month + 1}-${day}`;
                    if (!result[key]) result[key] = [];
                    result[key].push({...event});
                }
            } else {
                const key = `${date.getFullYear()}-${month + 1}-${day}`;
                if (!result[key]) result[key] = [];
                result[key].push({...event});
            }
        });

        return result;
    };

    const handleAddEventClick = () => {
        setShowAddModal(true);
        setOpenFromDateClick(false);
        setSelectedDateKey(dayjs());
    }

    useEffect(() => {
        if (!selectedEvent) {
            form.resetFields();
            return;
        }
        form.setFieldsValue(selectedEvent);
    }, [isEditing]);

    useEffect(() => {
    }, [selectedDateKey]);

    const handleDateClick = (monthIndex, day) => {
        const dateKey = `${currentYear}-${monthIndex + 1}-${day}`;
        if (isMultiSelectMode) {
            setMultiSelectedDates(prev => {
                if (prev.includes(dateKey)) {
                    return prev.filter(date => date !== dateKey);
                } else {
                    return [...prev, dateKey];
                }
            });
        } else {
            setSelectedDateKey(dateKey);
            setOpenFromDateClick(true);

            const eventList = events[dateKey];
            if (eventList && eventList.length > 0) {
                // setShowEventModal(true);
            } else {
                if (isAdmin()) {
                    setShowAddModal(true);
                }
            }
        }
    };

    const handleAddUpdateEventApi = async (eventId, values) => {
        try {
            const {eventDate} = values;

            let body;

            if (multiSelectedDates.length > 0) {
                body = multiSelectedDates.map(date => ({
                    ...values,
                    eventType: getKeyByLabel(values.eventType, eventTypeMenuList),
                    eventLeaveType: getKeyByLabel(values.eventLeaveType, eventLeaveTypeMenuList),
                    eventDate: dayjs(date).format("YYYY-MM-DD"),
                    isLeaveOnDay: isLeaveOnDay,
                }));
            } else {
                const isoDate = eventDate
                    ? dayjs(eventDate).format("YYYY-MM-DD")
                    : dayjs(selectedDateKey).format("YYYY-MM-DD");

                body = [{
                    ...values,
                    eventType: getKeyByLabel(values.eventType, eventTypeMenuList),
                    eventLeaveType: getKeyByLabel(values.eventLeaveType, eventLeaveTypeMenuList),
                    eventDate: isoDate,
                    isLeaveOnDay: isLeaveOnDay,
                }];
            }

            await apiCall({
                method: HttpMethod.POST,
                url: eventId ? `${endpoints.updateEvent}${eventId}` : endpoints.addEvent,
                // data: festivalList,
                data: body,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    handleAddEventModelCancel();
                    form.resetFields();
                    setEventRecord(data.data);
                    setIsMultiSelectMode(false);
                    setMultiSelectedDates([]);
                    setIsLeaveOnDay(false)
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    }

    const handleDeleteEvent = async (eventId) => {
        try {
            await apiCall({
                method: HttpMethod.DELETE,
                url: `${endpoints.deleteEvent}${eventId}`,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    setEventRecord(data.data);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    };

    const handleAddEventModelCancel = () => {
        setShowAddModal(false)
        setOpenFromDateClick(false);
        setIsEditing(null);
        setSelectedEvent(null);
    };

    const getOrderedMonths = () => {
        const allMonths = [...Array(12).keys()];
        return pinnedMonth?.year === currentYear
            ? [pinnedMonth.month, ...allMonths.filter((i) => i !== pinnedMonth.month)]
            : allMonths;
    };

    const renderMonth = (monthIndex) => {
        const daysInMonth = new Date(currentYear, monthIndex + 1, 0).getDate();
        const firstDay = new Date(currentYear, monthIndex, 1).getDay();
        const dates = Array.from({length: daysInMonth}, (_, i) => i + 1);

        const today = new Date();
        const todayKey = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
        const thisYear = today.getFullYear();

        const isPinnedMonth = pinnedMonth?.month === monthIndex && pinnedMonth?.year === currentYear;

        return (
            <div className="month" key={monthIndex}>
                <div className="monthHeader">
                    <h5>{months[monthIndex]}</h5>
                    <div className="pinUnpinMonth" style={{display: "flex", gap: "10px", alignItems: "center"}}>
                        {(monthIndex === new Date().getMonth() && currentYear === new Date().getFullYear()) && (
                            <Tooltip title={isPinnedMonth ? "Unpin this month" : "Pin this month"}>
                                {isPinnedMonth ? (
                                    <PushpinFilled
                                        className="normalIconStyle"
                                        onClick={() => {
                                            setPinnedMonth(null);
                                            localStorage.removeItem("pinnedMonth");
                                        }}
                                    />
                                ) : (
                                    <PushpinOutlined
                                        className="greyIconStyle"
                                        onClick={() => {
                                            const pinned = {month: monthIndex, year: currentYear};
                                            setPinnedMonth(pinned);
                                            localStorage.setItem("pinnedMonth", JSON.stringify(pinned));
                                        }}
                                    />
                                )}
                            </Tooltip>
                        )}
                        <Popover
                            title={`${months[monthIndex]} Events`}
                            content={
                                <div className="popoverEvents">
                                    {Object.entries(events)
                                        .filter(([key]) => {
                                            const [y, m] = key.split("-").map(Number);
                                            return y === currentYear && m === monthIndex + 1;
                                        })
                                        .map(([key, evList], idx) => (
                                            <div key={idx} style={{marginBottom: "10px"}}>
                                                <strong style={{
                                                    fontSize: "13px",
                                                    fontWeight: "550",
                                                    color: "#292929"
                                                }}>{dayjs(key).format("dddd, DD MMM")}:</strong>
                                                <ul style={{paddingLeft: "20px", margin: 0}}>
                                                    {evList.map((ev, i) => (
                                                        <li key={i}>
                                                            {getLabelByKey(ev.eventType, eventTypeMenuList)?.split(" ")[0] || "📅"} {ev.eventTitle}
                                                            {ev.eventType === "birthday" ? "'s Birthday" : ""}
                                                        </li>
                                                    ))}
                                                </ul>
                                                <Divider style={{margin: "10px 0"}}/>
                                            </div>
                                        ))}
                                    {Object.entries(events).filter(([key]) => {
                                        const [y, m] = key.split("-").map(Number);
                                        return y === currentYear && m === monthIndex + 1;
                                    }).length === 0 && <p>No events</p>}
                                </div>
                            }
                        >
                            <InfoCircleOutlined className="greyIconStyle" style={{cursor: "pointer"}}/>
                        </Popover>
                    </div>
                </div>

                <div className="weekdays">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
                        <div key={d} className="weekday">{d}</div>
                    ))}
                </div>
                <div className="days">
                    {Array(firstDay).fill(null).map((_, i) => <div key={`empty-${i}`} className="empty"></div>)}
                    {dates.map((day) => {
                        const dateKey = `${currentYear}-${monthIndex + 1}-${day}`;
                        const isSunday = new Date(currentYear, monthIndex, day).getDay() === 0;
                        const isToday = currentYear === thisYear && dateKey === todayKey;
                        const eventList = events[dateKey] || [];

                        const isHoliday = eventList.some(ev => ev.eventType === "holiday" || ev.isLeaveOnDay || ev.eventType === "offSaturday");
                        const isWorkingSaturday = eventList.some(ev => ev.eventType === "workingSaturday");
                        const isMultiSelected = multiSelectedDates.includes(dateKey);

                        const showPopover = eventList.length > 0;

                        const popoverTitle = `${day} ${months[monthIndex].substring(0, 3)}, Events`;

                        const popoverContent = (
                            <div className="popoverEvents">
                                {eventList.map((ev, idx) => (
                                    <div key={idx} className="popoverEventItem"
                                         style={{gap: "10px", marginTop: "10px"}}>
                                        <span>{`${getLabelByKey(ev.eventType, eventTypeMenuList)?.split(" ")[0] || "📅"} ${ev.eventTitle}${ev.eventType === 'birthday' ? "'s Birthday" : ""}`}</span>

                                        {(isAdmin() && ev.isFromDb === true) && (
                                            <span className="popoverActions">
                        <Tooltip title="Edit Event">
                          <EditOutlined
                              className="normalIconStyle"
                              style={{
                                  color: appColor.primary,
                                  marginLeft: "10px",
                                  marginRight: "5px",
                                  cursor: "pointer"
                              }}
                              onClick={() => {
                                  setSelectedDateKey(`${currentYear}-${monthIndex + 1}-${day}`);
                                  setIsEditing(ev.eventId);
                                  setShowAddModal(true);
                                  setOpenFromDateClick(false);
                                  setSelectedEvent({
                                      eventTitle: ev.eventTitle,
                                      eventDetail: ev.eventDetail,
                                      eventType: getLabelByKey(ev.eventType, eventTypeMenuList),
                                      eventLeaveType: getLabelByKey(ev.eventLeaveType, eventLeaveTypeMenuList),
                                      eventDate: dayjs(ev.eventDate),
                                      isLeaveOnDay: ev.isLeaveOnDay,
                                  });
                                  setIsLeaveOnDay(ev.isLeaveOnDay);
                              }}
                          />
                        </Tooltip>
                        <Popconfirm
                            title={appString.deleteConfirmation}
                            onConfirm={() => handleDeleteEvent(ev.eventId)}
                            style={{margin: "0"}}
                        >
                          <Tooltip title="Delete Event">
                            <DeleteOutlined
                                className="deleteIconStyle"
                                style={{color: appColor.danger, cursor: "pointer"}}
                            />
                          </Tooltip>
                        </Popconfirm>

                      </span>
                                        )}
                                    </div>
                                ))}
                            </div>
                        );

                        const dayCell = (
                            <div
                                key={day}
                                className={`day ${(eventList.length > 0) ? "event-day" : ""} ${(isSunday || isHoliday) ? "sunday" : ""} ${isToday ? "today" : ""} ${isMultiSelected ? 'multi-selected' : ''} ${isWorkingSaturday ? 'workingSaturday' : ''}`}
                                onClick={() => handleDateClick(monthIndex, day)}
                            >
                                <div>{day}</div>
                                <EventIcons eventList={eventList}/>
                            </div>
                        );

                        return showPopover ? (
                            <Popover
                                placement="top"
                                title={popoverTitle}
                                content={
                                    <div>
                                        {eventList.length > 0 ? (
                                            popoverContent
                                        ) : (
                                            <p>No Events</p>
                                        )}
                                        {isAdmin() && (<Button
                                            type="link"
                                            size="small"
                                            onClick={() => {
                                                setSelectedDateKey(`${currentYear}-${monthIndex + 1}-${day}`);
                                                setOpenFromDateClick(true);
                                                setShowAddModal(true);
                                            }}
                                            style={{
                                                padding: 0,
                                                marginTop: "10px",
                                                color: appColor.primary,
                                                fontWeight: "550"
                                            }}
                                        >
                                            + Add Event
                                        </Button>)}
                                    </div>
                                }
                            >
                                {dayCell}
                            </Popover>
                        ) : (
                            dayCell
                        );
                    })}
                </div>
            </div>
        );
    };

    const tagColors = [
        "magenta",
        "red",
        "volcano",
        "orange",
        "gold",
        "lime",
        "green",
        "cyan",
        "blue",
        "geekblue",
        "purple"
    ];

    const getRandomColor = () => {
        return tagColors[Math.floor(Math.random() * tagColors.length)];
    };

    const handleIsLeaveOnDayStatus = (checked) => {
        setIsLeaveOnDay(checked);
        const updatedValues = { ...form.getFieldsValue(), isLeaveOnDay: checked };
        form.setFieldsValue(updatedValues);
    }

    return (
        <div className="mainContainer">
            <div className="calenderHeader">
                <div className="pageHeader">{`Holidays/Events Calendar ${currentYear}`}</div>
                <div className="taskheaderManageSection">
                    <DatePicker defaultValue={dayjs()} className="filterTaskButton" allowClear={false}
                                style={{width: "100px"}} onChange={(date, dateString) => {
                        setCurrentYear(date ? date.year() : thisYear);
                    }} picker="year"/>
                    {isAdmin() && (
                        <div className="addTaskButton" onClick={handleAddEventClick}>
                            <Plus className="whiteIconStyle"/>
                            <div>Add Event</div>
                        </div>)}
                    {(isAdmin() && !isMultiSelectMode) && (
                        <Tooltip
                            title={isMultiSelectMode ? "Clear all selected dates" : "Select multiple dates"}
                        >
                            {isMultiSelectMode ? (
                                <Popconfirm
                                    title="Sure you want to clear all selected dates?"
                                    onConfirm={() => {
                                        setIsMultiSelectMode(false);
                                        setMultiSelectedDates([]);
                                    }}
                                    style={{marginRight: 35}}
                                >
                                    <div className="filterTaskButton">
                                        <X/>
                                    </div>
                                </Popconfirm>
                            ) : (
                                <div
                                    className="filterTaskButton"
                                    onClick={() => {
                                        setIsMultiSelectMode(true);
                                    }}
                                >
                                    <Plus/>
                                </div>
                            )}
                        </Tooltip>
                    )}
                </div>
            </div>

            {
                isMultiSelectMode && (
                    <div className="saveMultiEventBox">
                        {multiSelectedDates.length > 0 ? <div style={{display: "flex", flexWrap: "wrap", gap: "8px"}}>
                            {multiSelectedDates.map((date, index) => (
                                <Tag color={getRandomColor()} key={index}>
                                    {date}
                                </Tag>
                            ))}
                        </div> : <div>No dates selected. Tap on date to select.</div>}
                        <div style={{display: "flex", gap: "10px" , alignItems: "center"}}>
                            <Button disabled={multiSelectedDates <= 0} color="primary" variant="solid" onClick={() => {
                                setShowAddModal(true);
                            }} >
                                Save Events
                            </Button>
                            <Popconfirm
                                title="Sure you want to clear all selected dates?"
                                onConfirm={() => {
                                    setIsMultiSelectMode(false);
                                    setMultiSelectedDates([]);
                                }}
                                style={{marginRight: 35}}
                            >
                                <Tooltip title="Clear all selected dates" placement="bottom">
                                    <X style={{cursor: "pointer"}}/>
                                </Tooltip>
                            </Popconfirm>
                        </div>
                    </div>
                )
            }

            <div className="calendar-container">
                {getOrderedMonths().map((monthIndex) => renderMonth(monthIndex))}
            </div>

            {showAddModal ? <Modal
                title={isEditing ? "Edit Event" : "Add Event"}
                open={showAddModal}
                onCancel={handleAddEventModelCancel}
                onClose={handleAddEventModelCancel}
                okText="Save"
                onOk={() => form.submit()}
                confirmLoading={isLoading}
            >
                <Form
                    form={form}
                    name="EventModel"
                    layout="vertical"
                    onFinish={(values) => {
                        handleAddUpdateEventApi(isEditing, values);
                    }}
                >
                    <WrapBox>
                        <AppTextFormField
                            name={appKeys.eventTitle}
                            label={appString.eventTitle}
                            placeholder={appString.eventTitle}
                            isRequired={true}
                            span={24}
                        />
                        <AppTextFormField
                            showSearch={true}
                            name={appKeys.eventType}
                            label={appString.eventType}
                            type={InputType.Select}
                            selectOptions={eventTypeMenuList}
                        />
                        <AppTextFormField
                            name={appKeys.eventLeaveType}
                            label={appString.eventLeaveType}
                            type={InputType.Select}
                            selectOptions={eventLeaveTypeMenuList}
                        />
                        <AppTextFormField
                            name={appKeys.eventDetail}
                            label={appString.eventDetail}
                            type={InputType.TextArea}
                            placeholder={appString.eventDetail}
                            value={form.getFieldValue(appKeys.eventDetail)}
                            span={24}
                        />
                        {
                            !isMultiSelectMode && !openFromDateClick ? <AppTextFormField
                                name={appKeys.eventDate}
                                label={appString.eventDate}
                                type={InputType.DatePicker}
                                defaultValue={selectedDateKey ? dayjs(selectedDateKey) : dayjs()}
                                // onDateSelect ={onDobSelect}
                            /> : null
                        }
                        <Form.Item name={appKeys.isLeaveOnDay} label={appString.isLeaveOnDay}>
                            <Switch
                                checked={isLeaveOnDay}
                                onChange={handleIsLeaveOnDayStatus}
                            />
                        </Form.Item>
                        {
                            isMultiSelectMode ? <div style={{display: "flex", flexWrap: "wrap", gap: "8px"}} span={24}>
                                {multiSelectedDates.map((date, index) => (
                                    <Tag color={getRandomColor()} key={index}>
                                        {date}
                                    </Tag>
                                ))}
                            </div> : null
                        }
                    </WrapBox>
                </Form>
            </Modal> : null}
        </div>
    );
}

const EventIcons = ({eventList}) => {
    const containerRef = useRef(null);
    const iconRef = useRef(null);
    const [maxIcons, setMaxIcons] = useState(eventList.length);

    useEffect(() => {
        const calculateMaxIcons = () => {
            if (containerRef.current && iconRef.current) {
                const containerWidth = containerRef.current.offsetWidth;
                const iconWidth = iconRef.current.offsetWidth;
                const fitCount = Math.floor(containerWidth / iconWidth);
                setMaxIcons(fitCount);
            }
        };

        calculateMaxIcons();
        window.addEventListener("resize", calculateMaxIcons);

        return () => {
            window.removeEventListener("resize", calculateMaxIcons);
        };
    }, [eventList]);

    const visibleEventList = eventList.filter(ev => !ev.isSilentLeave);
    const visibleEvents = visibleEventList.slice(0, maxIcons);
    const hiddenCount = visibleEventList.length - visibleEvents.length;

    return (
        <div className="icons" ref={containerRef}>
            {visibleEvents.map((ev, idx) => (
                <span
                    key={idx}
                    className="eventIcon"
                    ref={idx === 0 ? iconRef : null}
                >
                {getLabelByKey(ev.eventType, eventTypeMenuList)?.split(" ")[0] || "📅"}
            </span>
            ))}
            {hiddenCount > 0 && (
                <span className="eventIcon">+{hiddenCount}</span>
            )}
        </div>
    );
};
