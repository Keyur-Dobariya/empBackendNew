import React, { useEffect, useState } from "react";
import { getLocalData, loginDataKeys } from "../../dataStorage/DataPref";
import AddUpdateEmpModel from "../../model/AddUpdateEmpModel";
import { Button, Form, Tabs } from "antd";
import Card from "../../components/common/Card";
import Column from "../../components/common/Column";
import appKeys from "../../utils/appKeys";
import appString from "../../utils/appString";
import AppTextFormField, {
  InputType,
} from "../../components/common/AppTextFormField";
import {
  confirmPasswordFieldRules,
  passwordFieldRules,
} from "../../config/formConfig";
import { changePasswordApi } from "../../api/apiUtils";
import { Loader } from "../../components/Loader";
import {AppDataFields, useAppData} from "../../AppDataContext";

export default function MyProfilePage() {
  const {loginUserData, updateAppDataField} = useAppData();
  const [employeeData, setEmployeesData] = useState(loginUserData);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("1");
  const [form] = Form.useForm();

  useEffect(() => {
    setEmployeesData(loginUserData);
  }, [loginUserData]);

  const handleTabChange = (key) => {
    setActiveTab(key);
  };

  const items = [
    {
      key: "1",
      label: "My Profile",
    },
    {
      key: "2",
      label: "Change Password",
    },
  ];

  const handleSubmit = () => {
    changePasswordApi({
      form: form,
      setIsLoading: setIsLoading,
    });
  };

  return (
    <>
      {isLoading ? (
        <Loader />
      ) : (
        <Card padding="20px 20px" height="100%">
          <Tabs
            defaultActiveKey="1"
            items={items}
            tabPosition="top"
            onChange={handleTabChange}
          />
          <div
            style={{
              maxHeight: "calc(100vh - 180px)",
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            {activeTab === "1" && (
              <Column justifyContent={"center"} alignItems={"center"}>
                <AddUpdateEmpModel
                  employeeData={employeeData}
                  isEditing={true}
                  onSuccessCallback={(data) => {
                    const employeeFilterData = data?.data.filter(emp => emp._id.toString() === getLocalData(loginDataKeys._id));
                    updateAppDataField(AppDataFields.loginUserData, employeeFilterData[0]);
                  }}
                  isModel={false}
                />
              </Column>
            )}
            {activeTab === "2" && (
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: "100px",
                }}
              >
                <div
                  style={{
                    border: "1px solid rgb(223, 223, 223)",
                    padding: "20px",
                    borderRadius: "10px",
                    width: "380px",
                  }}
                >
                  <Form
                    form={form}
                    name="EmpAddUpdateModel"
                    layout="vertical"
                    style={{
                      marginRight: 15,
                      marginTop: 15,
                      alignContent: "center",
                    }}
                  >
                    <AppTextFormField
                      name="oldPassword"
                      label={appString.oldPassword}
                      type={InputType.Password}
                      rules={passwordFieldRules}
                      isRequired={true}
                      placeholder={appString.oldPassword}
                    />
                    <AppTextFormField
                      name={appKeys.newPassword}
                      label={appString.newPassword}
                      type={InputType.Password}
                      rules={passwordFieldRules}
                      isRequired={true}
                      placeholder={appString.newPassword}
                    />
                    <AppTextFormField
                      name={appKeys.confirmPassword}
                      label={appString.confirmPassword}
                      type={InputType.Password}
                      rules={confirmPasswordFieldRules(form)}
                      isRequired={true}
                      placeholder={appString.confirmPassword}
                    />
                    <div style={{ display: "flex", justifyContent: "right" }}>
                      <Button
                        type="primary"
                        onClick={handleSubmit}
                        style={{ margin: "10px 0px", width: "200px" }}
                      >
                        Change Password
                      </Button>
                    </div>
                  </Form>
                </div>
              </div>
            )}
          </div>
        </Card>
      )}
    </>
  );
}
