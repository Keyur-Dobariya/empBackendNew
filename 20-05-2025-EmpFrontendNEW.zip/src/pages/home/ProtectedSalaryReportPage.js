import { useParams, useLocation, Navigate } from 'react-router-dom';
import SalaryReportPage from "./SalaryReportPage";

const ProtectedSalaryPage = () => {
    const { verificationKey } = useParams();
    const location = useLocation();
    const { paramDetail } = location.state || {};
    const code = paramDetail?.code;

    if (!code || code !== verificationKey) {
        return <Navigate to="*" replace />;
    }

    return <SalaryReportPage />;
};

export default ProtectedSalaryPage;