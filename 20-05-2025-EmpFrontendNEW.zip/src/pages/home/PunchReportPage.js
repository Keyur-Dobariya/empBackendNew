import React, {useEffect, useState} from "react";
import {CloseOutlined, EditOutlined} from '@ant-design/icons';
import imagePaths from "../../assets/assetsPaths";
import {
    Search,
} from "react-feather";
import {
    Avatar,
    Button, Col,
    Card, Row,
    Select,
    Spin,
    Table,
    Tag, Modal, Form, Input, TimePicker, DatePicker,
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    ApprovalStatus, reportTypeKey, reportTypeLabels,
} from "../../utils/enum";
import {
    getPunchReportList,
    getUsersList
} from "../../api/apiUtils";
import {UserRole} from './../../utils/enum';
import {SearchTextField} from "../../components/formField/DynamicForm";

import PunchReportAddUpdateModel from "../../model/PunchReportAddUpdateModel";
import appKeys from "../../utils/appKeys";
import dayjs from "dayjs";
import {showToast} from "../../components/CommonComponents";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import appString from "../../utils/appString";
import {antTag} from "../../common/colorTag";
import {isAdmin} from "../../utils/utils";

const {Option} = Select;

const PunchReportPage = () => {

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isAddPunchReportModelOpen, setAddPunchReportModelOpen] = useState(false);
    const [isPunchReportEditing, setIsPunchReportEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [punchReportRecord, setPunchReportRecord] = useState([]);
    const [punchReportFullRecord, setPunchReportFullRecord] = useState([]);
    const [selectedPunchReportRecord, setSelectedPunchReportRecord] = useState({});
    const [originalPunchReport, setOriginalPunchReport] = useState({});
    const [employeeRecord, setEmployeeRecord] = useState([]);

    const now = new Date();
    const prevMonth = now.getMonth();
    const defaultMonth = prevMonth === 0 ? 12 : prevMonth;
    const defaultYear = prevMonth === 0 ? now.getFullYear() - 1 : now.getFullYear();

    const defaultMonthDayjs = dayjs(`${defaultYear}-${String(defaultMonth).padStart(2, '0')}`, 'YYYY-MM');
    const defaultYearDayjs = dayjs(defaultYear, 'YYYY');

    const [filters, setFilters] = useState({
        user: isAdmin() ? null : getLocalData(loginDataKeys._id),
        year: null,
        month: null,
        // year: defaultYear,
        // month: defaultMonth,
    });

    useEffect(() => {
        getEmployeeData();
    }, []);

    const getQueryParams = () => {
        const params = new URLSearchParams();
        if (filters.user) params.append('user', filters.user);
        if (filters.year) params.append('year', filters.year);
        if (filters.month) params.append('month', filters.month);
        return params.toString();
    };

    React.useEffect(() => {
        const query = getQueryParams();
        getPunchReportData(query);
    }, [filters]);

    const getStatusTag = (status) => {
        const colorMap = {
            'A': 'red',
            'P': 'green',
            'WO': 'purple',
            'P/2': 'orange',
        };
        return <Tag color={colorMap[status] || 'default'}>{status}</Tag>;
    };

    const processPunchData = (punchList) => {
        const flat = [];
        punchList.forEach((entry, index) => {
            flat.push({key: index, type: entry.type.toUpperCase(), time: entry.time});
        });

        const main = {};
        const extra = [];
        flat.forEach((item, index) => {
            if (index < 6) {
                main[`col${index + 1}`] = item.time;
            } else {
                extra.push(item);
            }
        });
        return {main, extra};
    };

    const getEmployeeData = () => {
        getUsersList({
            setIsLoading: false,
            successCallback: (data) => {
                const filteredEmployees = data["data"].filter(
                    (record) =>
                        record.approvalStatus === ApprovalStatus.Approved ||
                        record.isActive
                );

                const selectedFields = filteredEmployees.map((employee) => ({
                    userId: employee._id,
                    fullName: employee.fullName,
                    emailAddress: employee.emailAddress,
                    profilePhoto: employee.profilePhoto,
                }));

                setEmployeeRecord(selectedFields);
            },
        });
    };

    const getPunchReportData = (query) => {
        getPunchReportList({
            filterQuery: query,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                handleDataConditionWise(data.data, false);
            },
        });
    };

    const handleDataConditionWise = (data, isSearchField) => {
        const filteredPunchReport = isAdmin() ? data : data.filter((leave) => leave.user.userId === getLocalData(loginDataKeys._id));
        // const filterPunchReportRecord = filteredPunchReport.filter((leave) => leave.isUnexpected !== true);
        setPunchReportRecord(filteredPunchReport);
        if (!isSearchField) {
            setPunchReportFullRecord(filteredPunchReport);
        }
    };

    const handlePunchReportAddClick = () => {
        setAddPunchReportModelOpen(true);
        setSelectedPunchReportRecord({});
    };

    const handleEditClick = (value) => {
        const updated = {...value};

        // Convert col1, col2, ... to punchIn1, punchOut1, ...
        for (let i = 0; i < 6; i++) {
            updated[`punchIn${i + 1}`] = value[`col${i * 2 + 1}`] || '';
            updated[`punchOut${i + 1}`] = value[`col${i * 2 + 2}`] || '';
        }

        // Map extraPunches if present
        if (value.extraPunches?.length) {
            for (let i = 0; i < value.extraPunches.length; i++) {
                const punch = value.extraPunches[i];
                const punchIndex = Math.floor(i / 2) + 7; // Starts from punchIn7
                if (punch.type === 'IN') {
                    updated[`punchIn${punchIndex}`] = punch.time || '';
                } else {
                    updated[`punchOut${punchIndex}`] = punch.time || '';
                }
            }
        }

        setIsPunchReportEditing(true);
        setSelectedPunchReportRecord(updated);
        setOriginalPunchReport(updated);
        // setAddPunchReportModelOpen(true);
        setIsModalOpen(true);
    };

    const columns = [
        {
            title: 'Date',
            dataIndex: 'date',
            render: (date) => {
                return date ? date : '-';
            },
        },
        {
            title: 'IN 1',
            dataIndex: 'col1',
            render: (col1) => {
                return col1 ? col1 : '-';
            },
        },
        {
            title: 'OUT 1',
            dataIndex: 'col2',
            render: (col2) => {
                return col2 ? col2 : '-';
            },
        },
        {
            title: 'IN 2',
            dataIndex: 'col3',
            render: (col3) => {
                return col3 ? col3 : '-';
            },
        },
        {
            title: 'OUT 2',
            dataIndex: 'col4',
            render: (col4) => {
                return col4 ? col4 : '-';
            },
        },
        {
            title: 'IN 3',
            dataIndex: 'col5',
            render: (col5) => {
                return col5 ? col5 : '-';
            },
        },
        {
            title: 'OUT 3',
            dataIndex: 'col6',
            render: (col6) => {
                return col6 ? col6 : '-';
            },
        },
        {
            title: 'Status',
            dataIndex: 'status',
            render: getStatusTag,
        },
        {
            title: 'Working Hours',
            dataIndex: 'workingHours',
            render: (workingHours) => {
                return workingHours ? workingHours : '-';
            },
        },
        {
            title: 'Missing Hours',
            dataIndex: 'missingHours',
            render: (missingHours) => {
                return missingHours ? missingHours : '-';
            },
        },
        // {
        //     title: 'Is Leave',
        //     dataIndex: 'deductForDate',
        //     key: 'deductForDate.isLeaveOnDay',
        //     render: (text, record) => {
        //         return record.deductForDate ? antTag(
        //             record.deductForDate.isLeaveOnDay ? 'Yes' : 'No',
        //             record.deductForDate.isLeaveOnDay ? "green" : "red"
        //         ) : '-';
        //     },
        // },
        {
            title: 'Actions', render: (_, record) => <EditOutlined onClick={() => {
                handleEditClick(record)
            }}/>
        },
    ];

    const handleUpdate = async () => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.updatePunchReports}${selectedPunchReportRecord["_id"]}`,
                data: generateUpdatedPunchJson(),
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    setIsModalOpen(false);
                    handleDataConditionWise(data.data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const expandedRowRender = (record) => {
        if (!record.extraPunches.length) return null;

        // Group punches in pairs of IN and OUT
        const pairs = [];
        for (let i = 0; i < record.extraPunches.length; i += 2) {
            const inPunch = record.extraPunches[i];
            const outPunch = record.extraPunches[i + 1];
            pairs.push({in: inPunch?.time || '', out: outPunch?.time || ''});
        }

        return (
            <div style={{background: '#fafafa'}}>
                <b>Extra Punches:</b>
                <div style={{display: 'flex', flexWrap: 'wrap', marginTop: 8}}>
                    {pairs.map((_, idx) => (
                        <React.Fragment key={`label-${idx}`}>
                            <span style={{
                                width: 60,
                                fontWeight: 550,
                                textAlign: 'center',
                                marginRight: 25
                            }}>{`IN ${idx + 4}`}</span>
                            <span style={{
                                width: 60,
                                fontWeight: 550,
                                textAlign: 'center',
                                marginRight: 25
                            }}>{`OUT ${idx + 4}`}</span>
                        </React.Fragment>
                    ))}
                </div>
                <div style={{display: 'flex', flexWrap: 'wrap', marginTop: 4}}>
                    {pairs.map((pair, idx) => (
                        <React.Fragment key={`time-${idx}`}>
                            <span style={{
                                width: 60,
                                fontWeight: 500,
                                textAlign: 'center',
                                marginRight: 25
                            }}>{pair.in || "-"}</span>
                            <span style={{
                                width: 60,
                                fontWeight: 500,
                                textAlign: 'center',
                                marginRight: 25
                            }}>{pair.out || "-"}</span>
                        </React.Fragment>
                    ))}
                </div>
            </div>
        );
    };

    const getDisabledTimeConfig = (previousTimeString) => {
        if (!previousTimeString) return {};
        const previous = dayjs(previousTimeString, "HH:mm");

        return {
            disabledHours: () => Array.from({length: 24}, (_, i) => i).filter(h => h < previous.hour()),
            disabledMinutes: (selectedHour) => {
                if (selectedHour === previous.hour()) {
                    return Array.from({length: 60}, (_, i) => i).filter(m => m <= previous.minute());
                }
                return [];
            },
        };
    };

    const generateUpdatedPunchJson = () => {
        const punchList = [];

        for (let i = 0; i < 9; i++) {
            const inKey = `punchIn${i + 1}`;
            const outKey = `punchOut${i + 1}`;

            const originalIn = originalPunchReport[inKey] || "";
            const originalOut = originalPunchReport[outKey] || "";
            const currentIn = selectedPunchReportRecord[inKey] || "";
            const currentOut = selectedPunchReportRecord[outKey] || "";

            if (currentIn && currentIn !== originalIn) {
                punchList.push({
                    type: `In${i + 1}`,
                    time: currentIn,
                });
            }

            if (currentOut && currentOut !== originalOut) {
                punchList.push({
                    type: `Out${i + 1}`,
                    time: currentOut,
                });
            }
        }

        const result = {
            user: selectedPunchReportRecord.userId,
            punchReport: {
                date: selectedPunchReportRecord.date,
                punchList,
                status: selectedPunchReportRecord.status,
                workingHours: selectedPunchReportRecord.workingHours,
                missingHours: selectedPunchReportRecord.missingHours,
            },
        };

        return result;
    };


    return (
        <>
            <div style={{margin: "15px 5px"}}>
                <Row gutter={[16, 16]}>
                    <Col xs={24} sm={12} md={12} lg={6}>
                        <SearchTextField
                            field={{
                                name: "search",
                                placeholder: "Search Salary Report",
                                prefix: <Search/>,
                                style: {margin: 0, width: "100%", height: "38px"},
                                onChange: (e) => {
                                    const searchText = e.target.value.toLowerCase();
                                    const filteredData = punchReportFullRecord?.filter((record) => {
                                        return (
                                            record.user?.fullName.toLowerCase().includes(searchText)
                                        );
                                    });
                                    handleDataConditionWise(filteredData, true);
                                },
                            }}
                        />
                    </Col>
                    <Col xs={24} sm={12} md={12} lg={6}>
                        <Select
                            placeholder="Select User"
                            allowClear
                            style={{width: "100%", height: '40px'}}
                            showSearch
                            onChange={(key) => {
                                setFilters(prev => ({...prev, user: key}));
                            }}
                            filterOption={(input, option) =>
                                option?.label?.toLowerCase().includes(input.toLowerCase())
                            }
                        >
                            {employeeRecord.map(employee => (
                                <Option key={employee.userId} value={employee.userId}
                                        label={employee.fullName}>
                                    <div
                                        style={{display: "flex", alignItems: "center", gap: "10px"}}
                                    >
                                        <Avatar
                                            src={employee.profilePhoto || imagePaths.profile_placeholder}
                                            size="small"/>
                                        {employee.fullName}
                                    </div>
                                </Option>))}
                        </Select>
                    </Col>
                    <Col xs={8} sm={9} md={10} lg={4}>
                        <DatePicker onChange={(date, dateString) => {
                            setFilters(prev => ({...prev, year: date ? date.year() : null}));
                        }} picker="year" style={{width: "100%", height: "40px"}}/>
                    </Col>
                    <Col xs={8} sm={9} md={10} lg={4}>
                        <DatePicker onChange={(date, dateString) => {
                            setFilters(prev => ({...prev, month: date ? date.month() + 1 : null}));
                        }} picker="month" format="MMMM" style={{width: "100%", height: "40px"}}/>
                    </Col>
                    <Col xs={8} sm={6} md={4} lg={4}>
                        <Button onClick={handlePunchReportAddClick} type="primary"
                                style={{width: "100%", height: "40px", borderRadius: 10}}>
                            Upload Sheet
                        </Button>
                    </Col>
                </Row>
            </div>

            <div>
                {isLoading ? (
                    <div style={{display: "flex", justifyContent: "center", alignItems: "center", marginTop: "200px"}}>
                        <Spin/>
                    </div>
                ) : (
                    punchReportRecord.map((user) => {
                        const dataSource = user.punchReport.map((report, index) => {
                            const {main, extra} = processPunchData(report.punchList);
                            return {
                                key: index,
                                _id: user._id,
                                userId: user.user.userId,
                                fullName: user.user.fullName,
                                empCode: user.empCode,
                                date: report.date,
                                status: report.status,
                                workingHours: report.workingHours,
                                missingHours: report.missingHours,
                                ...main,
                                extraPunches: extra,
                            };
                        });

                        return (
                            <Card
                                key={user._id}
                                title={
                                    <div style={{display: 'flex', justifyContent: 'space-between'}}>
                                        <span>User Name: <span>{user.user?.fullName}</span></span>
                                        {/*<span>User ID: <span>{user.user?.userId}</span></span>*/}
                                        <span>Employee Code: <span>{user.empCode}</span></span>
                                    </div>
                                }
                                style={{marginBottom: 24}}
                            >
                                <Table
                                    columns={columns}
                                    dataSource={dataSource}
                                    expandable={{expandedRowRender}}
                                    pagination={false}
                                    bordered
                                />
                            </Card>
                        );
                    })
                )}
            </div>
            {isAddPunchReportModelOpen && (
                <PunchReportAddUpdateModel
                    isModelOpen={isAddPunchReportModelOpen}
                    setIsModelOpen={setAddPunchReportModelOpen}
                    employeeList={employeeRecord}
                    leaveData={selectedPunchReportRecord}
                    isEditing={isPunchReportEditing}
                    setIsEditing={setIsPunchReportEditing}
                    onSuccessCallback={(data) => {
                        window.location.reload();
                        // handleDataConditionWise(data.data, false);
                    }}
                />
            )}

            <Modal
                title="Update Punch Report"
                open={isModalOpen}
                onCancel={() => setIsModalOpen(false)}
                onClose={() => setIsModalOpen(false)}
                width={600}
                onOk={handleUpdate}
                loading={isLoading}
            >
                <Form layout="vertical">
                    <Row gutter={16}>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item label="User Name">
                                <Input disabled value={selectedPunchReportRecord[appKeys.fullName]}
                                       style={{height: "40px"}}/>
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item label="Employee Code">
                                <Input disabled value={selectedPunchReportRecord["empCode"]}
                                       style={{height: "40px"}}/>
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item label="Date">
                                <Input disabled value={selectedPunchReportRecord["date"]}
                                       style={{height: "40px"}}/>
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item label="Working Hours">
                                <Input value={selectedPunchReportRecord['workingHours']}
                                       style={{height: "40px"}} disabled/>
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item label="Missing Hours">
                                <Input placeholder="HH:MM" value={selectedPunchReportRecord['missingHours']}
                                       style={{height: "40px"}}/>
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item label="Status">
                                <Select
                                    value={selectedPunchReportRecord['status']}
                                    style={{height: "40px"}}
                                    onChange={(value) => setSelectedPunchReportRecord({
                                        ...selectedPunchReportRecord,
                                        status: value
                                    })}
                                >
                                    <Select.Option key="P" value="P">Present</Select.Option>
                                    <Select.Option key="A" value="A">Absent</Select.Option>
                                    <Select.Option key="P/2" value="P/2">Half-Day Present</Select.Option>
                                    <Select.Option key="WO" value="WO">Weekly Off</Select.Option>
                                </Select>
                            </Form.Item>
                        </Col>
                    </Row>

                    <Row gutter={16}>
                        {Array.from({length: 9}).map((_, i) => {
                            const punchInKey = `punchIn${i + 1}`;
                            const punchOutKey = `punchOut${i + 1}`;
                            const prevPunchOutKey = `punchOut${i}`;
                            const prevPunchInKey = `punchIn${i}`;

                            const isPunchInDisabled = i === 0 ? false : !selectedPunchReportRecord[prevPunchOutKey];
                            const isPunchOutDisabled = !selectedPunchReportRecord[punchInKey];

                            const prevTimeForIn = i === 0
                                ? null
                                : selectedPunchReportRecord[prevPunchOutKey];

                            const prevTimeForOut = selectedPunchReportRecord[punchInKey];

                            return (
                                <React.Fragment key={i}>
                                    <Col xs={12} sm={6} md={6}>
                                        <Form.Item label={`Punch-in ${i + 1}`}>
                                            <TimePicker
                                                format="HH:mm"
                                                allowClear={true}
                                                placeholder="Time"
                                                disabled={isPunchInDisabled}
                                                value={
                                                    selectedPunchReportRecord[punchInKey]
                                                        ? dayjs(selectedPunchReportRecord[punchInKey], "HH:mm")
                                                        : null
                                                }
                                                {...getDisabledTimeConfig(prevTimeForIn)}
                                                onChange={(time, timeString) => {
                                                    setSelectedPunchReportRecord((prev) => {
                                                        const updated = {...prev, [punchInKey]: timeString};

                                                        if (!timeString) {
                                                            // Clear punchIn[i], punchOut[i], punchIn[i+1], punchOut[i+1], ...
                                                            for (let j = i; j < 9; j++) {
                                                                updated[`punchIn${j + 1}`] = "";
                                                                updated[`punchOut${j + 1}`] = "";
                                                            }
                                                        }

                                                        return updated;
                                                    });
                                                }}
                                                style={{height: "40px"}}
                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col xs={12} sm={6} md={6}>
                                        <Form.Item label={`Punch-out ${i + 1}`}>
                                            <TimePicker
                                                format="HH:mm"
                                                allowClear={true}
                                                placeholder="Time"
                                                disabled={isPunchOutDisabled}
                                                value={
                                                    selectedPunchReportRecord[punchOutKey]
                                                        ? dayjs(selectedPunchReportRecord[punchOutKey], "HH:mm")
                                                        : null
                                                }
                                                {...getDisabledTimeConfig(prevTimeForOut)}
                                                onChange={(time, timeString) => {
                                                    setSelectedPunchReportRecord((prev) => {
                                                        const updated = {...prev, [punchOutKey]: timeString};

                                                        if (!timeString) {
                                                            // Only clear punchOut[i], punchIn[i+1], punchOut[i+1], ...
                                                            updated[punchOutKey] = "";

                                                            for (let j = i + 1; j < 9; j++) {
                                                                updated[`punchIn${j + 1}`] = "";
                                                                updated[`punchOut${j + 1}`] = "";
                                                            }
                                                        }

                                                        return updated;
                                                    });
                                                }}
                                                style={{height: "40px"}}
                                            />
                                        </Form.Item>
                                    </Col>
                                </React.Fragment>
                            );
                        })}
                    </Row>
                </Form>
            </Modal>
        </>
    );
};

export default PunchReportPage;