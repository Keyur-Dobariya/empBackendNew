import { Image } from "antd";
import Column from "../../../components/common/Column";
import Container from "../../../components/common/Container";
import { Grid, GridItem } from "../../../components/common/GridSystem";
import appColor from "../../../utils/appColors";
import { getLocalData, loginDataKeys } from "../../../dataStorage/DataPref";
import { useEffect, useRef, useState } from "react";
import ElectronDashboard from "../ElectronDashboard";

export default function AdminDashboard() {
  const OFFICE_TIME = 9 * 3600000; // 9 hours in milliseconds

  const [punchInTime, setPunchInTime] = useState(
    localStorage.getItem("punchInTime") || null
  );
  const [punchOutTime, setPunchOutTime] = useState(
    localStorage.getItem("punchOutTime") || null
  );
  const [breakInTime, setBreakInTime] = useState(
    localStorage.getItem("breakInTime") || null
  );
  const [totalBreakTime, setTotalBreakTime] = useState(
    parseInt(localStorage.getItem("totalBreakTime")) || 0
  );
  const [currentTime, setCurrentTime] = useState(0);
  const [breakTime, setBreakTime] = useState(0);

  useEffect(() => {
    let interval;
    if (punchInTime && !punchOutTime) {
      interval = setInterval(() => {
        const now = Date.now();
        const totalElapsed = now - parseInt(punchInTime);
        const workTime =
          totalElapsed -
          totalBreakTime -
          (breakInTime ? now - parseInt(breakInTime) : 0);
        setCurrentTime(workTime);
        setBreakTime(
          breakInTime
            ? now - parseInt(breakInTime) + totalBreakTime
            : totalBreakTime
        );
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [punchInTime, punchOutTime, breakInTime, totalBreakTime]);

  const handlePunchInOut = () => {
    if (punchInTime) {
      const now = Date.now();
      setPunchOutTime(now);
      localStorage.setItem("punchOutTime", now);
    } else {
      const now = Date.now();
      setPunchInTime(now);
      localStorage.setItem("punchInTime", now);
      setPunchOutTime(null);
      localStorage.removeItem("punchOutTime");
      setTotalBreakTime(0);
      localStorage.setItem("totalBreakTime", 0);
    }
  };

  const handleBreakIn = () => {
    if (punchInTime && !breakInTime) {
      const now = Date.now();
      setBreakInTime(now);
      localStorage.setItem("breakInTime", now);
    }
  };

  const handleBreakOut = () => {
    if (breakInTime) {
      const now = Date.now();
      const breakDuration = now - parseInt(breakInTime);
      const updatedBreakTime = totalBreakTime + breakDuration;
      setTotalBreakTime(updatedBreakTime);
      localStorage.setItem("totalBreakTime", updatedBreakTime);
      setBreakInTime(null);
      localStorage.removeItem("breakInTime");
    }
  };

  const formatTime = (milliseconds) => {
    const hours = Math.floor(milliseconds / 3600000);
    const minutes = Math.floor((milliseconds % 3600000) / 60000);
    const seconds = Math.floor((milliseconds % 60000) / 1000);
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  const getPercentage = (time) => {
    return ((time / OFFICE_TIME) * 100).toFixed(2);
  };

  const [image, setImage] = useState(null);

  return (
   <>
   <ElectronDashboard />
   {/* <div className="box b">
          {boxItem({
            countText: employeeData.length,
            mainIcon: imagePaths.usersIcon,
            boxHeader: "Total Employees",
            statusIcon: imagePaths.plusIcon,
            statusIconColor: appColor.green,
            dailyStatus: "2 new employees added!",
          })}
        </div>
        <div className="box c">
          {boxItem({
            countText: "360",
            mainIcon: imagePaths.clockIcon,
            boxHeader: "On Time",
            statusIcon: imagePaths.increaseIcon,
            statusIconColor: appColor.green,
            dailyStatus: "-10% Less than yesterday",
          })}
        </div>
        <div className="box d">
          {boxItem({
            countText: "30",
            mainIcon: imagePaths.absentIcon,
            boxHeader: "Absent",
            statusIcon: imagePaths.decreaseIcon,
            statusIconColor: appColor.red,
            dailyStatus: "+3% Increase than yesterday",
          })}
        </div>
        <div className="box e">
          {boxItem({
            countText: "62",
            mainIcon: imagePaths.lateArrivalLogo,
            boxHeader: "Late Arrival",
            statusIcon: imagePaths.decreaseIcon,
            statusIconColor: appColor.red,
            dailyStatus: "+3% Increase than yesterday",
          })}
        </div>
        <div className="box f">
          {boxItem({
            countText: "6",
            mainIcon: imagePaths.earlyLogo,
            boxHeader: "Early Departures",
            statusIcon: imagePaths.increaseIcon,
            statusIconColor: appColor.green,
            dailyStatus: "-10% Less than yesterday",
          })}
        </div>
        <div className="box g">
          {boxItem({
            countText: "42",
            mainIcon: imagePaths.timeOffIcon,
            boxHeader: "Time-off",
            statusIcon: imagePaths.increaseIcon,
            statusIconColor: appColor.primary,
            dailyStatus: "2% Increase than yesterday",
          })}
        </div> */}
   </>
  );
}
