import { useEffect, useState } from "react";
import Container from "../../../components/common/Container";
import Column from "../../../components/common/Column";
import AppText from "../../../components/common/AppText";
import appString from "../../../utils/appString";
import appColor from "../../../utils/appColors";
import SpaceBox from "../../../components/common/SpaceBox";
import { Progress, Tooltip } from "antd";
import { useScreenshot } from "use-react-screenshot";

export default function AttendancePunchComponent() {
    const OFFICE_TIME = 9 * 3600000; // 9 hours in milliseconds

    const [punchInTime, setPunchInTime] = useState(localStorage.getItem("punchInTime") || null);
    const [punchOutTime, setPunchOutTime] = useState(localStorage.getItem("punchOutTime") || null);
    const [breakInTime, setBreakInTime] = useState(localStorage.getItem("breakInTime") || null);
    const [totalBreakTime, setTotalBreakTime] = useState(parseInt(localStorage.getItem("totalBreakTime")) || 0);
    const [currentTime, setCurrentTime] = useState(0);
    const [breakTime, setBreakTime] = useState(0);
    const [liveTime, setLiveTime] = useState(new Date());
  
    useEffect(() => {
      let interval;
      if (punchInTime && !punchOutTime) {
        interval = setInterval(() => {
          const now = Date.now();
          const totalElapsed = now - parseInt(punchInTime);
          const workTime = totalElapsed - totalBreakTime - (breakInTime ? now - parseInt(breakInTime) : 0);
          setCurrentTime(workTime);
          setBreakTime(breakInTime ? now - parseInt(breakInTime) + totalBreakTime : totalBreakTime);
          setLiveTime(new Date());
        }, 1000);
      }
      return () => clearInterval(interval);
    }, [punchInTime, punchOutTime, breakInTime, totalBreakTime]);
  
    const handlePunchInOut = () => {
      if (punchInTime) {
        const now = Date.now();
        setPunchOutTime(now);
        localStorage.setItem("punchOutTime", now);
      } else {
        const now = Date.now();
        setPunchInTime(now);
        localStorage.setItem("punchInTime", now);
        setPunchOutTime(null);
        localStorage.removeItem("punchOutTime");
        setTotalBreakTime(0);
        localStorage.setItem("totalBreakTime", 0);
      }
    };
  
    const handleBreakIn = () => {
      if (punchInTime && !breakInTime) {
        const now = Date.now();
        setBreakInTime(now);
        localStorage.setItem("breakInTime", now);
      }
    };
  
    const handleBreakOut = () => {
      if (breakInTime) {
        const now = Date.now();
        const breakDuration = now - parseInt(breakInTime);
        const updatedBreakTime = totalBreakTime + breakDuration;
        setTotalBreakTime(updatedBreakTime);
        localStorage.setItem("totalBreakTime", updatedBreakTime);
        setBreakInTime(null);
        localStorage.removeItem("breakInTime");
      }
    };
  
    const formatTime = (milliseconds) => {
      const hours = Math.floor(milliseconds / 3600000);
      const minutes = Math.floor((milliseconds % 3600000) / 60000);
      const seconds = Math.floor((milliseconds % 60000) / 1000);
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    };
  
    const getPercentage = (time) => {
      return ((time / OFFICE_TIME) * 100).toFixed(2);
    };
  
    const formatLiveTime = (date) => {
      const options = { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true };
      return date.toLocaleTimeString("en-US", options);
    };
  
    const formatLiveDate = (date) => {
      const options = { day: "2-digit", month: "short", year: "numeric" };
      return date.toLocaleDateString("en-US", options);
    };


  return (
    <>
      <Container height="100%">
        <Container height="100%" padding={20}>
          <Column
            justifyContent="center"
            alignItems="center"
            style={{
              // justifyContent: "space-around",
              height: "100%",
            }}
          >
            <AppText
              text={appString.attendance}
              fontSize="14px"
              fontWeight="450"
              color={appColor.secondary}
            />
            <AppText
              text={`${formatLiveTime(liveTime)}, ${formatLiveDate(liveTime)}`}
              fontSize="15px"
              fontWeight="550"
              color={appColor.black}
            />
            <SpaceBox space={3} />
            <Tooltip title="3 done / 3 in progress / 4 to do">
              <Progress
                percent={40}
                // steps={{
                //   count: 3,
                //   gap: 0,
                //   gapColor: appColor.primary,
                //   done: {
                //     status: "success",
                //     color: appColor.green,
                //     text: {
                //       color: appColor.white,
                //       fontSize: 12,
                //       fontWeight: "400",
                //     },
                //   },
                //   inProgress: {
                //     status: "active",
                //     color: appColor.primary,
                //     text: {
                //       color: appColor.white,
                //       fontSize: 12,
                //       fontWeight: "400",
                //     }
                //   }
                // }}
                // format={(percent) => `${percent} Days`}
                format={(percent) => (
                  <Column alignItems="center">
                    <AppText
                      text={appString.totalHours}
                      fontSize={12}
                      fontWeight="400"
                      color={appColor.secondary}
                    />
                    <AppText
                      text={appString.totalHours}
                      fontSize={12}
                      fontWeight="450"
                      color={appColor.black}
                    />
                  </Column>
                )}
                // status="exception"
                type="circle"
                size={110}
              />
            </Tooltip>
          </Column>
        </Container>
      </Container>
    </>
    // <div>
    //   <h1>Attendance System</h1>
    //   <button onClick={handlePunchInOut}>{punchInTime ? "Punch Out" : "Punch In"}</button>
    //   <button onClick={handleBreakIn} disabled={!punchInTime || !!breakInTime}>Break In</button>
    //   <button onClick={handleBreakOut} disabled={!breakInTime}>Break Out</button>

    //   <h2>Total Time: {formatTime(punchInTime ? (Date.now() - punchInTime) : 0)}</h2>
    //   <h2>Break Time: {formatTime(breakTime)}</h2>
    //   <h2>Work Time: {formatTime(currentTime)}</h2>

    //   <h3>Total Time Percentage: {getPercentage(punchInTime ? (Date.now() - punchInTime) : 0)}%</h3>
    //   <h3>Break Time Percentage: {getPercentage(breakTime)}%</h3>
    //   <h3>Work Time Percentage: {getPercentage(currentTime)}%</h3>
    // </div>
  );
}
