import React, {useEffect, useState} from "react";
import {Avatar, Drawer, Dropdown, Form, Modal, Switch, Tag} from "antd";
import {Airplay, Box, Calendar, DollarSign, FileMinus, Map, Menu, Monitor, Plus, TrendingUp, User} from "react-feather";
import {
    getLocalData,
    loginDataKeys,
    storeLoginData,
} from "../../../dataStorage/DataPref";
import {
    checkImageExistence,
    checkImageExists,
    getTwoCharacterFromName,
    showToast
} from "../../../components/CommonComponents";
import "../../../components/sidebar/Sidebar.css";
import Sidebar from "../../../components/sidebar/Sidebar";
import EmployeeListContent from "./EmployeeListContent";
import Dashboard from "../Dashboard";
import {Outlet, useLocation, useNavigate, useNavigation, useParams} from "react-router-dom";
import AppText from "../../../components/common/AppText";
import SpaceBox from "../../../components/common/SpaceBox";
import {HelpCircle, Home, LogOut, Settings, Users} from "react-feather";
import appColor from "../../../utils/appColors";
import Container from "../../../components/common/Container";
import Image from "../../../components/common/Image";
import imagePaths from "../../../assets/assetsPaths";
import Row from "../../../components/common/Row";
import AdminDashboard from "./AdminDashboard";
import MyProfilePage from "../MyProfilePage";
import apiCall, {HttpMethod} from "../../../api/apiServiceProvider";
import {endpoints} from "../../../api/apiEndpoints";
import appString from "../../../utils/appString";
import SeetingPage from "../SeetingPage";
import routes from "../../../common/routes";
import {eventLeaveTypeMenuList, eventTypeMenuList, getKeyByLabel, UserRole} from "../../../utils/enum";
import WrapBox from "../../../components/common/WrapBox";
import AppTextFormField, {InputType} from "../../../components/common/AppTextFormField";
import appKeys from "../../../utils/appKeys";
import dayjs from "dayjs";
import {isAdmin} from "../../../utils/utils";
import {useAppData} from "../../../AppDataContext";
import {FullScreenLoader} from "../../../components/Loader";

const HomeContent = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [userLocation, setUserLocation] = useState({ latitude: null, longitude: null });
    const [isDrawerMode, setIsDrawerMode] = useState(false);
    const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
    const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
    const [open, setOpen] = useState(false);
    const [form] = Form.useForm();

    const [activeTab, setActiveTab] = useState("Dashboard");

    function formatUrl(url) {
        return url
            .replace("/", "")   // Remove leading "/"
            .replace(/-/g, " ") // Replace hyphens with spaces
            .replace(/\b\w/g, c => c.toUpperCase()); // Capitalize each word
    }

    useEffect(() => {
        if(!isAdmin()) {
            if (!navigator.geolocation) {
                showToast("error", 'Geolocation is not supported by your browser')
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setUserLocation({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    });
                },
                (err) => {
                    showToast("error", 'Unable to retrieve your location: ' + err.message)
                }
            );
        }
    }, []);

    useEffect(() => {
        if (getLocalData(loginDataKeys.isLogin) !== "true") {
            navigate("/login");
        }
        // const formatURL = formatUrl(location.pathname)
        // setActiveTab(() => {
        //   const routeName = location.pathname.replace("/", "") ? formatURL : "Dashboard";
        //   return routeName;
        // });
        const formattedTab = formatUrl(location.pathname);
        setActiveTab(formattedTab || "Dashboard");

    }, [location.pathname]);

    const menuClick = ({route, state}) => {
        if (location.pathname !== route) {
            if(state) {
                navigate(route, state);
            } else {
                navigate(route);
            }
        }
    }

    function capitalizeString(input) {
        return input
            .replace(/[-_]/g, " ")
            .replace(/([a-z])([A-Z])/g, "$1 $2")
            .toLowerCase()
            .replace(/\b\w/g, (char) => char.toUpperCase());
    }

    const tabList = [
        {
            name: appString.dashboard,
            icon: <Home/>,
            position: "top",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.dashboard});
            },
        },
        {
            name: "Employee Manage",
            icon: <Users/>,
            position: "top",
            isShow: isAdmin(),
            // onClick: () => {
            //     menuClick({route: routes.employees});
            // },
            subMenu: [
                {
                    name: capitalizeString(routes.employees.replace("/", "")),
                    icon: <Users/>,
                    isShow: isAdmin(),
                    onClick: () => { menuClick({route: routes.employees}); },
                },
                {
                    name: capitalizeString(routes.todayReport.replace("/", "")),
                    icon: <TrendingUp/>,
                    isShow: isAdmin(),
                    onClick: () => { menuClick({route: routes.todayReport}); },
                },
                {
                    name: capitalizeString(routes.basicSalary.replace("/", "")),
                    icon: <DollarSign/>,
                    isShow: isAdmin(),
                    onClick: () => {
                        menuClick({route: routes.basicSalary});
                    },
                },
            ],
        },
        // {
        //     name: capitalizeString(routes.todayReport.replace("/", "")),
        //     icon: <TrendingUp/>,
        //     position: "top",
        //     isShow: isAdmin(),
        //     onClick: () => {
        //         menuClick({route: routes.todayReport});
        //     },
        // },
        {
            name: capitalizeString(routes.client.replace("/", "")),
            icon: <Users/>,
            position: "top",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.client});
            },
        },
        {
            name: capitalizeString(routes.project.replace("/", "")),
            icon: <Box/>,
            position: "top",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.project});
            },
        },
        {
            name: capitalizeString(routes.tasks.replace("/", "")),
            icon: <Airplay/>,
            position: "top",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.tasks});
            },
        },
        {
            name: capitalizeString(routes.leave.replace("/", "")),
            icon: <Map />,
            position: "top",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.leave});
            },
        },
        // {
        //     name: capitalizeString(routes.leaveReport.replace("/", "")),
        //     icon: <FileMinus />,
        //     position: "top",
        //     isShow: true,
        //     onClick: () => {
        //         menuClick({route: routes.leaveReport});
        //     },
        // },
        // {
        //     name: capitalizeString(routes.punchReport.replace("/", "")),
        //     icon: <FileMinus />,
        //     position: "top",
        //     isShow: isAdmin(),
        //     onClick: () => {
        //         menuClick({route: routes.punchReport});
        //     },
        // },
        {
            name: "View Report",
            icon: <FileMinus />,
            position: "top",
            isShow: true,
            subMenu: [
                {
                    name: capitalizeString(routes.leaveReport.replace("/", "")),
                    icon: <FileMinus />,
                    isShow: true,
                    onClick: () => { menuClick({route: routes.leaveReport}); },
                },
                {
                    name: capitalizeString(routes.punchReport.replace("/", "")),
                    icon: <FileMinus />,
                    isShow: isAdmin(),
                    onClick: () => {
                        menuClick({route: routes.punchReport});
                    },
                },
                {
                    name: capitalizeString(routes.salaryReport.replace("/", "")),
                    icon: <FileMinus />,
                    isShow: true,
                    onClick: () => {
                        if(isAdmin()) {
                            menuClick({route: routes.salaryReport});
                        } else {
                            setIsCodeModalOpen(true);
                        }
                    },
                },
            ]
        },
        // {
        //     name: capitalizeString(routes.basicSalary.replace("/", "")),
        //     icon: <DollarSign/>,
        //     position: "top",
        //     isShow: isAdmin(),
        //     onClick: () => {
        //         menuClick({route: routes.basicSalary});
        //     },
        // },
        {
            name: capitalizeString(routes.calendar.replace("/", "")),
            icon: <Calendar/>,
            position: "top",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.calendar});
            },
        },
        {
            name: capitalizeString(routes.myProfile.replace("/", "")),
            icon: <User/>,
            position: "bottom",
            isShow: true,
            onClick: () => {
                menuClick({route: routes.myProfile});
            },
        },
        {
            name: capitalizeString(routes.settings.replace("/", "")),
            icon: <Settings/>,
            position: "bottom",
            isShow: isAdmin(),
            onClick: () => {
                menuClick({route: routes.settings});
            },
        },
        {
            name: "LogOut",
            icon: <LogOut/>,
            position: "bottom",
            isShow: true,
            onClick: () => {
                setIsLogoutModalOpen(true);
            },
        },
    ];

    const onClose = () => {
        setOpen(false);
    };

    const [isShrinkView, setIsShrinkView] = useState(false);

    const [isLoading, setIsLoading] = useState(false);

    const handleMenuClick = () => {
        if (isDrawerMode) {
            setOpen(!open);
        } else {
            setIsShrinkView(!isShrinkView);
        }
    };

    useEffect(() => {
        const handleResize = () => {
            setIsDrawerMode(window.innerWidth <= 1220);
        };
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    const profileMenuItems = [
        {
            label: "My Profile",
            key: "1",
            icon: <User size={17}/>,
            onMenuClick: () => {
                menuClick({route: routes.myProfile});
            },
        },
        {
            label: "LogOut",
            key: "3",
            icon: <LogOut size={18}/>,
            onMenuClick: () => {
                setIsLogoutModalOpen(true);
            },
        },
    ];

    const menuProps = {
        items: profileMenuItems,
        onClick: ({key}) => {
            const selectedItem = profileMenuItems.find((item) => item.key === key);
            if (selectedItem && selectedItem.onMenuClick) {
                selectedItem.onMenuClick();
            }
        },
    };

    const handleCodeVerifyApi = async (values) => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.salaryCodeVerify,
                data: {
                    code: values.code,
                    latitude: userLocation.latitude,
                    longitude: userLocation.longitude,
                },
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    setIsCodeModalOpen(false);
                    menuClick({route: `${routes.salaryReport}/${values.code}`, state: { state: { paramDetail: { code: values.code } } }});
                    form.resetFields();
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    }

    return (
        <>
            <div className="bodyContainer">
                <div className="appContainer">
                    {!isDrawerMode ? (
                        <Sidebar
                            isMobileView={false}
                            isShrinkView={isShrinkView}
                            activeTab={activeTab}
                            tabList={tabList}
                            handleClick={(o) => {
                                o.onClick();
                            }}
                        />
                    ) : (
                        <Drawer
                            placement="left"
                            closable={false}
                            onClose={onClose}
                            open={open}
                            width="280px"
                        >
                            <Sidebar
                                isMobileView={true}
                                isShrinkView={isShrinkView}
                                activeTab={activeTab}
                                tabList={tabList}
                                handleClick={(o) => {
                                    onClose();
                                    o.onClick();
                                }}
                            />
                        </Drawer>
                    )}
                    <div className="partB">
                        <div className="headerContainer">
                            <Row justifyContent="center">
                                <div onClick={handleMenuClick}>
                                    <Menu size={20} style={{cursor: "pointer"}}/>
                                </div>
                                <SpaceBox left={8}/>
                                <AppText
                                    text={activeTab}
                                    fontSize={17}
                                    fontWeight={550}
                                    color={appColor.primary}
                                />
                            </Row>
                            <div className="userInfoContainer">
                                {/* <Image
                  path={imagePaths.notificationIcon}
                  iconColor={appColor.primary}
                  width="35px"
                  height="35px"
                  backgroundColor={appColor.mainBg}
                  borderRadius={100}
                  padding={9}
                  style={{ cursor: "pointer" }}
                /> */}
                                <Dropdown menu={menuProps} trigger={["click"]}>
                                    <div style={{ display: "flex",
                                        cursor: "pointer", }}>
                                        <div
                                            style={{
                                                width: "35px",
                                                height: "35px",
                                                margin: isDrawerMode ? "0 0 0 10px" : "0 10px 0 10px",
                                                alignSelf: "center"
                                            }}
                                        >
                                            {getLocalData(loginDataKeys.profilePhoto) && checkImageExistence(getLocalData(loginDataKeys.profilePhoto)) ? (
                                                <Avatar
                                                    className="avatarImageStyle"
                                                    src={<img
                                                        src={!checkImageExists(getLocalData(loginDataKeys.profilePhoto)) ? imagePaths.profile_placeholder : getLocalData(loginDataKeys.profilePhoto)}
                                                        alt="avatar"/>}
                                                />
                                            ) : (
                                                <Avatar className="avatarTxtStyle">
                                                    {getTwoCharacterFromName(getLocalData(loginDataKeys.fullName))}
                                                </Avatar>
                                            )}
                                        </div>
                                        <div style={{display: isDrawerMode ? "none" : ""}}>
                                            <div style={{fontSize: 14, fontWeight: 600, color: appColor.primary}}>{getLocalData(loginDataKeys.fullName)}</div>
                                            <div style={{fontSize: 12.5, fontWeight: 450, color: appColor.secondary}}>{getLocalData(loginDataKeys.role)}</div>
                                        </div>
                                    </div>
                                </Dropdown>

                            </div>
                        </div>
                        {/* <div className="mainContentContainer">{content}</div> */}
                        <main className="mainContentContainer">
                            <Outlet/>
                        </main>
                        <div className="footerContainer">Part E (15% height)</div>
                    </div>
                </div>
            </div>
            <Modal
                title="Confirmation!"
                width="auto"
                maskClosable={true}
                centered
                closeIcon={false}
                open={isLogoutModalOpen}
                onOk={() => {
                    localStorage.clear();
                    navigate("/login");
                }}
                onCancel={() => {
                    setIsLogoutModalOpen(false);
                }}
                onClose={() => {
                    setIsLogoutModalOpen(false);
                }}
                okText="LogOut"
            >
                <AppText
                    text="Are you sure you want to log out?"
                    fontSize={14}
                />
                <SpaceBox space={5}/>
            </Modal>
            <Modal
                title="User Code Verification!"
                maskClosable={true}
                centered
                closeIcon={false}
                open={isCodeModalOpen}
                onOk={() => form.submit()}
                onCancel={() => {
                    setIsCodeModalOpen(false);
                }}
                onClose={() => {
                    setIsCodeModalOpen(false);
                }}
                okText="Verify"
                confirmLoading={isLoading}
            >
                <Form
                    form={form}
                    name="EventModel"
                    layout="vertical"
                    onFinish={(values) => {
                        handleCodeVerifyApi(values);
                    }}
                >
                    <AppTextFormField
                        name="code"
                        label="Code"
                        inputMode={InputType.Number}
                        placeholder="Enter Code"
                        isRequired={true}
                    />
                </Form>
            </Modal>
        </>
    );
};

export default HomeContent;
