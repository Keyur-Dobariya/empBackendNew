import React, {useEffect, useState} from "react";
import "./AntdStyle.css";
import "./App.css";

import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import SignUp from "./pages/auth/SignUp";
import Login from "./pages/auth/Login";
import SendEmailOtp from "./pages/auth/SendEmailOtp";
import VerifyEmailOtp from "./pages/auth/VerifyEmailOtp";
import ForgotPassword from "./pages/auth/ForgotPassword";
import HomeContent from "./pages/home/navContents/HomeContent";
import NoPage from './pages/NoPage';
import appColor from "./utils/appColors";
import {getLocalData, loginDataKeys, storeLoginData} from "./dataStorage/DataPref";
import ViewFullEmployeeDetails from "./pages/home/navContents/ViewFullEmployeeDetails";
import TaskBoard from "./pages/home/TaskBoard";
import NewDashboard from "./pages/home/NewDashboard";
import Dashboard from "./pages/home/Dashboard";
import EmployeeListContent from "./pages/home/navContents/EmployeeListContent";
import MyProfilePage from "./pages/home/MyProfilePage";
import SeetingPage from "./pages/home/SeetingPage";
import routes from "./common/routes";
import TodayReport from "./pages/home/TodayReport";
import HolidayPage from "./pages/home/HolidayPage";
import ProjectPage from "./pages/home/ProjectPage";
import LeavePage from "./pages/home/LeavePage";
import ClientPage from "./pages/home/ClientPage";
import BasicSalaryPage from "./pages/home/BasicSalaryPage";
import SalaryReportPage from "./pages/home/SalaryReportPage";
import PunchReportPage from "./pages/home/PunchReportPage";
import {UserRole} from "./utils/enum";
import OneSignal from "react-onesignal";
import ProtectedSalaryPage from "./pages/home/ProtectedSalaryReportPage";
import NavigationInitializer from "./NavigationInitializer";
import DrawerPage from "./pages/home/DrawerPage";
import apiCall, {HttpMethod} from "./api/apiServiceProvider";
import {endpoints} from "./api/apiEndpoints";
import {useAppData} from "./AppDataContext";
import {FullScreenLoader} from "./components/Loader";
import {isAdmin} from "./utils/utils";
import TaskBoardNew from "./pages/home/TaskBoardNew";
import TranslateDemo from "./pages/home/TranslateDemo";
import {useTranslate} from "./index";

// npm install javascript-obfuscator -g

const isAuthenticated = () => {
  return getLocalData(loginDataKeys.isLogin) === "true";
};

const ProtectedRoute = ({ element }) => {
  return isAuthenticated() ? element : <Navigate to="/login" replace />;
};

const AdminRoute = ({ element }) => {
  return isAdmin() ? element : <Navigate to={routes.dashboard} replace />;
};

const setCSSVariables = (colors) => {
  const root = document.documentElement;

  Object.keys(colors).forEach((key) => {
    root.style.setProperty(`--${key}`, colors[key]);
  });
};


function App() {

  // useEffect(() => {
    // window.googleTranslateElementInit = () => {
    //   new window.google.translate.TranslateElement(
    //       {
    //         pageLanguage: "en",  // Your page language
    //         autoDisplay: false,
    //       },
    //       "google_translate_element"
    //   );
    //
    //   const selectElem = document.querySelector("#google_translate_element select");
    //   if (selectElem) {
    //     selectElem.value = 'en';
    //     const event = new Event('change', { bubbles: true });
    //     selectElem.dispatchEvent(event);
    //   }

      // setTimeout(() => {
      //   const selectElem = document.querySelector("#google_translate_element select");
      //   if (selectElem) {
      //     selectElem.value = localStorage.getItem("selectedLang") || 'es';
      //     const event = new Event('change', { bubbles: true });
      //     selectElem.dispatchEvent(event);
      //   }
      // }, 1500);
    // };

    // const addScript = document.createElement("script");
    // addScript.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    // document.body.appendChild(addScript);
  // }, []);

  useEffect(() => {
    setCSSVariables(appColor);
  }, []);

  useEffect(() => {
    OneSignal.init({
      appId: "5228ee13-2fd7-49db-a028-2c22188522c8",
      notifyButton: {
        enable: true,
      },
      allowLocalhostAsSecureOrigin: true,
    }).then(async () => {
      const playerId = OneSignal.User.PushSubscription.id;
      localStorage.setItem("onesignalPlayerId", playerId);
      console.log('Player ID:', playerId);
      OneSignal.showSlidedownPrompt();
      OneSignal.isPushNotificationsEnabled().then(isEnabled => {
        if (isEnabled) {
          console.log('Push notifications are enabled!');
        } else {
          OneSignal.getNotificationPermission().then(permission => {
            console.log('Notification permission:', permission);
          });
        }
      });
    });
  }, []);


  const appDataContext = useAppData();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams();
    if (localStorage.getItem("onesignalPlayerId")) params.append('onesignalPlayerId', localStorage.getItem("onesignalPlayerId"));
    const fetchMasterData = async () => {
      try {
        const response = await apiCall({
          method: HttpMethod.GET,
          url: `${endpoints.getMasterData}?${params.toString()}`,
          setIsLoading: setIsLoading,
          showSuccessMessage: false,
        });

        if (response?.data) {
          appDataContext.setAllMasterData(response.data);
          storeLoginData(response?.data?.loginUserData, false);
        }
      } catch (error) {
        console.error("Failed to fetch master data:", error);
      }
    };

    if(getLocalData(loginDataKeys.isLogin) === 'true') {
      fetchMasterData();//
    }
  }, [getLocalData(loginDataKeys.isLogin)]);

  if (isLoading) return <FullScreenLoader />;

  return (
      <>
        {/*<BrowserRouter>*/}
          <NavigationInitializer />
          <Routes>
            <Route path="/signup" element={<SignUp />} />
            <Route path="/login" element={<Login />} />
            <Route path="/sendEmailOtp" element={<SendEmailOtp />} />
            <Route path="/verifyEmailOtp" element={<VerifyEmailOtp />} />
            <Route path="/forgotPassword" element={<ForgotPassword />} />
            <Route path="/dd" element={<DrawerPage />} />
            <Route path="/translator" element={<TranslateDemo />} />

            <Route path={routes.dashboard} element={<ProtectedRoute element={<HomeContent />} />}>
              <Route index element={<Dashboard />} />
              <Route path={routes.employees.replace("/", "")} element={<AdminRoute element={<EmployeeListContent />} />} />
              <Route path={routes.myProfile.replace("/", "")} element={<MyProfilePage />} />
              <Route path={routes.settings.replace("/", "")} element={<AdminRoute element={<SeetingPage />} />} />
              {/*<Route path={routes.tasks.replace("/", "")} element={<TaskBoard />} />*/}
              <Route path={routes.tasks.replace("/", "")} element={<TaskBoardNew />} />
              <Route path={`${routes.tasks.replace("/", "")}/:taskId`} element={<TaskBoardNew />} />
              <Route path={routes.todayReport.replace("/", "")} element={<AdminRoute element={<TodayReport />} />} />
              <Route path={routes.calendar.replace("/", "")} element={<HolidayPage />} />
              <Route path={routes.project.replace("/", "")} element={<ProjectPage />} />
              <Route path={routes.leave.replace("/", "")} element={<LeavePage isReportPage={false} />} />
              <Route path={routes.basicSalary.replace("/", "")} element={<AdminRoute element={<BasicSalaryPage />} />} />
              <Route path={routes.client.replace("/", "")} element={<ClientPage />} />
              <Route path={routes.leaveReport.replace("/", "")} element={<LeavePage isReportPage={true} />} />
              <Route path={routes.punchReport.replace("/", "")} element={<PunchReportPage />} />
              <Route path={routes.salaryReport.replace("/", "")} element={<AdminRoute element={<SalaryReportPage />} />} />
              <Route path={routes.salaryReport.replace("/", "") + "/:verificationKey"} element={<ProtectedSalaryPage />} />
            </Route>

            {/* <Route path="users/:id" element={<UserDetails />} /> */}
            {/* <Route path="/dashboard" element={<ProtectedRoute element={<HomeContent />} />} /> */}
            {/* <Route path="/empDetails" element={<ProtectedRoute element={<ViewFullEmployeeDetails />} />} /> */}
            <Route path={routes.employeeDetails} element={<AdminRoute element={<ViewFullEmployeeDetails />} />} />
            <Route path="/newDash" element={<NewDashboard />} />
            <Route path="*" element={<NoPage />} />
          </Routes>
        {/*</BrowserRouter>*/}
      </>
  );
}

export default App;
