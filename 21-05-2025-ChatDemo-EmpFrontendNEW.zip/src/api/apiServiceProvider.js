import axios from "axios";
import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {showToast} from "../components/CommonComponents";
import {navigate} from "../NavigationService";

const apiCall = async ({
                           method,
                           url,
                           data,
                           isMultipart = false,
                           showSuccessMessage = true,
                           showErrorMessage = true,
                           successCallback,
                           errorCallback,
                           headers = {},
                           setIsLoading,
                       }) => {
    if (setIsLoading) setIsLoading(true);

    const token = getLocalData(loginDataKeys.jwtToken) ?? "";

    const defaultHeaders = {
        Authorization: `Bearer ${token}`,
        'Content-Type': isMultipart ? 'multipart/form-data' : 'application/json',
        ...headers,
    };

    try {
        const response = await axios({
            method,
            url,
            data,
            headers: defaultHeaders,
        });

        if (successCallback) {
            successCallback(response.data);
        }

        if (showSuccessMessage) {
            showToast("success", response.data?.message || "Request was successful");
        }

        return response.data;
    } catch (error) {
        if (setIsLoading) setIsLoading(false);

        const errorMessage = error.response?.data?.message || error.message || "Something went wrong";

        if (errorCallback) {
            errorCallback(error.response?.data);
        }

        if (showErrorMessage) {
            showToast("error", errorMessage);
        }

        if(error.response?.status === 403) {
            navigate("/login");
        }

        console.error("API Call Error:", error);
        throw error;
    } finally {
        if (setIsLoading) setIsLoading(false);
    }
};

export const HttpMethod = {
    GET: "GET",
    POST: "POST",
    PUT: "PUT",
    DELETE: "DELETE",
    PATCH: "PATCH",
    HEAD: "HEAD",
    OPTIONS: "OPTIONS",
};

export default apiCall;
