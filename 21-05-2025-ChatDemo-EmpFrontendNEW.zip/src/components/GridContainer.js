import React from "react";

const GridContainer = ({ items, columns }) => {

  return (
    <div
      className="grid-container"
      style={{
        gridTemplateColumns: `repeat(${columns}, 1fr)`,
      }}
    >
      {items.map((item) => (
        <div
          key={item.id}
          className="grid-item"
          style={{
            gridColumn: `span ${item.colSpan || 1}`,
            gridRow: `span ${item.rowSpan || 1}`,
          }}
        >
          {item.content}
        </div>
      ))}
    </div>
  );
};

export default GridContainer;
