import React, { useState } from "react";
import PropTypes from "prop-types";

const AppText = ({
  text,
  fontSize,
  fontWeight,
  color,
  textAlign,
  lineHeight,
  letterSpacing,
  textTransform,
  fontFamily,
  margin,
  padding,
  className,
  style,
  isLink,
  onClick,
}) => {
  const [isHovered, setIsHovered] = useState(false);

  const hoverColor = isHovered ? `rgba(${parseInt(color.slice(1, 3), 16)}, ${parseInt(color.slice(3, 5), 16)}, ${parseInt(color.slice(5, 7), 16)}, 0.75)` : color;

  const textStyle = {
    fontSize: fontSize || "16px",
    fontWeight: fontWeight || "normal",
    color: isLink && !isHovered ? color : hoverColor,
    textAlign: textAlign || "left",
    lineHeight: lineHeight || "1.5",
    letterSpacing: letterSpacing || "normal",
    textTransform: textTransform || "none",
    fontFamily: fontFamily || "Montserrat, Helvetica, Arial, serif",
    margin: margin || "0",
    padding: padding || "0",
    cursor: isLink ? "pointer" : "default",
    textDecoration: isLink ? "none" : "initial",
    width: isLink ? "fit-content" : '',
    ...style,
  };

  const handleMouseEnter = () => setIsHovered(true);
  const handleMouseLeave = () => setIsHovered(false);

  const renderText = isLink ? (
    <span
      style={textStyle}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      className={className}
    >
      {text}
    </span>
  ) : (
    <div className={className} style={textStyle}>
      {text}
    </div>
  );

  return renderText;
};

AppText.propTypes = {
  text: PropTypes.string.isRequired,
  fontSize: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  fontWeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  color: PropTypes.string,
  textAlign: PropTypes.oneOf(["left", "center", "right", "justify"]),
  lineHeight: PropTypes.string,
  letterSpacing: PropTypes.string,
  textTransform: PropTypes.oneOf([
    "none",
    "uppercase",
    "lowercase",
    "capitalize",
  ]),
  fontFamily: PropTypes.string,
  margin: PropTypes.string,
  padding: PropTypes.string,
  className: PropTypes.string,
  style: PropTypes.object,
  isLink: PropTypes.bool,
  onClick: PropTypes.func,
};

export default AppText;
