import React from "react";
import PropTypes from "prop-types";

const Container = ({
  children,
  padding,
  margin,
  width,
  height,
  maxWidth,
  minHeight,
  maxHeight,
  backgroundColor,
  backgroundImage,
  backgroundSize,
  backgroundPosition,
  backgroundPositionX,
  backgroundPositionY,
  backgroundRepeat,
  backgroundAttachment,
  borderWidth,
  borderRadius,
  borderColor,
  borderStyle,
  border,
  boxShadow,
  display,
  justifyContent,
  alignItems,
  flexDirection,
  flexWrap,
  overflowY,
  position,
  cursor,
  top,
  left,
  right,
  bottom,
  zIndex,
  style,
  className,
  scrollable,
  onClick,
}) => {
  const containerStyle = {
    padding: padding || "0px",
    margin: margin || "0",
    width: width || "100%",
    height: height || "auto",
    minHeight: minHeight || "auto",
    maxHeight: maxHeight || "none",
    maxWidth: maxWidth || "none",
    backgroundColor: backgroundColor || "transparent",
    backgroundImage: backgroundImage ? `url(${backgroundImage})` : "none",
    backgroundSize: backgroundSize || "cover",
    backgroundPosition:
      backgroundPosition ||
      `${backgroundPositionX || "center"} ${backgroundPositionY || "center"}`,
    backgroundRepeat: backgroundRepeat || "no-repeat",
    backgroundAttachment: backgroundAttachment || "scroll",
    border: border || "none",
    borderColor: borderColor || "none",
    borderWidth: borderWidth || "0px",
    borderRadius: borderRadius || "8px",
    borderStyle: borderStyle || "solid",
    boxShadow: boxShadow || "none",
    cursor: cursor || "default",
    display: display || "block",
    justifyContent: justifyContent || "flex-start",
    alignItems: alignItems || "stretch",
    flexDirection: flexDirection || "row",
    flexWrap: flexWrap || "wrap",
    overflowY: overflowY || "auto",
    position: position || "static",
    top: top || "auto",
    left: left || "auto",
    right: right || "auto",
    bottom: bottom || "auto",
    zIndex: zIndex || "auto",
    scrollable: scrollable || false,
    style: {
      ...style,
    },
  };

  return (
    <div
      className={`${className} ${scrollable ? "container-with-scrollbar" : ""}`}
      style={containerStyle}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

Container.propTypes = {
  children: PropTypes.node.isRequired,
  padding: PropTypes.string,
  margin: PropTypes.string,
  width: PropTypes.string,
  height: PropTypes.string,
  minHeight: PropTypes.string,
  maxHeight: PropTypes.string,
  maxWidth: PropTypes.string,
  backgroundColor: PropTypes.string,
  backgroundImage: PropTypes.string,
  backgroundSize: PropTypes.string,
  backgroundPosition: PropTypes.string,
  backgroundPositionX: PropTypes.string,
  backgroundPositionY: PropTypes.string,
  backgroundRepeat: PropTypes.string,
  backgroundAttachment: PropTypes.string,
  borderRadius: PropTypes.string,
  boxShadow: PropTypes.string,
  display: PropTypes.string,
  justifyContent: PropTypes.string,
  alignItems: PropTypes.string,
  flexDirection: PropTypes.string,
  flexWrap: PropTypes.string,
  overflowY: PropTypes.string,
  position: PropTypes.string,
  top: PropTypes.string,
  left: PropTypes.string,
  right: PropTypes.string,
  bottom: PropTypes.string,
  zIndex: PropTypes.string,
  style: PropTypes.object,
  className: PropTypes.string,
};

export default Container;
