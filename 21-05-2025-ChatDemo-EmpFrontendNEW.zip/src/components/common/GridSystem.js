// import React from 'react';
// import { useState, useEffect } from 'react';

// const Grid = ({ children, gridGap, style = {} }) => {
//   const [columns, setColumns] = useState(4);
//   const [gap, setGap] = useState(16);
  
//   // Count the number of children
//   const itemCount = React.Children.count(children);

//   useEffect(() => {
//     const updateColumns = () => {
//       if (window.innerWidth >= 1550) {
//         setColumns(4);
//         setGap(40);
//       } else if (window.innerWidth >= 1000) {
//         setColumns(3);
//         setGap(30);
//       } else if (window.innerWidth >= 768) {
//         setColumns(2);
//         setGap(30);
//       } else if (window.innerWidth >= 480) {
//         setColumns(1);
//         setGap(20);
//       }
//     };

//     window.addEventListener("resize", updateColumns);
//     updateColumns();

//     return () => window.removeEventListener("resize", updateColumns);
//   }, []);

//   const gridStyle = {
//     display: "grid",
//     gridTemplateColumns: `repeat(${columns}, minmax(160px, 1fr))`,
//     gridAutoRows: "minmax(160px, auto)",
//     gap: `${gridGap || gap}px`,
//     width: "100%",
//     ...style,
//   };

//   return (
//     <div className="container" style={gridStyle}>
//       {React.Children.map(children, (child, index) => {
//         const itemsInLastRow = itemCount % columns || columns;
//         const lastRowStartIndex = itemCount - itemsInLastRow;
        
//         if (index >= lastRowStartIndex && itemsInLastRow < columns) {
//           const newColspan = Math.floor(columns / itemsInLastRow);
//           return React.cloneElement(child, { 
//             isLastRow: true,
//             adjustedColspan: newColspan
//           });
//         }
//         return child;
//       })}
//     </div>
//   );
// };

// const GridItem = ({ 
//   children, 
//   height = 160, 
//   colspan = 1, 
//   rowspan = 1, 
//   gridGap,
//   isLastRow = false,
//   adjustedColspan
// }) => {
//   const [columns, setColumns] = useState(4);

//   useEffect(() => {
//     const updateColumns = () => {
//       if (window.innerWidth >= 1550) {
//         setColumns(4);
//       } else if (window.innerWidth >= 1000) {
//         setColumns(3);
//       } else if (window.innerWidth >= 768) {
//         setColumns(2);
//       } else if (window.innerWidth >= 480) {
//         setColumns(1);
//       }
//     };

//     window.addEventListener("resize", updateColumns);
//     updateColumns();

//     return () => window.removeEventListener("resize", updateColumns);
//   }, []);

//   const finalColspan = isLastRow && adjustedColspan ? adjustedColspan : Math.min(colspan, columns);

//   const itemStyle = {
//     gridColumn: `span ${finalColspan}`,
//     gridRow: `span ${rowspan}`,
//     height: height * rowspan + (rowspan - 1) * gridGap,
//     textAlign: "center",
//     fontSize: "1.2rem",
//     backgroundColor: "#ffffff",
//     flexGrow: 1,
//     borderRadius: "10px",
//     boxShadow: "rgba(0, 0, 0, 0.09) 0px 1px 20px",
//   };

//   return <div style={itemStyle}>{children}</div>;
// };

// export { Grid, GridItem };















import React from 'react';
import { useState, useEffect } from 'react';

const Grid = ({ children, gridGap, style = {} }) => {
  const [columns, setColumns] = useState(4);
  const [gap, setGap] = useState(16);

  useEffect(() => {
    const updateColumns = () => {
      if (window.innerWidth >= 1550) {
        setColumns(4);
        setGap(40);
      } else if (window.innerWidth >= 1000) {
        setColumns(2);
        setGap(30);
      } else if (window.innerWidth >= 768) {
        setColumns(2);
        setGap(30);
      } else if (window.innerWidth >= 480) {
        setColumns(1);
        setGap(20);
      }
    };

    window.addEventListener("resize", updateColumns);
    updateColumns();

    return () => window.removeEventListener("resize", updateColumns);
  }, []);

  const gridStyle = {
    display: "grid",
    gridTemplateColumns: `repeat(${columns}, minmax(160px, 1fr))`, // Dynamic columns
    gridAutoRows: "minmax(160px, auto)",
    gap: `${gridGap || gap}px`,
    width: "100%",
    ...style,
  };

  return <div className="container" style={gridStyle}>{children}</div>;
};

const GridItem = ({ children, height = 160, colspan = 1, rowspan = 1 }) => {
  const [columns, setColumns] = useState(4);
  const [gap, setGap] = useState(16);

  useEffect(() => {
    const updateColumns = () => {
      if (window.innerWidth >= 1550) {
        setColumns(4);
        setGap(40);
      } else if (window.innerWidth >= 1000) {
        setColumns(2);
        setGap(30);
      } else if (window.innerWidth >= 768) {
        setColumns(2);
        setGap(30);
      } else if (window.innerWidth >= 480) {
        setColumns(1);
        setGap(20);
      }
    };

    window.addEventListener("resize", updateColumns);
    updateColumns();

    return () => window.removeEventListener("resize", updateColumns);
  }, []);

  const adjustedColspan = Math.min(colspan, columns);

  const itemStyle = {
    gridColumn: `span ${adjustedColspan}`,
    gridRow: `span ${rowspan}`,
    height: `${height * rowspan + (rowspan - 1) * gap}px`,
    textAlign: "center",
    fontSize: "1.2rem",
    backgroundColor: "#ffffff",
    flexGrow: 1,
    borderRadius: "10px",
    boxShadow: "rgba(0, 0, 0, 0.09) 0px 1px 20px",
  };

  return <div style={itemStyle}>{children}</div>;
};

export { Grid, GridItem };