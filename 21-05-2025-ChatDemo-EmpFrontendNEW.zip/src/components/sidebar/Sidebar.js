import SingleTab from "./SidebarTab";
import AppLogoHalfWhite from "../../assets/appLogoHalfWhite.jpeg";
import {useEffect, useState} from "react";

const Sidebar = ({ isMobileView, isShrinkView, activeTab, tabList, handleClick }) => {

  const [activeTabNew, setActiveTabNew] = useState(activeTab);

  useEffect(() => {
    setActiveTabNew(activeTab);
  }, [activeTab]);

  return (
    <div
      className={`sbMainContainer ${
        isMobileView
          ? "drMainContainer"
          : isShrinkView
          ? "sbCloseContainer"
          : "sbOpenContainer"
      }`}
    >
      <div className="sbTitleDiv" onClick={() => handleClick(tabList[0])}>
        <div className="sbImageDiv">
          <img src={AppLogoHalfWhite} alt="Keyur" width="100%" height="100%" />
        </div>
        <p
          className={`sbTitleText ${
            isShrinkView ? "sbTitleTextClose" : "sbTitleTextOpen"
          }`}
        >
          <span>Teqheal</span>Solution
        </p>
      </div>
      <div className="sbTabWrapper">
        <div className="sbTopWrapper">
          {tabList
            .filter((tab) => tab.position === "top" && tab.isShow === true)
            .map((o) => (
              <SingleTab
                  key={o.name}
                item={o}
                isShrink={isShrinkView}
                isActive={activeTab === o.name}
                activeTabNew={activeTabNew}
                handleClick={(item) => {
                  setActiveTabNew(item.name)
                  handleClick(item);
                }}
              />
            ))}
        </div>
        <div className="sbBottomWrapper">
          {tabList
            .filter((tab) => tab.position === "bottom" && tab.isShow === true)
            .map((o) => (
              <SingleTab
                  key={o.name}
                item={o}
                isShrink={isShrinkView}
                isActive={activeTab === o.name}
                activeTabNew={activeTabNew}
                handleClick={(item) => {
                  setActiveTabNew(activeTabNew === item.name)
                  handleClick(item)
                }}
              />
            ))}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
