import { Mail, Lock, Phone } from "react-feather";

export const emailFieldConfig = (value) => ({
  name: "emailAddress",
  placeholder: "Email Address",
  prefix: <Mail />,
  rules: [
    { required: true, message: "Please enter your email!" },
    {
      pattern: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      message: "Invalid email format",
    },
  ],
  type: "email",
  label: "Email Address",
  value: value,
  maxLength: 100,
  inputMode: "email",
  onInput: (e) => {
    let value = e.target.value;
    e.target.value = value.trim();
  },
});

export const mobileFieldConfig = (value) => ({
  name: "mobileNumber",
  placeholder: "Mobile Number",
  prefix: <Phone />,
  rules: [
    { required: true, message: "Please enter your mobile number" },
    {
      pattern: /^[6789]\d{9}$/,
      message: "Invalid mobile number format",
    },
  ],
  value: value,
  type: "tel",
  maxLength: 10,
  inputMode: "numeric",
  label: "Mobile Number",
  onInput: (e) => {
    let value = e.target.value;
    value = value.replace(/[^\d]/g, "");
    e.target.value = value;
    if (value.length > 10) {
      e.target.value = value.slice(0, 10);
    }
  },
});

export const emergencyContactFieldConfig = (value) => ({
  name: "emergencyContactNo",
  placeholder: "Emergency Contact No",
  prefix: <Phone />,
  rules: [
    { required: true, message: "Please enter your emergency contact number" },
    {
      pattern: /^[6789]\d{9}$/,
      message: "Invalid mobile number format",
    },
  ],
  value: value,
  type: "tel",
  maxLength: 10,
  inputMode: "numeric",
  label: "Emergency Contact No",
  onInput: (e) => {
    let value = e.target.value;
    value = value.replace(/[^\d]/g, "");
    e.target.value = value;
    if (value.length > 10) {
      e.target.value = value.slice(0, 10);
    }
  },
});

export const passwordFieldConfig = (value) => ({
  name: "password",
  placeholder: "Password",
  prefix: <Lock />,
  value: value,
  label: "Password",
  rules: [
    { required: true, message: "Please enter your password!" },
    {
      pattern: /^[A-Z]/,
      message: "Password must start with an uppercase letter.",
    },
    {
      pattern: /\d/,
      message: "Password must contain at least one number.",
    },
    {
      pattern: /[@$!%*?&]/,
      message: "Password must contain at least one special character.",
    },
    {
      min: 8,
      message: "Password must be at least 8 characters long.",
    },
  ],
  type: "password",
  label: "Password",
});

export const confirmPasswordFieldConfig = (form) => ({
  name: "confirmPassword",
  placeholder: "Confirm Password",
  prefix: <Lock />,
  label: "Confirm Password",
  rules: [
    { required: true, message: "Please enter your confirm password!" },
    {
      validator: (_, value) => {
        const password = form.getFieldValue("password");
        if (password && value && value !== password) {
          return Promise.reject("Password do not matched!");
        }
        return Promise.resolve();
      },
    },
  ],
  type: "password",
});

export const passwordFieldRules = [
  {
    pattern: /^[A-Z]/,
    message: "Password must start with an uppercase letter.",
  },
  {
    pattern: /\d/,
    message: "Password must contain at least one number.",
  },
  {
    pattern: /[@$!%*?&]/,
    message: "Password must contain at least one special character.",
  },
  {
    min: 8,
    message: "Password must be at least 8 characters long.",
  },
];

export const confirmPasswordFieldRules = (form) => [
  {
    validator: (_, value) => {
      const password = form.getFieldValue("password");
      if (password && value && value !== password) {
        return Promise.reject("Password do not matched!");
      }
      return Promise.resolve();
    },
  },
];
