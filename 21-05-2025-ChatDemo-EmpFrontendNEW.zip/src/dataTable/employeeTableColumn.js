import React from "react";
import { Tag, Tooltip, Popconfirm, Switch } from "antd";
import { CheckCircle, Edit, Eye, Trash2, XCircle } from "react-feather";
import appColor from "./../utils/appColors";
import { ApprovalStatus, DateTimeFormat } from "../utils/enum";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import dayjs from "dayjs";
import { colorTag } from "../common/colorTag";
import AppText from "../components/common/AppText";

const employeeTableColumn = ({
  employeeData,
  handleEditClick,
  handleDeleteClick,
  handleApproveClick,
  handleRejectClick,
  handleViewClick,
  handleUserStatusChange,
  hiddenColumns = [],
}) => [
    {
      title: appString.empCode,
      dataIndex: appKeys.employeeCode,
      key: appKeys.employeeCode,
      width: 100,
      // hidden: getUserRole() === "Admin"
    },
    {
      title: appString.fullName,
      dataIndex: appKeys.fullName,
      key: appKeys.fullName,
      sorter: (a, b) => {
        if (a.fullName > b.fullName) return 1;
        if (a.fullName < b.fullName) return -1;
        return 0;
      },
      sortDirections: [appKeys.ascend, appKeys.descend],
    },
    {
      title: appString.emailAddress,
      dataIndex: appKeys.emailAddress,
      key: appKeys.emailAddress,
      sorter: (a, b) => {
        if (a.emailAddress > b.emailAddress) return 1;
        if (a.emailAddress < b.emailAddress) return -1;
        return 0;
      },
      sortDirections: [appKeys.ascend, appKeys.descend],
    },
    {
      title: appString.mobileNumber,
      dataIndex: appKeys.mobileNumber,
      key: appKeys.mobileNumber,
    },
    {
      title: appString.dateOfBirth,
      dataIndex: appKeys.dateOfBirth,
      key: appKeys.dateOfBirth,
      render: (dateOfBirth) => {
        if (!dateOfBirth) return "";
        return dayjs(dateOfBirth).format(DateTimeFormat.DDMMMMYYYY);
      },
    },
    {
      title: appString.role,
      dataIndex: appKeys.role,
      key: appKeys.role,
      sorter: (a, b) => {
        if (a.userRole > b.userRole) return 1;
        if (a.userRole < b.userRole) return -1;
        return 0;
      },
      sortDirections: [appKeys.ascend, appKeys.descend],
    },
    {
      title: appString.status,
      dataIndex: appKeys.approvalStatus,
      key: appKeys.approvalStatus,
      width: 120,
      sorter: (a, b) => {
        if (a.approvalStatus > b.approvalStatus) return 1;
        if (a.approvalStatus < b.approvalStatus) return -1;
        return 0;
      },
      sortDirections: [appKeys.ascend, appKeys.descend],
      hidden: hiddenColumns.includes(appKeys.approvalStatus),
      render: (_, record) => {
        let color;
        if (record.approvalStatus === ApprovalStatus.Approved) {
          color = appColor.success;
        } else if (record.approvalStatus === ApprovalStatus.Pending) {
          color = appColor.warning;
        } else if (record.approvalStatus === ApprovalStatus.Rejected) {
          color = appColor.danger;
        } else {
          color = appColor.transparant;
        }
        return (
          <>
            {record.approvalStatus === ApprovalStatus.Approved ? (
              <Switch
                loading={false}
                checked={record.isActive}
                onChange={(checked) => handleUserStatusChange(record, checked)}
              />
            ) : record.approvalStatus === ApprovalStatus.Pending ? (
              <div
                style={{
                  display: "flex",
                }}
              >
                <Popconfirm
                  title={appString.rejectConfirmation}
                  onConfirm={() => handleRejectClick(record)}
                  style={{ marginRight: 35 }}
                >
                  <div style={{ marginRight: 35, cursor: "pointer" }}>
                    <Tooltip title={appString.reject}>
                      <XCircle className="deleteIconStyle" />
                    </Tooltip>
                  </div>
                </Popconfirm>
                <Popconfirm
                  title={appString.approveConfirmation}
                  onConfirm={() => handleApproveClick(record)}
                  style={{ margin: 0 }}
                >
                  <div style={{ cursor: "pointer" }}>
                    <Tooltip title={appString.approve}>
                      <CheckCircle className="successIconStyle" />
                    </Tooltip>
                  </div>
                </Popconfirm>
              </div>
            ) : (
              <Tag color={color}>{record.approvalStatus.toUpperCase()}</Tag>
            )}
          </>
        );
      },
    },
    {
      title: appString.action,
      dataIndex: appKeys.operation,
      fixed: "right",
      width: 50,
      render: (_, record) => {
        return employeeData?.length >= 1 ? (
          <>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <div
                style={{ marginRight: 25, cursor: "pointer" }}
                onClick={() => handleEditClick(record)}
              >
                <Tooltip title={appString.edit}>
                  <Edit className="commonIconStyle" />
                </Tooltip>
              </div>
              <Popconfirm
                title={appString.deleteConfirmation}
                onConfirm={() => handleDeleteClick(record)}
                style={{ margin: "0" }}
              >
                <div style={{ marginRight: 25, cursor: "pointer" }}>
                  <Tooltip title={appString.delete} placement="bottom">
                    <Trash2 className="deleteIconStyle" />
                  </Tooltip>
                </div>
              </Popconfirm>
              <div
                style={{ cursor: "pointer" }}
                onClick={() => handleViewClick(record)}
              >
                <Tooltip title={appString.view}>
                  <Eye className="commonIconStyle" />
                </Tooltip>
              </div>
            </div>
          </>
        ) : null;
      },
    },
  ];

const formatTime = (milliseconds) => {
  if (isNaN(milliseconds)) {
    return "Running...";
  }
  const hours = String(Math.floor(milliseconds / 3600000)).padStart(2, "0");
  const minutes = String(Math.floor((milliseconds % 3600000) / 60000)).padStart(
    2,
    "0"
  );
  const seconds = String(Math.floor((milliseconds % 60000) / 1000)).padStart(
    2,
    "0"
  );
  return `${hours}:${minutes}:${seconds}`;
};

const empReportTableColumn = () => [
  {
    title: "Date",
    dataIndex: "createdAt",
    key: "createdAt",
    render: (createdAt) => {
      if (!createdAt) return "-";
      return dayjs(createdAt).format(DateTimeFormat.DDMMMMYYYY);
    },
  },
  {
    title: "Total Hours",
    dataIndex: "totalHours",
    key: "totalHours",
    render: (totalHours) => {
      return colorTag(totalHours, appColor.primary);
    },
  },
  {
    title: "Working Hours",
    dataIndex: "workingHours",
    key: "workingHours",
    render: (workingHours) => {
      return colorTag(workingHours, appColor.success);
    },
  },
  {
    title: "Break Hours",
    dataIndex: "breakHours",
    key: "breakHours",
    render: (breakHours) => {
      return colorTag(breakHours, appColor.danger);
    },
  },
  {
    title: "Late Arrival",
    dataIndex: "lateArrival",
    key: "lateArrival",
    render: (lateArrival) => {
      return colorTag(lateArrival, appColor.warning);
    },
  },
  {
    title: "Overtime",
    dataIndex: "overtime",
    key: "overtime",
    render: (overtime) => {
      return colorTag(overtime, appColor.info);
    },
  },
  // {
  //   title: "Event Count",
  //   dataIndex: "keyPressCount",
  //   key: "keyPressCount",
  //   render: (_, record) => {
  //     return (
  //       <AppText
  //         text={`${record.keyPressCount ? record.keyPressCount : "0"
  //           } keyboard hits  •  ${record.mouseEventCount ? record.mouseEventCount : "0"
  //           } mouse clicks`}
  //         color={appColor.primary}
  //         fontSize={14}
  //         fontWeight={550}
  //       />
  //     );
  //   },
  // },
];

const isToday = (timestamp) => {
  const givenDate = new Date(timestamp);
  const today = new Date();

  return (
    givenDate.getFullYear() === today.getFullYear() &&
    givenDate.getMonth() === today.getMonth() &&
    givenDate.getDate() === today.getDate()
  );
};

const timeTag = (value, color) => {
  return (
    <Tag color={color} style={{ fontWeight: "bold" }}>
      {value ? formatTime(value) : "00:00:00"}
    </Tag>
  );
};

export { employeeTableColumn, empReportTableColumn };
