import React, {createContext, useContext, useEffect, useState} from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import {ToastContainer} from "react-toastify";
import {Loader} from "./components/Loader";
import {ConfigProvider, message, notification} from "antd";
import appColor from "./utils/appColors";
import {setGlobalMessageApi} from "./components/CommonComponents";
import {AppDataProvider} from "./AppDataContext";
import {LoadingBarContainer, useLoadingBar} from "react-top-loading-bar";
import {BrowserRouter, useLocation} from "react-router-dom";


export const LoadingContext = createContext({
    isLoading: false,
    setIsLoading: () => {
    },
});

export const PageLoadingContext = createContext({
    isPageLoading: false,
    setIsPageLoading: () => {
    },
});

export const ToastContext = createContext({
    showToast: (type, message) => {
    },
});

export const useToast = () => useContext(ToastContext);

export const useLoading = () => useContext(LoadingContext);
export const usePageLoading = () => useContext(PageLoadingContext);

function Root() {
    const [isLoading, setIsLoading] = useState(false);
    const [isPageLoading, setIsPageLoading] = useState(false);

    const themeConfig = {
        token: {
            colorPrimary: appColor.primary,
            borderRadius: 10,
        },
    };

    const [messageApi, contextHolder] = message.useMessage();
    setGlobalMessageApi(messageApi);

    return (
        <ConfigProvider theme={themeConfig}>
            <LoadingBarContainer
                props={{
                    color: appColor.primary,
                    height: 3,
                    shadow: false,
                }}
            >
                <InnerApp
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                    isPageLoading={isPageLoading}
                    setIsPageLoading={setIsPageLoading}
                    contextHolder={contextHolder}
                />
            </LoadingBarContainer>
        </ConfigProvider>
    );
}

function InnerApp({ isLoading, setIsLoading, isPageLoading, setIsPageLoading, contextHolder }) {
    const location = useLocation();
    const { start, complete } = useLoadingBar();


    useEffect(() => {
        console.log("location.pathname", location.pathname);
        start();

        const timer = setTimeout(() => {
            complete();
        }, 500);

        return () => clearTimeout(timer);
    }, [location.pathname]);

    return (
        <PageLoadingContext.Provider value={{ isPageLoading, setIsPageLoading }}>
            <LoadingContext.Provider value={{ isLoading, setIsLoading }}>
                <div id="google_translate_element" style={{ display: "none" }}></div>
                {isLoading ? <Loader /> : ""}
                {contextHolder}
                <AppDataProvider>
                    <App />
                </AppDataProvider>
            </LoadingContext.Provider>
        </PageLoadingContext.Provider>
    );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
    <BrowserRouter>
        <Root />
    </BrowserRouter>
);
