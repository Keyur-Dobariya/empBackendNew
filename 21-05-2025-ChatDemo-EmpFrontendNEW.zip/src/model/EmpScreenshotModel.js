import React, { useEffect, useState } from "react";
import { Modal, Spin, Button, message } from "antd";
import ImageGallery from "react-image-gallery";
import "react-image-gallery/styles/css/image-gallery.css";
import axios from "axios";
import { endpoints } from "../api/apiEndpoints";
import { DeleteFilled, DeleteOutlined } from "@ant-design/icons";
import { formatTimestamp } from "../common/DateFormat";
import appColor from "../utils/appColors";

const EmpScreenshotModel = ({
  open,
  setOpen,
  loading,
  screenshots,
  setScreenshots,
  empID,
  onClose,
}) => {
  const [galleryItems, setGalleryItems] = useState([]);

  const handleDelete = async (id, imageUrl) => {
    try {
      const response = await axios.delete(
        `${endpoints.deleteScreenshot}?id=${empID}&ssid=${id}`,
        {
          method: "DELETE",
        }
      );

      if (response.status === 200) {
        const updatedScreenshots = screenshots?.filter(
          (item, i) => item._id !== id
        );
        setScreenshots(updatedScreenshots);
        message.success("Screenshot deleted successfully");
      } else {
        message.error("Failed to delete screenshot");
      }
    } catch (error) {
      message.error("An error occurred while deleting the screenshot");
    }
  };
  // not remove this code
  // const modifyScreenshots = screenshots?.map((item, index) => ({
  //   original: item.image,
  //   thumbnail: item.image,
  //   renderItem: () => (
  //     <div style={{ position: "relative" }}>
  //       <img src={item.image} alt={`Screenshot ${index + 1}`} style={{ width: "100%" }} />
  //       <Button
  //         type="primary"
  //         danger
  //         style={{ position: "absolute", top: 10, right: 10 }}
  //         onClick={() => handleDelete(index, item.image)}>
  //         Delete
  //       </Button>
  //     </div>
  //   )
  // }));

  useEffect(() => {
    setGalleryItems(
      screenshots?.map((item, index) => ({
        original: item.image,
        thumbnail: item.image,
        renderItem: () => (
          <div style={{ position: "relative" }}>
            <img
              src={item.image}
              alt={`Screenshot ${index + 1}`}
              style={{ width: "100%" }}
            />
            <div
              className=""
              style={{
                position: "absolute",
                left: 5,
                zIndex: 10,
                bottom: 5,
                padding: 5,
                backgroundColor: "rgba(0, 0, 0, 0.86)",
                borderRadius: "5px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: 10,
                  padding: "5px",
                }}
              >
                <p
                  style={{
                    color: "white",
                    textAlign: "center",
                    fontSize: "11px",
                    fontWeight: 500,
                  }}
                >
                  {`${formatTimestamp(item?.capturedTime)} • ${
                  item.keyPressCount ? item.keyPressCount : "0"
                } keyboard hits  •  ${
                  item.mouseEventCount ? item.mouseEventCount : "0"
                } mouse clicks`}
                </p>
                {/* <div onClick={() => handleDelete(screenshots[index]?._id)}>
                  <DeleteFilled style={{ color: appColor.danger }} />
                </div> */}
              </div>
            </div>
          </div>
        ),
      }))
    );
  }, [screenshots]);

  return (
    <Modal
      title="Screenshot Viewer"
      open={open}
      onCancel={() => {
        onClose();
        setOpen(false);
      }}
      onClose={() => {
        onClose();
        setOpen(false);
      }}
      footer={null}
      width={900}
      style={{ top: 100 }}
    >
      {loading ? (
        <div
          style={{
            height: "500px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Spin active />
        </div>
      ) : galleryItems && galleryItems.length > 0 ? (
        <div style={{ backgroundColor: "black" }}>
          <ImageGallery key={galleryItems.length} items={galleryItems} />
        </div>
      ) : (
        <p style={{ textAlign: "center", color: "white" }}>
          {" "}
          No screenshots available.{" "}
        </p>
      )}
    </Modal>
  );
};

export default EmpScreenshotModel;
