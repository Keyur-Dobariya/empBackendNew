import React, { useEffect, useState } from "react";
import { Button, Form } from "antd";
import DynamicForm from "../../components/formField/DynamicForm";
import { useLocation, useNavigate } from "react-router-dom";
import {
  confirmPasswordFieldConfig,
  passwordFieldConfig,
} from "../../config/formConfig";
import { Loader } from "../../components/Loader";
import Container from "../../components/common/Container";
import imagePaths from "../../assets/assetsPaths";
import Card from "../../components/common/Card";
import AppText from "../../components/common/AppText";
import appString from "../../utils/appString";
import appColor from "../../utils/appColors";
import SpaceBox from "../../components/common/SpaceBox";
import { forgetPasswordApi } from "../../api/apiUtils";

export default function ForgotPassword() {
  const [isLoading, setIsLoading] = useState(false);
  const location = useLocation();
  const { emailAddress } = location.state || {};

  const [form] = Form.useForm();
  const [formValues, setFormValues] = useState({});

  const initialConfig = [
    passwordFieldConfig(),
    confirmPasswordFieldConfig(form),
  ];

  const handleFieldChange = (values) => {
    setFormValues(values);
  };

  useEffect(() => {
    formValues.emailAddress = emailAddress;
    setFormValues(formValues);
  }, []);

  const navigate = useNavigate();

  const handleSubmit = () => {
    forgetPasswordApi({
      form: form,
      formValues: formValues,
      setIsLoading: setIsLoading,
      navigate: navigate,
    });
  };

  return (
    <>
      {isLoading ? <Loader /> : ""}
      <Container
        padding="15px"
        width="100vw"
        height="100vh"
        backgroundColor="white"
        backgroundImage={imagePaths.bgImage}
        backgroundSize="cover"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        <Card
          width="22rem"
          padding="20px"
          elevation="0px 7px 29px 0px rgba(100, 100, 111, 0.2)"
        >
          <AppText
            text={appString.resetPassword}
            fontSize="20px"
            fontWeight="600"
            color={appColor.primary}
          />
          <AppText
            text={appString.resetPasswordDes}
            fontSize="14px"
            color={appColor.black}
          />
          <SpaceBox space={5} />
          <DynamicForm
            formConfig={initialConfig}
            form={form}
            onFieldChange={handleFieldChange}
          />
          <SpaceBox space={2} />
          <Button
            className="btnStyle"
            block
            type="primary"
            htmlType="submit"
            onClick={handleSubmit}
          >
            {appString.resetPassword}
          </Button>
        </Card>
      </Container>
    </>
  );
}
