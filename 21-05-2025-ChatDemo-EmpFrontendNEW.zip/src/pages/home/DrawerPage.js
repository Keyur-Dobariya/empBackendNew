import React, { useState, useEffect } from 'react';
import {
    DesktopOutlined,
    FileOutlined, MenuFoldOutlined, MenuUnfoldOutlined,
    PieChartOutlined,
    TeamOutlined,
    UserOutlined,
} from '@ant-design/icons';
import { Breadcrumb, Button, Layout, Menu, theme } from 'antd';

const { Header, Content, Footer, Sider } = Layout;

function getItem(label, key, icon, isShow = true, children = null) {
    return { key, icon, children, label, isShow };
}

// Menu structure
const rawItems = [
    getItem('Dashboard', '1', <PieChartOutlined />, true),
    getItem('Reports', '2', <DesktopOutlined />, true),
    getItem('Users', 'sub1', <UserOutlined />, true, [
        getItem('Tom', '3', null, true),
        getItem('Bill', '4', null, true),
    ]),
    getItem('Teams', 'sub2', <TeamOutlined />, true, [
        getItem('Team A', '5', null, true),
        getItem('Team B', '6', null, true),
    ]),
    getItem('Files', '7', <FileOutlined />, true),
];

// Filter items by isShow
const filterMenuItems = (items) => {
    return items
        .filter(item => item.isShow)
        .map(item => ({
            ...item,
            children: item.children ? filterMenuItems(item.children) : undefined,
        }));
};

const DrawerPage = () => {
    const [collapsed, setCollapsed] = useState(false);
    const [selectedKey, setSelectedKey] = useState('1');
    const [breadcrumb, setBreadcrumb] = useState(['Dashboard']);
    const [headerTitle, setHeaderTitle] = useState('Dashboard');
    const [history, setHistory] = useState(['1']);  // Stack of visited pages

    const {
        token: { colorBgContainer, borderRadiusLG },
    } = theme.useToken();

    // Key-label map for content, breadcrumb and title
    const keyToContent = {
        '1': { title: 'Dashboard', content: 'This is the dashboard page.' },
        '2': { title: 'Reports', content: 'Here are your reports.' },
        '3': { title: 'Tom', content: 'Tom\'s user profile.' },
        '4': { title: 'Bill', content: 'Bill\'s user profile.' },
        '5': { title: 'Team A', content: 'Team A details.' },
        '6': { title: 'Team B', content: 'Team B details.' },
        '7': { title: 'Files', content: 'File management screen.' },
    };

    // Set up listener for browser back button (popstate event)
    useEffect(() => {
        // Popstate event listener (when browser back or forward button is pressed)
        const handlePopState = () => {
            const previousHistory = [...history];
            previousHistory.pop();  // Remove the last visited page
            const previousKey = previousHistory[previousHistory.length - 1];

            if (previousKey) {
                setHistory(previousHistory);
                setSelectedKey(previousKey);
                setHeaderTitle(keyToContent[previousKey]?.title || 'Dashboard');
                setBreadcrumb(previousHistory.reverse().map(k => keyToContent[k]?.title || k));
            }
        };

        window.addEventListener('popstate', handlePopState);

        // Cleanup listener on component unmount
        return () => {
            window.removeEventListener('popstate', handlePopState);
        };
    }, [history]);

    const getItemByKey = (key) => {
        const findItem = (items) => {
            for (let item of items) {
                if (item.key === key) return item;
                if (item.children) {
                    const found = findItem(item.children);
                    if (found) return found;
                }
            }
            return null;
        };
        return findItem(rawItems);
    };

    const onMenuClick = ({ key, keyPath }) => {
        // Push the current key to history stack
        const item = getItemByKey(key);

        setHistory(prevHistory => {
            const newHistory = [...prevHistory, key];
            // Use history.pushState to ensure that the back button works
            window.history.pushState({}, '', `/${key}`);
            return newHistory;
        });

        // Update the selected key, header title, and breadcrumb
        setSelectedKey(key);
        const title = keyToContent[key]?.title || 'Dashboard';
        setHeaderTitle(title);
        setBreadcrumb(keyPath.reverse().map(k => keyToContent[k]?.title || k));
    };

    const handleBackClick = () => {
        // Pop the current page from history stack (if there are more than one pages)
        if (history.length > 1) {
            const previousHistory = [...history];
            previousHistory.pop();  // Remove the last visited page
            const previousKey = previousHistory[previousHistory.length - 1];
            setHistory(previousHistory);

            // Update the selected key, header title, and breadcrumb for the previous page
            setSelectedKey(previousKey);
            setHeaderTitle(keyToContent[previousKey]?.title || 'Dashboard');
            setBreadcrumb(previousHistory.reverse().map(k => keyToContent[k]?.title || k));

            // Use history.pushState to ensure that the back button works
            window.history.pushState({}, '', `/${previousKey}`);
        }
    };

    return (
        <Layout style={{ minHeight: '100vh' }}>
            <Sider
                theme='light'
                trigger={null}
                collapsible
                collapsed={collapsed}
                onCollapse={value => setCollapsed(value)}
                width={250}
            >
                {/* Sidebar Title/Logo - fixed */}
                <div style={{ padding: 16, textAlign: 'center', fontSize: 18 }}>
                    My Sidebar
                </div>

                {/* Scrollable Menu Container */}
                <div style={{
                    overflowY: 'scroll',
                    height: 'calc(100vh - 64px)',
                    scrollbarWidth: 'none', /* For Firefox */
                }}>
                    <Menu
                        theme="light"
                        mode="inline"
                        selectedKeys={[selectedKey]}
                        onClick={onMenuClick}
                        items={filterMenuItems(rawItems)}
                    />
                </div>
            </Sider>
            <Layout>
                <Header style={{ padding: '0 0', background: colorBgContainer, fontSize: 18 }}>
                    <Button
                        type="text"
                        icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                        onClick={() => setCollapsed(!collapsed)}
                        style={{
                            fontSize: '16px',
                            width: 64,
                            height: 64,
                        }}
                    />
                    {headerTitle}
                    {/* Back Button */}
                    {history.length > 1 && (
                        <Button
                            style={{ marginLeft: 10 }}
                            type="text"
                            icon={<MenuUnfoldOutlined />}
                            onClick={handleBackClick}
                        >
                            Back
                        </Button>
                    )}
                </Header>
                <Content style={{ margin: '0 16px' }}>
                    <Breadcrumb style={{ margin: '16px 0' }}>
                        {breadcrumb.map((crumb, index) => (
                            <Breadcrumb.Item key={index}>{crumb}</Breadcrumb.Item>
                        ))}
                    </Breadcrumb>
                    <div
                        style={{
                            padding: 24,
                            minHeight: 360,
                            background: colorBgContainer,
                            borderRadius: borderRadiusLG,
                        }}
                    >
                        {keyToContent[selectedKey]?.content || 'No content found.'}
                    </div>
                </Content>
                {/*<Footer style={{ textAlign: 'center' }}>*/}
                {/*    Ant Design ©{new Date().getFullYear()} Created by Ant UED*/}
                {/*</Footer>*/}
            </Layout>
        </Layout>
    );
};

export default DrawerPage;
