import appColor from "./appColors";

const colorMap = {
    A: '#e34c2c',
    B: '#30c64a',
    C: '#3656ef',
    D: '#F39C12',
    E: '#8E44AD',
    F: '#16A085',
    G: '#F1C40F',
    H: '#E74C3C',
    I: '#2ECC71',
    J: '#9B59B6',
    K: '#34495E',
    L: '#1ABC9C',
    M: '#E67E22',
    N: '#2980B9',
    O: '#8E44AD',
    P: '#D35400',
    Q: '#F39C12',
    R: '#e35b43',
    S: '#7D3C98',
    T: '#F1C40F',
    U: '#2980B9',
    V: '#27AE60',
    W: '#8E44AD',
    X: '#F39C12',
    Y: '#9B59B6',
    Z: '#34495E',
};

const lightenColor = (hex, percent) => {
    let r = parseInt(hex.slice(1, 3), 16);
    let g = parseInt(hex.slice(3, 5), 16);
    let b = parseInt(hex.slice(5, 7), 16);

    r = Math.min(255, Math.floor(r + (255 - r) * percent));
    g = Math.min(255, Math.floor(g + (255 - g) * percent));
    b = Math.min(255, Math.floor(b + (255 - b) * percent));

    return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1).padStart(6, '0')}`;
};

export const getLightColor = (value) => {
    if(!value) {
        return lightenColor(appColor.primary, 0.5);
    }
    const firstChar = value.trim().charAt(0).toUpperCase();
    return lightenColor(colorMap[firstChar], 0.5);
}

export const getDarkColor = (value) => {
    if (!value) {
        return appColor.primary;
    }
    const firstChar = value.trim().charAt(0).toUpperCase();
    return colorMap[firstChar] || appColor.primary;
};