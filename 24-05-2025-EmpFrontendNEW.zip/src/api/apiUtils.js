import {
  getLocalData,
  loginDataKeys,
  storeLoginData,
} from "../dataStorage/DataPref.js";
import { endpoints } from "./apiEndpoints.js";
import apiCall, { HttpMethod } from "./apiServiceProvider.js";
import BasicSalaryPage from "../pages/home/BasicSalaryPage";
import {UserRole} from "../utils/enum";
import {isAdmin} from "../utils/utils";

export const loginApi = async ({
  form,
  formValues,
  setIsLoading,
  navigate,
}) => {
  const isValid = await form.validateFields();
  if (isValid) {
    const body = {
      loginId: formValues.emailAddress,
      password: formValues.password,
    };

    try {
      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.login,
        data: body,
        setIsLoading,
        successCallback: (data) => {
          storeLoginData(data, true);
          navigate("/");
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const signupApi = async ({
  formValues,
  form,
  setIsLoading,
  navigate,
}) => {
  const isValid = await form.validateFields();

  if (isValid) {
    try {
      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.signUp,
        data: formValues,
        setIsLoading,
        successCallback: () => {
          navigate("/login");
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const forgetPassSendOtpApi = async ({
  formValues,
  form,
  setIsLoading,
  navigate,
}) => {
  const isValid = await form.validateFields();

  if (isValid) {
    try {
      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.forgetPassSendOtp,
        data: formValues,
        setIsLoading,
        successCallback: () => {
          navigate("/verifyEmailOtp", {
            state: { emailAddress: formValues.emailAddress },
          });
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const forgetPassVerifyOtpApi = async ({
  formValues,
  setIsLoading,
  navigate,
}) => {
  if (formValues.otp !== "") {
    try {
      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.forgetPassVerifyOtp,
        data: formValues,
        setIsLoading,
        successCallback: () => {
          navigate("/forgotPassword", {
            state: { emailAddress: formValues.emailAddress },
          });
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const forgetPasswordApi = async ({
  formValues,
  form,
  setIsLoading,
  navigate,
}) => {
  const isValid = await form.validateFields();

  if (isValid) {
    try {
      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.forgetPassword,
        data: formValues,
        setIsLoading,
        successCallback: () => {
          navigate("/login");
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const changePasswordApi = async ({ form, setIsLoading }) => {
  const isValid = await form.validateFields();

  if (isValid) {
    try {
      await apiCall({
        method: HttpMethod.POST,
        url: endpoints.changePassword,
        data: form.getFieldsValue(),
        setIsLoading,
        successCallback: () => {
          form.resetFields();
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const getAllEmployees = async ({
  setIsLoading,
  // setEmployeesData,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getAllUsers,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        // setEmployeesData(data["data"].reverse());
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getUsersList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getUsersList,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getTasksList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getAllTasks,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getNewTasksList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getGroupTask,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getProjectList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getProject,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getClientList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getClient,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getLeaveList = async ({
    forAdmin,
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: forAdmin ? endpoints.getLeaves : endpoints.empLeaveList,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getLeaveReportList = async ({
  filterQuery,
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.allLeaveLength + filterQuery,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getSalaryReportList = async ({
  filterQuery,
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: isAdmin() ? endpoints.generateSalaryReports + filterQuery : endpoints.getUserWiseReport,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getPunchReportList = async ({
  filterQuery,
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getPunchReportsList + filterQuery,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getBasicSalaryList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.basicSalaryList,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const deleteBasicSalaryApi = async ({ id, setIsLoading, successCallback }) => {
  try {
    await apiCall({
      method: HttpMethod.DELETE,
      url: `${endpoints.deleteBasicSalary}${id}`,
      setIsLoading,
      successCallback: successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const deleteProjectApi = async ({ id, setIsLoading, successCallback }) => {
  try {
    await apiCall({
      method: HttpMethod.DELETE,
      url: `${endpoints.deleteProject}${id}`,
      setIsLoading,
      successCallback: successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const deleteClientApi = async ({ id, setIsLoading, successCallback }) => {
  try {
    await apiCall({
      method: HttpMethod.DELETE,
      url: `${endpoints.deleteClient}${id}`,
      setIsLoading,
      successCallback: successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const deleteLeaveApi = async ({ id, setIsLoading, successCallback }) => {
  try {
    await apiCall({
      method: HttpMethod.DELETE,
      url: `${endpoints.deleteLeave}${id}`,
      setIsLoading,
      successCallback: successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const deleteTaskApi = async ({ id, setIsLoading, successCallback }) => {
  try {
    await apiCall({
      method: HttpMethod.DELETE,
      url: `${endpoints.deleteTask}${id}`,
      setIsLoading,
      successCallback: successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getEventsList = async ({
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getAllEventHolidays,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: (data) => {
        successCallback && successCallback(data);
      },
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const addUpdateUserApi = async ({
  id,
  isNew,
  formValues,
  form,
  setIsLoading,
  successCallback,
}) => {
  const isValid = await form.validateFields();

  if (isValid) {
    try {
      await apiCall({
        method: HttpMethod.POST,
        url: `${endpoints.addUpdateUser}${id}`,
        data: formValues,
        isMultipart: false,
        setIsLoading,
        successCallback: (data) => {
          form.resetFields();
          successCallback(data);
        },
      });
    } catch (error) {
      console.error("API Call Failed:", error);
    }
  }
};

export const userApprovalUpdateApi = async ({
  id,
  data,
  setIsLoading,
  successCallback,
}) => {
  try {
    await apiCall({
      method: HttpMethod.POST,
      url: `${endpoints.addUpdateUser}${id}`,
      data: data,
      setIsLoading,
      successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const deleteUserApi = async ({ id, setIsLoading, successCallback }) => {
  try {
    await apiCall({
      method: HttpMethod.DELETE,
      url: `${endpoints.deleteUser}${id}`,
      setIsLoading,
      successCallback: successCallback,
    });
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getEmployeeDetailsData = async ({
  id,
  startDate,
  endDate,
  setIsLoading,
}) => {
  try {
    const baseUrl = `${endpoints.userWiseAttendanceData}${id}`;
          let queryParams = [];
    
          if (startDate) {
            queryParams.push(`startDate=${startDate}`);
          }
          if (endDate) {
            queryParams.push(`endDate=${endDate}`);
          }
    
          const finalUrl =
            queryParams.length > 0
              ? `${baseUrl}?${queryParams.join("&")}`
              : baseUrl;
    const response = await apiCall({
      method: HttpMethod.GET,
      url: finalUrl,
      setIsLoading,
      showSuccessMessage: false,
    });

    return response?.data;
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};

export const getTodayReportAll = async ({setIsLoading, successCallback}) => {
  try {
    const response = await apiCall({
      method: HttpMethod.GET,
      url: endpoints.getTodayAttendance,
      setIsLoading,
      showSuccessMessage: false,
      successCallback: successCallback,
    });

    return response?.data;
  } catch (error) {
    console.error("API Call Failed:", error);
  }
};
