import afternoonIcon from '../assets/afternoonIcon.svg'
import appLogoHalf from '../assets/appLogoHalf.png'
import appLogoHalfBlack from '../assets/appLogoHalfBlack.jpeg'
import nightIcon from '../assets/nightIcon.svg'
import appIcon from '../assets/appIcon.jpeg'
import appLogo from '../assets/appLogo.png'
import appLogoHalfWhite from '../assets/appLogoHalfWhite.jpeg'
import bgImage from '../assets/bg_image.jpg'
import morningIcon from '../assets/morningIcon.svg'
import usersIcon from '../assets/icons/users.svg'
import userIcon from '../assets/icons/user.png'
import employeesIcon from '../assets/icons/employeesIcon.png'
import increaseIcon from '../assets/icons/increaseIcon.svg'
import decreaseIcon from '../assets/icons/decreaseIcon.svg'
import plusIcon from '../assets/icons/plusIcon.png'
import clockIcon from '../assets/icons/clockIcon.svg'
import absentIcon from '../assets/icons/absentIcon.svg'
import lateArrivalLogo from '../assets/icons/lateArrivalLogo.svg'
import notificationIcon from '../assets/icons/notificationIcon.svg'
import earlyLogo from '../assets/icons/earlyLogo.svg'
import timeOffIcon from '../assets/icons/timeOffIcon.svg'
import dayLightBg from '../assets/dayLightBg.png'
import nightBg from '../assets/nightBg.png'
import fingerprintIcon from '../assets/icons/fingerprintIcon.svg'
import breakIcon from '../assets/icons/breakIcon.png'
import boxBg from '../assets/boxBg.png'
import profile_placeholder from '../assets/profile_placeholder.png'
import pageNotFound from '../assets/pageNotFound.png'
import noTaskFoundImage from '../assets/noTaskFoundImage.png'
import noDataFoundImage from '../assets/noDataFoundImage.png'
import plusIconSvg from '../assets/icons/plusIcon.svg'
import filterIcon from '../assets/icons/filterIcon.svg'
import clear_priority from '../assets/clear_priority.png'
import low_priority from '../assets/low_priority.png'
import high_priority from '../assets/high_priority.png'
import urjent_priority from '../assets/urjent_priority.png'
import normal_priority from '../assets/normal_priority.png'
import on_hold_priority from '../assets/on_hold_priority.png'
import clearIcon from '../assets/icons/clearIcon.png'

const imagePaths = {
    afternoonIcon,
    appLogoHalf,
    appLogoHalfBlack,
    nightIcon,
    appIcon,
    appLogo,
    appLogoHalfWhite,
    bgImage,
    morningIcon,
    usersIcon,
    userIcon,
    employeesIcon,
    increaseIcon,
    decreaseIcon,
    plusIcon,
    clockIcon,
    absentIcon,
    lateArrivalLogo,
    earlyLogo,
    timeOffIcon,
    dayLightBg,
    nightBg,
    notificationIcon,
    fingerprintIcon,
    breakIcon,
    boxBg,
    profile_placeholder,
    pageNotFound,
    plusIconSvg,
    filterIcon,
    noTaskFoundImage,
    noDataFoundImage,
    clear_priority,
    low_priority,
    high_priority,
    urjent_priority,
    normal_priority,
    on_hold_priority,
    clearIcon
};
export default imagePaths;