import { format } from "date-fns";
import { useCallback, useEffect, useState } from "react";
import { Bounce, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { endpoints } from "../api/apiEndpoints";
import {message} from "antd";
import CryptoJS from 'crypto-js';

let messageApi = null;

export const setGlobalMessageApi = (api) => {
  messageApi = api;
};

const showToast = (type = "info", content = "") => {
  if (messageApi) {
    messageApi.open({
      type,
      content,
    });
  } else {
    message.open({
      type,
      content,
    });
  }
};

const decryptValue = (value) => {
  if (!value || !value.includes(':')) return value;

  try {
    const [ivHex, encryptedData] = value.split(':');

    const key = CryptoJS.SHA256("secretKeys"); // same as backend
    const iv = CryptoJS.enc.Hex.parse(ivHex);
    const encryptedWordArray = CryptoJS.enc.Hex.parse(encryptedData);

    const decrypted = CryptoJS.AES.decrypt(
        { ciphertext: encryptedWordArray },
        key,
        { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
    );

    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (e) {
    return value;
  }
};

// const showToast = (type = "info", content = "") => {
//   if (messageApi) {
//     messageApi[type]({
//       message: content,
//       showProgress: true,
//       pauseOnHover: true,
//       // duration: 50000,
//     });
//   }
// };

// const showToast = (type, message) => {
//   toast[type](message, {
//     position: "top-right",
//     autoClose: 3000,
//     hideProgressBar: true,
//     closeOnClick: true,
//     pauseOnHover: true,
//     draggable: false,
//     progress: undefined,
//     theme: "colored",
//     transition: Bounce,
//   });
// };

const getTwoCharacterFromName = (str) => {
  if (str) {
    const words = str.trim().split(" ");
    const firstInitial = words[0].charAt(0).toUpperCase();
    const secondInitial =
      words.length > 1 ? words[1].charAt(0).toUpperCase() : "";
    return firstInitial + secondInitial;
  }
  return "N/A";
};

const generateEmployeeCode = () => {
  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numbers = "0123456789";
  let result = "";

  for (let i = 0; i < 7; i++) {
    if (i % 2 === 0) {
      result += letters.charAt(Math.floor(Math.random() * letters.length));
    } else {
      result += numbers.charAt(Math.floor(Math.random() * numbers.length));
    }
  }
  const newStrings = Array.from({ length: 1 }, () => result);
  return newStrings[0];
};

const useIsMobileView = () => {
  const [isMobileView, setIsMobileView] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobileView(window.innerWidth <= 810);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return isMobileView;
};

const useIsMobileScreenView = () => {
  const [isMobileView, setIsMobileView] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobileView(window.innerWidth <= 770);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return isMobileView;
};

const checkImageExistence = async (url) => {
  return true;
};

const hexToRgba = ({ hex, opacity }) => {
  hex = hex.replace("#", "");

  if (hex.length === 6) {
    hex += "FF";
  }

  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);

  const a = parseInt(hex.substring(6, 8), 16) / 255;

  return `rgba(${r}, ${g}, ${b}, ${opacity || 1})`;
};

const checkImageExists = (url) => {
  if (url) {
    return true;
  }
  return false;
};

function useDynamicTimer(
  initialFormat = "hh:mm a - MMM dd, yyyy",
  autoUpdate = true
) {
  const [currentTime, setCurrentTime] = useState("");
  const [timerRunning, setTimerRunning] = useState(false);
  const [timeFormat, setTimeFormat] = useState(initialFormat);

  // Function to get the current time in the specified format
  const getCurrentTime = useCallback((formatString) => {
    const currentDate = new Date();
    // currentDate.setHours(0, 0, 0, 0);
    // const epochTime = currentDate.getTime();
    return format(currentDate, formatString);
  }, []);

  // Function to start the timer
  const startTimer = (formatString) => {
    setTimeFormat(formatString);
    setTimerRunning(true);
  };

  // Function to stop the timer
  const stopTimer = () => {
    setTimerRunning(false);
  };

  // Function to update the current time in the selected format
  const updateCurrentTime = (formatString) => {
    const formattedTime = getCurrentTime(formatString);
    setCurrentTime(formattedTime);
  };

  // Automatically update the time if autoUpdate is true
  useEffect(() => {
    if (!timerRunning && autoUpdate) {
      const intervalId = setInterval(() => {
        updateCurrentTime(timeFormat);
      }, 1000);

      return () => clearInterval(intervalId); // Cleanup interval on component unmount
    }
  }, [autoUpdate, timerRunning, timeFormat]);

  return {
    currentTime,
    startTimer,
    stopTimer,
    setTimeFormat,
  };
}

const convertCamelCase = (text) => {
  if (!text) return '';
  return text
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase());
};

export {
  showToast,
  decryptValue,
  getTwoCharacterFromName,
  generateEmployeeCode,
  hexToRgba,
  useIsMobileView,
  useIsMobileScreenView,
  useDynamicTimer,
  checkImageExistence,
  checkImageExists,
  convertCamelCase,
};
