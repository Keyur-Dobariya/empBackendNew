import React, {useEffect, useState} from 'react';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';

const Editor = ({isShowSendButton = true, onClickSendButton, onChange}) => {
    const [value, setValue] = useState(null);

    const modules = {
        toolbar: {
            container: '#toolbar',
        },
    };

    useEffect(() => {
        const observer = new MutationObserver(() => {
            const tooltip = document.querySelector('.ql-tooltip');
            const toolbar = document.querySelector('.ql-toolbar');

            if (tooltip && toolbar) {
                const toolbarRect = toolbar.getBoundingClientRect();
                const tooltipHeight = tooltip.offsetHeight;

                tooltip.style.position = 'absolute';
                tooltip.style.left = `${toolbarRect.left + toolbarRect.width / 2 - tooltip.offsetWidth / 2}px`;
                tooltip.style.top = `${toolbarRect.top - tooltipHeight - 8}px`;
                tooltip.style.zIndex = '9999';
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true,
        });

        return () => observer.disconnect();
    }, []);

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (value.trim()) {
                const styledValue = value.replace(/<img /g, '<img style="max-width:200px;height:auto;" ');
                const newValue = styledValue.replace('<p><br></p>', '');
                onClickSendButton(newValue);
                setValue(null);
            }
        }
    };

    useEffect(() => {
        const quill = document.querySelector('.ql-editor');
        if (quill) {
            quill.style.color = 'black'; // Set default text color to black
        }
    }, []);

    return (<div className="editorStyle">
        <ReactQuill
            theme="snow"
            value={value}
            placeholder="Add Comment..."
            onChange={(value) => {
                const images = document.querySelectorAll('.ql-editor img');
                images.forEach(img => {
                    img.style.maxWidth = '200px';
                    img.style.height = 'auto';
                });

                setValue(value);
                if (onChange) onChange(value);
            }}
            // preserveWhitespace={}
            modules={modules}
            onKeyDown={handleKeyDown}
        />
        <div id="toolbar">
            <div className="editorToolbar">
                <div>
                        <span className="ql-formats">
          <select className="ql-header"/>
          {/*<select className="ql-font"/>*/}
        </span>
                    <span className="ql-formats">
          <button className="ql-bold"/>
          <button className="ql-italic"/>
          <button className="ql-underline"/>
          <button className="ql-strike"/>
        </span>
                    <span className="ql-formats">
          <select className="ql-color"/>
          <select className="ql-background"/>
        </span>
                    <span className="ql-formats">
          <button className="ql-list" value="ordered"/>
          <button className="ql-list" value="bullet"/>
        </span>
                    <span className="ql-formats">
          <button className="ql-link"/>
          <button className="ql-image"/>
        </span>
                </div>
                {isShowSendButton ? <div className="messageSendButton" onClick={() => {
                    if(value) {
                        const styledValue = value.replace(/<img /g, '<img style="max-width:200px;height:auto;" ');
                        onClickSendButton(styledValue);
                        setValue(null);
                    }
                }}>
                    Submit
                    {/*Send ➤*/}
                </div> : null}
            </div>
        </div>
    </div>);
};

export default Editor;