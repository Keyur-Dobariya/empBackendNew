import React from "react";
import {Spin} from 'antd';
// import { RotatingLines } from "react-loader-spinner";

export const FullScreenLoader = () => {
  return (
      <div
          style={{
            height: "100vh",
            width: "100vw",
            backgroundColor: "#ffffff",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            zIndex: 9999,
          }}
      >
        <Spin tip="Loading data..." />
        <div style={{
          marginTop: "15px",
          fontSize: "15px",
          fontWeight: 500,
        }}>Loading Data...</div>
      </div>
  );
};

export const Loader = () => {
  return (
    <div style={styles.overlay}>
      <div style={styles.loaderContainer}>
        {/* <RotatingLines
          visible={true}
          height="40"
          width="40"
          strokeColor="#335A69"
          strokeWidth="4"
          animationDuration="0.75"
          ariaLabel="rotating-lines-loading"
          wrapperStyle={{}}
          wrapperClass=""
        /> */}
        <Spin tip="Loading" />
      </div>
    </div>
  );
};

export const OnScreenLoader = () => {
  return (
    <div style={onScreenLoaderStyles.overlay}>
      {/* <RotatingLines
          visible={true}
          height="40"
          width="40"
          strokeColor="#335A69"
          strokeWidth="4"
          animationDuration="0.75"
          ariaLabel="rotating-lines-loading"
          wrapperStyle={{}}
          wrapperClass=""
        /> */}
        <Spin tip="Loading" />
    </div>
  );
};

const styles = {
  overlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    zIndex: 1000,
  },
  loaderContainer: {
    backgroundColor: "#ffffff",
    borderRadius: "10px",
    width: "70px",
    height: "70px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    boxShadow: "0 4px 10px rgba(0, 0, 0, 0.1)",
  },
};

const onScreenLoaderStyles = {
  overlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "white",
    zIndex: 1000,
  },
};
