import React from 'react';
import PropTypes from 'prop-types';

const SpaceBox = ({
  space,
}) => {
  const spaceStyle = {
    margin: space || 0,
  };

  return (
    <div style={spaceStyle}>
    </div>
  );
};

export default SpaceBox;
