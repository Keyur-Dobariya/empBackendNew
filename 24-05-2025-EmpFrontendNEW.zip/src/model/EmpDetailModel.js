import React, { useState, useEffect, useRef } from "react";
import { Avatar, Image, Modal } from "antd";
import {
  checkImageExistence,
  generateEmployeeCode,
  getTwoCharacterFromName,
} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import Row from "../components/common/Row";
import appString from "../utils/appString";
import dayjs from "dayjs";
import { useNavigate } from "react-router-dom";
import Column from "../components/common/Column";
import Container from "../components/common/Container";

const newEmpCode = generateEmployeeCode();

export default function EmpDetailModel({
  isModelOpen,
  setIsModelOpen,
  employeeData,
  isEditing,
}) {
  const [empRecord, setEmpRecord] = useState(employeeData || {});

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const containerRef = useRef(null);

  const navigate = useNavigate();

  // useEffect(() => {
  //   const formattedDob = employeeData.dateOfBirth
  //     ? dayjs(employeeData.dateOfBirth)
  //     : dayjs();

  // empRecord = {
  //   ...empRecord,
  //   dateOfBirth: formattedDob,
  // };
  // }, [employeeData]);

  const handleEditCancel = () => {
    setIsModelOpen(false);
    if (containerRef.current) {
      containerRef.current.scrollTop = 0;
    }
  };

  const moreInfoBtnClicked = () => {
    setIsModelOpen(false);
    navigate("/empDetails", { state: { employeeDetails: empRecord } });
  };

  return (
    <>
      <Modal
        title={
          <Row justifyContent="left" alignItems="center">
            <AppText
              text={appString.employeeDetails}
              fontSize={16}
              fontWeight={500}
              color={appColor.black}
            />
            <SpaceBox space={2} />
            <AppText
              text={`( ${empRecord?.employeeCode || newEmpCode} )`}
              fontSize={14}
              fontWeight={500}
              color={appColor.primary}
            />
          </Row>
        }
        maskClosable={false}
        centered
        open={isModelOpen}
        width={600}
        footer={null}
        onOk={() => {}}
        onCancel={handleEditCancel}
        onClose={handleEditCancel}
        okText={isEditing ? appString.edit : appString.add}
      >
        {
          <div
            className="container-with-scrollbar"
            ref={containerRef}
            style={{
              maxHeight: "75vh",
              overflowY: "auto",
              alignItems: "center",
            }}
          >
            <Column justifyContent="center" alignItems="center">
              {/* <Image
                width={100}
                src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png"
                style={{ alignSelf: "center" }}
              /> */}

              {empRecord.profilePhoto &&
              checkImageExistence(
                empRecord.profilePhoto
              ) ? (
                <Avatar
                  size={100}
                  className="avatarImageStyle"
                  src={
                    <img
                      src={empRecord.profilePhoto}
                      alt="avatar"
                    />
                  }
                />
              ) : (
                <Avatar className="avatarTxtStyle" size={100}>
                  {getTwoCharacterFromName(empRecord.fullName)}
                </Avatar>
              )}
              <SpaceBox space={3} />
              <AppText
                text={empRecord.fullName}
                fontSize={16}
                fontWeight={550}
                color={appColor.black}
              />
              <AppText
                text={empRecord.role}
                fontSize={13}
                fontWeight={400}
                color={appColor.secondary}
              />
            </Column>
            <SpaceBox space={2} />
            <Container
              borderRadius={10}
              padding={"0px"}
              backgroundColor={appColor.primaryTrans}
              onClick={moreInfoBtnClicked}
            >
              <Row justifyContent="space-around">
                <AppText
                  text={`+91 ${empRecord.mobileNumber}`}
                  fontSize={14}
                  fontWeight={500}
                  color={appColor.black}
                  style={{ margin: "10px" }}
                />
                <SpaceBox space={0.5} style={{ backgroundColor: appColor.secondary }} />
                <AppText
                  text={empRecord.emailAddress}
                  fontSize={14}
                  fontWeight={500}
                  color={appColor.black}
                  style={{ margin: "10px" }}
                />
              </Row>
            </Container>
          </div>
        }
      </Modal>
    </>
  );
}
