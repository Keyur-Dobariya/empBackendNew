import React, {useEffect, useRef, useState} from "react";
import {Avatar, Button, DatePicker, Dropdown, Form, Image, Modal, Select, Tooltip, Upload} from "antd";
import {getTwoCharacterFromName,} from "../components/CommonComponents";

import SpaceBox from "../components/common/SpaceBox";
import Column from "../components/common/Column";
import {CloseCircleOutlined, PlusOutlined} from "@ant-design/icons";
import appColor from "../utils/appColors";
import AppText from "../components/common/AppText";
import AppTextFormField, {InputType,} from "../components/common/AppTextFormField";
import WrapBox from "../components/common/WrapBox";
import appKeys from "../utils/appKeys";
import appString from "../utils/appString";
import {getLocalData, loginDataKeys} from "../dataStorage/DataPref";
import {endpoints} from "../api/apiEndpoints";
import apiCall, {HttpMethod} from "../api/apiServiceProvider";
import {
    getIconByKey,
    getKeyByLabel,
    getLabelByKey,
    projectTypeLabel,
    taskColumnLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
} from "../utils/enum";
import {Loader} from "../components/Loader";
import dayjs from "dayjs";
import imagePaths from "../assets/assetsPaths";
import {getDataById, isAdmin} from "../utils/utils";

const {Option} = Select;

export default function ProjectAddUpdateModel({
                                                  isModelOpen,
                                                  setIsModelOpen,
                                                  employeeList,
                                                  clientData,
                                                  projectData,
                                                  isEditing,
                                                  setIsEditing,
                                                  onSuccessCallback,
                                              }) {
    const [isLoading, setIsLoading] = useState(false);
    const [form] = Form.useForm();
    const containerRef = useRef(null);

    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [fileList, setFileList] = useState([]);
    const [newFileList, setNewFileList] = useState([]);
    const [selectedClient, setSelectedClient] = useState(null);

    const usersSort = (fieldKey) => projectData[fieldKey] && Array.isArray(projectData[fieldKey]) ? projectData[fieldKey].map((user) => {
        return getDataById(employeeList, user.userId);
    }) : [];

    const defaultProjectValues = {
        [appKeys.projectName]: projectData[appKeys.projectName] || "",
        [appKeys.clientName]: projectData[appKeys.clientName] || "",
        [appKeys.projectDescription]: projectData[appKeys.projectDescription] || "",
        [appKeys.projectStatus]: projectData[appKeys.projectStatus] || getKeyByLabel(taskColumnLabel.ToDo, taskColumnStatusLabel),
        [appKeys.projectPriority]: projectData[appKeys.projectPriority] || taskPriorityLabel[0].key,
        [appKeys.projectType]: projectData[appKeys.projectType] || "fullstackDevelopment",
        [appKeys.teamMembers]: usersSort(appKeys.teamMembers),
        [appKeys.tags]: projectData[appKeys.tags] || "",
        [appKeys.startDate]: projectData[appKeys.startDate] || null,
        [appKeys.endDate]: projectData[appKeys.endDate] || null,
        [appKeys.attachFiles]: projectData[appKeys.attachFiles] || [],
        [appKeys.teamLeader]: usersSort(appKeys.teamLeader),
        [appKeys.teamManager]: usersSort(appKeys.teamManager),
        [appKeys.isActive]: projectData[appKeys.isActive] || false,
    };

    const [projectsValues, setProjectsValues] = useState(defaultProjectValues);

    useEffect(() => {
        if (isEditing) {
            form.setFieldsValue(projectsValues);

            const projectAttachmentsLive = projectData[appKeys.attachFiles]?.map((attachment, index) => ({
                uid: `${Date.now()}_${index}`,
                name: attachment.url?.split('/').pop() || 'file.png',
                url: attachment.url,
            })) || [];

            setFileList(projectAttachmentsLive);

            setProjectsValues((prev) => ({
                ...prev, [appKeys.attachFiles]: projectAttachmentsLive,
            }));

        }
    }, []);

    const resetProjectValues = () => {
        setProjectsValues(defaultProjectValues);
        form.resetFields();
        if (containerRef.current) {
            containerRef.current.scrollTop = 0;
        }
    };

    const handleEditCancel = () => {
        setIsModelOpen(false);
        setIsEditing(false);
        resetProjectValues();
    };

    const handleFieldChange = (changedValues, allValues) => {
        form.setFieldsValue(allValues);
        setProjectsValues((prev) => ({
            ...prev,
            [appKeys.projectName]: allValues[appKeys.projectName],
            [appKeys.clientName]: allValues[appKeys.clientName],
            [appKeys.projectDescription]: allValues[appKeys.projectDescription],
        }));
    };

    const handleSelectUser = (fieldKey, user) => {
        if (!projectsValues[fieldKey].some((u) => u.userId === user.userId)) {
            setProjectsValues((prev) => ({
                ...prev,
                [fieldKey]: [...prev[fieldKey], user],
            }));
        }
    };

    const handleRemoveUser = (fieldKey, userId) => {
        setProjectsValues((prev) => ({
            ...prev,
            [fieldKey]: prev[fieldKey].filter((user) => user.userId !== userId),
        }));
    };

    const menu = {
        items: employeeList.map((user) => ({
            key: user._id, label: (<div
                onClick={() => handleSelectUser(user)}
                style={{display: "flex", alignItems: "center", gap: "10px"}}
            >
                <Avatar src={user.profilePhoto || imagePaths.profile_placeholder} size="small"/>
                {user.fullName}
            </div>),
        })),
    };

    const handleAddUpdateProjectApi = async () => {
        try {
            setIsLoading(true);
            await form.validateFields([appKeys.clientName, appKeys.projectName,]);

            let uploadedAttachments = [];

            if (newFileList.length > 0) {

                const formData = new FormData();
                newFileList.forEach((file) => {
                    formData.append("attachFiles", file);
                });

                await apiCall({
                    method: HttpMethod.POST,
                    url: endpoints.uploadFiles,
                    data: formData,
                    isMultipart: true,
                    setIsLoading: setIsLoading,
                    successCallback: (data) => {
                        if (data.data) {
                            uploadedAttachments = data.data;
                        }
                    },
                });
            }

            const existingAttachments = projectsValues[appKeys.attachFiles] || [];
            const allAttachments = [...existingAttachments, ...uploadedAttachments];

            const finalProjectData = {
                ...projectsValues,
                addedBy: getLocalData(loginDataKeys._id),
                [appKeys.attachFiles]: allAttachments,
            };

            await apiCall({
                method: HttpMethod.POST,
                url: !isEditing ? endpoints.updateProject : `${endpoints.updateProject}/${projectData["_id"]}`,
                data: finalProjectData,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    handleEditCancel();
                    onSuccessCallback(data);
                },
            });
        } catch (error) {
            console.error("Form validation or API failed:", error);
        } finally {
            setIsLoading(false);
        }
    };

    var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) {
            return value instanceof P ? value : new P(function (resolve) {
                resolve(value);
            });
        }

        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) {
                try {
                    step(generator.next(value));
                } catch (e) {
                    reject(e);
                }
            }

            function rejected(value) {
                try {
                    step(generator['throw'](value));
                } catch (e) {
                    reject(e);
                }
            }

            function step(result) {
                result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
            }

            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };

    const getBase64 = file => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });

    const handlePreview = file => __awaiter(void 0, void 0, void 0, function* () {
        if (!file.url && !file.preview) {
            file.preview = yield getBase64(file.originFileObj);
        }
        setPreviewImage(file.url || file.preview);
        setPreviewOpen(true);
    });

    const handleChange = ({fileList: newFileList}) => {
        const originFiles = newFileList
            .map(file => file.originFileObj)
            .filter(file => !!file);
        setFileList(newFileList);

        setNewFileList(originFiles);

        const existingAttachments = newFileList.filter(file => file.url); // already uploaded files
        const newAttachments = originFiles;

        setProjectsValues((prev) => ({
            ...prev, [appKeys.attachFiles]: existingAttachments,
        }));
    }

    const handleBeforeUpload = (file) => {
        return false;
    };

    const uploadButton = (<button style={{border: 0, background: 'none'}} type="button">
        <PlusOutlined/>
        <div style={{marginTop: 8}}>Upload</div>
    </button>);

    const formUi = () => {
        return (<>
            {isLoading ? <Loader/> : ""}
            <Column justifyContent="center" alignItems="center">
                <Form
                    form={form}
                    name="EmpAddUpdateModel"
                    layout="vertical"
                    onValuesChange={handleFieldChange}
                    style={{
                        marginTop: 15, marginRight: 10, alignContent: "center", overflowX: "hidden",
                    }}
                >
                    <WrapBox>
                        <Form.Item name={appKeys.clientName} label={appString.clientName} span={12} rules={[
                            {
                                required: true,
                                message: "Client Selection Required"
                            }
                        ]}>
                            <Select
                                placeholder="Select Client"
                                allowClear
                                style={{height: '40px'}}
                                showSearch
                                value={selectedClient}
                                onChange={(value) => {
                                    setSelectedClient(value);
                                    form.setFieldsValue({[appKeys.projectName]: undefined}); // clear project on client change
                                }}
                                filterOption={(input, option) =>
                                    option.children.toLowerCase().includes(input.toLowerCase())
                                }
                            >
                                {clientData.map(client => (
                                    <Option key={client._id} value={client._id}>{client.clientName}</Option>
                                ))}
                            </Select>
                        </Form.Item>
                        <AppTextFormField
                            name={appKeys.projectName}
                            label={appString.projectName}
                            isRequired={true}
                            type={InputType.Text}
                            placeholder={appString.projectName}
                            value={projectsValues[appKeys.projectName]}
                            span={12}
                        />
                        {/*<AppTextFormField*/}
                        {/*    name={appKeys.clientName}*/}
                        {/*    label={appString.clientName}*/}
                        {/*    type={InputType.Text}*/}
                        {/*    placeholder={appString.clientName}*/}
                        {/*    value={projectsValues[appKeys.clientName]}*/}
                        {/*    span={24}*/}
                        {/*/>*/}
                        <AppTextFormField
                            name={appKeys.projectDescription}
                            label={appString.projectDescription}
                            type={InputType.TextArea}
                            placeholder={appString.projectDescription}
                            value={projectsValues[appKeys.projectDescription]}
                            span={24}
                        />
                        {isAdmin() ? <Column span={24}>
                            <div className="categoryAssigneeRow">
                                <AppText
                                    text={`Fields:`}
                                    fontSize={15}
                                    fontWeight={500}
                                    color={appColor.black}
                                />
                            </div>
                            <SpaceBox space={3}/>
                            <div className="taskFieldContainer">
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        📌 Project Status
                                    </div>
                                    <div className="taskFieldValue">
                                        <Dropdown menu={{
                                            items: taskColumnStatusLabel, onClick: ({key}) => {
                                                setProjectsValues((prev) => ({
                                                    ...prev, [appKeys.projectStatus]: key
                                                }));
                                            }
                                        }} trigger={["click"]}>
                                            <div
                                                className="taskFieldValueSelectorItem">{getLabelByKey(projectsValues[appKeys.projectStatus], taskColumnStatusLabel)}</div>
                                        </Dropdown>
                                    </div>
                                </div>
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        ⏳ Project Start/End
                                    </div>
                                    <div className="taskFieldValue">
                                        <DatePicker
                                            className="taskFieldValueSelectorItem"
                                            format={"DD-MM-YYYY hh:mm:ss A"}
                                            showTime={{
                                                format: "HH:mm",
                                            }}
                                            // use12Hours
                                            placeholder="Start Date"
                                            value={projectsValues[appKeys.startDate] ? dayjs(projectsValues[appKeys.startDate], 'DD-MM-YYYY hh:mm:ss A') : null}
                                            onChange={(time, timeString) => {
                                                setProjectsValues((prev) => ({
                                                    ...prev, [appKeys.startDate]: timeString
                                                }));
                                            }}
                                        />

                                        <DatePicker
                                            className="taskFieldValueSelectorItem"
                                            format={"DD-MM-YYYY hh:mm:ss A"}
                                            showTime={{
                                                format: "HH:mm",
                                            }}
                                            // use12Hours
                                            placeholder="End Date"
                                            value={projectsValues[appKeys.endDate] ? dayjs(projectsValues[appKeys.endDate], 'DD-MM-YYYY hh:mm:ss A') : null}
                                            onChange={(time, timeString) => {
                                                setProjectsValues((prev) => ({
                                                    ...prev, [appKeys.endDate]: timeString
                                                }));
                                            }}
                                        />
                                    </div>
                                </div>
                                {/*<div className="taskFieldRow">*/}
                                {/*    <div className="taskFieldLabel">*/}
                                {/*        🏷️ Tags*/}
                                {/*    </div>*/}
                                {/*    <div className="taskFieldValue">*/}
                                {/*        <Dropdown menu={{*/}
                                {/*            items: taskStatusLabel, onClick: ({key}) => {*/}
                                {/*                setProjectsValues((prev) => ({...prev, [appKeys.tags]: key}));*/}
                                {/*            }*/}
                                {/*        }} trigger={["click"]}>*/}
                                {/*            <div*/}
                                {/*                className="taskFieldValueSelectorItem">{getLabelByKey(projectsValues[appKeys.tags], taskStatusLabel)}</div>*/}
                                {/*        </Dropdown>*/}
                                {/*    </div>*/}
                                {/*</div>*/}
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        👥 Team Members
                                    </div>
                                    <div className="taskFieldValue">
                                        <TeamMemberPicker
                                            fieldKey={appKeys.teamMembers}
                                            employeeList={employeeList}
                                            selectedUserList={projectsValues[appKeys.teamMembers]}
                                            handleSelectUser={handleSelectUser}
                                            handleRemoveUser={handleRemoveUser}
                                        />
                                    </div>
                                </div>
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        🔥 Priority
                                    </div>
                                    <div className="taskFieldValue">
                                        <Dropdown menu={{
                                            items: taskPriorityLabel, onClick: ({key}) => {
                                                setProjectsValues((prev) => ({
                                                    ...prev, [appKeys.projectPriority]: key
                                                }));
                                            }
                                        }} trigger={["click"]}>
                                            <div
                                                className="taskFieldValueSelectorItem">{getIconByKey(projectsValues[appKeys.projectPriority], taskPriorityLabel)}{getLabelByKey(projectsValues[appKeys.projectPriority], taskPriorityLabel)}</div>
                                        </Dropdown>
                                    </div>
                                </div>
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        👨‍💼 Team Leader
                                    </div>
                                    <div className="taskFieldValue">
                                        <TeamMemberPicker
                                            fieldKey={appKeys.teamLeader}
                                            employeeList={employeeList}
                                            selectedUserList={projectsValues[appKeys.teamLeader]}
                                            handleSelectUser={handleSelectUser}
                                            handleRemoveUser={handleRemoveUser}
                                            isSingleSelect={true}
                                        />
                                    </div>
                                </div>
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        ‍💼 Team Manager
                                    </div>
                                    <div className="taskFieldValue">
                                        <TeamMemberPicker
                                            fieldKey={appKeys.teamManager}
                                            employeeList={employeeList}
                                            selectedUserList={projectsValues[appKeys.teamManager]}
                                            handleSelectUser={handleSelectUser}
                                            handleRemoveUser={handleRemoveUser}
                                            isSingleSelect={true}
                                        />
                                    </div>
                                </div>
                                <div className="taskFieldRow">
                                    <div className="taskFieldLabel">
                                        📂 Project Type
                                    </div>
                                    <div className="taskFieldValue">
                                        <Dropdown menu={{
                                            items: projectTypeLabel, onClick: ({key}) => {
                                                setProjectsValues((prev) => ({
                                                    ...prev, [appKeys.projectType]: key
                                                }));
                                            }
                                        }} trigger={["click"]}>
                                            <div
                                                className="taskFieldValueSelectorItem">{getLabelByKey(projectsValues[appKeys.projectType], projectTypeLabel)}</div>
                                        </Dropdown>
                                    </div>
                                </div>
                                <div className="taskFieldRow" style={{borderBottom: "none"}}>
                                    <div className="taskFieldLabel">📑 Attachment</div>
                                    <div className="taskFieldValue">
                                        <div className="taskFieldValueAttachment">
                                            <Upload
                                                key={"image"}
                                                listType="picture-card"
                                                fileList={fileList}
                                                beforeUpload={handleBeforeUpload}
                                                onPreview={handlePreview}
                                                onChange={handleChange}
                                                multiple
                                            >
                                                {uploadButton}
                                            </Upload>
                                            {previewImage && (<Image
                                                wrapperStyle={{display: 'none'}}
                                                preview={{
                                                    visible: previewOpen,
                                                    onVisibleChange: visible => setPreviewOpen(visible),
                                                    afterOpenChange: visible => !visible && setPreviewImage(''),
                                                }}
                                                src={previewImage}
                                            />)}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Column> : null}
                    </WrapBox>
                </Form>
                <SpaceBox space={5}/>
            </Column>
        </>);
    };

    return (<>
        {isModelOpen && (<Modal
            title={isEditing ? "Edit Project" : "Add Project"}
            maskClosable={false}
            centered
            open={isModelOpen}
            width={700}
            onOk={() => {
                handleAddUpdateProjectApi();
            }}
            onCancel={handleEditCancel}
            onClose={handleEditCancel}
            okText={"Save"}
        >
            {<div
                className="container-with-scrollbar"
                ref={containerRef}
                style={{
                    width: "100%", maxHeight: "75vh", overflow: "auto", alignItems: "center",
                }}
            >
                {formUi()}
            </div>}
        </Modal>)}
    </>);
}

const TeamMemberPicker = ({
                              fieldKey,
                              employeeList,
                              selectedUserList,
                              handleSelectUser,
                              handleRemoveUser,
                              isSingleSelect = false
                          }) => {

    const [dropdownHeight, setDropdownHeight] = useState(200);

    // Dynamically calculate dropdown height based on window size
    useEffect(() => {
        const updateDropdownHeight = () => {
            const screenHeight = window.innerHeight; // Get the height of the window
            setDropdownHeight(screenHeight * 0.4); // Set dropdown height to 40% of screen height
        };

        updateDropdownHeight(); // Call on initial render

        window.addEventListener('resize', updateDropdownHeight); // Recalculate height on window resize
        return () => window.removeEventListener('resize', updateDropdownHeight); // Cleanup
    }, []);

    return (
        <div style={{display: 'flex', alignItems: 'center', gap: '5px'}}>
            {selectedUserList.map((user) => {
                return user && user.userId ? (
                    <Tooltip key={user.userId}
                             title={getDataById(employeeList, user.userId)?.fullName || 'Unknown User'}>
                        <div style={{position: 'relative', display: 'inline-block'}}>
                            <Avatar
                                src={user.profilePhoto || null}
                                style={{
                                    backgroundColor: appColor.primaryTrans,
                                    color: appColor.primary,
                                    fontWeight: '600',
                                    border: 'none',
                                }}
                            >
                                {getTwoCharacterFromName(user.fullName)}
                            </Avatar>
                            <CloseCircleOutlined
                                onClick={() => handleRemoveUser(fieldKey, user.userId)}
                                style={{
                                    position: 'absolute',
                                    top: 0,
                                    right: 0,
                                    fontSize: '13px',
                                    color: 'red',
                                    cursor: 'pointer',
                                    background: 'white',
                                    borderRadius: '50%',
                                }}
                            />
                        </div>
                    </Tooltip>
                ) : null;
            })}

            <Dropdown
                menu={{
                    items: employeeList.map((user) => ({
                        key: user._id,
                        label: (
                            <div
                                onClick={() => handleSelectUser(fieldKey, user)}
                                style={{display: 'flex', alignItems: 'center', gap: '10px'}}
                            >
                                <Avatar src={user.profilePhoto || imagePaths.profile_placeholder} size="small"/>
                                {user.fullName}
                            </div>
                        ),
                    })),
                }}
                trigger={['click']}
                dropdownRender={(menu) => (
                    <div
                        style={{
                            borderRadius: '8px',
                            overflow: 'hidden',
                            border: '1px solid #ddd',
                            boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)',
                        }}
                    >
                        <div
                            style={{
                                maxHeight: dropdownHeight,
                                overflowY: 'auto',
                            }}
                        >
                            {menu}
                        </div>
                    </div>
                )}
            >
                {
                    isSingleSelect && selectedUserList.length === 0 ?
                        <Button shape="circle" icon={<PlusOutlined/>}/> : !isSingleSelect ?
                            <Button shape="circle" icon={<PlusOutlined/>}/> : null
                }
            </Dropdown>
        </div>
    );
};