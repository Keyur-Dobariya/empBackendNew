import imagePaths from "../assets/assetsPaths";

export default function NoPage() {
    return (
        <div style={{ justifyContent: "center", alignItems: "center", display: "flex", height: "100vh" }}>
            <img src={imagePaths.pageNotFound} width="400" alt="Page Not Found" />
        </div>
    )
}
