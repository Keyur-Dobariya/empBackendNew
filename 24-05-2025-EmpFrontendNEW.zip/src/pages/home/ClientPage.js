import React, {useEffect, useState} from "react";
import {
    Search,
    Edit, Trash2, UserPlus
} from "react-feather";
import {
    Col,
    Popconfirm,
    Spin,
    Table,
    Tooltip
} from "antd";
import dayjs from "dayjs";
import {
    deleteClientApi,
} from "../../api/apiUtils";
import {SearchTextFieldNew} from "../../components/formField/DynamicForm";
import {useIsMobileScreenView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import ClientAddUpdateModel from "../../model/ClientAddUpdateModel";
import Row from "../../components/common/Row";
import {AppDataFields, useAppData} from "../../AppDataContext";

const ClientPage = () => {
    const isMobileView = useIsMobileScreenView();
    const {activeUsersData, clientsData, updateAppDataField} = useAppData();
    const [isAddClientModelOpen, setAddClientModelOpen] = useState(false);
    const [isClientEditing, setIsClientEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [clientRecord, setClientRecord] = useState(clientsData);
    const [selectedClientRecord, setSelectedClientRecord] = useState({});

    useEffect(() => {
        setClientRecord(clientsData);
    }, [clientsData]);

    const handleDataConditionWise = (data) => {
        updateAppDataField(AppDataFields.clientsData, data?.data);
    };

    const handleAddClick = () => {
        setAddClientModelOpen(true);
        setSelectedClientRecord({});
    };

    const handleEditClick = (value) => {
        setIsClientEditing(true);
        setSelectedClientRecord(value);
        setAddClientModelOpen(true);
    };

    const handleDeleteClientApi = async (event) => {
        await deleteClientApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddClientModelOpen(false);
                handleDataConditionWise(data);
            },
        });
    };

    const projectTableColumn = [
        {
            title: appString.clientName,
            dataIndex: appKeys.clientName,
            key: appKeys.clientName,
        },
        {
            title: appString.createdAt,
            dataIndex: appKeys.createdAt,
            key: appKeys.createdAt,
            render: (createdAt) => {
                return dayjs(createdAt).format("DD, MMM YYYY [at] hh:mm a");
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            render: (_, record) => {
                return activeUsersData?.length >= 1 ? (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            <div
                                style={{marginRight: 25, cursor: "pointer"}}
                                onClick={() => handleEditClick(record)}
                            >
                                <Tooltip title={appString.edit}>
                                    <Edit className="commonIconStyle"/>
                                </Tooltip>
                            </div>
                            <Popconfirm
                                title={appString.deleteConfirmation}
                                onConfirm={() => handleDeleteClientApi(record)}
                                style={{margin: "0"}}
                            >
                                <div style={{marginRight: 25, cursor: "pointer"}}>
                                    <Tooltip title={appString.delete} placement="bottom">
                                        <Trash2 className="deleteIconStyle"/>
                                    </Tooltip>
                                </div>
                            </Popconfirm>
                        </div>
                    </>
                ) : null;
            },
        },
    ];

    return (
        <>
            <div className="taskBoardContainer">
                <Row gutter={[16, 16]} style={{display: "flex", justifyContent: "space-between", margin: "15px 0px", gap: "10px"}}>
                    <Col xs={20} sm={20} md={15} lg={8}>
                        <SearchTextFieldNew
                            field={{
                                name: "search",
                                placeholder: "Search Data",
                                prefix: <Search />,
                                onChange: (e) => {
                                    const searchText = e.target.value.toLowerCase();
                                    const filteredData = clientsData?.filter((record) => {
                                        return (
                                            record.clientName?.toLowerCase().includes(searchText)
                                        );
                                    });
                                    setClientRecord(filteredData);
                                },
                            }}
                        />
                    </Col>
                    <Col xs={4} sm={4} md={6} lg={5} xl={4} xxl={3}>
                        <div className="addUpdateCommonBtn" onClick={handleAddClick}>
                            <UserPlus />
                            {!isMobileView ? <div>Add Client</div> : null}
                        </div>
                    </Col>
                </Row>
                <Table
                    columns={projectTableColumn}
                    dataSource={[...clientRecord]}
                    scroll={{x: "max-content"}}
                    loading={isLoading}
                />
            </div>
            {isAddClientModelOpen && (
                <ClientAddUpdateModel
                    isModelOpen={isAddClientModelOpen}
                    setIsModelOpen={setAddClientModelOpen}
                    employeeList={activeUsersData}
                    clientData={selectedClientRecord}
                    isEditing={isClientEditing}
                    setIsEditing={setIsClientEditing}
                    onSuccessCallback={(data) => {
                        handleDataConditionWise(data);
                    }}
                />
            )}
        </>
    );
};

export default ClientPage;