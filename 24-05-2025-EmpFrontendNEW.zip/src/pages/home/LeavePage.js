import React, {useEffect, useRef, useState} from "react";
import {DragDropContext, Droppable, Draggable} from "@hello-pangea/dnd";
import imagePaths from "../../assets/assetsPaths";
import {
    Tag as TagIcon,
    Calendar,
    Check,
    ChevronsUp,
    Filter,
    Plus,
    ShoppingCart,
    User,
    Search,
    XCircle,
    CheckCircle,
    Edit,
    Trash2,
    Eye,
    ToggleLeft,
    ToggleRight,
    Clock,
    FileMinus,
    PieChart,
    PenTool,
    Box,
    Map,
    Users, UserPlus, UserMinus, Smile, GitHub
} from "react-feather";
import appColor from "../../utils/appColors";
import {
    Avatar,
    Button, Checkbox, Col,
    DatePicker,
    Divider, Form, Modal,
    Popconfirm,
    Popover, Row,
    Select,
    Spin,
    Switch,
    Table,
    Tag,
    Tooltip
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    ApprovalStatus,
    DateTimeFormat, dayTypeLabel, eventLeaveTypeMenuList, eventTypeMenuList,
    getIconByKey,
    getLabelByKey, leaveCategoryLabel, leaveCategoryNewLabel, leaveHalfDayTypeLabel, leaveLabelKeys, leaveTypeLabel,
    projectTypeLabel, reportTypeKey, reportTypeLabels,
    taskColumnStatusLabel,
    taskPriorityLabel,
} from "../../utils/enum";
import {CalendarOutlined, CheckOutlined, UserOutlined} from "@ant-design/icons";
import dayjs from "dayjs";
import {
    deleteLeaveApi,
    deleteProjectApi, deleteTaskApi,
    deleteUserApi,
    getLeaveList, getLeaveReportList,
    getProjectList,
    getTasksList,
    getUsersList
} from "../../api/apiUtils";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import {UserRole} from './../../utils/enum';
import {SearchTextField} from "../../components/formField/DynamicForm";
import {convertCamelCase, useIsMobileView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import LeaveAddUpdateModel from "../../model/LeaveAddUpdateModel";
import {antTag, colorTag} from "../../common/colorTag";

import AppTextFormField, {InputType} from "../../components/common/AppTextFormField";
import Container from "../../components/common/Container";
import Image from "../../components/common/Image";
import SpaceBox from "../../components/common/SpaceBox";
import Column from "../../components/common/Column";
import AppText from "../../components/common/AppText";
import {isAdmin} from "../../utils/utils";
import {useAppData} from "../../AppDataContext";
import {getDarkColor} from "../../utils/colorMapper";

const {Option} = Select;
const {RangePicker} = DatePicker;

const LeavePage = ({isReportPage}) => {
    const {activeUsersData} = useAppData();

    const [isAddLeaveModelOpen, setAddLeaveModelOpen] = useState(false);
    const [isLeaveEditing, setIsLeaveEditing] = useState(false);
    const [isLeaveStatusChange, setIsLeaveStatusChange] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingLeaveId, setLoadingLeaveId] = useState(null);
    const [leaveRecord, setLeaveRecord] = useState([]);
    const [leaveRecordCount, setLeaveRecordCount] = useState([]);
    const [unexpectedLeaveRecord, setUnexpectedLeaveRecord] = useState([]);
    const [leaveFullRecord, setLeaveFullRecord] = useState([]);
    const [selectedLeaveRecord, setSelectedLeaveRecord] = useState({});

    const now = new Date();
    const prevMonth = now.getMonth();
    const defaultMonth = prevMonth === 0 ? 12 : prevMonth;
    const defaultYear = prevMonth === 0 ? now.getFullYear() - 1 : now.getFullYear();

    const defaultMonthDayjs = dayjs(`${defaultYear}-${String(defaultMonth).padStart(2, '0')}`, 'YYYY-MM');

    const [filters, setFilters] = useState({
        user: isAdmin() ? null : getLocalData(loginDataKeys._id),
        leaveCategory: null,
        year: defaultYear,
        month: defaultMonth,
    });

    const getQueryParams = () => {
        const params = new URLSearchParams();
        if (filters.user) params.append('user', filters.user);
        if (filters.leaveCategory) params.append('leaveCategory', filters.leaveCategory);
        if (filters.year) params.append('year', filters.year);
        if (filters.month) params.append('month', filters.month);
        return params.toString();
    };

    React.useEffect(() => {
        const query = getQueryParams();
        // if (isReportPage) {
            getLeaveReportData(query);
        // }
    }, [filters]);

    const getLeaveReportData = (query) => {
        getLeaveReportList({
            filterQuery: query,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setLeaveRecordCount(data.count);
                handleDataConditionWise(data.data, false);
            },
        });
    };

    const handleDataConditionWise = (data, isSearchField) => {
        const filteredLeave = isAdmin() ? data : data.filter((leave) => leave.user.userId === getLocalData(loginDataKeys._id));
        const filterLeaveRecord = filteredLeave.filter((leave) => leave.isUnexpected !== true);
        const filterUnexpectedLeaveRecord = filteredLeave.filter((leave) => leave.isUnexpected === true);
        setLeaveRecord(filterLeaveRecord);
        setUnexpectedLeaveRecord(filterUnexpectedLeaveRecord);
        if (!isSearchField) {
            setLeaveFullRecord(data);
        }
    };

    const handleAddUpdateLeaveApi = async (_id, data) => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.addLeave}/${_id}`,
                data: data,
                setIsLoading: false,
                successCallback: (data) => {
                    handleDataConditionWise(data.data, false);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        } finally {
            setLoadingLeaveId(null);
        }
    };

    const handleLeaveAddClick = () => {
        setAddLeaveModelOpen(true);
        setSelectedLeaveRecord({});
    };

    const handleLeaveStatusChange = (record, checked) => {
        const body = {
            sandwichLeave: checked,
            user: record.user?.userId
        };

        setLoadingLeaveId(record._id);

        handleAddUpdateLeaveApi(record._id, body);
    }

    const handleEditClick = (value) => {
        setIsLeaveEditing(true);
        setSelectedLeaveRecord(value);
        setAddLeaveModelOpen(true);
    };

    const handleDeleteLeaveApi = async (event) => {
        await deleteLeaveApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddLeaveModelOpen(false);
                handleDataConditionWise(data.data, false);
            },
        });
    };

    const leaveTableColumn = [
        Table.EXPAND_COLUMN,
        {
            title: appString.fullName,
            dataIndex: appKeys.user,
            key: 'user.fullName',
            render: (text, record) => record.user ? record.user.fullName : '',
        },
        {
            title: appString.leaveType,
            dataIndex: appKeys.leaveType,
            key: appKeys.leaveType,
            render: (leaveType) => {
                return antTag(
                    getLabelByKey(leaveType, leaveTypeLabel),
                    leaveType === leaveLabelKeys.fullDay ? "red" : leaveType === leaveLabelKeys.halfDay ? "blue" : "purple"
                );
            },
        },
        {
            title: appString.hours,
            dataIndex: appKeys.hours,
            key: appKeys.hours,
        },
        {
            title: appString.startDate,
            dataIndex: appKeys.startDate,
            key: appKeys.startDate,
            render: (startDate) => {
                return startDate ? dayjs(startDate).format("YYYY-MM-DD") : '-';
            },
        },
        {
            title: appString.endDate,
            dataIndex: appKeys.endDate,
            key: appKeys.endDate,
            render: (endDate) => {
                return endDate ? dayjs(endDate).format("YYYY-MM-DD") : '-';
            },
        },
        {
            title: appString.leaveCategory,
            dataIndex: appKeys.leaveCategory,
            key: appKeys.leaveCategory,
            render: (leaveCategory) => {
                return antTag(
                    getLabelByKey(leaveCategory, leaveCategoryLabel({disabledValues: []})),
                    leaveCategory === leaveLabelKeys.paid ? "red" : "green"
                );
            },
        },
        {
            title: appString.isUnexpected,
            dataIndex: appKeys.isUnexpected,
            key: appKeys.isUnexpected,
            render: (isUnexpected) => {
                return antTag(
                    isUnexpected ? 'Yes' : 'No',
                    isUnexpected ? "red" : "green"
                );
            },
        },
        {
            title: appString.status,
            dataIndex: appKeys.status,
            key: appKeys.status,
            render: (status) => {
                return antTag(
                    convertCamelCase(status),
                    status === leaveLabelKeys.rejected ? "red" : status === leaveLabelKeys.approved ? "green" : "gold"
                );
            },
        },
        // {
        //     title: appString.createdAt,
        //     dataIndex: appKeys.createdAt,
        //     key: appKeys.createdAt,
        //     render: (createdAt) => {
        //         return createdAt ? dayjs(createdAt).format("DD, MMM YYYY [at] hh:mm a") : '-';
        //     },
        // },
        {
            title: appString.sandwichLeave,
            dataIndex: appKeys.sandwichLeave,
            key: appKeys.sandwichLeave,
            render: (sandwichLeave) => {
                return antTag(
                    sandwichLeave ? 'Yes' : 'No',
                    sandwichLeave ? "red" : "green"
                );
            },
        },
        {
            title: "Sandwich Button",
            dataIndex: appKeys.sandwichLeave,
            key: appKeys.sandwichLeave,
            width: 120,
            hidden: !isAdmin() || isReportPage,
            render: (_, record) => {
                return (
                    <Switch
                        loading={loadingLeaveId === record._id}
                        checked={record.sandwichLeave}
                        onChange={(checked) => handleLeaveStatusChange(record, checked)}
                    />
                );
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            hidden: isReportPage,
            render: (_, record) => {
                return (
                    <>
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            {
                                isAdmin() ? <div
                                    style={{marginRight: 25, cursor: "pointer"}}
                                    onClick={() => {
                                        setIsLeaveStatusChange(true);
                                        handleEditClick(record)
                                    }}
                                >
                                    <Tooltip title={appString.changeStatus}>
                                        <ToggleRight className="successIconStyle"/>
                                    </Tooltip>
                                </div> : null
                            }
                            {
                                isAdmin() ? <div
                                    style={{marginRight: 25, cursor: "pointer"}}
                                    onClick={() => handleEditClick(record)}
                                >
                                    <Tooltip title={appString.edit}>
                                        <Edit className="commonIconStyle"/>
                                    </Tooltip>
                                </div> : record.status === leaveLabelKeys.pending ? <div
                                    style={{marginRight: 25, cursor: "pointer"}}
                                    onClick={() => handleEditClick(record)}
                                >
                                    <Tooltip title={appString.edit}>
                                        <Edit className="commonIconStyle"/>
                                    </Tooltip>
                                </div> : null
                            }
                            {
                                isAdmin() ? <Popconfirm
                                    title={appString.deleteConfirmation}
                                    onConfirm={() => handleDeleteLeaveApi(record)}
                                    style={{margin: "0"}}
                                >
                                    <div style={{marginRight: 25, cursor: "pointer"}}>
                                        <Tooltip title={appString.delete} placement="bottom">
                                            <Trash2 className="deleteIconStyle"/>
                                        </Tooltip>
                                    </div>
                                </Popconfirm> : null
                            }
                        </div>
                    </>
                );
            },
        },
    ];

    const extraFieldCommon = (title, value) => {
        return value && true ? <div className="extraFieldRow">
            <div className="extraFieldRowTitle">{title}:</div>
            <div className="extraFieldRowValue">{value}</div>
        </div> : null;
    }

    const tableExpandRows = (record) => {
        return (
            <div>
                {extraFieldCommon(appString.createdAt, dayjs(record.createdAt).format("DD, MMM YYYY [at] hh:mm a"))}
                {extraFieldCommon(appString.leaveType, record.leaveType ? getLabelByKey(record.leaveType, leaveTypeLabel) : null)}
                {extraFieldCommon(appString.dayType, record.dayType ? getLabelByKey(record.dayType, dayTypeLabel) : null)}
                {extraFieldCommon(appString.leaveHalfDayType, record.leaveHalfDayType ? getLabelByKey(record.leaveHalfDayType, leaveHalfDayTypeLabel) : null)}
                {extraFieldCommon(appString.startTime, record.startTime)}
                {extraFieldCommon(appString.endTime, record.endTime)}
                {extraFieldCommon(appString.reason, record.reason)}
                {extraFieldCommon(appString.rejectedReason, record.rejectedReason)}
            </div>
        );
    }

    const commonGridBox = ({title, value, color, icon}) => {
        return (
            <Col xs={12} sm={12} md={8} lg={4}>
                <div className="dashGridBox">
                    <div className="dashGridBoxIconRow">
                        <div className="dashGridBoxIcon" style={{backgroundColor: color}}>
                            {icon}
                        </div>
                        <div className="dashGridBoxValue" style={{color: color}}>{value}</div>
                    </div>
                    <div className="dashGridBoxTitle">{title}</div>
                </div>
            </Col>
        );
    }

    return (
        <>
            <div>
                {
                    isReportPage ?
                        <div style={{margin: "15px 5px"}}>
                            <Row gutter={[16, 16]}>
                                {commonGridBox({
                                    title: "Leave Time",
                                    value: `${leaveRecordCount?.totalLeaveHours || 0} h`,
                                    color: getDarkColor("A"),
                                    icon: <Clock className="gridBoxIcon"/>
                                })}
                                {commonGridBox({
                                    title: "Total Leave",
                                    value: leaveRecordCount?.totalLeave || 0,
                                    color: getDarkColor("V"),
                                    icon: <FileMinus className="gridBoxIcon"/>
                                })}
                                {commonGridBox({
                                    title: "Unexpected",
                                    value: leaveRecordCount?.unexpectedLeave || 0,
                                    color: getDarkColor("C"),
                                    icon: <PieChart className="gridBoxIcon"/>
                                })}
                                {commonGridBox({
                                    title: "Total Unexpected",
                                    value: 0,
                                    color: getDarkColor("D"),
                                    icon: <PenTool className="gridBoxIcon"/>
                                })}
                                {commonGridBox({
                                    title: "Paid Leave",
                                    value: leaveRecordCount?.totalPaidLeave || 0,
                                    color: getDarkColor("E"),
                                    icon: <Box className="gridBoxIcon"/>
                                })}
                                {commonGridBox({
                                    title: "Sandwich",
                                    value: leaveRecordCount?.sandwichLeaves || 0,
                                    color: getDarkColor("F"),
                                    icon: <Map className="gridBoxIcon"/>
                                })}
                            </Row>
                        </div>
                        : null
                }
                <div className="listContainer">
                    <div style={{margin: "15px 5px"}}>
                        <Row gutter={[16, 16]}>
                            <Col xs={24} sm={12} md={8} lg={5}>
                                <SearchTextField
                                    field={{
                                        name: "search",
                                        placeholder: "Search Salary Report",
                                        prefix: <Search/>,
                                        style: {margin: 0, width: "100%", height: "38px"},
                                        onChange: (e) => {
                                            const searchText = e.target.value.toLowerCase();
                                            const filteredData = leaveFullRecord?.filter((record) => {
                                                return (
                                                    record.user?.fullName.toLowerCase().includes(searchText) ||
                                                    record.leaveType?.toLowerCase().includes(searchText) ||
                                                    record.leaveCategory?.toLowerCase().includes(searchText) ||
                                                    record.reason?.toLowerCase().includes(searchText) ||
                                                    record.rejectedReason?.toLowerCase().includes(searchText)
                                                );
                                            });
                                            handleDataConditionWise(filteredData, true);
                                        },
                                    }}
                                />
                            </Col>
                            {isAdmin() ? <Col xs={24} sm={12} md={8} lg={4}>
                                <Select
                                    placeholder="Select User"
                                    allowClear
                                    style={{width: "100%", height: '40px'}}
                                    showSearch
                                    onChange={(key) => {
                                        setFilters(prev => ({...prev, user: key}));
                                    }}
                                    filterOption={(input, option) =>
                                        option?.label?.toLowerCase().includes(input.toLowerCase())
                                    }
                                >
                                    {activeUsersData.map(employee => (
                                        <Option key={employee.userId} value={employee.userId}
                                                label={employee.fullName}>
                                            <div
                                                style={{display: "flex", alignItems: "center", gap: "10px"}}
                                            >
                                                <Avatar
                                                    src={employee.profilePhoto || imagePaths.profile_placeholder}
                                                    size="small"/>
                                                {employee.fullName}
                                            </div>
                                        </Option>))}
                                </Select>
                            </Col> : null}
                            <Col xs={12} sm={6} md={8} lg={4}>
                                <Select
                                    size="small"
                                    allowClear
                                    placeholder="Leave Category"
                                    style={{width: "100%", height: "40px", borderRadius: 10}}
                                    onChange={(value) => {
                                        setFilters(prev => ({...prev, leaveCategory: value}));
                                    }}
                                >
                                    {leaveCategoryNewLabel.map((item) => (
                                        <Option key={item.value} value={item.value}>
                                            <div>{item.label}</div>
                                        </Option>
                                    ))}
                                </Select>
                            </Col>
                            <Col xs={12} sm={6} md={10} lg={4}>
                                <DatePicker allowClear={false} defaultValue={dayjs(`${defaultYear}`, 'YYYY')}
                                            onChange={(date, dateString) => {
                                                setFilters(prev => ({...prev, year: date ? date.year() : null}));
                                            }} picker="year" style={{width: "100%", height: "40px"}}/>
                            </Col>
                            <Col xs={12} sm={6} md={10} lg={4}>
                                <DatePicker allowClear={false} defaultValue={defaultMonthDayjs} onChange={(date, dateString) => {
                                    setFilters(prev => ({...prev, month: date ? date.month() + 1 : null}));
                                }} picker="month" format="MMMM" style={{width: "100%", height: "40px"}}/>
                            </Col>
                            {!isReportPage ? <Col xs={12} sm={6} md={4} lg={3}>
                                <Button onClick={handleLeaveAddClick} type="primary" style={{width: "100%", height: "40px", borderRadius: 10}}>
                                    Add Leave
                                </Button>
                            </Col> : null}
                        </Row>
                    </div>
                    <Table
                        rowKey={(record) => record._id}
                        columns={leaveTableColumn}
                        expandable={{
                            expandedRowRender: record => (
                                tableExpandRows(record)
                            ),
                        }}
                        dataSource={[...leaveRecord]}
                        scroll={{x: "max-content"}}
                        loading={isLoading}
                    />
                </div>
                <div className="listContainer" style={{marginTop: "15px"}}>
                    <div className="taskBoardHeader">
                        <div className="taskheaderTitle">Unexpected Leaves</div>
                    </div>
                    <Table
                        rowKey={(record) => record._id}
                        columns={leaveTableColumn}
                        expandable={{
                            expandedRowRender: record => (
                                tableExpandRows(record)
                            ),
                        }}
                        dataSource={[...unexpectedLeaveRecord]}
                        scroll={{x: "max-content"}}
                        loading={isLoading}
                    />
                </div>
            </div>
            {isAddLeaveModelOpen && (
                <LeaveAddUpdateModel
                    isModelOpen={isAddLeaveModelOpen}
                    setIsModelOpen={setAddLeaveModelOpen}
                    employeeList={activeUsersData}
                    leaveData={selectedLeaveRecord}
                    isEditing={isLeaveEditing}
                    isLeaveStatusChange={isLeaveStatusChange}
                    setIsEditing={setIsLeaveEditing}
                    setIsLeaveStatusChange={setIsLeaveStatusChange}
                    onSuccessCallback={(data) => {
                        handleDataConditionWise(data.data, false);
                    }}
                />
            )}
        </>
    );
};

const Counter = ({ finalNumber }) => {
    const [count, setCount] = useState(0);
    const duration = 4000; // 4 seconds
    const speed = 20; // speed of update in ms

    useEffect(() => {
        let startTime = Date.now();
        const interval = setInterval(() => {
            const elapsed = Date.now() - startTime;

            // calculate a fake fast-increasing number
            const progress = elapsed / duration;
            const randomFactor = 1 + Math.random(); // random speed effect
            const displayNumber = Math.min(
                Math.floor(progress * finalNumber * randomFactor),
                finalNumber
            );
            setCount(displayNumber);

            // Stop after duration
            if (elapsed >= duration) {
                clearInterval(interval);
                setCount(finalNumber);
            }
        }, speed);

        return () => clearInterval(interval);
    }, [finalNumber]);

    return (
        <div style={{ fontSize: '32px', fontWeight: 'bold' }}>
            {count}
        </div>
    );
};

export default LeavePage;