import React, {useEffect, useState} from "react";
import {
    Search,
    Edit, Trash2, FilePlus
} from "react-feather";
import {
    Col,
    Popconfirm,
    Switch,
    Table,
    Tooltip
} from "antd";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {
    getIconByKey,
    getLabelByKey,
    projectTypeLabel,
    taskColumnStatusLabel,
    taskPriorityLabel,
} from "../../utils/enum";
import dayjs from "dayjs";
import {
    deleteProjectApi,
} from "../../api/apiUtils";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {endpoints} from "../../api/apiEndpoints";
import ProjectAddUpdateModel from "../../model/ProjectAddUpdateModel";
import {SearchTextFieldNew} from "../../components/formField/DynamicForm";
import {useIsMobileScreenView} from "../../components/CommonComponents";
import appString from "../../utils/appString";
import appKeys from "../../utils/appKeys";
import {isAdmin} from "../../utils/utils";
import Row from "../../components/common/Row";
import {AppDataFields, useAppData} from "../../AppDataContext";

const ProjectPage = () => {
    const isMobileView = useIsMobileScreenView();
    const {activeUsersData, activeClientData, projectsData, updateAppDataField} = useAppData();
    const [isAddProjectModelOpen, setAddProjectModelOpen] = useState(false);
    const [isProjectEditing, setIsProjectEditing] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [loadingProjectId, setLoadingProjectId] = useState(null);
    const [projectRecord, setProjectRecord] = useState([]);
    const [selectedProjectRecord, setSelectedProjectRecord] = useState({});

    useEffect(() => {
        setProjectRecord(projectsData);
    }, [projectsData]);

    const handleDataConditionWise = (data) => {
        updateAppDataField(AppDataFields.projectsData, data?.data);
    };

    const handleAddUpdateTaskApi = async (_id, data) => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: `${endpoints.updateProject}/${_id}`,
                data: data,
                setIsLoading: false,
                successCallback: (data) => {
                    handleDataConditionWise(data);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        } finally {
            setLoadingProjectId(null);
        }
    };

    const handleTaskAddClick = () => {
        setAddProjectModelOpen(true);
        setSelectedProjectRecord({});
    };

    const handleProjectStatusChange = (record, checked) => {
        const body = {
            isActive: checked,
            userId: getLocalData(loginDataKeys._id),
        };

        setLoadingProjectId(record._id);

        handleAddUpdateTaskApi(record._id, body);
    }

    const handleEditClick = (value) => {
        setIsProjectEditing(true);
        setSelectedProjectRecord(value);
        setAddProjectModelOpen(true);
    };

    const handleDeleteProjectApi = async (event) => {
        await deleteProjectApi({
            id: event._id,
            setIsLoading: setIsLoading,
            successCallback: (data) => {
                setAddProjectModelOpen(false);
                handleDataConditionWise(data);
            },
        });
    };

    const projectTableColumn = [
        {
            title: appString.projectName,
            dataIndex: appKeys.projectName,
            key: appKeys.projectName,
        },
        {
            title: appString.projectType,
            dataIndex: appKeys.projectType,
            key: appKeys.projectType,
            hidden: !isAdmin(),
            render: (projectType) => {
                if (!projectType) return "";
                return getLabelByKey(projectType, projectTypeLabel);
            },
        },
        {
            title: appString.projectStatus,
            dataIndex: appKeys.projectStatus,
            key: appKeys.projectStatus,
            hidden: !isAdmin(),
            render: (projectStatus) => {
                if (!projectStatus) return "";
                return getLabelByKey(projectStatus, taskColumnStatusLabel);
            },
        },
        {
            title: appString.projectPriority,
            dataIndex: appKeys.projectPriority,
            key: appKeys.projectPriority,
            hidden: !isAdmin(),
            render: (projectPriority) => {
                if (!projectPriority) return "";
                return (
                    <div style={{display: "flex", alignItems: "center"}}>
                        {getIconByKey(projectPriority, taskPriorityLabel)}
                        {getLabelByKey(projectPriority, taskPriorityLabel)}
                    </div>
                );
            },
        },
        {
            title: "Active",
            dataIndex: appKeys.isActive,
            key: appKeys.isActive,
            width: 120,
            hidden: !isAdmin(),
            render: (_, record) => {
                return (
                    <Switch
                        loading={loadingProjectId === record._id}
                        checked={record.isActive}
                        onChange={(checked) => handleProjectStatusChange(record, checked)}
                    />
                );
            },
        },
        {
            title: appString.createdAt,
            dataIndex: appKeys.createdAt,
            key: appKeys.createdAt,
            render: (createdAt) => {
                return dayjs(createdAt).format("DD, MMM YYYY [at] hh:mm a");
            },
        },
        {
            title: appString.action,
            dataIndex: appKeys.operation,
            fixed: "right",
            width: 50,
            render: (_, record) => {
                return <>
                    <div
                        style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    >
                        <div
                            style={{marginRight: 25, cursor: "pointer"}}
                            onClick={() => handleEditClick(record)}
                        >
                            <Tooltip title={appString.edit}>
                                <Edit className="commonIconStyle"/>
                            </Tooltip>
                        </div>
                        <Popconfirm
                            title={appString.deleteConfirmation}
                            onConfirm={() => handleDeleteProjectApi(record)}
                            style={{margin: "0"}}
                        >
                            <div style={{marginRight: 25, cursor: "pointer"}}>
                                <Tooltip title={appString.delete} placement="bottom">
                                    <Trash2 className="deleteIconStyle"/>
                                </Tooltip>
                            </div>
                        </Popconfirm>
                    </div>
                </>;
            },
        },
    ];

    return (
        <>
            <div className="taskBoardContainer">
                <Row gutter={[16, 16]} style={{display: "flex", justifyContent: "space-between", margin: "15px 0px", gap: "10px"}}>
                    <Col xs={20} sm={20} md={15} lg={8}>
                        <SearchTextFieldNew
                            field={{
                                name: "search",
                                placeholder: "Search Data",
                                prefix: <Search />,
                                onChange: (e) => {
                                    const searchText = e.target.value.toLowerCase();
                                    const filteredData = projectsData?.filter((record) => {
                                        return (
                                            record.projectId?.toLowerCase().includes(searchText) ||
                                            record.projectName?.toLowerCase().includes(searchText) ||
                                            record.projectDescription?.toLowerCase().includes(searchText) ||
                                            record.clientName?.toLowerCase().includes(searchText) ||
                                            record.projectType?.toLowerCase().includes(searchText) ||
                                            record.tags?.toLowerCase().includes(searchText)
                                        );
                                    });
                                    setProjectRecord(filteredData);
                                },
                            }}
                        />
                    </Col>
                    <Col xs={4} sm={4} md={6} lg={5} xl={4} xxl={3}>
                        <div className="addUpdateCommonBtn" onClick={handleTaskAddClick}>
                            <FilePlus />
                            {!isMobileView ? <div>Add Project</div> : null}
                        </div>
                    </Col>
                </Row>
                <Table
                    columns={projectTableColumn}
                    dataSource={[...projectRecord]}
                    scroll={{x: "max-content"}}
                    loading={isLoading}
                />
            </div>
            {isAddProjectModelOpen && (
                <ProjectAddUpdateModel
                    isModelOpen={isAddProjectModelOpen}
                    setIsModelOpen={setAddProjectModelOpen}
                    employeeList={activeUsersData}
                    clientData={activeClientData}
                    projectData={selectedProjectRecord}
                    isEditing={isProjectEditing}
                    setIsEditing={setIsProjectEditing}
                    onSuccessCallback={handleDataConditionWise}
                />
            )}
        </>
    );
};

export default ProjectPage;