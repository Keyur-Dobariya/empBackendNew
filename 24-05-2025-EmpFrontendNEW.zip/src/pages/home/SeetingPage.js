import React, {useEffect, useState} from "react";
import {Button, Col, Form, Input, Row, Space, Switch, TimePicker} from "antd";
import {endpoints} from "../../api/apiEndpoints";
import apiCall, {HttpMethod} from "../../api/apiServiceProvider";
import {useLoading} from "../..";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";

import appKeys from "../../utils/appKeys";
import {getLocalData, loginDataKeys} from "../../dataStorage/DataPref";
import {InputType} from "../../components/common/AppTextFormField";
import appString from "../../utils/appString";
import {convertCamelCase} from "../../components/CommonComponents";
import {AppDataFields, useAppData} from "../../AppDataContext";

dayjs.extend(customParseFormat);

export default function SettingPage() {
    const {settings, updateAppDataField} = useAppData();
    const [settingData, setSettingData] = useState(settings);
    const {setIsLoading} = useLoading();

    useEffect(() => {
        setSettingData(settings);
    }, [settings]);

    const updateAppSetting = async () => {
        try {
            await apiCall({
                method: HttpMethod.POST,
                url: endpoints.updateSetting,
                data: settingData,
                setIsLoading: setIsLoading,
                successCallback: (data) => {
                    const responseData = data?.data;
                    updateAppDataField(AppDataFields.settings, responseData);
                },
            });
        } catch (error) {
            console.error("API Call Failed:", error);
        }
    };

    const handleSettingsFieldsChange = (field, value) => {
        setSettingData((prevData) => ({
            ...prevData,
            appSettings: {
                ...prevData.appSettings,
                [field]: value,
            },
        }));
    };

    const handleMonthlyTotalHoursChange = (field, value) => {
        setSettingData((prevData) => ({
            ...prevData,
            monthlyTotalHours: {
                ...prevData.monthlyTotalHours,
                [field]: value,
            },
        }));
    };

    useEffect(() => {
    }, [settingData]);

    const months = {
        january: "january",
        february: "february",
        march: "march",
        april: "april",
        may: "may",
        june: "june",
        july: "july",
        august: "august",
        september: "september",
        october: "october",
        november: "november",
        december: "december",
    };

    return (
        <>
            <div>
                <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "15px"}}>
                    <div style={{fontSize: "16px", fontWeight: "600", color: "black"}}>App Setting</div>
                    <Button type="primary" onClick={updateAppSetting}>Update Settings</Button>
                </div>
                <div className="settingPage">
                    <div className="settingGridBox">
                        <div className="settingPageTitle">Admin Settings</div>
                        <Row gutter={[16, 16]}>
                            <Col xs={24} sm={12} md={8} lg={6}>
                                <div>
                                    <div className="seetingLabel">{appString.adminEmail}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode="email"
                                        value={settingData[appKeys.appSettings]?.adminEmail}
                                        placeholder="Email Address"
                                        onInput={(e) => {
                                            handleSettingsFieldsChange(appKeys.adminEmail, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                        </Row>
                    </div>
                    <div className="settingGridBox">
                        <div className="settingPageTitle">Office Time Settings</div>
                        <Row gutter={[16, 16]}>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{appString.officeStartTime}</div>
                                    <TimePicker
                                        className="settingPageField"
                                        use12Hours
                                        value={settingData[appKeys.appSettings]?.officeStartTime ? dayjs(settingData[appKeys.appSettings]?.officeStartTime, "h:mm a") : null}
                                        title="Select Office Start Time"
                                        format="h:mm a"
                                        onChange={(time, timeString) =>
                                            handleSettingsFieldsChange(appKeys.officeStartTime, timeString)
                                        }
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{appString.officeEndTime}</div>
                                    <TimePicker
                                        className="settingPageField"
                                        use12Hours
                                        value={settingData[appKeys.appSettings]?.officeEndTime ? dayjs(settingData[appKeys.appSettings]?.officeEndTime, "h:mm a") : null}
                                        title="Select Office End Time"
                                        format="h:mm a"
                                        onChange={(time, timeString) =>
                                            handleSettingsFieldsChange(appKeys.officeEndTime, timeString)
                                        }
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{appString.breakDuration}</div>
                                    <Input
                                        className="settingPageField"
                                        maxLength={3}
                                        inputMode="numeric"
                                        value={settingData[appKeys.appSettings]?.breakDuration}
                                        placeholder="Break Duration"
                                        onInput={(e) => {
                                            let value = e.target.value.replace(/[^\d]/g, "");
                                            e.target.value = value;
                                            handleSettingsFieldsChange(appKeys.breakDuration, value);
                                        }}
                                    />
                                </div>
                            </Col>
                        </Row>
                    </div>
                    <div className="settingGridBox">
                        <div className="settingPageTitle">Screenshot Settings</div>
                        <Row gutter={[16, 16]}>
                            <Col xs={24} sm={12} md={8} lg={6}>
                                <div>
                                    <div className="seetingLabel">{appString.screenshotTime}</div>
                                    <Input
                                        className="settingPageField"
                                        maxLength={3}
                                        inputMode="numeric"
                                        placeholder="Screenshot Capture Time"
                                        value={settingData[appKeys.appSettings]?.screenshotTime}
                                        onInput={(e) => {
                                            let value = e.target.value.replace(/[^\d]/g, "");
                                            e.target.value = value;
                                            handleSettingsFieldsChange(appKeys.screenshotTime, value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={24} sm={12} md={8} lg={6}>
                                <div>
                                    <div className="seetingLabel">{appString.isTakeScreenShot}</div>
                                    <Switch
                                        loading={false}
                                        checked={settingData[appKeys.appSettings]?.isTakeScreenShot}
                                        onChange={(checked) => {
                                            handleSettingsFieldsChange(appKeys.isTakeScreenShot, checked);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={24} sm={12} md={8} lg={6}>
                                <div>
                                    <div className="seetingLabel">{appString.showScreenShot}</div>
                                    <Switch
                                        loading={false}
                                        checked={settingData[appKeys.appSettings]?.showScreenShot}
                                        onChange={(checked) => {
                                            handleSettingsFieldsChange(appKeys.showScreenShot, checked);
                                        }}
                                    />
                                </div>
                            </Col>
                        </Row>
                    </div>
                    <div className="settingGridBox">
                        <div className="settingPageTitle">Leave Settings</div>
                        <Row gutter={[16, 16]}>
                            <Col xs={24} sm={12} md={8} lg={6}>
                                <div>
                                    <div className="seetingLabel">{appString.yearlyPaidLeave}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode="email"
                                        value={settingData[appKeys.appSettings]?.yearlyPaidLeave}
                                        placeholder="Yearly Paid Leave"
                                        onInput={(e) => {
                                            handleSettingsFieldsChange(appKeys.yearlyPaidLeave, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={24} sm={12} md={8} lg={6}>
                                <div>
                                    <div className="seetingLabel">{appString.monthlyMaxPaidLeave}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode="email"
                                        value={settingData[appKeys.appSettings]?.monthlyMaxPaidLeave}
                                        placeholder="Monthly Paid Leave"
                                        onInput={(e) => {
                                            handleSettingsFieldsChange(appKeys.monthlyMaxPaidLeave, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                        </Row>
                    </div>
                    <div className="settingGridBox">
                        <div className="settingPageTitle">Monthly Total Hours</div>
                        <Row gutter={[16, 16]}>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.january)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode="numeric"
                                        value={settingData[appKeys.monthlyTotalHours]?.january || ''}
                                        placeholder={`${convertCamelCase(months.january)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.january, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.february)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.february}
                                        placeholder={`${convertCamelCase(months.february)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.february, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.march)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.march}
                                        placeholder={`${convertCamelCase(months.march)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.march, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.april)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.april}
                                        placeholder={`${convertCamelCase(months.april)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.april, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.may)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.may}
                                        placeholder={`${convertCamelCase(months.may)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.may, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.june)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.june}
                                        placeholder={`${convertCamelCase(months.june)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.june, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.july)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.july}
                                        placeholder={`${convertCamelCase(months.july)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.july, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.august)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.august}
                                        placeholder={`${convertCamelCase(months.august)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.august, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.september)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.september}
                                        placeholder={`${convertCamelCase(months.september)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.september, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.october)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.october}
                                        placeholder={`${convertCamelCase(months.october)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.october, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.november)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.november}
                                        placeholder={`${convertCamelCase(months.november)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.november, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={6} lg={4}>
                                <div>
                                    <div className="seetingLabel">{convertCamelCase(months.december)}</div>
                                    <Input
                                        className="settingPageField"
                                        inputMode={InputType.Number}
                                        value={settingData[appKeys.monthlyTotalHours]?.december}
                                        placeholder={`${convertCamelCase(months.december)} Hours`}
                                        onInput={(e) => {
                                            handleMonthlyTotalHoursChange(months.december, e.target.value);
                                        }}
                                    />
                                </div>
                            </Col>
                        </Row>
                    </div>
                </div>
            </div>
        </>
    );
}
