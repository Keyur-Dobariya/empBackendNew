import React, { useState, useEffect } from "react";
import {Col, Table} from "antd";
import { Search, UserPlus } from "react-feather";
import {
  deleteUserApi,
  userApprovalUpdateApi,
} from "../../../api/apiUtils";
import { employeeTableColumn } from "../../../dataTable/employeeTableColumn";
import {
  useIsMobileScreenView,
} from "../../../components/CommonComponents";
import {SearchTextFieldNew} from "../../../components/formField/DynamicForm";
import AddUpdateEmpModel from "../../../model/AddUpdateEmpModel";
import { ApprovalStatus } from "../../../utils/enum";
import appColor from "../../../utils/appColors";
import AppText from "../../../components/common/AppText";
import { useNavigate } from "react-router-dom";
import EmpDetailModel from "../../../model/EmpDetailModel";
import Row from "../../../components/common/Row";
import routes from "../../../common/routes";
import {AppDataFields, useAppData} from "../../../AppDataContext";

export default function EmployeeListContent({
  isInDashboard = false,
  formTitle = "",
  empData,
}) {
  const isMobileView = useIsMobileScreenView();

  const [isLoading, setIsLoading] = useState(false);
  const [employeeData, setEmployeesData] = useState([]);
  const [allEmployeeData, setAllEmployeesData] = useState(empData || []);
  const [isEditing, setIsEditing] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState(null);

  const navigate = useNavigate();

  const {usersData, updateAppDataField} = useAppData();

  useEffect(() => {
    const filteredEmployees = usersData ? usersData.filter(
        (record) =>
            record.approvalStatus === ApprovalStatus.Approved
    ) : [];
    setEmployeesData(filteredEmployees);
    setAllEmployeesData([...filteredEmployees]);
  }, [usersData]);

  useEffect(() => {
    if (empData) {
      setEmployeesData(empData);
      setAllEmployeesData(empData?.reverse());
    }
  }, [empData]);

  const showEditModal = async () => {
    setIsEditing(false);
    setIsEditModalOpen(true);
  };

  const handleEditClick = (value) => {
    setIsEditing(true);
    setEditingRecord(value);
    setIsEditModalOpen(true);
  };

  const handleDeleteUserApi = async (event) => {
    await deleteUserApi({
      id: event._id,
      setIsLoading: setIsLoading,
      successCallback: (data) => {
        setIsEditModalOpen(false);
        updateAppDataField(AppDataFields.usersData, data?.data);
      },
    });
  };

  const handleApproveUserApi = async (event) => {
    await userApprovalUpdateApi({
      id: event._id,
      data: {
        approvalStatus: ApprovalStatus.Approved,
      },
      setIsLoading: setIsLoading,
      successCallback: (data) => {
        updateAppDataField(AppDataFields.usersData, data?.data);
      },
    });
  };

  const handleRejectUserApi = async (event) => {
    await userApprovalUpdateApi({
      id: event._id,
      data: {
        approvalStatus: ApprovalStatus.Rejected,
      },
      setIsLoading: setIsLoading,
      successCallback: (data) => {
        updateAppDataField(AppDataFields.usersData, data?.data);
      },
    });
  };

  const handleUserStatusChange = async (event, checked) => {
    await userApprovalUpdateApi({
      id: event._id,
      data: {
        isActive: checked,
      },
      setIsLoading: setIsLoading,
      successCallback: (data) => {
        updateAppDataField(AppDataFields.usersData, data?.data);
      },
    });
  };


  const handleViewClick = async (event) => {
    setEditingRecord(event);
    navigate(routes.employeeDetails, { state: { employeeDetails: event } });
  };

  const columns = employeeTableColumn({
    employeeData: employeeData,
    handleEditClick: handleEditClick,
    handleDeleteClick: handleDeleteUserApi,
    handleApproveClick: handleApproveUserApi,
    handleRejectClick: handleRejectUserApi,
    handleUserStatusChange: handleUserStatusChange,
    handleViewClick: handleViewClick,
  });

  return (
    <>
      <div className="listBox" style={{ overflowX: "auto" }}>
        {!isInDashboard ? (
            <Row gutter={[16, 16]} style={{display: "flex", justifyContent: "space-between", margin: "15px 0px", gap: "10px"}}>
              <Col xs={20} sm={20} md={15} lg={8}>
                <SearchTextFieldNew
                    field={{
                      name: "search",
                      placeholder: "Search Data",
                      prefix: <Search />,
                      onChange: (e) => {
                        const searchText = e.target.value.toLowerCase();
                        const filteredData = allEmployeeData?.filter((record) => {
                          return (
                              record.employeeCode?.toLowerCase().includes(searchText) ||
                              record.fullName?.toLowerCase().includes(searchText) ||
                              record.emailAddress?.toLowerCase().includes(searchText) ||
                              record.mobileNumber?.toLowerCase().includes(searchText) ||
                              record.role?.toLowerCase().includes(searchText) ||
                              record.gender?.toLowerCase().includes(searchText) ||
                              record.approvalStatus?.toLowerCase().includes(searchText)
                          );
                        });
                        setEmployeesData(filteredData);
                      },
                    }}
                />
              </Col>
              <Col xs={4} sm={4} md={6} lg={5} xl={4} xxl={3}>
                <div className="addUpdateCommonBtn" onClick={showEditModal}>
                  <UserPlus />
                  {!isMobileView ? <div>Add Employee</div> : null}
                </div>
              </Col>
            </Row>
        ) : null}
        {isInDashboard ? (
          <AppText
            text={formTitle}
            fontSize="17px"
            fontWeight={550}
            color={appColor.primary}
            style={{ margin: "15px 0px 20px 10px" }}
          />
        ) : null}
        <div>
          <Table
            columns={columns}
            dataSource={[...employeeData]}
            scroll={{ x: "max-content" }}
            pagination={false}
            loading={isLoading}
          />
        </div>
      </div>
      {isEditModalOpen ? (
        <AddUpdateEmpModel
          isModelOpen={isEditModalOpen}
          setIsModelOpen={setIsEditModalOpen}
          employeeData={editingRecord}
          isEditing={isEditing}
          onSuccessCallback={(data) => {
            updateAppDataField(AppDataFields.usersData, data?.data);
          }}
          isModel={true}
        />
      ) : null}
      {isDetailModalOpen ? (
        <EmpDetailModel
          isModelOpen={isDetailModalOpen}
          setIsModelOpen={setIsDetailModalOpen}
          employeeData={editingRecord}
        />
      ) : null}
    </>
  );
}
