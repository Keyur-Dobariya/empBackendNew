package Contactbackup.import_export.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.view.Window;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.NativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityBackupBinding;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import Contactbackup.PrefManager;

public class BackUpActivity extends AppCompatActivity {
    Context context;
    int count;
    Cursor cursor;
    Cursor cursor2;
    int f45p = 1;
    PrefManager prefManager;
    String storage_path;
    ArrayList<String> vCard;
    String vfile;
    ProgressDialog progress;

    ActivityBackupBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.clearFlags(67108864);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
            StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        }
        binding = ActivityBackupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();
//        *********native*************************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);
        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(BackUpActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        this.context = this;
        this.prefManager = new PrefManager(this);
        cursor2 = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, "in_visible_group=1", null, null, null);
        if (cursor2.getCount() <= 0) {
            binding.txtcontact.setText("NO CONTACTS");
        }
        count = this.cursor2.getCount();
        binding.txtcontactcount.setText("" + this.count);
        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        binding.libackup.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("StaticFieldLeak")
            public void onClick(View view) {
                new AsyncTask<Integer, Integer, String>() {
                    public void onProgressUpdate(Integer... numArr) {
                    }

                    public String doInBackground(Integer... numArr) {
                        try {
                            @SuppressLint("StaticFieldLeak")
                            File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + getString(R.string.restore_folder_path_Contact));
                            if (!file.exists()) {
                                file.mkdir();
                            }
                            Date date = new Date();
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyy_HHmmss", Locale.getDefault());
                            simpleDateFormat.setTimeZone(TimeZone.getDefault());
                            String format = simpleDateFormat.format(date);
                            vfile = getResources().getString(R.string.file_name) + "_" + format + ".vcf";
                            vCard = new ArrayList<>();
                            cursor = getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, "in_visible_group=1", null, null, null);
                            if (cursor == null || cursor.getCount() <= 0) {
                                return "Executed";
                            }
                            storage_path = file.getAbsolutePath() + File.separator + vfile;
                            FileOutputStream fileOutputStream = new FileOutputStream(storage_path, false);
                            cursor.moveToFirst();
                            int count = cursor.getCount() / 90;
                            int i = 0;
                            while (i < cursor.getCount()) {
                                get(cursor);
                                StringBuilder sb = new StringBuilder();
                                sb.append("Contact ");
                                int i2 = i + 1;
                                sb.append(i2);
                                sb.append("VcF String is");
                                sb.append(vCard.get(i));
                                Log.d("TAG", sb.toString());
                                if (i == f45p * count) {
                                    if (f45p != 101) {
                                        publishProgress(Integer.valueOf(f45p));
                                        f45p++;
                                    }
                                }
                                cursor.moveToNext();
                                fileOutputStream.write(vCard.get(i).toString().getBytes());
                                i = i2;
                            }
                            fileOutputStream.close();
                            cursor.close();
                            return "Executed";
                        } catch (Exception e) {
                            e.printStackTrace();
                            return "Executed";
                        }
                    }

                    public void onPostExecute(String str) {
                        progress.dismiss();
                        startActivitys(new Intent(BackUpActivity.this, ImportContactActivity.class));
                        finish();
                    }

                    public void onPreExecute() {
                        progress = new ProgressDialog(BackUpActivity.this);
                        progress.setMessage("Loading.... ");
                        progress.setProgressStyle(0);
                        progress.setIndeterminate(true);
                        progress.setProgress(0);
                        progress.show();
                    }

                    private void get(Cursor cursor) {
                        Uri withAppendedPath = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, cursor.getString(cursor.getColumnIndex("lookup")));
                        Log.e("uri", "" + withAppendedPath.toString());
                        try {
                            FileInputStream createInputStream = getContentResolver().openAssetFileDescriptor(withAppendedPath, "r").createInputStream();
                            byte[] bArr = new byte[createInputStream.available()];
                            createInputStream.read(bArr);
                            String str = new String(bArr);
                            Log.e("vcardstring", "" + str);
                            vCard.add(str);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.execute(new Integer[0]);
            }
        });
    }



    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(BackUpActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}