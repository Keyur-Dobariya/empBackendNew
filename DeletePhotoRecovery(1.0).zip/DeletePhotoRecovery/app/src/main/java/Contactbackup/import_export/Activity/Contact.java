package Contactbackup.import_export.Activity;

import java.util.HashMap;

public class Contact {
    HashMap<Integer, Address> addresses;
    String displayName = "";
    HashMap<Integer, String> emails;
    String id = "";
    HashMap<Integer, String> im;
    boolean isSelected = false;
    String lookup_key;
    HashMap<Integer, String> phones;

    public static class Address {
        private String city = "";
        private String country = "";
        private String neighborhood = "";
        private String postBox = "";
        private String postalCode = "";
        private String state = "";
        private String street = "";

        Address() {
        }

        public String getPostBox() {
            return this.postBox;
        }

        public void setPostBox(String str) {
            this.postBox = str;
        }

        public String getStreet() {
            return this.street;
        }

        public void setStreet(String str) {
            this.street = str;
        }

        public String getCity() {
            return this.city;
        }

        public void setCity(String str) {
            this.city = str;
        }

        public String getState() {
            return this.state;
        }

        public void setState(String str) {
            this.state = str;
        }

        public String getPostalCode() {
            return this.postalCode;
        }

        public void setPostalCode(String str) {
            this.postalCode = str;
        }

        public String getCountry() {
            return this.country;
        }

        public void setCountry(String str) {
            this.country = str;
        }

        public String getNeighborhood() {
            return this.neighborhood;
        }

        public void setNeighborhood(String str) {
            this.neighborhood = str;
        }

        public String toString() {
            return this.postBox + "," + this.street + "," + this.neighborhood + this.city + " " + this.state + " " + this.postalCode + this.country;
        }
    }

    public void setLookup_key(String str) {
        this.lookup_key = str;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public void setDisplayName(String str) {
        this.displayName = str;
    }

    public HashMap<Integer, String> getEmails() {
        return this.emails;
    }

    public void setEmails(HashMap<Integer, String> hashMap) {
        this.emails = hashMap;
    }

    public HashMap<Integer, String> getPhones() {
        return this.phones;
    }

    public void setPhones(HashMap<Integer, String> hashMap) {
        this.phones = hashMap;
    }

    public HashMap<Integer, Address> getAddresses() {
        return this.addresses;
    }

    public void setAddresses(HashMap<Integer, Address> hashMap) {
        this.addresses = hashMap;
    }

    public HashMap<Integer, String> getIm() {
        return this.im;
    }

    public void setIm(HashMap<Integer, String> hashMap) {
        this.im = hashMap;
    }

    public String toString() {
        return "Contact [id=" + this.id + "\n displayName=" + this.displayName + "\n dateOfBirth=\n dateOfAnniversary=\n nickName=\n note=\n image=\n emails=" + this.emails + "\n phones=" + this.phones + "\n addresses=" + this.addresses + "\n organizations=\n im=" + this.im + "]";
    }
}