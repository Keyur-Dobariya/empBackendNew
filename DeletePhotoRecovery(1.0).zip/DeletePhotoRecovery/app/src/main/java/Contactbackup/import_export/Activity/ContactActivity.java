package Contactbackup.import_export.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.NativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityContactBinding;

import Contactbackup.PrefManager;

public class ContactActivity extends AppCompatActivity implements View.OnClickListener {
    Activity activity;
    Context context;
    PrefManager prefManager;
    ActivityContactBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityContactBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

//        *****native*****************************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(ContactActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        this.activity = this;
        this.context = this;
        this.prefManager = new PrefManager(this);
        binding.btnBack.setOnClickListener(this);
        binding.libackup.setOnClickListener(this);
        binding.liexporttovcard.setOnClickListener(this);
        binding.liimportfromexcel.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()) {
            case R.id.btnBack:
                onBackPressed();
                break;
            case R.id.libackup:
                intent = new Intent(ContactActivity.this, BackUpActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivitys(intent);
                break;
            case R.id.liexporttovcard:
                intent = new Intent(ContactActivity.this, ExportContactActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivitys(intent);
                break;
            case R.id.liimportfromexcel:
                intent = new Intent(ContactActivity.this, ImportContactActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivitys(intent);
                break;
        }
    }


    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(ContactActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}