package Contactbackup.import_export.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityExportBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import Contactbackup.import_export.Adpater.ContactAdpater;
import Contactbackup.import_export.Pojo.ContactsPOJO;

public class ExportContactActivity extends AppCompatActivity implements View.OnClickListener {
    public static ArrayList<ContactsPOJO> allContacts;
    ArrayList<ContactsPOJO> SearchContacts;
    ContactAdpater contactAdpater;
    List<Contact> contactList;
    Context context;
    ContentResolver cr;
    ProgressDialog pd = null;
    public ArrayList<ContactsPOJO> selectcontact;

    public static ActivityExportBinding binding;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityExportBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getWindow().setSoftInputMode(3);
        binds();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(ExportContactActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        if (ContactAdpater.selected.size() != 0) {
                            ContactAdpater.selected.clear();
                        }
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void binds() {
        this.context = this;
        binding.btnBack.setOnClickListener(this);
        binding.liexportdone.setOnClickListener(this);
        binding.removeall.setOnClickListener(this);
        binding.checkall.setOnClickListener(this);
        binding.etsearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                Log.e("charSequence", "onTextChanged____4: ");
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                charSequence.toString();
                if (charSequence.length() == 0) {
                    getWindow().setSoftInputMode(3);
                    binding.recycontactlist.setVisibility(View.VISIBLE);
                    binding.emptytext.setVisibility(View.GONE);
                    contactAdpater = new ContactAdpater(getApplicationContext(), allContacts);
                    binding.recycontactlist.setAdapter(contactAdpater);
                    binding.recycontactlist.setLayoutManager(new LinearLayoutManager(ExportContactActivity.this));
                    return;
                }
                contactAdpater.getFilter().filter(charSequence);
            }

            public void afterTextChanged(Editable editable) {
                Log.e("charSequence", "onTextChanged____3: ");
            }
        });
        new getcontact_list().execute(new Void[0]);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnBack:
                onBackPressed();
                break;
            case R.id.checkall:
                binding.checkall.setVisibility(View.GONE);
                binding.removeall.setVisibility(View.VISIBLE);
                contactAdpater.getSelect_remove(false);
                break;
            case R.id.removeall:
                binding.checkall.setVisibility(View.VISIBLE);
                binding.removeall.setVisibility(View.GONE);
                contactAdpater.getSelect_remove(true);
                break;
            case R.id.liexportdone:
                selectcontact = ContactAdpater.selected;
                if (selectcontact.size() > 0) {
                    Intent intent = new Intent(ExportContactActivity.this, SelectedContactActivity.class);
                    intent.putExtra("from", "1");
                    startActivitys(intent);
                    return;
                }
                Toast makeText = Toast.makeText(ExportContactActivity.this, "select atleast one conatct", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
                break;
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();
        getWindow().setSoftInputMode(3);
        SearchContacts = new ArrayList<>();
        contactList = new ArrayList();
        if (selectcontact != null) {
            contactAdpater.notifyDataSetChanged();
        }
    }

    @SuppressLint("StaticFieldLeak")
    class getcontact_list extends AsyncTask<Void, Void, Void> {
        getcontact_list() {
        }

        public void onPreExecute() {
            pd = new ProgressDialog(ExportContactActivity.this);
            pd.setMessage("Please wait.... ");
            pd.setCancelable(false);
            pd.show();
            ExportContactActivity.allContacts = new ArrayList<>();
        }

        @SuppressLint("Range")
        public Void doInBackground(Void... voidArr) {
            Cursor cursor;
            int i;
            cr = getContentResolver();
            Cursor query = cr.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, "display_name");
            if (query.getCount() > 0) {
                while (query.moveToNext()) {
                    if (Integer.parseInt(query.getString(query.getColumnIndex("has_phone_number"))) > 0) {
                        Contact contact2 = new Contact();
                        String string = query.getString(query.getColumnIndex("_id"));
                        contact2.setId(string);
                        contact2.setLookup_key(query.getString(query.getColumnIndex("lookup")));
                        contact2.setDisplayName(query.getString(query.getColumnIndex("display_name")));
                        Cursor query2 = cr.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null, "contact_id = ?", new String[]{string}, null);
                        int columnIndex = query2.getColumnIndex("data1");
                        int columnIndex2 = query2.getColumnIndex("data2");
                        if (query2.getCount() > 0) {
                            HashMap<Integer, String> hashMap = new HashMap<>();
                            while (query2.moveToNext()) {
                                if (query2.getString(columnIndex) != null) {
                                    try {
                                        hashMap.put(Integer.valueOf(Integer.parseInt(query2.getString(columnIndex2))), query2.getString(columnIndex));
                                    } catch (Exception unused) {
                                    }
                                }
                            }
                            contact2.setEmails(hashMap);
                        }
                        query2.close();
                        Cursor query3 = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id = ?", new String[]{string}, null);
                        int columnIndex3 = query3.getColumnIndex("data1");
                        int columnIndex4 = query3.getColumnIndex("data2");
                        if (query3.getCount() > 0) {
                            HashMap<Integer, String> hashMap2 = new HashMap<>();
                            while (query3.moveToNext()) {
                                if (query3.getString(columnIndex3) != null) {
                                    try {
                                        hashMap2.put(Integer.valueOf(Integer.parseInt(query3.getString(columnIndex4))), query3.getString(columnIndex3));
                                    } catch (Exception unused2) {
                                    }
                                }
                            }
                            Log.e("doInBackground_phoneMap", "doInBackground: " + hashMap2);
                            contact2.setPhones(hashMap2);
                        }
                        query3.close();
                        Cursor query4 = cr.query(ContactsContract.Data.CONTENT_URI, null, "contact_id = ? AND mimetype = ?", new String[]{string, "vnd.android.cursor.item/postal-address_v2"}, null);
                        int columnIndex5 = query4.getColumnIndex("data2");
                        int columnIndex6 = query4.getColumnIndex("data4");
                        int columnIndex7 = query4.getColumnIndex("data5");
                        int columnIndex8 = query4.getColumnIndex("data6");
                        int columnIndex9 = query4.getColumnIndex("data7");
                        int columnIndex10 = query4.getColumnIndex("data8");
                        int columnIndex11 = query4.getColumnIndex("data9");
                        int columnIndex12 = query4.getColumnIndex("data10");
                        if (query4.getCount() >= 0) {
                            HashMap<Integer, Contact.Address> hashMap3 = new HashMap<>();
                            while (query4.moveToNext()) {
                                Contact.Address address = new Contact.Address();
                                String string2 = query4.getString(columnIndex5);
                                if (query4.getString(columnIndex6) != null) {
                                    i = columnIndex5;
                                    address.setStreet(query4.getString(columnIndex6));
                                } else {
                                    i = columnIndex5;
                                }
                                if (query4.getString(columnIndex8) != null) {
                                    address.setNeighborhood(query4.getString(columnIndex8));
                                }
                                if (query4.getString(columnIndex11) != null) {
                                    address.setPostalCode(query4.getString(columnIndex11));
                                }
                                if (query4.getString(columnIndex7) != null) {
                                    address.setPostBox(query4.getString(columnIndex7));
                                }
                                if (query4.getString(columnIndex9) != null) {
                                    address.setCity(query4.getString(columnIndex9));
                                }
                                if (query4.getString(columnIndex10) != null) {
                                    address.setState(query4.getString(columnIndex10));
                                }
                                if (query4.getString(columnIndex12) != null) {
                                    address.setCountry(query4.getString(columnIndex12));
                                }
                                hashMap3.put(Integer.valueOf(Integer.parseInt(string2)), address);
                                query = query;
                                columnIndex5 = i;
                            }
                            cursor = query;
                            contact2.setAddresses(hashMap3);
                        } else {
                            cursor = query;
                        }
                        query4.close();
                        Cursor query5 = cr.query(ContactsContract.Data.CONTENT_URI, null, "contact_id = ? AND mimetype = ?", new String[]{string, "vnd.android.cursor.item/im"}, null);
                        int columnIndex13 = query5.getColumnIndex("data1");
                        int columnIndex14 = query5.getColumnIndex("data5");
                        if (query5.getCount() > 0) {
                            HashMap<Integer, String> hashMap4 = new HashMap<>();
                            while (query5.moveToNext()) {
                                hashMap4.put(Integer.valueOf(Integer.parseInt(query5.getString(columnIndex14))), query5.getString(columnIndex13));
                            }
                            contact2.setIm(hashMap4);
                        }
                        query5.close();
                        contactList.add(contact2);
                        query = cursor;
                    }
                }
            }
            query.close();
            return null;
        }

        public void onPostExecute(Void r20) {
            String str;
            String str2;
            String str3;
            pd.cancel();
            Log.e("task_call", "onPostExecute: " + contactList.size());
            List<Contact> list = contactList;
            for (int i = 0; i < list.size(); i++) {
                HashMap<Integer, String> phones = list.get(i).getPhones();
                HashMap<Integer, Contact.Address> hashMap = null;
                if (phones != null) {
                    phones.get(7);
                    str3 = phones.get(2);
                    str = phones.get(1);
                    str2 = phones.get(3);
                } else {
                    str3 = null;
                    str2 = null;
                    str = null;
                }
                HashMap<Integer, String> emails = list.get(i).getEmails();
                String str4 = emails != null ? emails.get(1) : null;
                try {
                    hashMap = list.get(i).getAddresses();
                } catch (Exception unused) {
                }
                if (hashMap.get(1) != null) {
                    hashMap.get(1);
                }
                allContacts.add(new ContactsPOJO(list.get(i).getDisplayName(), str3, list.get(i).lookup_key, null, str2, str, str4, false, false));
            }
            Collections.sort(ExportContactActivity.allContacts, new Comparator<ContactsPOJO>() {
                public int compare(ContactsPOJO contactsPOJO, ContactsPOJO contactsPOJO2) {
                    return String.valueOf(contactsPOJO.getName()).compareToIgnoreCase(String.valueOf(contactsPOJO2.getName()));
                }
            });
            contactAdpater = new ContactAdpater(getApplicationContext(), allContacts);
            binding.recycontactlist.setAdapter(contactAdpater);
            binding.recycontactlist.setLayoutManager(new LinearLayoutManager(ExportContactActivity.this));
        }
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(ExportContactActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}