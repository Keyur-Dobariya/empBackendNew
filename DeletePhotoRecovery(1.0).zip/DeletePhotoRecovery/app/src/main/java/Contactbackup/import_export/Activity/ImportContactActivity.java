package Contactbackup.import_export.Activity;

import android.content.Context;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Window;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.google.android.material.tabs.TabLayout;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.databinding.ActivityImportContactBinding;

import java.util.ArrayList;
import java.util.List;

import Contactbackup.PrefManager;
import Contactbackup.import_export.Fragment.ExcelFragment;
import Contactbackup.import_export.Fragment.VcfFragment;

public class ImportContactActivity extends AppCompatActivity implements TabLayout.BaseOnTabSelectedListener {
    Context context;
    PrefManager prefManager;
    ActivityImportContactBinding binding;

    @Override
    public void onTabReselected(TabLayout.Tab tab) {
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityImportContactBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(ImportContactActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        this.context = this;
        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        prefManager = new PrefManager(this);
        binding.tablayout.addTab(binding.tablayout.newTab().setText("Excel Files"));
        binding.tablayout.addTab(binding.tablayout.newTab().setText(".Vcf Files"));
        binding.tablayout.setTabGravity(0);
        binding.viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(binding.tablayout));
        binding.tablayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewPager.setCurrentItem(tab.getPosition());
            }
        });
        setupViewPager(binding.viewPager);
    }

    private void setupViewPager(ViewPager viewPager2) {
        int i = 1;
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), 1);
        viewPagerAdapter.addFragment(new ExcelFragment(), "");
        viewPagerAdapter.addFragment(new VcfFragment(), "");
        viewPager2.setAdapter(viewPagerAdapter);
        if (viewPagerAdapter.getCount() > 1) {
            i = viewPagerAdapter.getCount() - 1;
        }
        viewPager2.setOffscreenPageLimit(i);
        viewPager2.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
                Log.d("ORANGES", "onPageScrollStateChanged: " + i);
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
                Log.d("ORANGES", "onPageScrolled: " + i);
            }

            @Override
            public void onPageSelected(int i) {
                Log.d("ORANGES", "onPageSelected: " + i);
            }
        });
    }

    public static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        public ViewPagerAdapter(FragmentManager fragmentManager, int i) {
            super(fragmentManager, i);
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        @Override
        public int getCount() {
            return this.mFragmentList.size();
        }

        @Override
        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        @Override
        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        binding.viewPager.setCurrentItem(tab.getPosition());
    }

}