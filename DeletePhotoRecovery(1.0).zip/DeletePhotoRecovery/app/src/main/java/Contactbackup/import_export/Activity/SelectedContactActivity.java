package Contactbackup.import_export.Activity;

import android.app.ProgressDialog;
import android.content.ContentProviderOperation;
import android.content.Context;
import android.content.Intent;
import android.content.OperationApplicationException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.RemoteException;
import android.os.StrictMode;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.view.Window;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.databinding.ActivitySelectedContactBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

import Contactbackup.import_export.Adpater.ContactAdpater;
import Contactbackup.import_export.Adpater.SelectedListAdapter;
import Contactbackup.import_export.Fragment.ExcelFragment;
import Contactbackup.import_export.Pojo.ContactsPOJO;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class SelectedContactActivity extends AppCompatActivity implements View.OnClickListener {
    Context context;
    String from;
    ProgressDialog pd = null;
    String saveinpath;
    ArrayList<ContactsPOJO> selectcontact;
    SelectedListAdapter selectedListAdapter;

    public static ActivitySelectedContactBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivitySelectedContactBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binds();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(SelectedContactActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void binds() {
        this.context = this;
        selectcontact = new ArrayList<>();
        String stringExtra = getIntent().getStringExtra("from");
        this.from = stringExtra;
        if (stringExtra.equalsIgnoreCase("1")) {
            selectcontact = ContactAdpater.selected;
            selectedListAdapter = new SelectedListAdapter(getApplicationContext(), this.selectcontact);
            binding.recycontactlist.setAdapter(selectedListAdapter);
            binding.recycontactlist.setLayoutManager(new LinearLayoutManager(this));
        } else {
            selectcontact = ExcelFragment.contact_list_excel;
            selectedListAdapter = new SelectedListAdapter(getApplicationContext(), this.selectcontact);
            binding.recycontactlist.setAdapter(selectedListAdapter);
            binding.recycontactlist.setLayoutManager(new LinearLayoutManager(this));
        }
        binding.checkall.setOnClickListener(this);
        binding.btnBack.setOnClickListener(this);
        binding.removeall.setOnClickListener(this);
        binding.liimport.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnBack:
                onBackPressed();
                break;
            case R.id.checkall:
                binding.checkall.setVisibility(View.GONE);
                binding.removeall.setVisibility(View.VISIBLE);
                selectedListAdapter.getSelect_remove(false);
                break;
            case R.id.removeall:
                binding.checkall.setVisibility(View.VISIBLE);
                binding.removeall.setVisibility(View.GONE);
                selectedListAdapter.getSelect_remove(true);
                break;
            case R.id.liimport:
                if (from.equalsIgnoreCase("1")) {
                    new CreateExel().execute(new Void[0]);
                } else {
                    new ImportContact().execute(new Void[0]);
                }
                break;
        }
    }

    class CreateExel extends AsyncTask<Void, Void, Void> {
        CreateExel() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(SelectedContactActivity.this);
            pd.setMessage("Please wait.... ");
            pd.setCancelable(false);
            pd.show();
        }

        public Void doInBackground(Void... voidArr) {
            saveinpath = Environment.getExternalStorageDirectory().toString() + File.separator + getResources().getString(R.string.restore_folder_path_Contact);
            File file = new File(saveinpath);
            if (!file.exists()) {
                file.mkdirs();
            }
            saveinpath = saveinpath + File.separator + "Excel" + System.currentTimeMillis() + ".xls";
            try {
                File file2 = new File(saveinpath);
                WorkbookSettings workbookSettings = new WorkbookSettings();
                workbookSettings.setLocale(new Locale("en", "EN"));
                WritableWorkbook createWorkbook = Workbook.createWorkbook(file2, workbookSettings);
                WritableSheet createSheet = createWorkbook.createSheet("userList", 0);
                createSheet.addCell(new Label(0, 0, "index"));
                createSheet.addCell(new Label(1, 0, "Name"));
                createSheet.addCell(new Label(2, 0, "Mobile"));
                createSheet.addCell(new Label(3, 0, "Mobile2"));
                createSheet.addCell(new Label(4, 0, "Email"));
                int i = 0;
                while (i < ContactAdpater.selected.size()) {
                    String name = ContactAdpater.selected.get(i).getName();
                    String number = ContactAdpater.selected.get(i).getNumber();
                    String home_number = ContactAdpater.selected.get(i).getHome_number();
                    String email = ContactAdpater.selected.get(i).getEmail();
                    i++;
                    createSheet.addCell(new Label(0, i, String.valueOf(i)));
                    createSheet.addCell(new Label(1, i, name));
                    createSheet.addCell(new Label(2, i, number));
                    createSheet.addCell(new Label(3, i, home_number));
                    createSheet.addCell(new Label(4, i, email));
                }
                createWorkbook.write();
                createWorkbook.close();
                return null;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public void onPostExecute(Void r3) {
            pd.dismiss();
            ContactAdpater.selected.clear();
            Intent intent = new Intent(SelectedContactActivity.this, ImportContactActivity.class);
            intent.putExtra("file_path", saveinpath);
            startActivitys(intent);
            finish();
        }
    }

    class ImportContact extends AsyncTask<Void, Void, Void> {
        ImportContact() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(SelectedContactActivity.this);
            pd.setMessage("Please wait Import contact.... ");
            pd.setCancelable(false);
            pd.show();
        }

        public Void doInBackground(Void... voidArr) {
            for (int i = 0; i < selectcontact.size(); i++) {
                fxAdd_RawContact(selectcontact.get(i).getName(), selectcontact.get(i).getNumber(), selectcontact.get(i).getMobile2(), selectcontact.get(i).getEmail());
            }
            return null;
        }

        public void onPostExecute(Void r5) {
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void fxAdd_RawContact(String str, String str2, String str3, String str4) {
        ArrayList<ContentProviderOperation> arrayList = new ArrayList<>();
        int size = arrayList.size();
        try {
            arrayList.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI).withValue("account_type", null).withValue("account_name", null).build());
            arrayList.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", size).withValue("mimetype", "vnd.android.cursor.item/name").withValue("data1", str).build());
            arrayList.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", size).withValue("mimetype", "vnd.android.cursor.item/email_v2").withValue("data1", str4).build());
            arrayList.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", size).withValue("mimetype", "vnd.android.cursor.item/phone_v2").withValue("data1", str2).withValue("data2", 2).build());
            arrayList.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", size).withValue("mimetype", "vnd.android.cursor.item/phone_v2").withValue("data1", str3).withValue("data2", 7).build());
            try {
                getContentResolver().applyBatch("com.android.contacts", arrayList);
            } catch (RemoteException e) {
                Log.e("getContentResolver()", e.getMessage());
            } catch (OperationApplicationException e2) {
                Log.e("getContentResolver()", e2.toString());
            } catch (Exception e3) {
                Log.e("getContentResolver()", e3.toString());
            }
        } catch (Exception unused) {
        }
    }



    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(SelectedContactActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }

}