package Contactbackup.import_export.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.recyclerview.widget.RecyclerView;


import com.photo.video.all.document.recovery.databinding.ItemContactBinding;

import java.util.ArrayList;

import Contactbackup.import_export.Activity.ExportContactActivity;
import Contactbackup.import_export.Pojo.ContactsPOJO;

public class ContactAdpater extends RecyclerView.Adapter implements Filterable {
    public static ArrayList<ContactsPOJO> selected = new ArrayList<>();
    public ArrayList<ContactsPOJO> ContactNamesList;
    boolean activate;
    Context context;
    ItemFilter filter;
    static ArrayList<ContactsPOJO> modelArrayList;

    public class ItemFilter extends Filter {
        private ItemFilter() {
        }

        public FilterResults performFiltering(CharSequence charSequence) {
            String charSequence2 = charSequence.toString();
            FilterResults filterResults = new FilterResults();
            ArrayList<ContactsPOJO> arrayList = ContactNamesList;
            int size = arrayList.size();
            ArrayList arrayList2 = new ArrayList(size);
            ArrayList arrayList3 = new ArrayList(size);
            for (int i = 0; i < size; i++) {
                String name = arrayList.get(i).getName();
                String number = arrayList.get(i).getNumber();
                if (name.toLowerCase().contains(charSequence2.toLowerCase())) {
                    arrayList3.add(arrayList.get(i));
                } else if (number != null && number.toString().contains(charSequence2.toString())) {
                    arrayList3.add(arrayList.get(i));
                }
            }
            filterResults.values = arrayList3;
            filterResults.count = arrayList2.size();
            return filterResults;
        }

        public void publishResults(CharSequence charSequence, FilterResults filterResults) {
            modelArrayList = new ArrayList<>();
            modelArrayList = (ArrayList) filterResults.values;
            if (modelArrayList.size() == 0) {
                ExportContactActivity.binding.recycontactlist.setVisibility(View.GONE);
                ExportContactActivity.binding.emptytext.setVisibility(View.VISIBLE);
            } else {
                ExportContactActivity.binding.recycontactlist.setVisibility(View.VISIBLE);
                ExportContactActivity.binding.emptytext.setVisibility(View.GONE);
            }
            notifyDataSetChanged();
        }
    }

    public Filter getFilter() {
        return this.filter;
    }

    public ContactAdpater(Context context2, ArrayList<ContactsPOJO> arrayList) {
        this.modelArrayList = arrayList;
        this.context = context2;
        ArrayList<ContactsPOJO> arrayList2 = new ArrayList<>();
        this.ContactNamesList = arrayList2;
        arrayList2.addAll(arrayList);
        this.filter = new ItemFilter();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemContactBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        if (this.context != null) {
            ContactsPOJO contactsPOJO = this.modelArrayList.get(i);
            adapter_ViewHolder.binding.name.setText("" + contactsPOJO.getName());
            adapter_ViewHolder.binding.number.setText("" + contactsPOJO.getNumber());
            if (contactsPOJO.isChecked()) {
                adapter_ViewHolder.binding.select.setVisibility(View.VISIBLE);
                adapter_ViewHolder.binding.selectempty.setVisibility(View.GONE);
            } else {
                adapter_ViewHolder.binding.select.setVisibility(View.GONE);
                adapter_ViewHolder.binding.selectempty.setVisibility(View.VISIBLE);
            }
            adapter_ViewHolder.binding.mainlayout.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    ContactsPOJO contactsPOJO = modelArrayList.get(i);
                    contactsPOJO.setChecked(!contactsPOJO.isChecked());
                    adapter_ViewHolder.binding.select.setVisibility(contactsPOJO.isChecked() ? View.VISIBLE : View.GONE);
                    if (contactsPOJO.isChecked()) {
                        ContactAdpater.selected.add(contactsPOJO);
                        adapter_ViewHolder.binding.select.setVisibility(View.VISIBLE);
                        adapter_ViewHolder.binding.selectempty.setVisibility(View.GONE);
                        if (ContactAdpater.selected.size() == modelArrayList.size()) {
                            ExportContactActivity.binding.removeall.setVisibility(View.GONE);
                            ExportContactActivity.binding.checkall.setVisibility(View.VISIBLE);
                            return;
                        }
                        return;
                    }
                    ContactAdpater.selected.remove(contactsPOJO);
                    adapter_ViewHolder.binding.select.setVisibility(View.GONE);
                    adapter_ViewHolder.binding.selectempty.setVisibility(View.VISIBLE);
                }
            });
        }
    }

    public static class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemContactBinding binding;

        public Adapter_ViewHolder(ItemContactBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

    @Override
    public int getItemViewType(int i) {
        return !this.modelArrayList.get(i).isSection ? 1 : 0;
    }

    @Override
    public int getItemCount() {
        return this.modelArrayList.size();
    }

    public ArrayList<ContactsPOJO> getSelect_remove(boolean z) {
        this.activate = z;
        notifyDataSetChanged();
        if (z) {
            selected.clear();
            for (int i = 0; i < this.modelArrayList.size(); i++) {
                if (!this.modelArrayList.get(i).isSection) {
                    this.modelArrayList.get(i).setSelected(true);
                    selected.add(this.modelArrayList.get(i));
                }
            }
        } else {
            selected.clear();
            for (int i2 = 0; i2 < this.modelArrayList.size(); i2++) {
                this.modelArrayList.get(i2).setSelected(false);
            }
        }
        return selected;
    }
}