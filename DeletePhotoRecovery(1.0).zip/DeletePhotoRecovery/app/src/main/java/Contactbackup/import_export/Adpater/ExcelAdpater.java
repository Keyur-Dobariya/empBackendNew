package Contactbackup.import_export.Adpater;

import static Contactbackup.import_export.Activity.ExportContactActivity.binding;

import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.databinding.ItemExcelBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import Contactbackup.import_export.Mainutils.ExcelData;
import Contactbackup.import_export.Mainutils.ItemClick;

public class ExcelAdpater extends RecyclerView.Adapter implements Filterable {
    public ItemClick clickListener;
    Context context;
    ItemFilter filter = new ItemFilter();
    public ArrayList<ExcelData> modelArrayList;
    boolean varible;

    private class ItemFilter extends Filter {
        private ItemFilter() {
        }

        public FilterResults performFiltering(CharSequence charSequence) {
            String charSequence2 = charSequence.toString();
            FilterResults filterResults = new FilterResults();
            ArrayList<ExcelData> arrayList = modelArrayList;
            int size = arrayList.size();
            ArrayList arrayList2 = new ArrayList(size);
            ArrayList arrayList3 = new ArrayList(size);
            for (int i = 0; i < size; i++) {
                if (arrayList.get(i).getName().toLowerCase().contains(charSequence2.toLowerCase())) {
                    arrayList3.add(arrayList.get(i));
                }
            }
            filterResults.values = arrayList3;
            filterResults.count = arrayList2.size();
            return filterResults;
        }

        public void publishResults(CharSequence charSequence, FilterResults filterResults) {
            modelArrayList = new ArrayList<>();
            modelArrayList = (ArrayList) filterResults.values;
            if (modelArrayList.size() == 0) {
                binding.recycontactlist.setVisibility(View.GONE);
                binding.emptytext.setVisibility(View.VISIBLE);
            } else {
                binding.recycontactlist.setVisibility(View.VISIBLE);
                binding.emptytext.setVisibility(View.GONE);
            }
            notifyDataSetChanged();
        }
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemExcelBinding binding;

        public Adapter_ViewHolder(ItemExcelBinding view) {
            super(view.getRoot());
            binding = view;
        }

        public void onClick(View view) {
            if (clickListener != null) {
                clickListener.onItemClick(view, modelArrayList.get(getAdapterPosition()).getPath());
            }
        }
    }

    public Filter getFilter() {
        return this.filter;
    }

    public ExcelAdpater(Context context2, ArrayList<ExcelData> arrayList, boolean z) {
        this.modelArrayList = arrayList;
        this.context = context2;
        this.varible = z;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemExcelBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) viewHolder;
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        final ExcelData excelData = this.modelArrayList.get(i);
        String name = excelData.getName();
        Date date = new Date(Long.parseLong(excelData.getDate()));
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy | hh:mm a");
        new SimpleDateFormat("MM/dd/yyyy");
        new SimpleDateFormat("K:mm a");
        String format = simpleDateFormat.format(date);
        adapter_ViewHolder.binding.txtfiledate.setText("" + format);
        adapter_ViewHolder.binding.txtfilepath.setText("" + name);
        adapter_ViewHolder.binding.lishare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Uri photoURI = FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", // Over here
                        new File(excelData.getPath()));
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("application/vnd.ms-excel");
                intent.putExtra("android.intent.extra.STREAM", photoURI);
                context.startActivity(Intent.createChooser(intent, "Share Using"));
            }
        });
        adapter_ViewHolder.binding.lidelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                File file = new File(excelData.getPath());
                if (file.exists()) {
                    file.delete();
                }
                modelArrayList.remove(i);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.modelArrayList.size();
    }

    public void setClickListener(ItemClick itemClick) {
        this.clickListener = itemClick;
    }
}