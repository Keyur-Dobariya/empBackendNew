package Contactbackup.import_export.Adpater;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;


import com.photo.video.all.document.recovery.databinding.ItemSelectedContactBinding;

import java.util.ArrayList;

import Contactbackup.import_export.Activity.SelectedContactActivity;
import Contactbackup.import_export.Pojo.ContactsPOJO;

public class SelectedListAdapter extends RecyclerView.Adapter {
    public static ArrayList<ContactsPOJO> selected = new ArrayList<>();
    boolean activate;

    ContactsPOJO f7contact;
    Context context;
    public ArrayList<ContactsPOJO> modelArrayList;

    public SelectedListAdapter(Context context2, ArrayList<ContactsPOJO> arrayList) {
        this.modelArrayList = arrayList;
        this.context = context2;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemSelectedContactBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        this.f7contact = this.modelArrayList.get(i);
        adapter_ViewHolder.binding.name.setText("" + this.f7contact.getName());
        adapter_ViewHolder.binding.number.setText("" + this.f7contact.getNumber());
        if (this.f7contact.isChecked()) {
            adapter_ViewHolder.binding.liselect.setVisibility(View.VISIBLE);
            adapter_ViewHolder.binding.linoselect.setVisibility(View.GONE);
        } else {
            adapter_ViewHolder.binding.liselect.setVisibility(View.GONE);
            adapter_ViewHolder.binding.linoselect.setVisibility(View.VISIBLE);
        }
        adapter_ViewHolder.binding.mainlayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ContactsPOJO contactsPOJO = SelectedListAdapter.this.modelArrayList.get(i);
                contactsPOJO.setChecked(!contactsPOJO.isChecked());
                adapter_ViewHolder.binding.liselect.setVisibility(contactsPOJO.isChecked() ? View.VISIBLE : View.GONE);
                if (contactsPOJO.isChecked()) {
                    SelectedListAdapter.selected.add(contactsPOJO);
                    adapter_ViewHolder.binding.liselect.setVisibility(View.VISIBLE);
                    adapter_ViewHolder.binding.linoselect.setVisibility(View.GONE);
                    if (SelectedListAdapter.selected.size() == SelectedListAdapter.this.modelArrayList.size()) {
                        SelectedContactActivity.binding.removeall.setVisibility(View.GONE);
                        SelectedContactActivity.binding.checkall.setVisibility(View.VISIBLE);
                        return;
                    }
                    return;
                }
                SelectedListAdapter.selected.remove(contactsPOJO);
                adapter_ViewHolder.binding.liselect.setVisibility(View.GONE);
                adapter_ViewHolder.binding.linoselect.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.modelArrayList.size();
    }

    public ArrayList<ContactsPOJO> getSelect_remove(boolean z) {
        this.activate = z;
        notifyDataSetChanged();
        if (z) {
            selected.clear();
            for (int i = 0; i < this.modelArrayList.size(); i++) {
                if (!this.modelArrayList.get(i).isSection) {
                    this.modelArrayList.get(i).setSelected(true);
                    selected.add(this.modelArrayList.get(i));
                }
            }
        } else {
            selected.clear();
            for (int i2 = 0; i2 < this.modelArrayList.size(); i2++) {
                this.modelArrayList.get(i2).setSelected(false);
            }
        }
        return selected;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemSelectedContactBinding binding;

        public Adapter_ViewHolder(ItemSelectedContactBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }
}