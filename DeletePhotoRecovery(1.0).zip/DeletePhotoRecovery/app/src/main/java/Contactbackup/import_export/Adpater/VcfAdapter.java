package Contactbackup.import_export.Adpater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.Build;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.databinding.ItemVcfBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import Contactbackup.import_export.Mainutils.ExcelData;

public class VcfAdapter extends RecyclerView.Adapter {
    Context context;
    File[] files;
    LayoutInflater inflater;
    public ArrayList<ExcelData> modelArrayList;
    boolean varible;

    @Override
    public int getItemCount() {
        return this.modelArrayList.size();
    }

    public VcfAdapter(Context context2, ArrayList<ExcelData> arrayList, File[] fileArr, boolean z) {
        this.context = context2;
        this.modelArrayList = arrayList;
        this.files = fileArr;
        this.inflater = LayoutInflater.from(context2);
        this.varible = z;
    }


    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemVcfBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    @SuppressLint("SimpleDateFormat")
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) viewHolder;
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        final ExcelData excelData = this.modelArrayList.get(i);
        String name = excelData.getName();
        Date date = new Date(Long.parseLong(excelData.getDate()));
        SimpleDateFormat simpleDateFormat = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            simpleDateFormat = new SimpleDateFormat("dd MMM yyyy | hh:mm a");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            new SimpleDateFormat("MM/dd/yyyy");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            new SimpleDateFormat("K:mm a");
        }
        String format = simpleDateFormat.format(date);
        adapter_ViewHolder.binding.filedatevcf.setText("" + format);
        adapter_ViewHolder.binding.filepathvcf.setText("" + name);
        adapter_ViewHolder.binding.lishare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Uri photoURI = FileProvider.getUriForFile(context,
                        context.getPackageName() + ".provider", // Over here
                        new File(excelData.getPath()));
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/x-vcard");
                intent.putExtra("android.intent.extra.STREAM", photoURI);
                context.startActivity(Intent.createChooser(intent, "Share Using"));
            }
        });
        adapter_ViewHolder.binding.lidelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                File file = files[i];
                if (file.exists()) {
                    file.delete();
                }
                modelArrayList.remove(i);
                notifyDataSetChanged();
            }
        });
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemVcfBinding binding;

        public Adapter_ViewHolder(ItemVcfBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

}