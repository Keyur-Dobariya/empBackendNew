package Contactbackup.import_export.Fragment;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.ExcelFragmentBinding;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import Contactbackup.import_export.Adpater.ExcelAdpater;
import Contactbackup.import_export.Mainutils.ExcelData;
import Contactbackup.import_export.Mainutils.ItemClick;
import Contactbackup.import_export.Pojo.ContactsPOJO;
import Contactbackup.import_export.Mainutils.RealPathUtil;

public class ExcelFragment extends Fragment {
    public static ArrayList<ContactsPOJO> contact_list_excel;
    public static String path_excel;
    int READ_REQUEST_CODE = 100;
    BigDecimal bd;
    ContactsPOJO contactsPOJO;
    private long lastClickTime = 0;
    ArrayList<ExcelData> listOfAllImages;
    ExcelAdpater myFileAdpater;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ExcelFragmentBinding binding = ExcelFragmentBinding.inflate(layoutInflater, viewGroup, false);
        this.listOfAllImages = new ArrayList<>();
        Search_Dir(new File(Environment.getExternalStorageDirectory().toString() + File.separator + getString(R.string.restore_folder_path_Contact)));
        if (this.listOfAllImages.size() == 0) {
            binding.txtempty.setVisibility(View.VISIBLE);
            binding.recycontactlist.setVisibility(View.GONE);
        } else {
            binding.txtempty.setVisibility(View.GONE);
            binding.recycontactlist.setVisibility(View.VISIBLE);
            myFileAdpater = new ExcelAdpater(getActivity(), this.listOfAllImages, false);
            binding.recycontactlist.setAdapter(myFileAdpater);
            binding.recycontactlist.setLayoutManager(new LinearLayoutManager(getActivity()));
            this.myFileAdpater.setClickListener(new ItemClick() {
                @Override
                public void onMenuItemClick(View view, String str) {
                }

                @Override
                public void onItemClick(View view, String str) {
                    if (SystemClock.elapsedRealtime() - ExcelFragment.this.lastClickTime > 1000) {
                        ExcelFragment.path_excel = str;
                        new ReadContact().execute(new Void[0]);
                        ExcelFragment.this.lastClickTime = SystemClock.elapsedRealtime();
                    }
                }
            });
        }
        //         **********small native*******************************
        new SmallNativeAds(screenName).showAd(getActivity(), binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);
        return binding.getRoot();
    }

    class ReadContact extends AsyncTask<Void, Void, Void> {
        ReadContact() {
        }

        public void onPreExecute() {
        }

        public Void doInBackground(Void... voidArr) {
            try {
                Iterator<Row> rowIterator = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(new File(ExcelFragment.path_excel)))).getSheetAt(0).rowIterator();
                int i = 0;
                while (rowIterator.hasNext()) {
                    HSSFRow hSSFRow = (HSSFRow) rowIterator.next();
                    if (i != 0) {
                        Iterator<Cell> cellIterator = hSSFRow.cellIterator();
                        String str = "";
                        String str2 = str;
                        String str3 = str2;
                        String str4 = str3;
                        int i2 = 0;
                        while (cellIterator.hasNext()) {
                            HSSFCell hSSFCell = (HSSFCell) cellIterator.next();
                            if (i2 == 0) {
                                hSSFCell.toString();
                            } else if (i2 == 1) {
                                str = hSSFCell.toString();
                            } else if (i2 == 2) {
                                str2 = hSSFCell.toString();
                            } else if (i2 == 3) {
                                str3 = hSSFCell.toString();
                            } else if (i2 == 4) {
                                str4 = hSSFCell.toString();
                            }
                            i2++;
                        }
                        ExcelFragment.this.add_list(str, str2, str3, str4);
                    }
                    i++;
                }
                return null;
            } catch (Exception unused) {
                return null;
            }
        }

        public void onPostExecute(Void r4) {
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        contact_list_excel = new ArrayList<>();
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == this.READ_REQUEST_CODE && i2 == -1) {
            String pathFromURI = RealPathUtil.getPathFromURI(getActivity(), intent.getData());
            if (pathFromURI.contains("xls")) {
                path_excel = pathFromURI;
                new ReadContact().execute(new Void[0]);
                return;
            }
            Toast makeText = Toast.makeText(getActivity(), "file not support", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public ArrayList Search_Dir(File file) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (int i = 0; i < listFiles.length; i++) {
                if (listFiles[i].isDirectory() && !listFiles[i].getName().equals("Android")) {
                    Search_Dir(listFiles[i]);
                } else if (listFiles[i].getName().endsWith(".xls")) {
                    this.listOfAllImages.add(new ExcelData(listFiles[i].getAbsolutePath().substring(listFiles[i].getAbsolutePath().lastIndexOf("/") + 1), String.valueOf(new File(listFiles[i].getAbsolutePath()).lastModified()), listFiles[i].getAbsolutePath()));
                }
            }
            Collections.sort(this.listOfAllImages, new Comparator<ExcelData>() {
                public int compare(ExcelData excelData, ExcelData excelData2) {
                    return excelData.getName().compareToIgnoreCase(excelData2.getName());
                }
            });
        }
        return this.listOfAllImages;
    }

    public void add_list(String str, String str2, String str3, String str4) {
        String str5;
        String str6;
        String str7;
        String str8;
        if (!str2.equals("")) {
            str2 = str2.replace(" ", "");
            try {
                bd = new BigDecimal(str2);
                str8 = String.valueOf(bd.longValue());
            } catch (Exception unused) {
                str3.equals("");
                str2.equals("");
                str8 = "";
            }
            str5 = str8;
        } else {
            str5 = "";
        }
        if (str3.equals("")) {
            try {
                bd = new BigDecimal(str3.replace(" ", ""));
                str7 = String.valueOf(bd.longValue()).trim();
            } catch (Exception unused2) {
                str2.equals("");
                str7 = "";
            }
            str6 = str7;
        } else {
            str6 = "";
        }
        if (!str2.equals("")) {
            contactsPOJO = new ContactsPOJO(str, str5, str6, str4, false);
            contact_list_excel.add(contactsPOJO);
        }
    }

}