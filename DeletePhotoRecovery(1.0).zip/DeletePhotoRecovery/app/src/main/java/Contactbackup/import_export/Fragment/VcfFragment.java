package Contactbackup.import_export.Fragment;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.VcfFragmentBinding;

import java.io.File;
import java.util.ArrayList;

import Contactbackup.import_export.Mainutils.ExcelData;
import Contactbackup.import_export.Adpater.VcfAdapter;

public class VcfFragment extends Fragment {
    ArrayList<ExcelData> contact;
    File[] files;
    VcfAdapter vcfAdapter;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        VcfFragmentBinding binding = VcfFragmentBinding.inflate(layoutInflater, viewGroup, false);
        int i = 0;
        File file = new File(Environment.getExternalStorageDirectory() + "/" + getString(R.string.restore_folder_path_Contact));
        if (file.exists()) {
            File[] listFiles = file.listFiles();
            this.files = listFiles;
            if (listFiles != null) {
                if (listFiles.length != 0) {
                    this.contact = new ArrayList<>();
                    while (true) {
                        File[] fileArr = this.files;
                        if (i >= fileArr.length) {
                            break;
                        }
                        if (fileArr[i].getName().endsWith(".vcf")) {
                            this.files[i].getName();
                            this.contact.add(new ExcelData(listFiles[i].getAbsolutePath().substring(listFiles[i].getAbsolutePath().lastIndexOf("/") + 1), String.valueOf(new File(listFiles[i].getAbsolutePath()).lastModified()), listFiles[i].getAbsolutePath()));
                        }
                        i++;
                    }
                    vcfAdapter = new VcfAdapter(getActivity(), this.contact, this.files, false);
                    binding.listvcf.setAdapter(vcfAdapter);
                    binding.listvcf.setLayoutManager(new LinearLayoutManager(getActivity()));
                }
                else {
                    binding.listvcf.setVisibility(View.GONE);
                    binding.txtempty.setVisibility(View.VISIBLE);
                }
            }
        } else {
            binding.listvcf.setVisibility(View.GONE);
            binding.txtempty.setVisibility(View.VISIBLE);
        }

        //         **********small native*******************************
        new SmallNativeAds(screenName).showAd(getActivity(), binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);
        return binding.getRoot();
    }
}