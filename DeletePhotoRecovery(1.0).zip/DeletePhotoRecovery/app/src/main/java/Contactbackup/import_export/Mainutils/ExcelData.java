package Contactbackup.import_export.Mainutils;

public class ExcelData {
    String date;
    String name;
    String path;

    public String getPath() {
        return this.path;
    }

    public void setPath(String str) {
        this.path = str;
    }

    public  ExcelData() {
    }

    public ExcelData(String str, String str2, String str3) {
        this.name = str;
        this.date = str2;
        this.path = str3;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String str) {
        this.date = str;
    }
}