package Contactbackup.import_export.Mainutils;

import android.view.View;

public interface ItemClick {
    void onItemClick(View view, String str);

    void onMenuItemClick(View view, String str);
}