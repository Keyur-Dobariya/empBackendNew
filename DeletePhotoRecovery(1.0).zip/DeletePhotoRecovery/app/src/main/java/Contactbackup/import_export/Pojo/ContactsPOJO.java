package Contactbackup.import_export.Pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class ContactsPOJO implements Parcelable {
    public static final Creator<ContactsPOJO> CREATOR = new Creator<ContactsPOJO>() {

        @Override
        public ContactsPOJO createFromParcel(Parcel parcel) {
            return new ContactsPOJO(parcel);
        }

        @Override
        public ContactsPOJO[] newArray(int i) {
            return new ContactsPOJO[i];
        }
    };
    public String Address;
    public String LOOKUP_KEY;
    public String email;
    public String home_number;
    public boolean isSection;
    boolean isSelected = false;
    public String mobile2;
    public String name;
    public String number;
    public String work_number;

    public int describeContents() {
        return 0;
    }

    public String getMobile2() {
        return this.mobile2;
    }

    public void setMobile2(String str) {
        this.mobile2 = str;
    }

    public ContactsPOJO() {
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String str) {
        this.email = str;
    }

    public String getHome_number() {
        return this.home_number;
    }

    public void setHome_number(String str) {
        this.home_number = str;
    }

    public ContactsPOJO(String str, String str2, String str3, String str4, String str5, String str6, String str7, boolean z, boolean z2) {
        this.name = str;
        this.number = str2;
        this.LOOKUP_KEY = str3;
        this.Address = str4;
        this.work_number = str5;
        this.home_number = str6;
        this.email = str7;
        this.isSelected = z;
        this.isSection = z2;
    }

    public ContactsPOJO(String str, String str2, String str3, String str4, boolean z) {
        this.name = str;
        this.number = str2;
        this.mobile2 = str3;
        this.email = str4;
        this.isSelected = z;
    }

    protected ContactsPOJO(Parcel parcel) {
        boolean z = false;
        this.name = parcel.readString();
        this.number = parcel.readString();
        this.Address = parcel.readString();
        this.work_number = parcel.readString();
        this.home_number = parcel.readString();
        this.email = parcel.readString();
        this.isSelected = parcel.readByte() != 0 ? true : z;
    }

    public boolean isChecked() {
        return this.isSelected;
    }

    public void setChecked(boolean z) {
        this.isSelected = z;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getNumber() {
        return this.number;
    }

    public void setNumber(String str) {
        this.number = str;
    }

    public String getLOOKUP_KEY() {
        return this.LOOKUP_KEY;
    }

    public void setLOOKUP_KEY(String str) {
        this.LOOKUP_KEY = str;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.name);
        parcel.writeString(this.number);
        parcel.writeString(this.Address);
        parcel.writeString(this.work_number);
        parcel.writeString(this.home_number);
        parcel.writeString(this.email);
        parcel.writeByte(this.isSelected ? (byte) 1 : 0);
    }
}