package com.photo.video.all.document.recovery;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.photo.video.all.document.recovery.ads.commons.AdsManager;
import com.photo.video.all.document.recovery.ads.commons.AdsUtils;
import com.photo.video.all.document.recovery.ads.commons.MyExtensionsKt;
import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityMainBinding;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import Contactbackup.import_export.Activity.ContactActivity;
import de.deleted.filerecovery.model.modul.recoveryaudio.AlbumAudioActivity;
import de.deleted.filerecovery.model.modul.recoveryaudio.Model.AlbumAudio;
import de.deleted.filerecovery.model.modul.recoveryaudio.Model.AudioModel;
import de.deleted.filerecovery.model.modul.recoveryphoto.AlbumPhotoActivity;
import de.deleted.filerecovery.model.modul.recoveryphoto.Model.AlbumPhoto;
import de.deleted.filerecovery.model.modul.recoveryphoto.Model.PhotoModel;
import de.deleted.filerecovery.model.modul.recoveryvideo.AlbumVideoActivity;
import de.deleted.filerecovery.model.modul.recoveryvideo.Model.AlbumVideo;
import de.deleted.filerecovery.model.modul.recoveryvideo.Model.VideoModel;
import de.deleted.filerecovery.ui.activity.NoFileActiviy;
import de.deleted.filerecovery.utilts.Utils;
import docs.async.SearchMotor;
import docs.async.VolumsFetcher;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public static ArrayList<AlbumAudio> mAlbumAudio = new ArrayList<>();
    public static ArrayList<AlbumPhoto> mAlbumPhoto = new ArrayList<>();
    public static ArrayList<AlbumVideo> mAlbumVideo = new ArrayList<>();
    ScanAsyncTask mScanAsyncTask;
    public static int open = 0;
    public static Boolean flag = false;
    private boolean z;
    private static final int STORAGE_REQUEST_CODE = 101;
    ActivityMainBinding binding;

    private ReviewManager manager;
    private ReviewInfo reviewInfo;

    private final String screenName = this.getClass().getSimpleName();
    //    **********************doc**********************

    ArrayList<String> volums;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (!CheckStoragePERMISSION()) {
            AskStoragePERMISSION();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                //todo when permission is granted
            } else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        }
        intView();
//        ****************doc*********************

        goReview();

        new SmallNativeAds(screenName).showAd(this, binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(MainActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        showExitDailog();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });

    }

    public void intView() {
        binding.cvImage.setOnClickListener(this);
        binding.cvAudio.setOnClickListener(this);
        binding.cvVideo.setOnClickListener(this);
        binding.doc.setOnClickListener(this);
        binding.contcat.setOnClickListener(this);
        binding.tvNumber.setText("");
        binding.more.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cvImage:
                flag = false;
                scanType(0);
                return;
            case R.id.cvVideo:
                flag = false;
                scanType(1);
                return;
            case R.id.cvAudio:
                flag = false;
                scanType(2);
                return;
            case R.id.doc: {
                open = 4;
                flag = true;
                if (flag) {
                    scanType(3);
                    flag = false;
                }
            }
            return;
            case R.id.contcat:
                startActivitys(new Intent(MainActivity.this, ContactActivity.class));
                return;
            case R.id.more:
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, binding.more);
                popupMenu.inflate(R.menu.popup_privacy);
                popupMenu.setOnMenuItemClickListener(menuItem -> {
                    int itemId = menuItem.getItemId();
                    if (itemId == R.id.share) {
                        shareApp();
                        return false;
                    } else if (itemId == R.id.rate) {
                        rateUs();
                        return false;
                    } else if (itemId == R.id.privacy) {
                        MyExtensionsKt.privacyPolicy(this, AdsUtils.getAdPref(this).ppLink);
                        return false;
                    } else {
                        return false;
                    }
                });
                popupMenu.show();
                break;
            default:
                return;
        }
    }

    public void shareApp() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", "Download this awesome app\n https://play.google.com/store/apps/details?id=" + getPackageName() + " \n");
        startActivity(intent);
    }

    public void rateUs() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
        } catch (ActivityNotFoundException unused) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }


    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(MainActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }

    public void scanType(int i) {
        if (mScanAsyncTask == null || mScanAsyncTask.getStatus() != AsyncTask.Status.RUNNING) {
            mAlbumAudio.clear();
            mAlbumPhoto.clear();
            mAlbumVideo.clear();
            binding.tvNumber.setVisibility(View.VISIBLE);
            binding.tvNumber.setText(getString(R.string.analyzing));
            binding.ivSearch.playAnimation();
            if (flag == true && i == 3) {
                if (mScanAsyncTask != null) {
                    mScanAsyncTask.isCancelled();
                    mScanAsyncTask = null;
                }
                binding.tvNumber.setVisibility(View.VISIBLE);
                binding.tvNumber.setText(getString(R.string.analyzing));
                volums = VolumsFetcher.getStorageVolums(getApplicationContext());
                int number = 0;
                int parseInt = Integer.parseInt(String.valueOf(volums.size()));
                if (parseInt > 10000) {
                    int i2 = number + 1;
                    number = i2;
                }
                if (volums != null) {
                    SearchMotor myMotor = new SearchMotor(volums, MainActivity.this, getApplicationContext());
                    myMotor.execute(new Void[0]);
                }
            } else {
                mScanAsyncTask = new ScanAsyncTask(i);
                mScanAsyncTask.execute(new Void[0]);
            }
            return;
        }
        Toast.makeText(this, getString(R.string.scan_wait), Toast.LENGTH_LONG).show();
    }

    public class ScanAsyncTask extends AsyncTask<Void, Integer, Void> {
        ArrayList<AudioModel> listAudio = new ArrayList<>();
        ArrayList<PhotoModel> listPhoto = new ArrayList<>();
        ArrayList<VideoModel> listVideo = new ArrayList<>();

        int number = 0;
        int typeScan = 0;

        public ScanAsyncTask(int i) {
            this.typeScan = i;
        }

        public void onPreExecute() {
            super.onPreExecute();
            this.number = 0;
        }

        public void onPostExecute(Void r3) {
            super.onPostExecute(r3);
            binding.ivSearch.pauseAnimation();
            binding.ivSearch.setProgress(0.0f);
            binding.tvNumber.setText("");
            binding.tvNumber.setVisibility(View.INVISIBLE);
            if (typeScan == 0) {
                if (MainActivity.mAlbumPhoto.size() == 0) {
                    startActivitys(new Intent(MainActivity.this, NoFileActiviy.class));
                } else {
                    startActivitys(new Intent(MainActivity.this, AlbumPhotoActivity.class));
                }
            }
            if (typeScan == 1) {
                if (MainActivity.mAlbumVideo.size() == 0) {
                    startActivitys(new Intent(MainActivity.this, NoFileActiviy.class));
                } else {
                    startActivitys(new Intent(MainActivity.this, AlbumVideoActivity.class));
                }
            }
            if (typeScan == 2) {
                if (MainActivity.mAlbumAudio.size() == 0) {
                    startActivitys(new Intent(MainActivity.this, NoFileActiviy.class));
                } else {
                    startActivitys(new Intent(MainActivity.this, AlbumAudioActivity.class));
                }
            }

        }

        public void onProgressUpdate(Integer... numArr) {
            super.onProgressUpdate(numArr);
            binding.tvNumber.setText("Files: " + String.valueOf(numArr[0]));
        }

        public Void doInBackground(Void... voidArr) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String absolutePath = Environment.getExternalStorageDirectory().getAbsolutePath();
            StringBuilder sb = new StringBuilder();
            sb.append("root = ");
            sb.append(absolutePath);
            if (typeScan == 0) {
                try {
                    getSdCardImage();
                    checkFileOfDirectoryImage(absolutePath, Utils.getFileList(absolutePath));
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
                Collections.sort(MainActivity.mAlbumPhoto, new Comparator<AlbumPhoto>() {
                    public int compare(AlbumPhoto albumPhoto, AlbumPhoto albumPhoto2) {
                        return Long.valueOf(albumPhoto2.getLastModified()).compareTo(Long.valueOf(albumPhoto.getLastModified()));
                    }
                });
            }
            if (typeScan == 1) {
                getSdCardVideo();
                checkFileOfDirectoryVideo(absolutePath, Utils.getFileList(absolutePath));
                Collections.sort(MainActivity.mAlbumVideo, new Comparator<AlbumVideo>() {
                    public int compare(AlbumVideo albumVideo, AlbumVideo albumVideo2) {
                        return Long.valueOf(albumVideo2.getLastModified()).compareTo(Long.valueOf(albumVideo.getLastModified()));
                    }
                });
            }
            if (typeScan == 2) {
                try {
                    getSdCardAudio();
                    checkFileOfDirectoryAudio(absolutePath, Utils.getFileList(absolutePath));
                } catch (Exception unused2) {
                    unused2.printStackTrace();
                }
                Collections.sort(MainActivity.mAlbumAudio, new Comparator<AlbumAudio>() {
                    public int compare(AlbumAudio albumAudio, AlbumAudio albumAudio2) {
                        return Long.valueOf(albumAudio2.getLastModified()).compareTo(Long.valueOf(albumAudio.getLastModified()));
                    }
                });
            }
            try {
                Thread.sleep(3000);
                return null;
            } catch (InterruptedException e2) {
                e2.printStackTrace();
                return null;
            }
        }

//        *******************images********************

        public void checkFileOfDirectoryImage(String str, File[] fileArr) {
            for (int i = 0; i < fileArr.length; i++) {
                if (fileArr[i].isDirectory()) {
                    String path = fileArr[i].getPath();
                    File[] fileList = Utils.getFileList(fileArr[i].getPath());
                    if (!(path == null || fileList == null || fileList.length <= 0)) {
                        checkFileOfDirectoryImage(path, fileList);
                    }
                } else {
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(fileArr[i].getPath(), options);
                    if (!(options.outWidth == -1 || options.outHeight == -1)) {
                        if (fileArr[i].getPath().endsWith(".jpg") || fileArr[i].getPath().endsWith(".jpeg") || fileArr[i].getPath().endsWith(".png") || fileArr[i].getPath().endsWith(".gif")) {
                            File file = new File(fileArr[i].getPath());
                            int parseInt = Integer.parseInt(String.valueOf(file.length()));
                            if (parseInt > 10000) {
                                this.listPhoto.add(new PhotoModel(fileArr[i].getPath(), file.lastModified(), (long) parseInt));
                                int i2 = this.number + 1;
                                this.number = i2;
                                publishProgress(Integer.valueOf(i2));
                            }
                        } else {
                            File file2 = new File(fileArr[i].getPath());
                            int parseInt2 = Integer.parseInt(String.valueOf(file2.length()));
                            if (parseInt2 > 50000) {
                                this.listPhoto.add(new PhotoModel(fileArr[i].getPath(), file2.lastModified(), (long) parseInt2));
                                int i3 = this.number + 1;
                                this.number = i3;
                                publishProgress(Integer.valueOf(i3));
                            }
                        }
                    }
                }
            }
            if (this.listPhoto.size() != 0) {
                if (!str.contains(Utils.getPathSave(MainActivity.this, getString(R.string.restore_folder_path_photo)))) {
                    AlbumPhoto albumPhoto = new AlbumPhoto();
                    albumPhoto.setStr_folder(str);
                    albumPhoto.setLastModified(new File(str).lastModified());
                    Collections.sort(this.listPhoto, new Comparator<PhotoModel>() {
                        public int compare(PhotoModel photoModel, PhotoModel photoModel2) {
                            return Long.valueOf(photoModel2.getLastModified()).compareTo(Long.valueOf(photoModel.getLastModified()));
                        }
                    });
                    albumPhoto.setListPhoto((ArrayList) this.listPhoto.clone());
                    MainActivity.mAlbumPhoto.add(albumPhoto);
                }
            }
            this.listPhoto.clear();
        }

        public void getSdCardImage() {
            String[] externalStorageDirectories = getExternalStorageDirectories();
            if (externalStorageDirectories != null && externalStorageDirectories.length > 0) {
                for (String str : externalStorageDirectories) {
                    File file = new File(str);
                    if (file.exists()) {
                        checkFileOfDirectoryImage(str, file.listFiles());
                    }
                }
            }
        }

//        ****************video******************************

        public void checkFileOfDirectoryVideo(String str, File[] fileArr) {
            if (fileArr != null) {
                for (int i = 0; i < fileArr.length; i++) {
                    if (fileArr[i].isDirectory()) {
                        String path = fileArr[i].getPath();
                        File[] fileList = Utils.getFileList(fileArr[i].getPath());
                        if (!(path == null || fileList == null || fileList.length <= 0)) {
                            checkFileOfDirectoryVideo(path, fileList);
                        }
                    } else if (fileArr[i].getPath().endsWith(".3gp") || fileArr[i].getPath().endsWith(".mp4") || fileArr[i].getPath().endsWith(".mkv") || fileArr[i].getPath().endsWith(".flv")) {
                        File file = new File(fileArr[i].getPath());
                        String substring = fileArr[i].getPath().substring(fileArr[i].getPath().lastIndexOf(".") + 1);
                        long j = 0;
                        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
                        try {
                            mediaMetadataRetriever.setDataSource(file.getPath());
                            j = Long.parseLong(mediaMetadataRetriever.extractMetadata(9));
                            mediaMetadataRetriever.release();
                        } catch (Exception unused) {
                        }
                        this.listVideo.add(new VideoModel(fileArr[i].getPath(), file.lastModified(), file.length(), substring, Utils.convertDuration(j)));
                        int i2 = this.number + 1;
                        this.number = i2;
                        publishProgress(Integer.valueOf(i2));
                    }
                }
                if (this.listVideo.size() != 0) {
                    if (!str.contains(Utils.getPathSave(MainActivity.this, getString(R.string.restore_folder_path_video)))) {
                        AlbumVideo albumVideo = new AlbumVideo();
                        albumVideo.setStr_folder(str);
                        albumVideo.setLastModified(new File(str).lastModified());
                        Collections.sort(this.listVideo, new Comparator<VideoModel>() {
                            public int compare(VideoModel videoModel, VideoModel videoModel2) {
                                return Long.valueOf(videoModel2.getLastModified()).compareTo(Long.valueOf(videoModel.getLastModified()));
                            }
                        });
                        albumVideo.setListPhoto((ArrayList) this.listVideo.clone());
                        MainActivity.mAlbumVideo.add(albumVideo);
                    }
                }
                this.listVideo.clear();
            }
        }

        public void getSdCardVideo() {
            String[] externalStorageDirectories = getExternalStorageDirectories();
            if (externalStorageDirectories != null && externalStorageDirectories.length > 0) {
                for (String str : externalStorageDirectories) {
                    File file = new File(str);
                    if (file.exists()) {
                        checkFileOfDirectoryVideo(str, file.listFiles());
                    }
                }
            }
        }

        //        *****************************Audio***************************
        public void checkFileOfDirectoryAudio(String str, File[] fileArr) {
            for (int i = 0; i < fileArr.length; i++) {
                if (fileArr[i].isDirectory()) {
                    String path = fileArr[i].getPath();
                    File[] fileList = Utils.getFileList(fileArr[i].getPath());
                    if (!(path == null || fileList == null || fileList.length <= 0)) {
                        checkFileOfDirectoryAudio(path, fileList);
                    }
                } else if (fileArr[i].getPath().endsWith(".mp3") || fileArr[i].getPath().endsWith(".aac") || fileArr[i].getPath().endsWith(".amr") || fileArr[i].getPath().endsWith(".m4a") || fileArr[i].getPath().endsWith(".ogg") || fileArr[i].getPath().endsWith(".wav") || fileArr[i].getPath().endsWith(".flac")) {
                    File file = new File(fileArr[i].getPath());
                    int parseInt = Integer.parseInt(String.valueOf(file.length()));
                    if (parseInt > 10000) {
                        this.listAudio.add(new AudioModel(fileArr[i].getPath(), file.lastModified(), (long) parseInt));
                        int i2 = this.number + 1;
                        this.number = i2;
                        publishProgress(Integer.valueOf(i2));
                    }
                }
            }
            if (this.listAudio.size() != 0) {
                if (!str.contains(Utils.getPathSave(MainActivity.this, getString(R.string.restore_folder_path_audio)))) {
                    AlbumAudio albumAudio = new AlbumAudio();
                    albumAudio.setStr_folder(str);
                    albumAudio.setLastModified(new File(str).lastModified());
                    Collections.sort(this.listAudio, new Comparator<AudioModel>() {
                        public int compare(AudioModel audioModel, AudioModel audioModel2) {
                            return Long.valueOf(audioModel2.getLastModified()).compareTo(Long.valueOf(audioModel.getLastModified()));
                        }
                    });
                    albumAudio.setListPhoto((ArrayList) this.listAudio.clone());
                    MainActivity.mAlbumAudio.add(albumAudio);
                }
            }
            this.listAudio.clear();
        }

        public void getSdCardAudio() {
            String[] externalStorageDirectories = getExternalStorageDirectories();
            if (externalStorageDirectories != null && externalStorageDirectories.length > 0) {
                for (String str : externalStorageDirectories) {
                    File file = new File(str);
                    if (file.exists()) {
                        checkFileOfDirectoryAudio(str, file.listFiles());
                    }
                }
            }
        }
    }

    public String[] getExternalStorageDirectories() {
        File[] externalFilesDirs;
        String[] split;
        boolean z;
        ArrayList arrayList = new ArrayList();
        InputStream inputStream = null;
        if ((externalFilesDirs = getExternalFilesDirs(null)) != null && externalFilesDirs.length > 0) {
            for (File file : externalFilesDirs) {
                if (!(file == null || (split = file.getPath().split("/Android")) == null || split.length <= 0)) {
                    String str = split[0];
                    z = Environment.isExternalStorageRemovable(file);
                    if (z) {
                        arrayList.add(str);
                    }
                }
            }
        }
        if (arrayList.isEmpty()) {
            String str2 = "";
            try {
                Process start = new ProcessBuilder(new String[0]).command("mount | grep /dev/block/vold").redirectErrorStream(true).start();
                start.waitFor();
                InputStream inputStream2 = start.getInputStream();
                byte[] bArr = new byte[1024];
                while (inputStream2.read(bArr) != -1) {
                    str2 = str2 + new String(bArr);
                }
                inputStream2.close();
            } catch (Exception unused) {
                if (0 != 0) {
                    try {
                        inputStream.close();
                    } catch (IOException unused2) {
                    }
                }
            }
            if (!str2.trim().isEmpty()) {
                String[] split2 = str2.split("\n");
                if (split2.length > 0) {
                    for (String str3 : split2) {
                        arrayList.add(str3.split(" ")[2]);
                    }
                }
            }
        }
        String[] strArr = new String[arrayList.size()];
        for (int i = 0; i < arrayList.size(); i++) {
            strArr[i] = (String) arrayList.get(i);
        }
        return strArr;
    }

//    **********************docs-***********************

    private void showExitDailog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_exitdialog);
        MaterialButton btnNo = bottomSheetDialog.findViewById(R.id.btnNo);
        TextView txtYesExit = bottomSheetDialog.findViewById(R.id.txtYesExit);
        txtYesExit.setOnClickListener(v -> {
            AdsManager.release(getApplication());
            finishAffinity();
            bottomSheetDialog.dismiss();
            if (mScanAsyncTask == null || mScanAsyncTask.getStatus() != AsyncTask.Status.RUNNING) {
                android.os.Process.killProcess(android.os.Process.myPid());
            } else {
                Toast.makeText(this, getString(R.string.scan_wait), Toast.LENGTH_LONG).show();
            }
        });
        btnNo.setOnClickListener(v -> bottomSheetDialog.dismiss());
        bottomSheetDialog.show();
    }

    //  ##---------------Begin: permission configuration for Storage --------

    private String[] StoragePERMISSION() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_AUDIO,
                    Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS};
        } else {
            return new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS};
        }
    }

    private void AskStoragePERMISSION() {
        ActivityCompat.requestPermissions(MainActivity.this, StoragePERMISSION(), STORAGE_REQUEST_CODE);
    }

    private boolean CheckStoragePERMISSION() {
        int result, result2, result3, result4, result5;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            result = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES);
            result2 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO);
            result3 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO);
            result4 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
            result5 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CONTACTS);
            return result == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED
                    && result3 == PackageManager.PERMISSION_GRANTED && result4 == PackageManager.PERMISSION_GRANTED
                    && result5 == PackageManager.PERMISSION_GRANTED;
        } else {
            result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            result2 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
            result3 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
            result4 = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CONTACTS);
            return result == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED
                    && result3 == PackageManager.PERMISSION_GRANTED && result4 == PackageManager.PERMISSION_GRANTED;
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] iArr) {
        super.onRequestPermissionsResult(requestCode, permissions, iArr);
        if (requestCode == 1 && iArr.length > 0 && iArr[0] == 0) {
            int i2 = iArr[1];
        }
        if (requestCode == STORAGE_REQUEST_CODE) {
            if (iArr.length > 0 && iArr[0] == PackageManager.PERMISSION_GRANTED) {
            }
        } else if (requestCode == 100) {
            for (int i2 = 0; i2 < iArr.length; i2++) {
                if (iArr.length <= 0 || iArr[i2] != 0) {
                    Toast.makeText(this, "The app was not allowed to read or write to your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    File file = new File(Utils.getPathSave(this, "RestoreAudio"));
                    if (!file.exists()) {
                        file.mkdirs();
                    }
                    File file2 = new File(Utils.getPathSave(this, "RestoreVideo"));
                    if (!file2.exists()) {
                        file2.mkdirs();
                    }
                    File file3 = new File(Utils.getPathSave(this, "RestorePhoto"));
                    if (!file3.exists()) {
                        file3.mkdirs();
                    }
                    File file4 = new File(Utils.getPathSave(this, "Docs"));
                    if (!file4.exists()) {
                        file4.mkdirs();
                    }
                }
            }
        } else if (permissions.length != 0) {
            if (iArr.length > 0) {
                int length = iArr.length;
                int i2 = 0;
                while (true) {
                    if (i2 >= length) {
                        break;
                    } else if (iArr[i2] != 0) {
                        z = false;
                        break;
                    } else {
                        i2++;
                    }
                }
                if (z) {
                    boolean z2 = false;
                    for (String str : permissions) {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, str)) {
                            Log.e("denied", str);
                            finish();
                        } else if (ActivityCompat.checkSelfPermission(this, str) == 0) {
                            Log.e("allowed", str);
                        } else {
                            Log.e("set to never ask again", str);
                            z2 = true;
                        }
                    }
                    if (z2) {
                        new AlertDialog.Builder(this).setTitle("Permissions Required").setMessage("You have forcefully denied some of the required permissions for this action. Please open settings, go to permissions and allow them.").setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", getPackageName(), null));
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        }).setCancelable(false).create().show();
                        return;
                    }
                    return;
                }
                return;
            }
            z = true;
        }
    }

    //  ##---------------End: permission configuration for Storage --------

    private void goReview() {
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener() {
            @Override
            public final void onComplete(Task task) {
                if (task.isSuccessful()) {
                    reviewInfo = (ReviewInfo) task.getResult();
                    manager.launchReviewFlow(MainActivity.this, reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                        }
                    });
                }
            }
        });
    }
}