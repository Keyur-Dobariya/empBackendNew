package com.photo.video.all.document.recovery;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.photo.video.all.document.recovery.ads.commons.AdsManager;
import com.photo.video.all.document.recovery.ads.interfaces.OnFirstData;
import com.photo.video.all.document.recovery.databinding.ActivitySplashBinding;

public class Splash_Activity extends AppCompatActivity implements OnFirstData {

    ActivitySplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.btnRetry.setVisibility(View.GONE);
                AdsManager.getFirstData(getApplication(), getApplication(), Splash_Activity.this, Splash_Activity.this);
            }
        });
        binding.btnRetry.performClick();
    }

    @Override
    public void onSuccess() {
        startActivity(new Intent(Splash_Activity.this, MainActivity.class));
        new Handler().postDelayed(this::finish, 500);
    }

    @Override
    public void onFailed() {
        binding.progress.setVisibility(View.GONE);
        binding.btnRetry.setVisibility(View.VISIBLE);
    }
}