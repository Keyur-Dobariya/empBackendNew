package com.photo.video.all.document.recovery.ads.commons

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatDialog
import com.photo.video.all.document.recovery.R

object AdDialog {

    private var rewardDialog: AppCompatDialog? = null
    private var adsDialog: AppCompatDialog? = null

    fun showAdDialog(context: Context) {
        adsDialog?.takeIf { it.isShowing }?.apply { return }
        adsDialog = AppCompatDialog(context).apply {
            supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(R.layout.ads_dialog)
            setCancelable(false)
        }
        adsDialog?.window?.apply {
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        adsDialog?.show()
    }

    fun dismissAdDialog() {
        adsDialog?.takeIf { it.isShowing }?.dismiss()
    }

    fun showRewardVideoDialog(context: Context) {
        rewardDialog?.takeIf { it.isShowing }?.apply { return }
        rewardDialog = AppCompatDialog(context).apply {
            supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(R.layout.dialog_reward)
            setCancelable(false)
        }
        rewardDialog?.window?.apply {
            setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        rewardDialog?.show()
    }

    fun dismissRewardVideoDialog() {
        rewardDialog?.takeIf { it.isShowing }?.dismiss()
    }
}