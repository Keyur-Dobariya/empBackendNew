package com.photo.video.all.document.recovery.ads.commons

import android.app.Activity
import android.content.*
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.ViewTreeObserver
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.annotation.*
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.snackbar.Snackbar
import com.google.gson.Gson
import com.photo.video.all.document.recovery.BuildConfig
import com.photo.video.all.document.recovery.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

fun View.show(flag: Boolean = true) {
    this.visibility = if (flag) View.VISIBLE else View.INVISIBLE
}

fun View.hide(flag: Boolean = true) {
    this.visibility = if (flag) View.GONE else View.VISIBLE
}

fun View.vanish(flag: Boolean = true) {
    this.visibility = if (flag) View.INVISIBLE else View.VISIBLE
}

fun Context.loadAnimation(@AnimRes id: Int): Animation = AnimationUtils.loadAnimation(this, id)
fun Context.drawable(@DrawableRes id: Int) = ContextCompat.getDrawable(this, id)
fun Context.color(@ColorRes id: Int) = ContextCompat.getColor(this, id)
fun Context.boolean(@BoolRes id: Int) = resources.getBoolean(id)
fun Context.integer(@IntegerRes id: Int) = resources.getInteger(id)
fun Context.dimen(@DimenRes id: Int) = resources.getDimension(id)
fun Context.string(@StringRes id: Int) = resources.getString(id)
fun Context.dimenPixelSize(@DimenRes id: Int) = resources.getDimensionPixelSize(id)

fun Context.stringArray(array: Int) = resources.getStringArray(array)
fun Context.intArray(array: Int) = resources.getIntArray(array)

val appVersionName: String
    get() = BuildConfig.VERSION_NAME
val appVersionCode: Int
    get() = BuildConfig.VERSION_CODE

fun String.toUri(): Uri = Uri.parse(this)
fun File.toUri(): Uri = Uri.fromFile(this)
fun String.toFile(): File = File(this)

inline fun Context.showAlertDialog(
    title: String? = getString(R.string.app_name),
    message: String,
    positiveButtonName: String = "Ok",
    negativeButtonName: String = "Cancel",
    showNegativeButton: Boolean = true,
    crossinline actionOnPositiveButton: (DialogInterface?) -> Unit
): AlertDialog {
    val builder = AlertDialog.Builder(this).apply {
        if (title != null) setTitle(title)
        setMessage(message)
        setCancelable(false)
        setPositiveButton(positiveButtonName) { dialog, _ ->
            actionOnPositiveButton(dialog)
        }
        if (showNegativeButton) setNegativeButton(negativeButtonName) { dialog, _ ->
            dialog.cancel()
        }
    }
    val alert = builder.create()
    alert.show()
    return alert
}

fun Context.toast(message: CharSequence, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, message, duration).show()
}

fun View.showSnackBar(message: CharSequence, duration: Int = Snackbar.LENGTH_SHORT) {
    Snackbar.make(this, message, duration).show()
}

fun View.snackBarWithAction(
    message: CharSequence, actionable: String, block: () -> Unit
) {
    Snackbar.make(this, message, Snackbar.LENGTH_LONG).setAction(actionable) {
        block()
    }.show()
}

fun String.getDate(): String {
    return try {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
        val netDate = Date(this.toLong().times(1000))
        sdf.format(netDate)
    } catch (e: Exception) {
        e.toString()
    }
}

private const val kilo: Long = 1000
private const val mega = kilo * kilo
private const val giga = mega * kilo
private const val tera = giga * kilo

fun Long?.getSizeInHumanReadable(): String {
    if (this == null) return ""
    var s = ""
    val kb = this.toDouble() / kilo
    val mb = kb / kilo
    val gb = mb / kilo
    val tb = gb / kilo
    if (this < kilo) {
        s = "$this Bytes"
    } else if (this in kilo until mega) {
        s = String.format("%.2f", kb) + " KB"
    } else if (this in mega until giga) {
        s = String.format("%.0f", mb) + " MB"
    } else if (this in giga until tera) {
        s = String.format("%.2f", gb) + " GB"
    } else if (this >= tera) {
        s = String.format("%.1f", tb) + " TB"
    }
    return s
}

fun String.toDuration(): String {
    this.toIntOrNull()?.let {
        val totalSecs = it / 1000
        val hours = totalSecs.toLong() / 3600
        val minutes = (totalSecs % 3600) / 60
        val seconds = totalSecs % 60
        return if (hours > 0) String.format("%02d:%02d:%02d", hours, minutes, seconds)
        else String.format("%02d:%02d", minutes, seconds)
    }
    return ""
}

//fun ImageView.loadWithGlide(path: Any) {
//    Glide.with(context)
//        .load(path)
//        .diskCacheStrategy(DiskCacheStrategy.ALL)
//        .into(this)
//}

fun <T : Any> T.loge(message: String) {
    inDebugMode { Log.e(this::class.java.simpleName, message) }
}

fun <T : Any> T.logd(message: String) {
    inDebugMode { Log.d(this::class.java.simpleName, message) }
}

fun <T : Any> T.logv(message: String) {
    inDebugMode { Log.v(this::class.java.simpleName, message) }
}

fun <T : Any> T.logw(message: String) {
    inDebugMode { Log.w(this::class.java.simpleName, message) }
}

inline fun <reified T> Context.newIntent(): Intent {
    return Intent(this, T::class.java)
}

inline fun <reified T> Context.launchActivityAndFinish(delayInMillis: Long = 0) {
    startActivity(newIntent<T>())
    handler(delayInMillis) { (this as? Activity)?.finish() }
}

inline fun <reified T> Context.launchActivity(block: Intent.() -> Unit = {}) {
    newIntent<T>().apply(block).also { startActivity(it) }
}

inline fun <reified T> Context.launchActivityForResult(
    activityResultLauncher: ActivityResultLauncher<Intent>, block: Intent.() -> Unit = {}
) {
    newIntent<T>().apply(block).also {
        activityResultLauncher.launch(it)
    }
}

fun Activity.getActivity(): Activity {
    return this
}

fun hideViews(vararg views: View) = views.asSequence().forEach { it.visibility = View.GONE }
fun showViews(vararg views: View) = views.asSequence().forEach { it.visibility = View.VISIBLE }
fun vanishViews(vararg views: View) = views.asSequence().forEach { it.visibility = View.INVISIBLE }
fun enableViews(vararg views: View) = views.asSequence().forEach { it.isEnabled = true }
fun disableViews(vararg views: View) = views.asSequence().forEach { it.isEnabled = false }

fun View.enable(bool: Boolean = true) {
    this.isEnabled = bool
}

fun View.disable(bool: Boolean = false) {
    this.isEnabled = bool
}

fun View.waitForLayout(block: () -> Unit) {
    viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() {
            viewTreeObserver.removeOnGlobalLayoutListener(this)
            block()
        }
    })
}

val Context?.isNotFinished: Boolean
    get() {
        this ?: return false
        return if (this is Activity) {
            !this.isFinishing && !this.isDestroyed
        } else {
            false
        }
    }

val Context?.isFinished: Boolean
    get() {
        this ?: return false
        return if (this is Activity) {
            this.isFinishing || this.isDestroyed
        } else {
            true
        }
    }


fun Context?.shareApp() {
    this ?: return
    try {
        Intent(Intent.ACTION_SEND).also {
            it.type = "text/plain"
            it.putExtra(Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name))
            var sAux = "\nDownload Free application\n\n"
            val appUrl = "http://play.google.com/store/apps/details?id=$packageName"
            sAux = "$sAux$appUrl\n\n "
            it.putExtra(Intent.EXTRA_TEXT, sAux)
            startActivity(Intent.createChooser(it, "Choose One"))
        }
    } catch (e: Exception) {
    }
}

fun Context?.rateApp() {
    this ?: return
    val uri = Uri.parse("market://details?id=$packageName")
    val goToMarket = Intent(Intent.ACTION_VIEW, uri)
    // To count with Play market backstack, After pressing back button,
    // to taken back to our application, we need to add following flags to intent.
    goToMarket.addFlags(
        Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
    )
    try {
        startActivity(goToMarket)
    } catch (e: ActivityNotFoundException) {
        startActivity(
            Intent(
                Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
            )
        )
    }
}

fun Context?.privacyPolicy(ppLink: String) {
    this ?: return
    try {
        val browserIntent = Intent(
            Intent.ACTION_VIEW, Uri.parse(ppLink)
        )
        startActivity(browserIntent)
    } catch (e: Exception) {
    }
}

fun Context?.sendMail(feedBack: String, email: String) {
    this ?: return
    Intent(Intent.ACTION_SENDTO).also {
        it.data = Uri.parse("mailto:")
        it.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
        it.putExtra(
            Intent.EXTRA_SUBJECT, resources.getString(R.string.app_name) + " App Feedback"
        )
        it.putExtra(Intent.EXTRA_TEXT, feedBack)
        startActivity(it)
    }
}

inline fun handler(delayMillis: Long = 0, crossinline block: () -> Unit) {
    Handler(Looper.getMainLooper()).postDelayed({
        block()
    }, delayMillis)
}

fun String?.nullToEmpty(): String {
    return this ?: ""
}

fun Long?.nullToZero(): Long {
    return this ?: 0L
}

fun Int?.nullToZero(): Int {
    return this ?: 0
}

inline val String?.isWebUrl: Boolean
    get() = if (this == null) false
    else Patterns.WEB_URL.matcher(this).find()

fun Bitmap.saveFile(path: String) {
    val f = File(path)
    if (!f.exists()) {
        f.createNewFile()
    }
    val stream = FileOutputStream(f)
    compress(Bitmap.CompressFormat.PNG, 100, stream)
    stream.flush()
    stream.close()
}

val <T : Any> T.TAG
    get() = this::class.simpleName

inline fun startTimer(
    millisInFuture: Long,
    countDownInterval: Long,
    crossinline onTick: (Long) -> Unit,
    crossinline onFinish: () -> Unit
): CountDownTimer {
    val timer = object : CountDownTimer(millisInFuture, countDownInterval) {
        override fun onTick(millisUntilFinished: Long) {
            onTick(millisUntilFinished)
        }

        override fun onFinish() {
            onFinish()
        }
    }.start()
    return timer
}

inline fun Context.registerWifiStateChanged(crossinline callback: (Intent) -> Unit): BroadcastReceiver {
    val action = "android.net.wifi.WIFI_STATE_CHANGED"
    return object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == action) {
                callback(intent)
            }
        }
    }.apply {
        val intent = IntentFilter().apply { addAction(action) }
        registerReceiver(this, intent)
    }
}

@RequiresApi(Build.VERSION_CODES.N)
inline fun Context.internetConnectivityListener(crossinline block: (Boolean) -> Unit) {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    connectivityManager.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            block(true)
        }

        override fun onLost(network: Network) {
            block(false)
        }
    })
}

inline fun ComponentActivity.handleBackPress(crossinline block: () -> Unit) {
    this.onBackPressedDispatcher.addCallback(object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            block()
        }
    })
}

fun ImageView.loadWithGlide(path: Any) {
    Glide.with(context).load(path).diskCacheStrategy(DiskCacheStrategy.ALL).into(this)
}

fun Context?.openPlayStore(pkgName: String) {
    this ?: return
    val uri = Uri.parse("market://details?id=$pkgName")
    val goToMarket = Intent(Intent.ACTION_VIEW, uri)
    // To count with Play market backstack, After pressing back button,
    // to taken back to our application, we need to add following flags to intent.
    goToMarket.addFlags(
        Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK
    )
    try {
        startActivity(goToMarket)
    } catch (e: ActivityNotFoundException) {
        startActivity(
            Intent(
                Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=$pkgName")
            )
        )
    }
}

val Context.isInternetConnected: Boolean
    get() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return connectivityManager.activeNetwork != null && connectivityManager.getNetworkCapabilities(
                connectivityManager.activeNetwork
            ) != null
        } else {
            val nwInfo = connectivityManager.activeNetworkInfo ?: return false
            return nwInfo.isConnected
        }
    }

val Context.myPreferences: SharedPreferences
    get() = getSharedPreferences(
        "${this.packageName}_myprefs", Context.MODE_PRIVATE
    )

@Suppress("UNCHECKED_CAST")
inline fun <reified T : Any> SharedPreferences.get(key: String, defaultValue: T? = null): T {
    return when (T::class) {
        Boolean::class -> getBoolean(key, defaultValue as? Boolean? ?: false) as T
        Float::class -> getFloat(key, defaultValue as? Float? ?: 0.0f) as T
        Int::class -> getInt(key, defaultValue as? Int? ?: 0) as T
        Long::class -> getLong(key, defaultValue as? Long? ?: 0L) as T
        String::class -> getString(key, defaultValue as? String? ?: "") as T
        else -> {
            if (defaultValue is Set<*>) {
                getStringSet(key, defaultValue as Set<String>) as T
            } else {
                val typeName = T::class.java.simpleName
                throw Error("Unable to get shared preference with value type '$typeName'. Use getObject")
            }
        }
    }
}

@Suppress("UNCHECKED_CAST")
inline operator fun <reified T : Any> SharedPreferences.set(key: String, value: T) {
    with(edit()) {
        when (T::class) {
            Boolean::class -> putBoolean(key, value as Boolean)
            Float::class -> putFloat(key, value as Float)
            Int::class -> putInt(key, value as Int)
            Long::class -> putLong(key, value as Long)
            String::class -> putString(key, value as String)
            else -> {
                if (value is Set<*>) {
                    putStringSet(key, value as Set<String>)
                } else {
                    val json = Gson().toJson(value)
                    putString(key, json)
                }
            }
        }
        apply()
    }
}

inline fun ioMain(crossinline workIO: suspend () -> Unit, crossinline workMain: () -> Unit) {
    CoroutineScope(Dispatchers.Default).launch {
        workIO()
        withContext(Dispatchers.Main) { workMain() }
    }
}

inline fun inReleaseMode(block: () -> Unit) {
    if (!BuildConfig.DEBUG) block()
}

inline fun inDebugMode(block: () -> Unit) {
    if (BuildConfig.DEBUG) block()
}

infix fun Int.plus(value: Int): Int = this + value