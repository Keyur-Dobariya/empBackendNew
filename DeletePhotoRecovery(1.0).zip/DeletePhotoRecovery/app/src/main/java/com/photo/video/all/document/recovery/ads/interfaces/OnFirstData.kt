package com.photo.video.all.document.recovery.ads.interfaces

interface OnFirstData {
    fun onSuccess()
    fun onFailed()
}