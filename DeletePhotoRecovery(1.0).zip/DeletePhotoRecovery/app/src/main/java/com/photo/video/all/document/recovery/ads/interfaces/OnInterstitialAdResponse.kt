package com.photo.video.all.document.recovery.ads.interfaces

interface OnInterstitialAdResponse {
    fun onAdClosed()
    fun onAdImpression()
}