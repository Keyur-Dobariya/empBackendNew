package com.photo.video.all.document.recovery.ads.interfaces

interface OnRewardAdResponse {
    fun onRewardEarned()
    fun onAdImpression()
    fun onAdCancelled()
    fun onAdFailed()
}