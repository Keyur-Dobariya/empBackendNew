package com.photo.video.all.document.recovery.ads.model

import com.google.gson.annotations.SerializedName

data class AdPrefs(
    @JvmField @field:SerializedName("splashTime") val splashTime: Int,
    @JvmField @field:SerializedName("adEnabled") val adEnabled: Boolean,
    @JvmField @field:SerializedName("adPref") val intAdPref: String,
    @JvmField @field:SerializedName("adFirstServe") val intFirstServe: String,
    @JvmField @field:SerializedName("adRoundRobin") val intRoundRobin: Boolean,
    @JvmField @field:SerializedName("nativeAdPref") val nativeAdPref: String,
    @JvmField @field:SerializedName("nativeFirstServe") val nativeFirstServe: String,
    @JvmField @field:SerializedName("nativeRoundRobin") val nativeRoundRobin: Boolean,
    @JvmField @field:SerializedName("bannerAdPref") val bannerAdPref: String,
    @JvmField @field:SerializedName("bannerFirstServe") val bannerFirstServe: String,
    @JvmField @field:SerializedName("bannerRoundRobin") val bannerRoundRobin: Boolean,
    @JvmField @field:SerializedName("inHouseEnabled") val inHouseEnabled: Boolean,
    @JvmField @field:SerializedName("iapEnabled") val iapEnabled: Boolean,
    @JvmField @field:SerializedName("appOpenEnabled") val appOpenEnabled: Boolean,
    @JvmField @field:SerializedName("splashAppOpenEnabled") val splashAppOpenEnabled: Boolean,
    @JvmField @field:SerializedName("backPressEnabled") val backPressEnabled: Boolean,
    @JvmField @field:SerializedName("rewardVideoEnabled") val rewardVideoEnabled: Boolean,
    @JvmField @field:SerializedName("rewardIntEnabled") val rewardIntEnabled: Boolean,
    @JvmField @field:SerializedName("intType") val intType: String,
    @JvmField @field:SerializedName("intSkip") val intSkip: Int,
    @JvmField @field:SerializedName("intClickInterval") val intClickInterval: Int,
    @JvmField @field:SerializedName("intTimeInterval") val intTimeInterval: Int,
    @JvmField @field:SerializedName("appOpenBackFill") val appOpenBackFill: Boolean,
    @JvmField @field:SerializedName("intBackFill") val intBackFill: Boolean,
    @JvmField @field:SerializedName("nativeBackFill") val nativeBackFill: Boolean,
    @JvmField @field:SerializedName("smallNativeBackFill") val smallNativeBackFill: Boolean,
    @JvmField @field:SerializedName("bannerBackFill") val bannerBackFill: Boolean,
    @JvmField @field:SerializedName("rewardVideoBackFill") val rewardVideoBackFill: Boolean,
    @JvmField @field:SerializedName("rewardIntBackFill") val rewardIntBackFill: Boolean,
    @JvmField @field:SerializedName("adBtnBGColor") val adBtnBGColor: String,
    @JvmField @field:SerializedName("adBtnTxtColor") val adBtnTxtColor: String,
    @JvmField @field:SerializedName("ppLink") val ppLink: String,
    @JvmField @field:SerializedName("feedBackId") val feedBackId: String,
    @JvmField @field:SerializedName("appOpenId") val appOpenId: String,
    @JvmField @field:SerializedName("appOpenIds") val appOpenIds: Array<String>,
    @JvmField @field:SerializedName("intIds") val intIds: Array<String>,
    @JvmField @field:SerializedName("nativeIds") val nativeIds: Array<String>,
    @JvmField @field:SerializedName("smallNativeIds") val smallNativeIds: Array<String>,
    @JvmField @field:SerializedName("bannerIds") val bannerIds: Array<String>,
    @JvmField @field:SerializedName("rewardIntIds") val rewardIntIds: Array<String>,
    @JvmField @field:SerializedName("rewardVideoIds") val rewardVideoIds: Array<String>,
    @JvmField @field:SerializedName("fbInt") val fbInt: String,
    @JvmField @field:SerializedName("fbNative") val fbNative: String,
    @JvmField @field:SerializedName("fbNativeBanner") val fbNativeBanner: String,
    @JvmField @field:SerializedName("fbRectBanner") val fbRectBanner: String,
    @JvmField @field:SerializedName("fbBanner") val fbBanner: String,
    @JvmField @field:SerializedName("fbRewardInt") val fbRewardInt: String,
    @JvmField @field:SerializedName("nativeScreens") val nativeScreens: String,
    @JvmField @field:SerializedName("smallNativeScreens") val smallNativeScreens: String,
    @JvmField @field:SerializedName("bannerScreens") val bannerScreens: String,
    @JvmField @field:SerializedName("inlineBannerScreens") val inlineBannerScreens: String,
    @JvmField @field:SerializedName("rewardIntScreens") val rewardIntScreens: String,
    @JvmField @field:SerializedName("rewardVideoScreens") val rewardVideoScreens: String,
    @JvmField @field:SerializedName("rewardItem") val rewardItem: Int,
    @JvmField @field:SerializedName("nativePreload") val nativePreload: Boolean,
    @JvmField @field:SerializedName("maxVer") val maxVer: Int,
    @JvmField @field:SerializedName("forcedInt") val forcedInt: Boolean,
    @JvmField @field:SerializedName("showFbRectBanner") val showFbRectBanner: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as AdPrefs

        if (!appOpenIds.contentEquals(other.appOpenIds)) return false
        if (!intIds.contentEquals(other.intIds)) return false
        if (!nativeIds.contentEquals(other.nativeIds)) return false
        if (!smallNativeIds.contentEquals(other.smallNativeIds)) return false
        if (!bannerIds.contentEquals(other.bannerIds)) return false
        if (!rewardIntIds.contentEquals(other.rewardIntIds)) return false
        if (!rewardVideoIds.contentEquals(other.rewardVideoIds)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = appOpenIds.contentHashCode()
        result = 31 * result + intIds.contentHashCode()
        result = 31 * result + nativeIds.contentHashCode()
        result = 31 * result + smallNativeIds.contentHashCode()
        result = 31 * result + bannerIds.contentHashCode()
        result = 31 * result + rewardIntIds.contentHashCode()
        result = 31 * result + rewardVideoIds.contentHashCode()
        return result
    }
}