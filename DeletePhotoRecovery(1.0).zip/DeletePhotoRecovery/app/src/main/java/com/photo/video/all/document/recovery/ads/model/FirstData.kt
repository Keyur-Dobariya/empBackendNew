package com.photo.video.all.document.recovery.ads.model

import com.google.gson.annotations.SerializedName

data class FirstData(@JvmField @field:SerializedName("data") val data: String)
