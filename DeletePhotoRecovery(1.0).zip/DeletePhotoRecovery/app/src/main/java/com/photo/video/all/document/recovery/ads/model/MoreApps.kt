package com.photo.video.all.document.recovery.ads.model

import com.google.gson.annotations.SerializedName

data class MoreApps(
    @JvmField @field:SerializedName("apps") val apps: MutableList<Apps>
) {
    data class Apps(
        @JvmField @field:SerializedName("appTitle") val appTitle: Array<String>,
        @JvmField @field:SerializedName("appDes") val appDes: Array<String>,
        @JvmField @field:SerializedName("appIcon") val appIcon: Array<String>,
        @JvmField @field:SerializedName("appNative") val appNative: Array<String>,
        @JvmField @field:SerializedName("appInt") val appInt: Array<String>,
        @JvmField @field:SerializedName("appAssetUrl") val appAssetUrl: String,
        @JvmField @field:SerializedName("appPkgName") val appPkgName: String
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as Apps

            if (!appTitle.contentEquals(other.appTitle)) return false
            if (!appDes.contentEquals(other.appDes)) return false
            if (!appIcon.contentEquals(other.appIcon)) return false
            if (!appNative.contentEquals(other.appNative)) return false
            if (!appInt.contentEquals(other.appInt)) return false
            if (appAssetUrl != other.appAssetUrl) return false
            if (appPkgName != other.appPkgName) return false

            return true
        }

        override fun hashCode(): Int {
            var result = appTitle.contentHashCode()
            result = 31 * result + appDes.contentHashCode()
            result = 31 * result + appIcon.contentHashCode()
            result = 31 * result + appNative.contentHashCode()
            result = 31 * result + appInt.contentHashCode()
            result = 31 * result + appAssetUrl.hashCode()
            result = 31 * result + appPkgName.hashCode()
            return result
        }
    }
}