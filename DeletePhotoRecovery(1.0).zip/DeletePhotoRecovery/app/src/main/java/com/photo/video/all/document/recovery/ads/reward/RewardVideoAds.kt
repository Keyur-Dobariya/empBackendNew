package com.photo.video.all.document.recovery.ads.reward

import android.app.Activity
import android.content.Context
import android.view.Window
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.AppCompatTextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.photo.video.all.document.recovery.ads.interfaces.OnRewardAdResponse
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.photo.video.all.document.recovery.R
import com.photo.video.all.document.recovery.ads.commons.*

object RewardVideoAds {

    private var googleRewardAd: RewardedAd? = null
    private var rewardIndex = -1
    private var isFailed = false

    fun load(context: Context) {
        if (!AdsUtils.isAdEnabled(context) || !AdsUtils.getAdPref(context).rewardVideoEnabled) {
            return
        }
        if (AdsUtils.getAdPref(context).rewardVideoScreens.contains("none", true)) {
            return
        }
        loadGoogle(context)
    }

    private fun loadGoogle(context: Context) {
        if (googleRewardAd != null) {
            return
        }
        isFailed = false
        val placementId = getPlacementId(context)
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(context, placementId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(p0: RewardedAd) {
                isFailed = false
                googleRewardAd = p0
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                isFailed = true
                googleRewardAd = null
                if (AdsUtils.getAdPref(context).rewardVideoBackFill) {
                    loadGoogleOnFail(context)
                }
            }
        })
    }

    private fun loadGoogleOnFail(context: Context) {
        if (!AdsUtils.isAdEnabled(context) || !AdsUtils.getAdPref(context).rewardVideoEnabled) {
            return
        }
        if (googleRewardAd != null) {
            return
        }
        isFailed = false
        val placementId = getPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            return
        }
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(context, placementId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(p0: RewardedAd) {
                super.onAdLoaded(p0)
                isFailed = false
                googleRewardAd = p0
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                isFailed = true
                googleRewardAd = null
                loadGoogleOnFail(context)
            }
        })
    }

    fun show(
        context: Context,
        screenName: String,
        key: String,
        rewardItem: Int,
        msg: String,
        @LayoutRes dialogLayout: Int,
        onRewardAdResponse: OnRewardAdResponse?
    ) {
        show(context, screenName, key, rewardItem, msg, dialogLayout, onRewardAdResponse, false)
    }

    fun show(
        context: Context,
        screenName: String,
        key: String,
        rewardItem: Int,
        msg: String,
        @LayoutRes dialogLayout: Int,
        onRewardAdResponse: OnRewardAdResponse?,
        showInterstitial: Boolean = false
    ) {
        if (!AdsUtils.isAdEnabled(context)) {
            AdsUtils.setReward(key)
            onRewardAdResponse?.onRewardEarned()
            return
        }
        if (!AdsUtils.getAdPref(context).rewardVideoEnabled) {
            if (AdsUtils.isRewardVideoEligible(context, key, rewardItem)) {
                if (showInterstitial) {
                    showInterstitialAd(context, key, onRewardAdResponse)
                } else {
                    AdsUtils.setReward(key)
                    onRewardAdResponse?.onRewardEarned()
                }
            } else {
                AdsUtils.setReward(key)
                onRewardAdResponse?.onRewardEarned()
            }
            return
        }
        val hasRewardScreen = AdsUtils.getAdPref(context).rewardVideoScreens.contains(screenName, true)
        if (!hasRewardScreen) {
            if (AdsUtils.isRewardVideoEligible(context, key, rewardItem)) {
                if (showInterstitial) {
                    showInterstitialAd(context, key, onRewardAdResponse)
                } else {
                    AdsUtils.setReward(key)
                    onRewardAdResponse?.onRewardEarned()
                }
            } else {
                AdsUtils.setReward(key)
                onRewardAdResponse?.onRewardEarned()
            }
            return
        }
        if (!AdsUtils.isRewardVideoEligible(context, key, rewardItem)) {
            AdsUtils.setReward(key)
            onRewardAdResponse?.onRewardEarned()
            return
        }
        BottomSheetDialog(context).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(dialogLayout)
            val width = (context.resources.displayMetrics.widthPixels * 0.95).toInt()
            window?.setLayout(width, -2)
            setCancelable(true)
            val txtMsg = findViewById<AppCompatTextView>(R.id.txt_msg)
            val btnOk = findViewById<MaterialButton>(R.id.btn_ok)
            val btnCancel = findViewById<MaterialButton>(R.id.btn_cancel)
            val progress = findViewById<ConstraintLayout>(R.id.lout_progress)
            txtMsg?.text = msg
            btnOk?.setOnClickListener {
                it.hide()
                btnCancel?.hide()
                progress?.show()
                showGoogle(context, key, onRewardAdResponse, this)
            }
            btnCancel?.setOnClickListener {
                if (!(context as Activity?)?.isFinishing!!) {
                    dismiss()
                }
                onRewardAdResponse?.onAdCancelled()
            }
            show()
        }
    }

    private fun showGoogle(
        context: Context, key: String, onRewardAdResponse: OnRewardAdResponse?, dialog: BottomSheetDialog
    ) {
        if (googleRewardAd == null) {
            showGoogleOnDemand(context, key, onRewardAdResponse, dialog)
        } else {
            var isCompleted = false
            handler(2500) {
                if (!(context as Activity?)?.isFinishing!!) {
                    dialog.dismiss()
                }
                googleRewardAd?.apply {
                    fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            googleRewardAd = null
                            AdsUtils.isInterstitialAdShowing = false
                            if (isCompleted) {
                                onRewardAdResponse?.onRewardEarned()
                            } else {
                                onRewardAdResponse?.onAdCancelled()
                            }
                            handler(2500) { load(context) }
                        }

                        override fun onAdShowedFullScreenContent() {
                            AdsUtils.isInterstitialAdShowing = true
                        }

                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            onRewardAdResponse?.onAdFailed()
                        }

                        override fun onAdImpression() {
                            CustomEvents.rewardVideoAd(context, CustomEvents.ADMOB)
                        }
                    }
                    show(context as Activity) {
                        AdsUtils.setReward(key)
                        isCompleted = true
                    }
                }
            }
        }
    }

    private fun showGoogleOnDemand(
        context: Context, key: String, onRewardAdResponse: OnRewardAdResponse?, dialog: BottomSheetDialog
    ) {
        val placementId = getPlacementId(context)
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(context, placementId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(rewardAd: RewardedAd) {
                super.onAdLoaded(rewardAd)
                dialog.dismiss()
                var isCompleted = false
                rewardAd.apply {
                    fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            AdsUtils.isInterstitialAdShowing = false
                            if (isCompleted) {
                                onRewardAdResponse?.onRewardEarned()
                            } else {
                                onRewardAdResponse?.onAdCancelled()
                            }
                            preload(context)
                        }

                        override fun onAdShowedFullScreenContent() {
                            AdsUtils.isInterstitialAdShowing = true
                        }

                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            onRewardAdResponse?.onAdFailed()
                            preload(context)
                        }

                        override fun onAdImpression() {
                            CustomEvents.rewardVideoAd(context, CustomEvents.ADMOB)
                        }
                    }
                    show(context as Activity) {
                        AdsUtils.setReward(key)
                        isCompleted = true
                    }
                }
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                if (AdsUtils.getAdPref(context).rewardVideoBackFill) {
                    showGoogleOnDemandOnFail(context, key, onRewardAdResponse, dialog)
                } else {
                    dialog.dismiss()
                    onRewardAdResponse?.onAdFailed()
                    preload(context)
                }
            }
        })
    }

    private fun showGoogleOnDemandOnFail(
        context: Context, key: String, onRewardAdResponse: OnRewardAdResponse?, dialog: BottomSheetDialog
    ) {
        val placementId = getPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            dialog.dismiss()
            onRewardAdResponse?.onAdFailed()
            preload(context)
            return
        }
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(context, placementId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(rewardAd: RewardedAd) {
                super.onAdLoaded(rewardAd)
                dialog.dismiss()
                var isCompleted = false
                rewardAd.apply {
                    fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            AdsUtils.isInterstitialAdShowing = false
                            if (isCompleted) {
                                onRewardAdResponse?.onRewardEarned()
                            } else {
                                onRewardAdResponse?.onAdCancelled()
                            }
                            preload(context)
                        }

                        override fun onAdShowedFullScreenContent() {
                            AdsUtils.isInterstitialAdShowing = true
                        }

                        override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                            onRewardAdResponse?.onAdFailed()
                            preload(context)
                        }

                        override fun onAdImpression() {
                            CustomEvents.rewardVideoAd(context, CustomEvents.ADMOB)
                        }
                    }
                    show(context as Activity) {
                        AdsUtils.setReward(key)
                        isCompleted = true
                    }
                }
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                showGoogleOnDemandOnFail(context, key, onRewardAdResponse, dialog)
            }
        })
    }

    private fun showInterstitialAd(
        context: Context, key: String, onRewardAdResponse: OnRewardAdResponse?
    ) {
        InterstitialAds.showForRewardAd(context, object : OnRewardAdResponse {

            override fun onRewardEarned() {
                AdsUtils.setReward(key)
                onRewardAdResponse?.onRewardEarned()
            }

            override fun onAdImpression() {
                onRewardAdResponse?.onAdImpression()
            }

            override fun onAdCancelled() {
                onRewardAdResponse?.onAdCancelled()
            }

            override fun onAdFailed() {
                onRewardAdResponse?.onAdFailed()
            }
        })
    }

    private fun preload(context: Context) {
        if (isFailed) {
            handler(2500) { load(context) }
        }
    }

    private fun getPlacementId(context: Context): String {
        val ids = AdsUtils.getAdPref(context).rewardVideoIds
        rewardIndex = 0
        return ids[rewardIndex]
    }

    private fun getPlacementIdOnFail(context: Context): String {
        val ids = AdsUtils.getAdPref(context).rewardVideoIds
        rewardIndex++
        return if (rewardIndex < ids.size) {
            ids[rewardIndex]
        } else {
            ""
        }
    }

    fun release() {
        googleRewardAd = null
    }
}