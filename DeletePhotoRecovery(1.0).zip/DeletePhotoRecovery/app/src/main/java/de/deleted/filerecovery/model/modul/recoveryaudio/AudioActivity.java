package de.deleted.filerecovery.model.modul.recoveryaudio;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.MainActivity;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityAudioBinding;

import java.util.ArrayList;

import de.deleted.filerecovery.model.modul.recoveryaudio.Model.AudioModel;
import de.deleted.filerecovery.model.modul.recoveryaudio.adapter.AudioAdapter;
import de.deleted.filerecovery.model.modul.recoveryaudio.task.RecoverAudioAsyncTask;
import de.deleted.filerecovery.ui.activity.RestoreResultActivity;

public class AudioActivity extends AppCompatActivity implements View.OnClickListener {
    AudioAdapter adapter;
    int int_position;
    ArrayList<AudioModel> mList = new ArrayList<>();
    RecoverAudioAsyncTask mRecoverPhotosAsyncTask;
    ActivityAudioBinding binding;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityAudioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
        intData();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(AudioActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void intView() {
        binding.btnBack.setOnClickListener(this);
        binding.btnRestore.setOnClickListener(this);
        binding.title.setText(getString(R.string.audio_recovery));
        binding.gvfolder.setLayoutManager(new GridLayoutManager(this, 1));
        binding.gvfolder.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBack:
                finish();
                break;
            case R.id.btnRestore:
                final ArrayList<AudioModel> selectedItem = adapter.getSelectedItem();
                if (selectedItem.size() == 0) {
                    Toast.makeText(AudioActivity.this, "Cannot restore, all items are unchecked!", Toast.LENGTH_LONG).show();
                    return;
                }
                mRecoverPhotosAsyncTask = new RecoverAudioAsyncTask(AudioActivity.this, adapter.getSelectedItem(), new RecoverAudioAsyncTask.OnRestoreListener() {
                    @Override
                    public void onComplete() {
                        Intent intent = new Intent(AudioActivity.this, RestoreResultActivity.class);
                        intent.putExtra("value", selectedItem.size());
                        intent.putExtra("type", 2);
                        startActivitys(intent);
                        adapter.setAllImagesUnseleted();
                        adapter.notifyDataSetChanged();
                        finish();
                    }
                });
                mRecoverPhotosAsyncTask.execute(new String[0]);
                break;
        }
    }

    public void intData() {
        int_position = getIntent().getIntExtra("value", 0);
        if (MainActivity.mAlbumAudio != null && MainActivity.mAlbumAudio.size() > this.int_position) {
            this.mList.addAll((ArrayList) MainActivity.mAlbumAudio.get(this.int_position).getListPhoto().clone());
        }
        adapter = new AudioAdapter(this, this.mList);
        binding.gvfolder.setAdapter(adapter);
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(AudioActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }

}