package de.deleted.filerecovery.model.modul.recoveryaudio.adapter;

import android.content.Context;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.databinding.CardAudioBinding;

import de.deleted.filerecovery.model.modul.recoveryaudio.Model.AlbumAudio;

import java.util.ArrayList;

public class AlbumsAudioAdapter extends RecyclerView.Adapter {
    ArrayList<AlbumAudio> al_menu;
    Context context;
    OnClickItemListener mOnClickItemListener;

    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(CardAudioBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false), this.mOnClickItemListener);
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        adapter_ViewHolder.binding.tvDate.setText(this.al_menu.get(i).getListPhoto().size() + " Audio");
        SectionListAudioAdapter sectionListAudioAdapter = new SectionListAudioAdapter(this.context, this.al_menu.get(i).getListPhoto(), i);
        adapter_ViewHolder.binding.recyclerviewlist.setLayoutManager(new GridLayoutManager(this.context, 1));
        adapter_ViewHolder.binding.recyclerviewlist.setAdapter(sectionListAudioAdapter);
    }

    public AlbumsAudioAdapter(Context context2, ArrayList<AlbumAudio> arrayList, OnClickItemListener onClickItemListener) {
        this.context = context2;
        this.al_menu = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        OnClickItemListener onClickItemListener;
        CardAudioBinding binding;

        public Adapter_ViewHolder(CardAudioBinding view, OnClickItemListener onClickItemListener2) {
            super(view.getRoot());
            binding = view;
            this.onClickItemListener = onClickItemListener2;
        }
        public void onClick(View view) {
            this.onClickItemListener.onClickItem(getAdapterPosition());
        }
    }

    @Override
    public int getItemCount() {
        return this.al_menu.size();
    }


}