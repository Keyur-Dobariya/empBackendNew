package de.deleted.filerecovery.model.modul.recoveryaudio.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.databinding.ItemAudioBinding;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;

import de.deleted.filerecovery.model.modul.recoveryaudio.Model.AudioModel;
import de.deleted.filerecovery.utilts.Utils;

public class AudioAdapter extends RecyclerView.Adapter {
    Context context;
    ArrayList<AudioModel> listPhoto = new ArrayList<>();

    public AudioAdapter(Context context2, ArrayList<AudioModel> arrayList) {
        this.context = context2;
        this.listPhoto = arrayList;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemAudioBinding binding;

        public Adapter_ViewHolder(ItemAudioBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemAudioBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        final AudioModel audioModel = this.listPhoto.get(i);
        adapter_ViewHolder.binding.tvType.setText(DateFormat.getDateInstance().format(Long.valueOf(audioModel.getLastModified())));
        adapter_ViewHolder.binding.tvSize.setText(Utils.formatSize(audioModel.getSizePhoto()));
        adapter_ViewHolder.binding.tvTitle.setText(Utils.getFileTitle(audioModel.getPathPhoto()));

        adapter_ViewHolder.binding.cbSelect.setChecked(audioModel.getIsCheck());
        adapter_ViewHolder.binding.cbSelect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (audioModel.getIsCheck()) {
                    adapter_ViewHolder.binding.cbSelect.setChecked(false);
                    audioModel.setIsCheck(false);
                    return;
                }
                adapter_ViewHolder.binding.cbSelect.setChecked(true);
                audioModel.setIsCheck(true);
            }
        });

        adapter_ViewHolder.binding.albumcard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    AudioAdapter.this.openFile(new File(audioModel.getPathPhoto()));
                } catch (Exception unused) {
                    unused.printStackTrace();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.listPhoto.size();
    }

    public ArrayList<AudioModel> getSelectedItem() {
        ArrayList<AudioModel> arrayList = new ArrayList<>();
        if (this.listPhoto != null) {
            for (int i = 0; i < this.listPhoto.size(); i++) {
                if (this.listPhoto.get(i).getIsCheck()) {
                    arrayList.add(this.listPhoto.get(i));
                }
            }
        }
        return arrayList;
    }

    public void setAllImagesUnseleted() {
        if (this.listPhoto != null) {
            for (int i = 0; i < this.listPhoto.size(); i++) {
                if (this.listPhoto.get(i).getIsCheck()) {
                    this.listPhoto.get(i).setIsCheck(false);
                }
            }
        }
    }

    public void openFile(File file) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        if (file.exists()) {
            if (Build.VERSION.SDK_INT < 24) {
                intent.setDataAndType(Uri.fromFile(file), "audio/*");
            } else {
                Uri uriForFile = FileProvider.getUriForFile(this.context, this.context.getPackageName() + ".provider", file);
                context.grantUriPermission(context.getPackageName(), uriForFile, 1);
                intent.setDataAndType(uriForFile, "audio/*");
                intent.setFlags(1);
            }
            this.context.startActivity(Intent.createChooser(intent, "Complete action using"));
        }
    }
}