package de.deleted.filerecovery.model.modul.recoveryaudio.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.databinding.ItemAudioAlbumBinding;
import com.photo.video.all.document.recovery.databinding.ItemAudioBinding;

import de.deleted.filerecovery.model.modul.recoveryaudio.AudioActivity;
import de.deleted.filerecovery.model.modul.recoveryaudio.Model.AudioModel;
import de.deleted.filerecovery.utilts.Utils;

import java.util.ArrayList;

public class SectionListAudioAdapter extends RecyclerView.Adapter {
    ArrayList<AudioModel> itemsList;
    private Context mContext;
    int postion;
    int size;

    public SectionListAudioAdapter(Context context, ArrayList<AudioModel> arrayList, int i) {
        this.itemsList = arrayList;
        this.mContext = context;
        this.postion = i;
        if (arrayList.size() >= 1) {
            this.size = 1;
        } else {
            this.size = arrayList.size();
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemAudioAlbumBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }


    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        adapter_ViewHolder.binding.albumcard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(mContext, AudioActivity.class);
                intent.putExtra("value", SectionListAudioAdapter.this.postion);
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.size;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemAudioAlbumBinding binding;

        public Adapter_ViewHolder(ItemAudioAlbumBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }
}