package de.deleted.filerecovery.model.modul.recoveryphoto;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityPhotosBinding;

import java.util.ArrayList;

import de.deleted.filerecovery.model.modul.recoveryphoto.Model.PhotoModel;
import de.deleted.filerecovery.model.modul.recoveryphoto.adapter.PhotoAdapter;
import de.deleted.filerecovery.model.modul.recoveryphoto.task.RecoverPhotosAsyncTask;

import com.photo.video.all.document.recovery.MainActivity;

import de.deleted.filerecovery.ui.activity.RestoreResultActivity;

public class PhotosActivity extends AppCompatActivity implements View.OnClickListener {
    PhotoAdapter adapter;
    int int_position;
    ArrayList<PhotoModel> mList = new ArrayList<>();
    RecoverPhotosAsyncTask mRecoverPhotosAsyncTask;
    ActivityPhotosBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityPhotosBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
        intData();


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(PhotosActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void intView() {
        binding.btnBack.setOnClickListener(this);
        binding.btnRestore.setOnClickListener(this);
        binding.title.setText(getString(R.string.photo_recovery));
        binding.gvfolder.setLayoutManager(new GridLayoutManager(this, 2));
        binding.gvfolder.addItemDecoration(new GridSpacingItemDecoration(2, dpToPx(2), true));
        binding.gvfolder.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBack:
                finish();
                break;
            case R.id.btnRestore:
                final ArrayList<PhotoModel> selectedItem = adapter.getSelectedItem();
                if (selectedItem.size() == 0) {
                    Toast.makeText(PhotosActivity.this, "Cannot restore, all items are unchecked!", Toast.LENGTH_LONG).show();
                    return;
                }
                mRecoverPhotosAsyncTask = new RecoverPhotosAsyncTask(PhotosActivity.this, adapter.getSelectedItem(), new RecoverPhotosAsyncTask.OnRestoreListener() {
                    @Override
                    public void onComplete() {
                        Intent intent = new Intent(PhotosActivity.this.getApplicationContext(), RestoreResultActivity.class);
                        intent.putExtra("value", selectedItem.size());
                        intent.putExtra("type", 0);
                        startActivitys(intent);
                        adapter.setAllImagesUnseleted();
                        adapter.notifyDataSetChanged();
                        finish();
                    }
                });
                mRecoverPhotosAsyncTask.execute(new String[0]);
                break;
        }
    }

    public void intData() {
        this.int_position = getIntent().getIntExtra("value", 0);
        if (MainActivity.mAlbumPhoto != null && MainActivity.mAlbumPhoto.size() > this.int_position) {
            this.mList.addAll((ArrayList) MainActivity.mAlbumPhoto.get(this.int_position).getListPhoto().clone());
        }
        adapter = new PhotoAdapter(this, this.mList);
        binding.gvfolder.setAdapter(adapter);
    }

    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {
        private boolean includeEdge;
        private int spacing;
        private int spanCount;

        public GridSpacingItemDecoration(int i, int i2, boolean z) {
            this.spanCount = i;
            this.spacing = i2;
            this.includeEdge = z;
        }

        @Override
        public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
            int childAdapterPosition = recyclerView.getChildAdapterPosition(view);
            int i = this.spanCount;
            int i2 = childAdapterPosition % i;
            if (this.includeEdge) {
                int i3 = this.spacing;
                rect.left = i3 - ((i2 * i3) / i);
                rect.right = ((i2 + 1) * this.spacing) / this.spanCount;
                if (childAdapterPosition < this.spanCount) {
                    rect.top = this.spacing;
                }
                rect.bottom = this.spacing;
                return;
            }
            rect.left = (this.spacing * i2) / i;
            int i4 = this.spacing;
            rect.right = i4 - (((i2 + 1) * i4) / this.spanCount);
            if (childAdapterPosition >= this.spanCount) {
                rect.top = this.spacing;
            }
        }
    }

    private int dpToPx(int i) {
        return Math.round(TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics()));
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(PhotosActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }

}