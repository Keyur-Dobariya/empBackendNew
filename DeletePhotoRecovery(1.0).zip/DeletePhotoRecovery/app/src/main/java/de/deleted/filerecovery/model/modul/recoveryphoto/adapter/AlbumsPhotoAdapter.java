package de.deleted.filerecovery.model.modul.recoveryphoto.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.databinding.CardAlbumNewBinding;
import com.photo.video.all.document.recovery.databinding.CardAudioBinding;

import java.util.ArrayList;

import de.deleted.filerecovery.model.modul.recoveryaudio.adapter.AlbumsAudioAdapter;
import de.deleted.filerecovery.model.modul.recoveryphoto.Model.AlbumPhoto;

public class AlbumsPhotoAdapter extends RecyclerView.Adapter {
    ArrayList<AlbumPhoto> al_menu;
    Context context;
    OnClickItemListener mOnClickItemListener;

    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    public AlbumsPhotoAdapter(Context context2, ArrayList<AlbumPhoto> arrayList, OnClickItemListener onClickItemListener) {
        this.context = context2;
        this.al_menu = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        OnClickItemListener onClickItemListener;

        CardAlbumNewBinding binding;

        public Adapter_ViewHolder(CardAlbumNewBinding view, OnClickItemListener onClickItemListener2) {
            super(view.getRoot());
            binding = view;
            binding.recyclerviewlist.setOnClickListener(this);
        }

        public void onClick(View view) {
            this.onClickItemListener.onClickItem(getAdapterPosition());
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(CardAlbumNewBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false), this.mOnClickItemListener);
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        adapter_ViewHolder.binding.tvfolder2.setText(this.al_menu.get(i).getListPhoto().size() + " Pictures");
        SectionListDataAdapter sectionListDataAdapter = new SectionListDataAdapter(this.context, this.al_menu.get(i).getListPhoto(), i);
        adapter_ViewHolder.binding.recyclerviewlist.setLayoutManager(new GridLayoutManager(this.context, 1));
        adapter_ViewHolder.binding.recyclerviewlist.setAdapter(sectionListDataAdapter);
    }

    @Override
    public int getItemCount() {
        return this.al_menu.size();
    }


}