package de.deleted.filerecovery.model.modul.recoveryphoto.adapter;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.databinding.CardPhotoBinding;

import java.text.DateFormat;
import java.util.ArrayList;

import de.deleted.filerecovery.model.modul.recoveryphoto.Model.PhotoModel;
import de.deleted.filerecovery.utilts.Utils;

public class PhotoAdapter extends RecyclerView.Adapter {
    Context context;
    ArrayList<PhotoModel> listPhoto = new ArrayList<>();
    BitmapDrawable placeholder;

    public PhotoAdapter(Context context2, ArrayList<PhotoModel> arrayList) {
        this.context = context2;
        this.listPhoto = arrayList;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {

        CardPhotoBinding binding;

        public Adapter_ViewHolder(CardPhotoBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(CardPhotoBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }


    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        final PhotoModel photoModel = this.listPhoto.get(i);
        adapter_ViewHolder.binding.tvDate.setText(DateFormat.getDateInstance().format(Long.valueOf(photoModel.getLastModified())));
        adapter_ViewHolder.binding.tvSize.setText(Utils.formatSize(photoModel.getSizePhoto()));
        if (photoModel.getIsCheck()) {
            adapter_ViewHolder.binding.isChecked.setVisibility(View.VISIBLE);
            adapter_ViewHolder.binding.isUnChecked.setVisibility(View.GONE);
        } else {
            adapter_ViewHolder.binding.isChecked.setVisibility(View.GONE);
            adapter_ViewHolder.binding.isUnChecked.setVisibility(View.VISIBLE);
        }
        try {
            ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).
                    load("file://" + photoModel.getPathPhoto()).diskCacheStrategy(DiskCacheStrategy.ALL)).
                    priority(Priority.HIGH)).centerCrop()).error(R.drawable.ic_error)).placeholder(this.placeholder)).into(adapter_ViewHolder.binding.ivimage);
        } catch (Exception e) {
            Toast.makeText(this.context, "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        adapter_ViewHolder.binding.albumcard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (photoModel.getIsCheck()) {
                    adapter_ViewHolder.binding.isChecked.setVisibility(View.GONE);
                    adapter_ViewHolder.binding.isUnChecked.setVisibility(View.VISIBLE);
                    photoModel.setIsCheck(false);
                    return;
                }
                adapter_ViewHolder.binding.isChecked.setVisibility(View.VISIBLE);
                adapter_ViewHolder.binding.isUnChecked.setVisibility(View.GONE);
                photoModel.setIsCheck(true);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.listPhoto.size();
    }

    public ArrayList<PhotoModel> getSelectedItem() {
        ArrayList<PhotoModel> arrayList = new ArrayList<>();
        if (this.listPhoto != null) {
            for (int i = 0; i < this.listPhoto.size(); i++) {
                if (this.listPhoto.get(i).getIsCheck()) {
                    arrayList.add(this.listPhoto.get(i));
                }
            }
        }
        return arrayList;
    }

    public void setAllImagesUnseleted() {
        if (this.listPhoto != null) {
            for (int i = 0; i < this.listPhoto.size(); i++) {
                if (this.listPhoto.get(i).getIsCheck()) {
                    this.listPhoto.get(i).setIsCheck(false);
                }
            }
        }
    }
}