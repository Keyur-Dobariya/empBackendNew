package de.deleted.filerecovery.model.modul.recoveryphoto.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.databinding.ItemAudioAlbumBinding;
import com.photo.video.all.document.recovery.databinding.ItemImageBinding;

import de.deleted.filerecovery.model.modul.recoveryaudio.adapter.SectionListAudioAdapter;
import de.deleted.filerecovery.utilts.SquareImageView;
import de.deleted.filerecovery.model.modul.recoveryphoto.Model.PhotoModel;
import de.deleted.filerecovery.model.modul.recoveryphoto.PhotosActivity;

import java.util.ArrayList;

public class SectionListDataAdapter extends RecyclerView.Adapter {
    private ArrayList<PhotoModel> itemsList;
    private Context mContext;
    int postion;
    int size;

    public SectionListDataAdapter(Context context, ArrayList<PhotoModel> arrayList, int i) {
        this.itemsList = arrayList;
        this.mContext = context;
        this.postion = i;
        if (arrayList.size() >= 5) {
            this.size = 5;
        } else {
            this.size = arrayList.size();
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(ItemImageBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }


    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        try {
            ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.mContext).
                    load("file://" + this.itemsList.get(i).getPathPhoto()).diskCacheStrategy(DiskCacheStrategy.ALL)).
                    priority(Priority.HIGH)).centerCrop()).error(R.drawable.ic_error)).into(adapter_ViewHolder.binding.ivImage);
        } catch (Exception e) {
            Toast.makeText(this.mContext, "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        adapter_ViewHolder.binding.ivImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(SectionListDataAdapter.this.mContext, PhotosActivity.class);
                intent.putExtra("value", SectionListDataAdapter.this.postion);
                SectionListDataAdapter.this.mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.size;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        ItemImageBinding binding;

        public Adapter_ViewHolder(ItemImageBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }
}