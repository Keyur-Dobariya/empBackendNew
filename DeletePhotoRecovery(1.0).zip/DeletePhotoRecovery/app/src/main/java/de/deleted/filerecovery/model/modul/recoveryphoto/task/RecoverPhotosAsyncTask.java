package de.deleted.filerecovery.model.modul.recoveryphoto.task;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.widget.TextView;

import com.photo.video.all.document.recovery.R;

import de.deleted.filerecovery.model.modul.recoveryphoto.Model.PhotoModel;
import de.deleted.filerecovery.ui.activity.LoadingDialog;
import de.deleted.filerecovery.utilts.MediaScanner;
import de.deleted.filerecovery.utilts.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

public class RecoverPhotosAsyncTask extends AsyncTask<String, Integer, String> {
    private final String TAG = getClass().getName();
    int count = 0;
    private ArrayList<PhotoModel> listPhoto;
    private Context mContext;
    private OnRestoreListener onRestoreListener;
    private LoadingDialog progressDialog;
    TextView tvNumber;

    public interface OnRestoreListener {
        void onComplete();
    }

    public RecoverPhotosAsyncTask(Context context, ArrayList<PhotoModel> arrayList, OnRestoreListener onRestoreListener2) {
        this.mContext = context;
        this.listPhoto = arrayList;
        this.onRestoreListener = onRestoreListener2;
    }

    public void onPreExecute() {
        super.onPreExecute();
        progressDialog = new LoadingDialog(this.mContext);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    public String doInBackground(String... strArr) {
        for (int i = 0; i < this.listPhoto.size(); i++) {
            File file = new File(this.listPhoto.get(i).getPathPhoto());
            Context context = this.mContext;
            File file2 = new File(Utils.getPathSave(context, context.getString(R.string.restore_folder_path_photo)));
            StringBuilder sb = new StringBuilder();
            Context context2 = this.mContext;
            sb.append(Utils.getPathSave(context2, context2.getString(R.string.restore_folder_path_photo)));
            sb.append(File.separator);
            sb.append(getFileName(this.listPhoto.get(i).getPathPhoto()));
            File file3 = new File(sb.toString());
            try {
                if (!file3.exists()) {
                    file2.mkdirs();
                }
                copy(file, file3);
                if (Build.VERSION.SDK_INT >= 19) {
                    Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
                    intent.setData(Uri.fromFile(file3));
                    this.mContext.sendBroadcast(intent);
                }
                new MediaScanner(this.mContext, file3);
                int i2 = i + 1;
                this.count = i2;
                publishProgress(Integer.valueOf(i2));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            Thread.sleep(2000);
            return null;
        } catch (InterruptedException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public void copy(File file, File file2) throws IOException {
        FileChannel channel = new FileInputStream(file).getChannel();
        FileChannel channel2 = new FileOutputStream(file2).getChannel();
        channel.transferTo(0, channel.size(), channel2);
        if (channel != null) {
            channel.close();
        }
        if (channel2 != null) {
            channel2.close();
        }
    }

    public String getFileName(String str) {
        String substring = str.substring(str.lastIndexOf("/") + 1);
        return (substring.endsWith(".jpg") || substring.endsWith(".jpeg") || substring.endsWith(".gif")) ? substring : substring + ".jpg";
    }

    public void onPostExecute(String str) {
        super.onPostExecute(str);
        try {
            if (progressDialog != null && progressDialog.isShowing()) {
                this.progressDialog.dismiss();
                this.progressDialog = null;
            }
        } catch (Exception unused) {
        }
        if (onRestoreListener != null) {
            onRestoreListener.onComplete();
        }
    }

    public void onProgressUpdate(Integer... numArr) {
        super.onProgressUpdate(numArr);
        tvNumber= (TextView) this.progressDialog.findViewById(R.id.tvNumber);
        tvNumber.setText(String.format(this.mContext.getString(R.string.restoring_number_format), numArr[0]));
    }
}