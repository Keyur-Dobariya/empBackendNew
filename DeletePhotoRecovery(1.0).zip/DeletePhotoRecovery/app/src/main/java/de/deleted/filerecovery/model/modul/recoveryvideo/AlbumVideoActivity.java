package de.deleted.filerecovery.model.modul.recoveryvideo;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityAlbumvideoBinding;

import de.deleted.filerecovery.model.modul.recoveryvideo.adapter.AlbumsVideoAdapter;

import com.photo.video.all.document.recovery.MainActivity;

public class AlbumVideoActivity extends AppCompatActivity implements AlbumsVideoAdapter.OnClickItemListener, View.OnClickListener {
    AlbumsVideoAdapter adapter;
    ActivityAlbumvideoBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityAlbumvideoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
        intData();

//        **********small native*******************
        new SmallNativeAds(screenName).showAd(this, binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(AlbumVideoActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBack:
                finish();
                break;
        }
    }

    @Override
    public void onClickItem(int i) {
        Intent intent = new Intent(AlbumVideoActivity.this, VideoActivity.class);
        intent.putExtra("value", i);
        startActivitys(intent);
    }

    public void intView() {
        binding.btnBack.setOnClickListener(this);
        binding.title.setText(getString(R.string.video_recovery));
        binding.gvfolder.setLayoutManager(new GridLayoutManager(this, 2));
        binding.gvfolder.setItemAnimator(new DefaultItemAnimator());
    }

    public void intData() {
        adapter = new AlbumsVideoAdapter(this, MainActivity.mAlbumVideo, this);
        binding.gvfolder.setAdapter(adapter);
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(AlbumVideoActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}