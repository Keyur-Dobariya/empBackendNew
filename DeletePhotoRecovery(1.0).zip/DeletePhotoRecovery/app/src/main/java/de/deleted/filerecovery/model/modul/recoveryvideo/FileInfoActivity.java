package de.deleted.filerecovery.model.modul.recoveryvideo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.provider.DocumentsContract;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentActivity;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.NativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityFileInfoBinding;

import java.io.File;
import java.security.AccessController;
import java.text.DateFormat;

import de.deleted.filerecovery.model.modul.recoveryvideo.Model.VideoModel;
import de.deleted.filerecovery.model.modul.recoveryvideo.task.RecoverOneVideosAsyncTask;
import de.deleted.filerecovery.ui.activity.RestoreResultActivity;
import de.deleted.filerecovery.utilts.Utils;

public class FileInfoActivity extends AppCompatActivity implements View.OnClickListener {
    RecoverOneVideosAsyncTask mRecoverOneVideosAsyncTask;
    VideoModel mVideoModel;
    SharedPreferences sharedPreferences;
    ActivityFileInfoBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityFileInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();
        intData();

//        ********native**************************

        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(FileInfoActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        cancleUIUPdate();
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void intView() {
        binding.btnOpen.setOnClickListener(this);
        binding.btnShare.setOnClickListener(this);
        binding.btnRestore.setOnClickListener(this);
        binding.ivVideo.setOnClickListener(this);
        binding.btnBack.setOnClickListener(this);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnOpen:
                openFile(this.mVideoModel.getPathPhoto());
                return;
            case R.id.btnRestore:
                RecoverOneVideosAsyncTask recoverOneVideosAsyncTask = new RecoverOneVideosAsyncTask(this, this.mVideoModel, new RecoverOneVideosAsyncTask.OnRestoreListener() {
                    @Override
                    public void onComplete() {
                        Intent intent = new Intent(FileInfoActivity.this, RestoreResultActivity.class);
                        intent.putExtra("value", 1);
                        startActivitys(intent);
                        finish();
                    }
                });
                this.mRecoverOneVideosAsyncTask = recoverOneVideosAsyncTask;
                recoverOneVideosAsyncTask.execute(new String[0]);
                return;
            case R.id.btnShare:
                shareVideo(this.mVideoModel.getPathPhoto());
                return;
            case R.id.ivVideo:
                openFile(this.mVideoModel.getPathPhoto());
                return;
            case R.id.btnBack:
                finish();
                break;
            default:
                return;
        }
    }

    public void intData() {
        mVideoModel = (VideoModel) getIntent().getSerializableExtra("ojectVideo");
        binding.tvDate.setText(DateFormat.getDateInstance().format(Long.valueOf(this.mVideoModel.getLastModified())) + "  " + this.mVideoModel.getTimeDuration());
        binding.tvSize.setText(Utils.formatSize(this.mVideoModel.getSizePhoto()));
        binding.tvType.setText(this.mVideoModel.getTypeFile());
        ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with((FragmentActivity) this).load("file://" + this.mVideoModel.getPathPhoto()).diskCacheStrategy(DiskCacheStrategy.ALL)).priority(Priority.HIGH)).centerCrop()).error(R.drawable.ic_error)).into(binding.ivVideo);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    }

    public void cancleUIUPdate() {
        if (mRecoverOneVideosAsyncTask != null && mRecoverOneVideosAsyncTask.getStatus() == AsyncTask.Status.RUNNING) {
            this.mRecoverOneVideosAsyncTask.cancel(true);
            this.mRecoverOneVideosAsyncTask = null;
        }
    }

    public void openFile(String str) {
        Intent intent;
        if (Build.VERSION.SDK_INT < 24) {
            Intent intent2 = new Intent("android.intent.action.VIEW");
            intent2.setDataAndType(Uri.fromFile(new File(str)), "video/*");
            intent = Intent.createChooser(intent2, "Complete action using");
        } else {
            File file = new File(str);
            Intent intent3 = new Intent("android.intent.action.VIEW");
            Uri uriForFile = FileProvider.getUriForFile(this, getPackageName() + ".provider", file);
            grantUriPermission(getPackageName(), uriForFile, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent3.setType("*/*");
            if (Build.VERSION.SDK_INT < 24) {
                uriForFile = Uri.fromFile(file);
            }
            intent3.setData(uriForFile);
            intent3.setFlags(1);
            intent = Intent.createChooser(intent3, "Complete action using");
        }
        startActivity(intent);
    }

    private void shareVideo(String str) {
        startActivity(Intent.createChooser(new Intent().setAction("android.intent.action.SEND").setType("video/*").setFlags(1).putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(str))), ""));
    }


    private static boolean checkIfSDCardRoot(Uri uri) {
        return isExternalStorageDocument(uri) && isRootUri(uri) && !isInternalStorage(uri);
    }

    private static boolean isRootUri(Uri uri) {
        return DocumentsContract.getTreeDocumentId(uri).endsWith(":");
    }

    public static boolean isInternalStorage(Uri uri) {
        return isExternalStorageDocument(uri) && DocumentsContract.getTreeDocumentId(uri).contains("primary");
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        boolean z;
        super.onActivityResult(i, i2, intent);
        if (i == 100 && i2 == -1) {
            SharedPreferences.Editor edit = this.sharedPreferences.edit();
            if (intent != null) {
                Uri data = intent.getData();
                if (Build.VERSION.SDK_INT >= 19 && AccessController.getContext() != null) {
                    getContentResolver().takePersistableUriPermission(data, 3);
                }
                z = true;
                if (checkIfSDCardRoot(data)) {
                    edit.putString("sdCardUri", data.toString());
                    edit.putBoolean("storagePermission", true);
                    if (edit.commit()) {
                        edit.apply();
                        if (z) {
                            RecoverOneVideosAsyncTask recoverOneVideosAsyncTask = new RecoverOneVideosAsyncTask(this, this.mVideoModel, new RecoverOneVideosAsyncTask.OnRestoreListener() {
                                @Override
                                public void onComplete() {
                                    Intent intent = new Intent(FileInfoActivity.this, RestoreResultActivity.class);
                                    intent.putExtra("value", 1);
                                    intent.putExtra("type", 1);
                                    startActivitys(intent);
                                    finish();
                                }
                            });
                            this.mRecoverOneVideosAsyncTask = recoverOneVideosAsyncTask;
                            recoverOneVideosAsyncTask.execute(new String[0]);
                        }
                    }
                } else {
                    Toast.makeText(this, "Please Select Right SD Card.", Toast.LENGTH_SHORT).show();
                    edit.putBoolean("storagePermission", false);
                    edit.putString("sdCardUri", "");
                }
            } else {
                Toast.makeText(this, "Please Select Right SD Card.", Toast.LENGTH_SHORT).show();
                edit.putString("sdCardUri", "");
            }
            z = false;
            if (edit.commit()) {
            }
        }
        if (i == 200 && i2 == -1) {
            finish();
        }
    }


    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(FileInfoActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}