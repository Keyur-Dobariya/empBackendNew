package de.deleted.filerecovery.model.modul.recoveryvideo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.photo.video.all.document.recovery.databinding.CardAlbumNewBinding;

import java.util.ArrayList;

import de.deleted.filerecovery.model.modul.recoveryvideo.Model.AlbumVideo;

public class AlbumsVideoAdapter extends RecyclerView.Adapter {
    ArrayList<AlbumVideo> al_menu;
    Context context;
    OnClickItemListener mOnClickItemListener;

    public interface OnClickItemListener {
        void onClickItem(int i);
    }

    public AlbumsVideoAdapter(Context context2, ArrayList<AlbumVideo> arrayList, OnClickItemListener onClickItemListener) {
        this.context = context2;
        this.al_menu = arrayList;
        this.mOnClickItemListener = onClickItemListener;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        OnClickItemListener onClickItemListener;

        CardAlbumNewBinding binding;

        public Adapter_ViewHolder(CardAlbumNewBinding view, OnClickItemListener onClickItemListener2) {
            super(view.getRoot());
            binding = view;
            this.onClickItemListener = onClickItemListener2;
            binding.recyclerviewlist.setOnClickListener(this);
        }

        public void onClick(View view) {
            this.onClickItemListener.onClickItem(getAdapterPosition());
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(CardAlbumNewBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false), this.mOnClickItemListener);
    }


    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        adapter_ViewHolder.binding.tvfolder2.setText(this.al_menu.get(i).getListPhoto().size() + " Videos");
        SectionListDataAdapter sectionListDataAdapter = new SectionListDataAdapter(this.context, this.al_menu.get(i).getListPhoto(), i);
        adapter_ViewHolder.binding.recyclerviewlist.setLayoutManager(new GridLayoutManager(this.context, 1));
        adapter_ViewHolder.binding.recyclerviewlist.setAdapter(sectionListDataAdapter);
    }

    @Override
    public int getItemCount() {
        return this.al_menu.size();
    }

}