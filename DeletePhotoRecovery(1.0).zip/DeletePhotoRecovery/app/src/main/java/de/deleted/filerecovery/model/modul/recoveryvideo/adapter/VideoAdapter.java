package de.deleted.filerecovery.model.modul.recoveryvideo.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.databinding.CardVideoBinding;
import com.photo.video.all.document.recovery.databinding.ItemAudioBinding;

import de.deleted.filerecovery.model.modul.recoveryaudio.adapter.AudioAdapter;
import de.deleted.filerecovery.utilts.SquareImageView;
import de.deleted.filerecovery.model.modul.recoveryvideo.FileInfoActivity;
import de.deleted.filerecovery.model.modul.recoveryvideo.Model.VideoModel;
import de.deleted.filerecovery.utilts.Utils;

import java.text.DateFormat;
import java.util.ArrayList;

public class VideoAdapter extends RecyclerView.Adapter {
    Context context;
    ArrayList<VideoModel> listPhoto = new ArrayList<>();

    public VideoAdapter(Context context2, ArrayList<VideoModel> arrayList) {
        this.context = context2;
        this.listPhoto = arrayList;
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {

        CardVideoBinding binding;

        public Adapter_ViewHolder(CardVideoBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(CardVideoBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }


    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        final VideoModel videoModel = this.listPhoto.get(i);
        adapter_ViewHolder.binding.tvDate.setText(DateFormat.getDateInstance().format(Long.valueOf(videoModel.getLastModified())) + "  " + videoModel.getTimeDuration());
        adapter_ViewHolder.binding.tvSize.setText(Utils.formatSize(videoModel.getSizePhoto()));
        adapter_ViewHolder.binding.tvType.setText(videoModel.getTypeFile());
        try {
            ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) ((RequestBuilder) Glide.with(this.context).load("file://" + videoModel.getPathPhoto()).diskCacheStrategy(DiskCacheStrategy.ALL)).priority(Priority.HIGH)).centerCrop()).error(R.drawable.ic_error)).into(adapter_ViewHolder.binding.ivimage);
        } catch (Exception e) {
            Toast.makeText(this.context, "Exception: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        adapter_ViewHolder.binding.albumcard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                InterstitialAds.showAd(context, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        Intent intent = new Intent(VideoAdapter.this.context, FileInfoActivity.class);
                        intent.putExtra("ojectVideo", videoModel);
                        VideoAdapter.this.context.startActivity(intent);
                    }
                    @Override
                    public void onAdImpression() {

                    }
                });

            }
        });
        adapter_ViewHolder.binding.cbSelected.setChecked(videoModel.getIsCheck());
        adapter_ViewHolder.binding.cbSelected.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (adapter_ViewHolder.binding.cbSelected.isChecked()) {
                    videoModel.setIsCheck(true);
                } else {
                    videoModel.setIsCheck(false);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.listPhoto.size();
    }

    public ArrayList<VideoModel> getSelectedItem() {
        ArrayList<VideoModel> arrayList = new ArrayList<>();
        if (this.listPhoto != null) {
            for (int i = 0; i < this.listPhoto.size(); i++) {
                if (this.listPhoto.get(i).getIsCheck()) {
                    arrayList.add(this.listPhoto.get(i));
                }
            }
        }
        return arrayList;
    }

    public void setAllImagesUnseleted() {
        if (this.listPhoto != null) {
            for (int i = 0; i < this.listPhoto.size(); i++) {
                if (this.listPhoto.get(i).getIsCheck()) {
                    this.listPhoto.get(i).setIsCheck(false);
                }
            }
        }
    }
}