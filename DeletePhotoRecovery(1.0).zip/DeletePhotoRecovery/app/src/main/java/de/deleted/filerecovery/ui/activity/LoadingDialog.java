package de.deleted.filerecovery.ui.activity;

import android.app.Dialog;
import android.content.Context;

import com.photo.video.all.document.recovery.R;

public class LoadingDialog extends Dialog {
    Context mContext;

    public LoadingDialog(Context context) {
        super(context);
        this.mContext = context;
        setContentView(R.layout.layout_loading_dialog);
    }
}