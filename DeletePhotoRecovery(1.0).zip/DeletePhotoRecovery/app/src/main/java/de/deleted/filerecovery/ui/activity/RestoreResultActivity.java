package de.deleted.filerecovery.ui.activity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.nativee.NativeAds;
import com.photo.video.all.document.recovery.databinding.ActivityRestoreResultBinding;

public class RestoreResultActivity extends AppCompatActivity implements View.OnClickListener {
    String mName = "";
    String path = "";
    int type = 0;
    ActivityRestoreResultBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = ActivityRestoreResultBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        intView();

        //        *********native************************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(RestoreResultActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBack:
                finish();
                break;
        }
    }

    public void intView() {
        type = getIntent().getIntExtra("type", 0);
        binding.btnBack.setOnClickListener(this);
        if (type == 0) {
            mName = getString(R.string.photo_recovery);
            path = getString(R.string.restore_folder_path_photo);
        }
        if (type == 1) {
            mName = getString(R.string.video_recovery);
            path = getString(R.string.restore_folder_path_video);
        }
        if (type == 2) {
            mName = getString(R.string.audio_recovery);
            path = getString(R.string.restore_folder_path_audio);
        }
        binding.title.setText(this.mName);
        binding.tvStatus.setText(String.valueOf(getIntent().getIntExtra("value", 0)));
        binding.tvPath.setText("File Restored to\\n/\" + this.path");
    }

}