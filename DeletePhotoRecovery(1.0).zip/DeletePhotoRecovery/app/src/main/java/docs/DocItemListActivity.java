package docs;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.photo.video.all.document.recovery.MainActivity;
import com.photo.video.all.document.recovery.R;
import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.ads.nativee.SmallNativeAds;
import com.photo.video.all.document.recovery.databinding.DocActivityItemlistBinding;

import java.util.ArrayList;

import docs.adapter.ItemListAdapter;
import docs.async.RestoreToGallery;
import docs.fordata.FilesCollecter;

public class DocItemListActivity extends AppCompatActivity implements View.OnClickListener {
    public static ArrayList<Integer> selectedImagePosition;
    ItemListAdapter adapter;
    int position;

    DocActivityItemlistBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        window.clearFlags(67108864);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.state_bar));
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        binding = DocActivityItemlistBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        selectedImagePosition = new ArrayList<>();
        bindView();
        adapter = new ItemListAdapter(this);
        binding.gvRestoreImage.setAdapter(this.adapter);
        binding.gvRestoreImage.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectedImagePosition.contains(Integer.valueOf(position))) {
                    selectedImagePosition.remove(Integer.valueOf(position));
                    setSelAll();
                    return;
                }
                selectedImagePosition.add(Integer.valueOf(position));
                setSelAll();
            }
        });
        binding.gvRestoreImage.setAdapter((ListAdapter) this.adapter);


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(DocItemListActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        startActivity(new Intent(DocItemListActivity.this, MainActivity.class));
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void setSelAll() {
        if (selectedImagePosition.size() == FilesCollecter.selected.size()) {
            binding.selAll.setImageResource(R.drawable.select_all_unpressed);
        } else {
            binding.selAll.setImageResource(R.drawable.select_all_unpressed);
        }
        this.adapter.notifyDataSetChanged();
    }

    private void bindView() {
        binding.btnBack.setOnClickListener(this);
        binding.selAll.setOnClickListener(this);
        binding.ivRestore.setOnClickListener(this);
        binding.title.setText("Recover Doc File");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnBack:
                finish();
                break;
            case R.id.ivRestore:
                if (selectedImagePosition.isEmpty()) {
                    Toast.makeText(getBaseContext(), "Please select files to restore !", Toast.LENGTH_LONG).show();
                    return;
                }
                new RestoreToGallery(DocItemListActivity.this, position, DocItemListActivity.selectedImagePosition, DocItemListActivity.this).execute(new Void[0]);
                break;
            case R.id.selAll:
                if (selectedImagePosition.size() == FilesCollecter.selected.size()) {
                    selectedImagePosition.clear();
                } else {
                    selectedImagePosition.clear();
                    for (int i = 0; i < FilesCollecter.selected.size(); i++) {
                        selectedImagePosition.add(Integer.valueOf(i));
                    }
                }
                setSelAll();
                break;
        }
    }


}