package docs.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;

import com.bumptech.glide.Glide;
import com.photo.video.all.document.recovery.R;

import com.photo.video.all.document.recovery.MainActivity;

import docs.DocItemListActivity;
import docs.fordata.FilesCollecter;

public class ItemListAdapter extends BaseAdapter {
    int hight;
    LayoutInflater inflater;
    Context mContext;
    int width;
    TextView item_name;
    ImageView sel;
    AppCompatImageView imagepreview;
    LinearLayout mainLay;

    public long getItemId(int i) {
        return 0;
    }

    public ItemListAdapter(Context context) {
        this.mContext = context;
        this.inflater = (LayoutInflater) this.mContext.getSystemService("layout_inflater");
        this.width = this.mContext.getResources().getDisplayMetrics().widthPixels;
        this.hight = this.mContext.getResources().getDisplayMetrics().heightPixels;
    }

    public int getCount() {
        return FilesCollecter.selected.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.inflater.inflate(R.layout.item_adapter, (ViewGroup) null);
        }
        imagepreview = (AppCompatImageView) view.findViewById(R.id.imagepreview);
        item_name = (TextView) view.findViewById(R.id.itemname);
        sel = (ImageView) view.findViewById(R.id.sel);
        mainLay = view.findViewById(R.id.mainLay);
        char c = 2;
        if (DocItemListActivity.selectedImagePosition.contains(Integer.valueOf(i))) {
            if (MainActivity.open == 4) {
                sel.setImageResource(R.drawable.theme4_selected);
            }
        } else if (MainActivity.open == 4) {
            sel.setImageResource(R.drawable.theme4_unselected);
        }
        String name = FilesCollecter.selected.get(i).getName();
        item_name.setText(name);
        String substring = name.substring(name.lastIndexOf("."), name.length());
        switch (c) {
            default:
                Glide.with(this.mContext).load(Integer.valueOf((int) R.drawable.ic_recover_doc)).into(imagepreview);
                break;
        }
        return view;
    }

}