package docs.async;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;


import com.photo.video.all.document.recovery.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

import de.deleted.filerecovery.ui.activity.LoadingDialog;
import de.deleted.filerecovery.utilts.Utils;
import docs.fordata.FilesCollecter;

public class RestoreToGallery extends AsyncTask<Void, Integer, Void> {
    Activity act;
    Context context;
    int folderPosition;
    LoadingDialog progressDialog;
    ArrayList<Integer> selectedImages;

    public  RestoreToGallery(Context context2, int i, ArrayList<Integer> arrayList, Activity activity) {
        this.context = context2;
        this.folderPosition = i;
        this.selectedImages = arrayList;
        this.act = activity;
    }

    public void onPreExecute() {
        super.onPreExecute();
        this.progressDialog = new LoadingDialog(this.context);
        this.progressDialog.setCancelable(false);
        this.progressDialog.show();
    }

    public Void doInBackground(Void... voidArr) {
        transferAllImages();
        return null;
    }

    public void onPostExecute(Void r4) {
        Context context2 = this.context;
        Toast.makeText(context2, "Images Restored To " + Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + this.context.getString(R.string.app_name) + "/", 1).show();
        this.progressDialog.dismiss();
    }

    public void transferAllImages() {
        String str;
        if (Build.VERSION.SDK_INT >= 30) {
            str = Environment.getExternalStorageDirectory().toString() + "/" + this.context.getString(R.string.restore_folder_path_document) + "/";
        } else {
            StringBuilder sb = new StringBuilder(String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()));
            sb.append("/" + this.context.getString(R.string.app_name) + "/");
            str = sb.toString();
        }
        File file = new File(str);
        if (!file.exists()) {
            file.mkdir();
        }
        for (int i = 0; i < this.selectedImages.size(); i++) {
            File file2 = FilesCollecter.selected.get(this.selectedImages.get(i).intValue());
            String name = file2.getName();
            int lastIndexOf = name.lastIndexOf(".");
            String lowerCase = name.substring(lastIndexOf).toLowerCase();
            Log.e("extension_" + i, lowerCase);
            name.substring(0, lastIndexOf + -1);
            try {
                transferImage(file2, new File(str, name));
                ContentResolver contentResolver = this.context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put("title", name);
                contentValues.put("_data", String.valueOf(str) + name + lowerCase);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void transferImage(File file, File file2) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(file);
        FileOutputStream fileOutputStream = new FileOutputStream(file2);
        FileChannel channel = fileInputStream.getChannel();
        channel.transferTo(0, channel.size(), fileOutputStream.getChannel());
        fileInputStream.close();
        fileOutputStream.close();
    }
}