package docs.async;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;

import com.photo.video.all.document.recovery.ads.interfaces.OnInterstitialAdResponse;
import com.photo.video.all.document.recovery.ads.interstitial.InterstitialAds;
import com.photo.video.all.document.recovery.MainActivity;

import java.io.File;
import java.util.ArrayList;

import docs.DocItemListActivity;
import docs.fordata.FilesCollecter;

public class SearchMotor extends AsyncTask<Void, Integer, Void> {
    Context mainContext;
    ArrayList<String> phoneStorageVolums;
    public static Activity uiActivity;

    //    ***********intetial**************************
    public static class startAct implements Runnable {
        startAct() {
        }

        public void run() {
            InterstitialAds.showAd(uiActivity, new OnInterstitialAdResponse() {
                @Override
                public void onAdClosed() {
                    uiActivity.startActivity(new Intent(uiActivity, DocItemListActivity.class));
                    uiActivity.finish();
                }

                @Override
                public void onAdImpression() {

                }
            });

        }
    }

    public SearchMotor(ArrayList<String> arrayList, Activity activity, Context context) {
        this.phoneStorageVolums = arrayList;
        this.uiActivity = activity;
        this.mainContext = context;
    }

    public void onPreExecute() {
        FilesCollecter.foundFiles.clear();
        FilesCollecter.hashMapKeys.clear();
        FilesCollecter.hashMapKeysVideos.clear();
        FilesCollecter.organizedByFolder.clear();
        FilesCollecter.selected.clear();
        super.onPreExecute();
    }

    public void onProgressUpdate(Integer... numArr) {
        super.onProgressUpdate(numArr);
    }

    public Void doInBackground(Void... voidArr) {
        checkDictionary(new File(Environment.getExternalStorageDirectory() + ""));
        return null;
    }

    public void onPostExecute(Void r4) {
        new Handler().postDelayed(new startAct(), 0);
    }

    public void checkDictionary(File file) {
        try {
            File[] listFiles = file.listFiles();
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    checkDictionary(file2);
                } else if (file2.isFile() && file2.canRead() && file2.getTotalSpace() > 0) {
                    String name = file2.getName();
                    if (MainActivity.open == 4 && (name.endsWith(".pdf") || name.endsWith(".docx") || name.endsWith(".doc") || name.endsWith(".xlsx") || name.endsWith(".txt"))) {
                        FilesCollecter.selected.add(file2);
                    }
                }
            }
        } catch (Exception unused) {
            unused.printStackTrace();
        }
    }
}