package docs.async;

import android.content.Context;
import android.os.Environment;
import android.os.storage.StorageManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class VolumsFetcher {

    public static ArrayList<String> getStorageVolums(Context context) {
        ArrayList<String> arrayList = new ArrayList<>();
        String removableVolumFromServices = getRemovableVolumFromServices(context);
        ArrayList<String> volumsFromFileSystem = getVolumsFromFileSystem();
        String path = Environment.getExternalStorageDirectory().getPath();
        String absolutePath = Environment.getDataDirectory().getAbsolutePath();
        if (removableVolumFromServices != null) {
            arrayList.add(removableVolumFromServices);
        }
        if (absolutePath != null && !arrayList.contains(absolutePath)) {
            arrayList.add(absolutePath);
        }
        if (path != null && !arrayList.contains(path)) {
            arrayList.add(path);
        }
        if (volumsFromFileSystem != null) {
            for (int i = 0; i < volumsFromFileSystem.size(); i++) {
                String str = volumsFromFileSystem.get(i);
                if (!arrayList.contains(str)) {
                    arrayList.add(str);
                }
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return arrayList;
    }

    public static String getRemovableVolumFromServices(Context context) {
        StorageManager storageManager = (StorageManager) context.getSystemService("storage");
        try {
            Object[] objArr = (Object[]) storageManager.getClass().getMethod("getVolumeList", new Class[0]).invoke(storageManager, new Object[0]);
            int length = Array.getLength(objArr);
            for (int i = 0; i < length; i++) {
                Object obj = Array.get(objArr, i);
                String str = (String) obj.getClass().getDeclaredMethod("getPath", new Class[0]).invoke(obj, new Object[0]);
                if (((Boolean) obj.getClass().getDeclaredMethod("isRemovable", new Class[0]).invoke(obj, new Object[0])).booleanValue() && mountsChecker(str)) {
                    return str;
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<String> getVolumsFromFileSystem() {
        File file = new File("/system/etc/vold.fstab");
        HashSet hashSet = new HashSet();
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            Scanner scanner = new Scanner(fileInputStream);
            while (scanner.hasNext()) {
                String nextLine = scanner.nextLine();
                if (nextLine.startsWith("dev_mount") || nextLine.startsWith("fuse_mount")) {
                    hashSet.add(nextLine.replace("\t", " ").split(" ")[2]);
                }
            }
            scanner.close();
            fileInputStream.close();
            if (!Environment.isExternalStorageRemovable()) {
                hashSet.remove(Environment.getExternalStorageDirectory().getPath());
            }
            ArrayList<String> arrayList = new ArrayList<>();
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                String str = (String) it.next();
                if (mountsChecker(str)) {
                    arrayList.add(str);
                }
            }
            if (arrayList.isEmpty()) {
                return null;
            }
            return arrayList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean mountsChecker(String str) {
        try {
            FileInputStream fileInputStream = new FileInputStream(new File("/proc/mounts"));
            Scanner scanner = new Scanner(fileInputStream);
            while (scanner.hasNextLine()) {
                if (scanner.nextLine().contains(str)) {
                    try {
                        scanner.close();
                        fileInputStream.close();
                        return true;
                    } catch (IOException unused) {
                        return true;
                    }
                }
            }
            return false;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}