package docs.fordata;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public class FilesCollecter {
    public static ArrayList<File> foundFiles = new ArrayList<>();
    public static ArrayList<String> hashMapKeys = new ArrayList<>();
    public static ArrayList<String> hashMapKeysVideos = new ArrayList<>();
    public static HashMap<String, ArrayList<File>> organizedByFolder = new HashMap<>();
    public static ArrayList<File> selected = new ArrayList<>();
}