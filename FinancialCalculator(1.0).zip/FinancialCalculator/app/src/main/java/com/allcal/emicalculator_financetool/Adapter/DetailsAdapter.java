package com.allcal.emicalculator_financetool.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.financial.all.calculator.R;

import java.util.ArrayList;

public class DetailsAdapter extends RecyclerView.Adapter<DetailsAdapter.DetailsViewHolder> {
    ArrayList<Double> balance;
    Context context;
    ArrayList<Double> interest;
    ArrayList<Integer> months;
    ArrayList<Double> principal;

    public DetailsAdapter(Context context2, ArrayList<Integer> arrayList, ArrayList<Double> arrayList2, ArrayList<Double> arrayList3, ArrayList<Double> arrayList4) {
        this.context = context2;
        this.months = arrayList;
        this.principal = arrayList2;
        this.interest = arrayList3;
        this.balance = arrayList4;
    }

    public DetailsViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new DetailsViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_details_item, viewGroup, false));
    }

    public void onBindViewHolder(DetailsViewHolder detailsViewHolder, int i) {
        String valueOf = String.valueOf(this.months.get(i));
        String valueOf2 = String.valueOf(this.principal.get(i));
        String valueOf3 = String.valueOf(this.interest.get(i));
        String valueOf4 = String.valueOf(this.balance.get(i));
        Log.e("size", String.valueOf(this.months.size()));
        if (this.months.size() > 0) {
            detailsViewHolder.tvM.setText(valueOf);
            detailsViewHolder.tvP.setText(valueOf2);
            detailsViewHolder.tvI.setText(valueOf3);
            detailsViewHolder.tvB.setText(valueOf4);
        }
    }

    public int getItemCount() {
        return this.months.size();
    }

    public class DetailsViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llDetails;
        TextView tvB;
        TextView tvI;
        TextView tvM;
        TextView tvP;

        public DetailsViewHolder(View view) {
            super(view);
            this.llDetails = (LinearLayout) view.findViewById(R.id.llDetails);
            this.tvM = (TextView) view.findViewById(R.id.tvMonth);
            this.tvP = (TextView) view.findViewById(R.id.tvP);
            this.tvI = (TextView) view.findViewById(R.id.tvI);
            this.tvB = (TextView) view.findViewById(R.id.tvB);
        }
    }
}
