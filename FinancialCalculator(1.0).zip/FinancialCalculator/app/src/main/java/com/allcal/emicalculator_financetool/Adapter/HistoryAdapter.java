package com.allcal.emicalculator_financetool.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.financial.all.calculator.R;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.DetailsViewHolder> {
    ArrayList<String> amount;
    Context context;
    ArrayList<String> date;
    ArrayList<String> interest;
    ArrayList<String> month;

    public HistoryAdapter(Context context2, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3, ArrayList<String> arrayList4) {
        this.context = context2;
        this.amount = arrayList;
        this.interest = arrayList2;
        this.month = arrayList3;
        this.date = arrayList4;
    }

    public DetailsViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new DetailsViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_history_item, viewGroup, false));
    }

    public void onBindViewHolder(DetailsViewHolder detailsViewHolder, int i) {
        if (this.amount.size() >= 0) {
            TextView textView = detailsViewHolder.tvDetailInfo;
            textView.setText(this.amount.get(i) + " @ " + this.interest.get(i) + "% for " + this.month.get(i) + " Months");
            detailsViewHolder.tvDateInfo.setText(this.date.get(i));
        }
    }

    public int getItemCount() {
        return this.amount.size();
    }

    public class DetailsViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llInfo;
        TextView tvDateInfo;
        TextView tvDetailInfo;

        public DetailsViewHolder(View view) {
            super(view);
            this.llInfo = (LinearLayout) view.findViewById(R.id.llInfo);
            this.tvDetailInfo = (TextView) view.findViewById(R.id.tvDetailInfo);
            this.tvDateInfo = (TextView) view.findViewById(R.id.tvDateInfo);
        }
    }
}
