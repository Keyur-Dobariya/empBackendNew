package com.allcal.emicalculator_financetool;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivityDashboardBinding;
import com.allcal.emicalculator_financetool.SIP.activity.SIPMainActivity;
import com.financial.all.calculator.ui.theme.ads.commons.AdsManager;
import com.financial.all.calculator.ui.theme.ads.commons.AdsUtils;
import com.financial.all.calculator.ui.theme.ads.commons.MyExtensionsKt;
import com.financial.all.calculator.ui.theme.ads.commons.Utils;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;

public class DashboardActivity extends AppCompatActivity {
    ActivityDashboardBinding binding;
    private final String screenName = this.getClass().getSimpleName();
    private ReviewManager manager;
    private ReviewInfo reviewInfo;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);
        goReview();
        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(DashboardActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        showExitDailog();
                    }
                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });

        binding.llEmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(DashboardActivity.this, EmiActivity.class));
            }
        });
        binding.llFd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(DashboardActivity.this, FdActivity.class));
            }
        });
        binding.llGst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(DashboardActivity.this, GstActivity.class));
            }
        });
        binding.llRd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(DashboardActivity.this, RdActivity.class));
            }
        });
        binding.llPpf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(DashboardActivity.this, PpfActivity.class));
            }
        });
        binding.llsip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(DashboardActivity.this, SIPMainActivity.class));
            }
        });
        binding.more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(DashboardActivity.this, binding.more);
                popupMenu.inflate(R.menu.popup_privacy);
                popupMenu.setOnMenuItemClickListener(menuItem -> {
                    int itemId = menuItem.getItemId();
                    if (itemId == R.id.share) {
                        shareApp();
                        return false;
                    } else if (itemId == R.id.rate) {
                        rateUs();
                        return false;
                    } else if (itemId == R.id.privacy) {
                        MyExtensionsKt.privacyPolicy(DashboardActivity.this, AdsUtils.getAdPref(DashboardActivity.this).ppLink);
                        return false;
                    } else {
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
    }

    private void showExitDailog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.AppBottomSheetDialogTheme);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_exitdialog);
        MaterialButton btnNo = bottomSheetDialog.findViewById(R.id.btnNo);
        TextView txtYesExit = bottomSheetDialog.findViewById(R.id.txtYesExit);
        txtYesExit.setOnClickListener(v -> {
            AdsManager.release(getApplication());
            finishAffinity();
        });
        btnNo.setOnClickListener(v -> bottomSheetDialog.dismiss());
        bottomSheetDialog.show();
    }

    //    *********review***********
    private void goReview() {
        if (!Utils.getPref(DashboardActivity.this, Utils.APP_REVIEW, false)) {
            Utils.setPref(DashboardActivity.this, Utils.APP_REVIEW, true);
            return;
        }
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener((OnCompleteListener<ReviewInfo>) task -> {
            if (task.isSuccessful()) {
                reviewInfo = (ReviewInfo) task.getResult();
                manager.launchReviewFlow(DashboardActivity.this, reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                    }
                });
            }
        });
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(DashboardActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }

    public void shareApp() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", "Download this awesome app\n https://play.google.com/store/apps/details?id=" + getPackageName() + " \n");
        startActivity(intent);
    }

    public void rateUs() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
        } catch (ActivityNotFoundException unused) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

}
