package com.allcal.emicalculator_financetool;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.financial.all.calculator.databinding.ActivityDetailsBinding;
import com.allcal.emicalculator_financetool.Adapter.DetailsAdapter;

import java.util.ArrayList;

public class DetailsActivity extends AppCompatActivity {
    ArrayList<Double> B;
    ArrayList<Double> I;
    ArrayList<Double> P;
    DetailsAdapter detailsAdapter;
    float emi;
    ArrayList<Integer> mont;
    String st1;
    String st2;
    String st3;

    ActivityDetailsBinding binding;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (getIntent().getExtras() != null) {
            st1 = getIntent().getExtras().getString("str1");
            st2 = getIntent().getExtras().getString("str2");
            st3 = getIntent().getExtras().getString("str3");
            emi = getIntent().getExtras().getFloat("emi");
        }
        binding.tvTitle.setText("EMI Details");
        detail();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, 1, false);
        detailsAdapter = new DetailsAdapter(this, this.mont, this.P, this.I, this.B);
        binding.rvDetails.setLayoutManager(linearLayoutManager);
        binding.rvDetails.setAdapter(this.detailsAdapter);
        detailsAdapter.notifyDataSetChanged();
    }

    public void detail() {
        double parseDouble = Double.parseDouble(this.st1);
        double parseDouble2 = Double.parseDouble(this.st2);
        double parseDouble3 = Double.parseDouble(this.st3) * 12.0d;
        int i = (int) parseDouble3;
        mont = new ArrayList<>();
        P = new ArrayList<>();
        I = new ArrayList<>();
        B = new ArrayList<>();
        double d = parseDouble2 / 1200.0d;
        double pow = (parseDouble * d) / (1.0d - (1.0d / Math.pow(d + 1.0d, parseDouble3)));
        for (int i2 = 1; i2 <= i; i2++) {
            this.mont.add(Integer.valueOf(i2));
            double round = (double) Math.round(d * parseDouble);
            double round2 = (double) Math.round(pow - round);
            parseDouble = (double) Math.round(parseDouble - round2);
            if (i2 == i) {
                parseDouble = 0.0d;
            }
            P.add(Double.valueOf(round2));
            I.add(Double.valueOf(round));
            B.add(Double.valueOf(parseDouble));
        }
    }

}
