package com.allcal.emicalculator_financetool;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivityMainBinding;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class EmiActivity extends AppCompatActivity {
    SQLiteDatabase db;
    float emi;
    String st1;
    String st2;
    String st3;

    ActivityMainBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    public float calDivider(float f) {
        return f - 1.0f;
    }

    public float calFinalDvdnt(float f, float f2, float f3) {
        return f * f2 * f3;
    }

    public float calInt(float f) {
        return (f / 12.0f) / 100.0f;
    }

    public float calMonth(float f) {
        return f * 12.0f;
    }

    public float calPric(float f) {
        return f;
    }

    public float calTotalInt(float f, float f2) {
        return f - f2;
    }

    public float calTotalPayable(float f, float f2) {
        return f + f2;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(EmiActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void init() {
        binding.tvTitle.setText(getResources().getString(R.string.app_name_s));
        binding.btncalculate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Validate()) {
                    Calculate();
                    binding.btndetails.setVisibility(View.VISIBLE);
                    binding.nested.postDelayed(new Runnable() {
                        public void run() {
                            binding.nested.smoothScrollTo(0, binding.nested.getHeight());
                        }
                    }, 1000);
                }
            }
        });
        binding.btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reset();
                binding.btndetails.setVisibility(View.GONE);
            }
        });
        binding.btndetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EmiActivity.this, DetailsActivity.class);
                intent.putExtra("str1", st1);
                intent.putExtra("str2", st2);
                intent.putExtra("str3", st3);
                intent.putExtra("emi", emi);
                startActivitys(intent);
            }
        });
        binding.imagebtninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(EmiActivity.this, HistoryActivity.class));
            }
        });
        binding.imagebtninfo.setVisibility(View.VISIBLE);
        db = openOrCreateDatabase("HistoryDB", 0, (SQLiteDatabase.CursorFactory) null);
        db.execSQL("CREATE TABLE IF NOT EXISTS History(Id INTEGER PRIMARY KEY AUTOINCREMENT, Amount VARCHAR, Interest VARCHAR, Months VARCHAR, TI VARCHAR, TP VARCHAR, Date VARCHAR);");
    }

    public void Calculate() {
        float parseFloat = Float.parseFloat(this.st1);
        float parseFloat2 = Float.parseFloat(this.st2);
        float parseFloat3 = Float.parseFloat(this.st3);
        float calPric = calPric(parseFloat);
        float calInt = calInt(parseFloat2);
        float calMonth = calMonth(parseFloat3);
        float calDvdnt = calDvdnt(calInt, calMonth);
        float calEmi = calEmi(calFinalDvdnt(calPric, calInt, calDvdnt), Float.valueOf(calDivider(calDvdnt)));
        this.emi = calEmi;
        float calTotalInt = calTotalInt(calTa(calEmi, Float.valueOf(calMonth)), calPric);
        float calTotalPayable = calTotalPayable(calTotalInt, calPric);
        if (!String.valueOf(this.emi).equalsIgnoreCase("") && !String.valueOf(calTotalInt).equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.VISIBLE);
            binding.emi.setText(String.valueOf(this.emi));
            binding.interesttotal.setText(String.valueOf(calTotalInt));
            binding.payableamount.setText(String.valueOf(calTotalPayable));
            int i = (int) (parseFloat3 * 12.0f);
            String format = new SimpleDateFormat("dd/mm/yyyy hh:mm:ss a", Locale.getDefault()).format(new Date());
            SQLiteDatabase sQLiteDatabase = this.db;
            sQLiteDatabase.execSQL("INSERT INTO History(Amount,Interest,Months,TI,TP,Date)VALUES('" + binding.principal.getText() + "','" + binding.interest.getText() + "','" + i + "','" + binding.interesttotal.getText() + "','" + binding.payableamount.getText() + "','" + format + "');");
            Log.e("DB", "Added");
        }
    }

    public boolean Validate() {
        st1 = binding.principal.getText().toString();
        st2 = binding.interest.getText().toString();
        st3 = binding.years.getText().toString();
        if (TextUtils.isEmpty(st1) || st1.equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Principal Amount", Toast.LENGTH_SHORT).show();
            binding.principal.requestFocus();
            return false;
        } else if (TextUtils.isEmpty(st2) || st2.equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Interest Rate", Toast.LENGTH_SHORT).show();
            binding.interest.requestFocus();
            return false;
        } else if (!TextUtils.isEmpty(st3) && !st3.equalsIgnoreCase("")) {
            return true;
        } else {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Years", Toast.LENGTH_SHORT).show();
            binding.years.requestFocus();
            return false;
        }
    }

    public float calDvdnt(float f, float f2) {
        return (float) Math.pow((double) (f + 1.0f), (double) f2);
    }

    public float calEmi(float f, Float f2) {
        return f / f2.floatValue();
    }

    public float calTa(float f, Float f2) {
        return f * f2.floatValue();
    }

    public void reset() {
        binding.llResult.setVisibility(View.GONE);
        binding.principal.setText("");
        binding.years.setText("");
        binding.interest.setText("");
        binding.principal.requestFocus();
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(EmiActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}
