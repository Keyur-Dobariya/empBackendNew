package com.allcal.emicalculator_financetool;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivityGstBinding;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;

public class GstActivity extends AppCompatActivity implements View.OnClickListener {
    String st1;
    String st2;
    String string_type;
    private final String screenName = this.getClass().getSimpleName();

    ActivityGstBinding binding;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityGstBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(GstActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void init() {
        binding.tvTitle.setText("GST Calculator");
        binding.btncalculate.setOnClickListener(this);
        binding.btnreset.setOnClickListener(this);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.btncalculate) {
            if (id == R.id.btnreset) {
                reset();
            }
        } else if (validate()) {
            calculate();
            binding.llResult.setVisibility(View.VISIBLE);
        }
    }

    public void calculate() {
        double parseDouble = Double.parseDouble(this.st1);
        double parseDouble2 = Double.parseDouble(this.st2);
        String charSequence = ((RadioButton) findViewById(binding.radipgroup.getCheckedRadioButtonId())).getText().toString();
        string_type = charSequence;
        if (charSequence.equalsIgnoreCase(getResources().getString(R.string.hint_add_gst))) {
            double d = (parseDouble2 * parseDouble) / 100.0d;
            double d2 = parseDouble + d;
            String valueOf = String.valueOf(Math.round(parseDouble));
            String valueOf2 = String.valueOf(Math.round(d));
            String valueOf3 = String.valueOf(Math.round(d2));
            binding.tvNetAmount.setText(valueOf);
            binding.tvGstAmount.setText(valueOf2);
            binding.tvTotalAmount.setText(valueOf3);
        } else if (this.string_type.equalsIgnoreCase(getResources().getString(R.string.hint_remove_gst))) {
            double d3 = parseDouble - ((100.0d / (parseDouble2 + 100.0d)) * parseDouble);
            double d4 = parseDouble - d3;
            String valueOf4 = String.valueOf(Math.round(parseDouble));
            String valueOf5 = String.valueOf(Math.round(d3));
            String valueOf6 = String.valueOf(Math.round(d4));
            binding.tvNetAmount.setText(valueOf4);
            binding.tvGstAmount.setText(valueOf5);
            binding.tvTotalAmount.setText(valueOf6);
        }
    }

    public boolean validate() {
        st1 = binding.etInitialAmount.getText().toString();
        st2 = binding.etRateGst.getText().toString();
        if (TextUtils.isEmpty(this.st1) || this.st1.equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Initial Amount", Toast.LENGTH_SHORT).show();
            binding.etInitialAmount.requestFocus();
            return false;
        } else if (!TextUtils.isEmpty(this.st2) && !this.st2.equalsIgnoreCase("")) {
            return true;
        } else {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter GST Rate", Toast.LENGTH_SHORT).show();
            binding.etRateGst.requestFocus();
            return false;
        }
    }

    public void reset() {
        binding.etInitialAmount.setText("");
        binding.etRateGst.setText("");
        binding.etInitialAmount.requestFocus();
        binding.llResult.setVisibility(View.GONE);
    }
}
