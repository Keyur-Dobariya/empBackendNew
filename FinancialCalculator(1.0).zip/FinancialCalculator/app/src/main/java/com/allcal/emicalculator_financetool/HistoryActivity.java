package com.allcal.emicalculator_financetool;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivityHistoryBinding;
import com.allcal.emicalculator_financetool.Adapter.HistoryAdapter;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    ArrayList<String> amount;
    ArrayList<String> date;
    SQLiteDatabase db;
    HistoryAdapter historyAdapter;
    ArrayList<String> interst;
    ArrayList<String> month;

    ActivityHistoryBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.ivExtra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delete();
            }
        });
        binding.tvTitle.setText("History");
        db = openOrCreateDatabase("HistoryDB", 0, (SQLiteDatabase.CursorFactory) null);
        Cursor rawQuery = db.rawQuery("SELECT * FROM History", (String[]) null);
        if (rawQuery.getCount() == 0) {
            binding.ivExtra.setVisibility(View.GONE);
            binding.tvNodata.setVisibility(View.VISIBLE);
            binding.rvHistory.setVisibility(View.GONE);
            Log.e("No records found", "Empty");
            return;
        }
        binding.ivExtra.setVisibility(View.VISIBLE);
        binding.tvNodata.setVisibility(View.GONE);
        binding.rvHistory.setVisibility(View.VISIBLE);
        amount = new ArrayList<>();
        interst = new ArrayList<>();
        month = new ArrayList<>();
        date = new ArrayList<>();
        while (rawQuery.moveToNext()) {
            amount.add(rawQuery.getString(1));
            interst.add(rawQuery.getString(2));
            month.add(rawQuery.getString(3));
            date.add(rawQuery.getString(6));
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, 1, false);
        historyAdapter = new HistoryAdapter(this, this.amount, this.interst, this.month, this.date);
        binding.rvHistory.setLayoutManager(linearLayoutManager);
        binding.rvHistory.setAdapter(this.historyAdapter);
        historyAdapter.notifyDataSetChanged();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(HistoryActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }


    public void delete() {
        if (db.rawQuery("SELECT * FROM History", (String[]) null) != null) {
            View inflate = LayoutInflater.from(this).inflate(R.layout.delete_dialog_popup, (ViewGroup) null);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(inflate);
            builder.setCancelable(false);
            final AlertDialog create = builder.create();
            create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            ((Button) inflate.findViewById(R.id.btn_delete)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    db.execSQL("DELETE FROM History");
                    create.dismiss();
                    finish();
                }
            });
            ((Button) inflate.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    create.dismiss();
                }
            });
            create.show();
            Log.e("dlt", "Record Deleted");
            return;
        }
        binding.tvNodata.setVisibility(View.VISIBLE);
        binding.ivExtra.setVisibility(View.GONE);
        binding.rvHistory.setVisibility(View.GONE);
    }
}
