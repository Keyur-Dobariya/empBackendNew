package com.allcal.emicalculator_financetool;

import android.app.DatePickerDialog;
import android.icu.text.DateFormat;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivityPpfBinding;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class PpfActivity extends AppCompatActivity implements View.OnClickListener {
    String DM;
    public int mDay = 0;
    public int mMonth = 0;
    public int mYear = 0;
    int selectedRange = 0;
    String st1;
    String st2;
    String st3;
    String st4;
    String y;

    ActivityPpfBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityPpfBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        init();
        currentDate();
        investmentDate();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(PpfActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void init() {
        binding.tvTitle.setText("PPF Calculator");
        int progress = binding.seekbar.getProgress();
        this.selectedRange = progress;
        st3 = String.valueOf(progress);
        binding.seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                selectedRange = seekBar.getProgress();
                PpfActivity ppfActivity = PpfActivity.this;
                ppfActivity.st3 = String.valueOf(ppfActivity.selectedRange);
                Log.e("seekbar3 ", st3);
            }
        });
        Log.e("seekbar ", this.st3);
        binding.btnCal.setOnClickListener(this);
        binding.btnreset.setOnClickListener(this);
    }

    public void currentDate() {
        String format = DateFormat.getDateInstance(2, Locale.UK).format(new Date());
        String[] split = format.split(" ");
        y = split[2];
        DM = split[0] + " " + split[1];
        binding.etDate.setText(format);
        Log.e("year", this.y + " " + this.DM);
    }

    public void investmentDate() {
        binding.etDate.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 1) {
                    Calendar instance = Calendar.getInstance();
                    if (mYear == 0 && mMonth == 0 && mDay == 0) {
                        int unused = mYear = instance.get(1);
                        int unused2 = mMonth = instance.get(2);
                        int unused3 = mDay = instance.get(5);
                    }
                    new DatePickerDialog(PpfActivity.this, new DatePickerDialog.OnDateSetListener() {
                        public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
                            int unused = mDay = i3;
                            int unused2 = mMonth = i2;
                            int unused3 = mYear = i;
                            Calendar instance = Calendar.getInstance();
                            instance.setTimeInMillis(0);
                            instance.set(i, i2, i3, 0, 0, 0);
                            String format = DateFormat.getDateInstance(2, Locale.UK).format(instance.getTime());
                            String[] split = format.split(" ");
                            y = split[2];
                            DM = split[0] + " " + split[1];
                            Log.e("year", y + " " + DM);
                            binding.etDate.setText(format);
                        }
                    }, mYear, mMonth, mDay).show();
                }
                return true;
            }
        });
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.btnCal) {
            if (id == R.id.btnreset) {
                reset();
            }
        } else if (Validate()) {
            calculate();
            binding.llResult.setVisibility(View.VISIBLE);
        }
    }

    private void calculate() {
        double parseDouble = Double.parseDouble(this.st1);
        double parseDouble2 = Double.parseDouble(this.st2) / 100.0d;
        String valueOf = String.valueOf(Integer.parseInt(this.y) + this.selectedRange);
        double pow = parseDouble * ((Math.pow(parseDouble2 + 1.0d, (double) this.selectedRange) - 1.0d) / parseDouble2);
        Math.round(pow);
        binding.tvMaturityValue.setText(String.valueOf(Math.round(pow)));
        binding.tvInvestmentDate.setText(binding.etDate.getText().toString());
        binding.tvMaturityDate.setText(this.DM + " " + valueOf);
    }

    public boolean Validate() {
        st1 = binding.etDeposite.getText().toString();
        st2 = binding.etInterest.getText().toString();
        st4 = binding.etDate.getText().toString();
        if (TextUtils.isEmpty(this.st1) || this.st1.equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Deposite Amount", Toast.LENGTH_SHORT).show();
            binding.etDeposite.requestFocus();
            return false;
        } else if (!TextUtils.isEmpty(this.st2) && !this.st2.equalsIgnoreCase("")) {
            return true;
        } else {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Interest Rate", Toast.LENGTH_SHORT).show();
            binding.etInterest.requestFocus();
            return false;
        }
    }

    private void reset() {
        binding.llResult.setVisibility(View.GONE);
        binding.etDeposite.setText("");
        binding.etInterest.setText("");
        currentDate();
        binding.etDeposite.requestFocus();
    }
}
