package com.allcal.emicalculator_financetool;

import android.app.DatePickerDialog;
import android.icu.text.DateFormat;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivityRdBinding;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class RdActivity extends AppCompatActivity implements View.OnClickListener {
    String DM;
    public int mDay = 0;
    public int mMonth = 0;
    public int mYear = 0;
    String st1;
    String st2;
    String st3;
    String st4;
    String y;

    ActivityRdBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityRdBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        currentDate();
        investmentDate();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(RdActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void init() {
        binding.tvTitle.setText("RD Calculator");
        binding.btnCal.setOnClickListener(this);
        binding.btnreset.setOnClickListener(this);
    }

    public void currentDate() {
        String format = DateFormat.getDateInstance(2, Locale.UK).format(new Date());
        String[] split = format.split(" ");
        y = split[2];
        DM = split[0] + " " + split[1];
        binding.etDate.setText(format);
        Log.e("year", this.y + " " + this.DM);
    }

    public void investmentDate() {
        binding.etDate.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 1) {
                    Calendar instance = Calendar.getInstance();
                    if (mYear == 0 && mMonth == 0 && mDay == 0) {
                        int unused = mYear = instance.get(1);
                        int unused2 = mMonth = instance.get(2);
                        int unused3 = mDay = instance.get(5);
                    }
                    new DatePickerDialog(RdActivity.this, new DatePickerDialog.OnDateSetListener() {
                        public void onDateSet(DatePicker datePicker, int i, int i2, int i3) {
                            int unused = mDay = i3;
                            int unused2 = mMonth = i2;
                            int unused3 = mYear = i;
                            Calendar instance = Calendar.getInstance();
                            instance.setTimeInMillis(0);
                            instance.set(i, i2, i3, 0, 0, 0);
                            String format = DateFormat.getDateInstance(2, Locale.UK).format(instance.getTime());
                            String[] split = format.split(" ");
                            y = split[2];
                            RdActivity rdActivity = RdActivity.this;
                            rdActivity.DM = split[0] + " " + split[1];
                            Log.e("year", y + " " + DM);
                            binding.etDate.setText(format);
                        }
                    }, mYear, mMonth, mDay).show();
                }
                return true;
            }
        });
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id != R.id.btnCal) {
            if (id == R.id.btnreset) {
                reset();
            }
        } else if (Validate()) {
            calculate();
            binding.llResult.setVisibility(View.VISIBLE);
        }
    }

    public void calculate() {
        float parseFloat = Float.parseFloat(this.st1);
        float parseFloat2 = Float.parseFloat(this.st2);
        float parseFloat3 = Float.parseFloat(this.st3);
        String valueOf = String.valueOf((int) (((float) Integer.parseInt(this.y)) + parseFloat3));
        float f = parseFloat2 / 100.0f;
        int i = (int) (parseFloat3 * 12.0f);
        double d = 0.0d;
        for (int i2 = 1; i2 <= i; i2++) {
            d += ((double) parseFloat) * Math.pow((double) ((f / 4.0f) + 1.0f), (double) ((i2 / i) * 4));
        }
        double round = (double) (Math.round(d) * ((long) i));
        binding.tvMaturityValue.setText(String.valueOf(Math.round(d)));
        double round2 = (double) (Math.round(round) - ((long) Math.round(parseFloat)));
        binding.tvTotalInterest.setText(String.valueOf(round2));
        binding.tvInvestmentAmount.setText(String.valueOf((double) (Math.round(round2) - Math.round(d))));
        binding.tvInvestmentDate.setText(binding.etDate.getText().toString());
        binding.tvMaturityDate.setText(this.DM + " " + valueOf);
    }

    public boolean Validate() {
        st1 = binding.etDeposite.getText().toString();
        st2 = binding.etInterest.getText().toString();
        st3 = binding.etYear.getText().toString();
        st4 = binding.etDate.getText().toString();
        if (TextUtils.isEmpty(this.st1) || this.st1.equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Deposite Amount", Toast.LENGTH_SHORT).show();
            binding.etDeposite.requestFocus();
            return false;
        } else if (TextUtils.isEmpty(this.st2) || this.st2.equalsIgnoreCase("")) {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Interest Rate", Toast.LENGTH_SHORT).show();
            binding.etInterest.requestFocus();
            return false;
        } else if (!TextUtils.isEmpty(this.st3) && !this.st3.equalsIgnoreCase("")) {
            return true;
        } else {
            binding.llResult.setVisibility(View.GONE);
            Toast.makeText(this, "Enter Years", Toast.LENGTH_SHORT).show();
            binding.etYear.requestFocus();
            return false;
        }
    }

    private void reset() {
        binding.llResult.setVisibility(View.GONE);
        binding.etDeposite.setText("");
        binding.etInterest.setText("");
        binding.etYear.setText("");
        currentDate();
        binding.etDeposite.requestFocus();
    }
}
