package com.allcal.emicalculator_financetool.SIP.activity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.allcal.emicalculator_financetool.SIP.adapter.HistoryAdapter;
import com.allcal.emicalculator_financetool.SIP.common.SharedPrefManager;
import com.allcal.emicalculator_financetool.SIP.common.Utils;
import com.allcal.emicalculator_financetool.SIP.model.HistoryModel;
import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivitySiphistoryBinding;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;
import com.ligl.android.widget.iosdialog.IOSDialog;

import java.util.ArrayList;

public class SIPHistoryActivity extends AppCompatActivity implements HistoryAdapter.onHistoryInterface {
    private ArrayList<HistoryModel> historyList = new ArrayList<>();
    private HistoryAdapter mHistoryadapter;
    SharedPreferences sharedpreferences;

    ActivitySiphistoryBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySiphistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setHeader();
        declaration();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(SIPHistoryActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void declaration() {
        sharedpreferences = getSharedPreferences("Count", 0);
        historyList = new ArrayList<>();
        historyList = SharedPrefManager.getInstance(SIPHistoryActivity.this).getHistoryList(SharedPrefManager.SHARED_HISTORY);
        Utils.showProgressDialog(SIPHistoryActivity.this, "Please wait...", false);
        ArrayList<HistoryModel> arrayList = this.historyList;
        if (arrayList == null || arrayList.size() <= 0) {
            Utils.dismissProgressDialog();
            binding.tvNoRecord.setVisibility(View.VISIBLE);
            binding.rvHistory.setVisibility(View.GONE);
            return;
        }
        setHistoryAdapter(this.historyList);
    }

    private void setHistoryAdapter(ArrayList<HistoryModel> arrayList) {
        ArrayList<HistoryModel> arrayList2 = this.historyList;
        if (arrayList2 != null && arrayList2.size() > 0) {
            binding.tvNoRecord.setVisibility(View.GONE);
            binding.rvHistory.setVisibility(View.VISIBLE);
            Utils.dismissProgressDialog();
            mHistoryadapter = new HistoryAdapter(this.historyList, SIPHistoryActivity.this, this);
            binding.rvHistory.setLayoutManager(new LinearLayoutManager(SIPHistoryActivity.this));
            binding.rvHistory.setAdapter(this.mHistoryadapter);
        }
    }


    private void setHeader() {
        binding.tvTitle.setText("History");
        binding.ivExtra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDeleteDialog("Are you sure want to delete all history?", true);
            }
        });
    }

    @Override
    public void onDeleteClick(ArrayList<HistoryModel> arrayList, int i) {
        String id = arrayList.get(i).getId();
        if (id != null && id.length() > 0) {
            getDeleteDialog("Are you sure want to delete?", false);
        }
    }

    private void deleteHistoryData(String str, int i) {
        ArrayList<HistoryModel> arrayList = this.historyList;
        if (arrayList != null && arrayList.size() > 0) {
            int i2 = 0;
            while (true) {
                if (i2 < this.historyList.size()) {
                    String id = this.historyList.get(i2).getId();
                    if (id != null && id.equalsIgnoreCase(str)) {
                        this.historyList.remove(i);
                        break;
                    }
                    i2++;
                } else {
                    break;
                }
            }
            SharedPrefManager.getInstance(SIPHistoryActivity.this).saveHistoryList(SharedPrefManager.SHARED_HISTORY, this.historyList);
            declaration();
        }
    }

    public void getDeleteDialog(String str, boolean z) {
        new IOSDialog.Builder(SIPHistoryActivity.this).
                setTitle("Alert!").setMessage(str).
                setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        if (z) {
                            SharedPrefManager.getInstance(SIPHistoryActivity.this).removeStringPref(SharedPrefManager.SHARED_HISTORY);
                            declaration();
                            return;
                        }
                        deleteHistoryData(str, i);

                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).show();
    }


}