package com.allcal.emicalculator_financetool.SIP.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.allcal.emicalculator_financetool.DashboardActivity;
import com.financial.all.calculator.R;
import com.financial.all.calculator.databinding.ActivitySipmainBinding;
import com.allcal.emicalculator_financetool.SIP.adapter.HomeAdapter;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse;
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds;
import com.financial.all.calculator.ui.theme.ads.nativee.SmallNativeAds;
import com.google.android.material.tabs.TabLayout;

public class SIPMainActivity extends AppCompatActivity implements TabLayout.OnTabSelectedListener {
    private HomeAdapter adapter;
    private final String screenName = this.getClass().getSimpleName();
    ActivitySipmainBinding binding;

    public void onTabReselected(TabLayout.Tab tab) {
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivitySipmainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadUiElements();
        declaration();

        //        ********small native***********************
        new SmallNativeAds(screenName, R.dimen._native_google_new, R.layout.native_google_new, R.layout.native_meta_new)
                .showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(SIPMainActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void declaration() {
        binding.tabLayout.setTabGravity(0);
        binding.tabLayout.setupWithViewPager(binding.pager);
        binding.pager.setOffscreenPageLimit(2);
        binding.tabLayout.setOnTabSelectedListener((TabLayout.OnTabSelectedListener) this);
        adapter = new HomeAdapter(getSupportFragmentManager());
        binding.pager.setAdapter(adapter);
    }

    private void loadUiElements() {
        binding.tvTitle.setText("SIP Calculator");
        binding.history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivitys(new Intent(SIPMainActivity.this, SIPHistoryActivity.class));
            }
        });
        binding.tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#FF0000"));
        binding.tabLayout.setSelectedTabIndicatorHeight((int) (5 * getResources().getDisplayMetrics().density));
        binding.tabLayout.setTabTextColors(Color.parseColor("#faf5f5"), Color.parseColor("#ffffff"));
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        binding.pager.setCurrentItem(tab.getPosition());
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(SIPMainActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}