package com.allcal.emicalculator_financetool.SIP.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.financial.all.calculator.R;
import com.allcal.emicalculator_financetool.SIP.model.HistoryModel;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    Context context;
    ArrayList<HistoryModel> historyModelList = new ArrayList<>();
    onHistoryInterface onHistoryInterface;

    public interface onHistoryInterface {
        void onDeleteClick(ArrayList<HistoryModel> arrayList, int i);
    }

    public HistoryAdapter(ArrayList<HistoryModel> arrayList, Context context2, onHistoryInterface onhistoryinterface) {
        this.historyModelList = arrayList;
        this.context = context2;
        this.onHistoryInterface = onhistoryinterface;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_history, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, final int i) {
        String str;
        String str2;
        HistoryModel historyModel = this.historyModelList.get(i);
        historyModel.getId();
        String amount = historyModel.getAmount();
        String period = historyModel.getPeriod();
        String rate = historyModel.getRate();
        String periodType = historyModel.getPeriodType();
        if (amount == null || !amount.contains(".")) {
            str = amount + ".0 @ ";
        } else {
            str = amount + " @ ";
        }
        if (rate == null || !rate.contains(".")) {
            str2 = rate + ".0 % for ";
        } else {
            str2 = rate + " % for ";
        }
        if (period == null || !period.contains(".")) {
            if (periodType != null && periodType.length() > 0) {
                period = period + ".0 " + periodType;
            }
        } else if (periodType != null && periodType.length() > 0) {
            period = period + " " + periodType;
        }
        viewHolder.tvDate.setText(historyModel.getDate());
        viewHolder.tvLevel.setText(historyModel.getLevel());
        viewHolder.tvDetails.setText(str + str2 + period);
    }

    @Override
    public int getItemCount() {
        return this.historyModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate;
        TextView tvDetails;
        TextView tvLevel;

        public ViewHolder(View view) {
            super(view);
            this.tvDetails = (TextView) view.findViewById(R.id.tvDetails);
            this.tvLevel = (TextView) view.findViewById(R.id.tvLevel);
            this.tvDate = (TextView) view.findViewById(R.id.tvDate);
        }
    }
}