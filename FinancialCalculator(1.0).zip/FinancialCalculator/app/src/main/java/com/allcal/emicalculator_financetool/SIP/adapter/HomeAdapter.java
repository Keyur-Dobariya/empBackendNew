package com.allcal.emicalculator_financetool.SIP.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.allcal.emicalculator_financetool.SIP.fragment.OneTimeFragment;
import com.allcal.emicalculator_financetool.SIP.fragment.PlanFragment;
import com.allcal.emicalculator_financetool.SIP.fragment.SIPFragment;


public class HomeAdapter extends FragmentStatePagerAdapter {
    boolean isHold;
    private String[] tabTitles;

    public HomeAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
        this.tabTitles = new String[]{"SIP", "ONE-TIME", "PLAN"};
        this.isHold = false;
        this.isHold = false;
    }

    @Override
    public CharSequence getPageTitle(int i) {
        return this.tabTitles[i];
    }

    @Override
    public Fragment getItem(int i) {
        if (i == 0) {
            return new SIPFragment();
        }
        if (i == 1) {
            return new OneTimeFragment();
        }
        if (i != 2) {
            return null;
        }
        return new PlanFragment();
    }

    @Override
    public int getCount() {
        return this.tabTitles.length;
    }
}