package com.allcal.emicalculator_financetool.SIP.adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.financial.all.calculator.R;
import com.allcal.emicalculator_financetool.SIP.model.PlanModel;

import java.util.ArrayList;

public class PlanDetailAdapter extends RecyclerView.Adapter<PlanDetailAdapter.ViewHolder> {
    Context context;
    onPlanInterface onOneTimePlanInterface;
    ArrayList<PlanModel> sipDetailsList = new ArrayList<>();

    public interface onPlanInterface {
        void onPlanClick(Dialog dialog, ArrayList<PlanModel> arrayList, int i);
    }

    public PlanDetailAdapter(ArrayList<PlanModel> arrayList, Context context2) {
        this.sipDetailsList = arrayList;
        this.context = context2;
        this.onOneTimePlanInterface = this.onOneTimePlanInterface;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_plan, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        PlanModel planModel = this.sipDetailsList.get(i);
        viewHolder.tvPeriod.setText(planModel.getPeriod());
        viewHolder.tvMonthlyInvestment.setText(planModel.getMonthlyInvestment());
        viewHolder.tvOntTimeInvestment.setText(planModel.getOneTimeInvestment());
    }

    @Override
    public int getItemCount() {
        return this.sipDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvMonthlyInvestment;
        TextView tvOntTimeInvestment;
        TextView tvPeriod;

        public ViewHolder(View view) {
            super(view);
            this.tvMonthlyInvestment = (TextView) view.findViewById(R.id.tvMonthlyInvestment);
            this.tvOntTimeInvestment = (TextView) view.findViewById(R.id.tvOntTimeInvestment);
            this.tvPeriod = (TextView) view.findViewById(R.id.tvPeriod);
        }
    }
}