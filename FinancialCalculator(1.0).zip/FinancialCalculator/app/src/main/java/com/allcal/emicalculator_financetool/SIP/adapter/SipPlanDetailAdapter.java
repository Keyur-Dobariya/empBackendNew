package com.allcal.emicalculator_financetool.SIP.adapter;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.financial.all.calculator.R;
import com.allcal.emicalculator_financetool.SIP.model.SipPlanModel;

import java.util.ArrayList;

public class SipPlanDetailAdapter extends RecyclerView.Adapter<SipPlanDetailAdapter.ViewHolder> {
    Context context;
    onSipPlanInterface onSipPlanInterface;
    ArrayList<SipPlanModel> sipDetailsList = new ArrayList<>();

    public interface onSipPlanInterface {
        void onPlanClick(Dialog dialog, ArrayList<SipPlanModel> arrayList, int i);
    }

    public SipPlanDetailAdapter(ArrayList<SipPlanModel> arrayList, Context context2) {
        this.sipDetailsList = arrayList;
        this.context = context2;
        this.onSipPlanInterface = this.onSipPlanInterface;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_sip_plan, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        SipPlanModel sipPlanModel = this.sipDetailsList.get(i);
        viewHolder.tvPeriod.setText(sipPlanModel.getPeriod());
        viewHolder.tvInvestedAmount.setText(sipPlanModel.getInvestedAmount());
        viewHolder.tvExpectedAmount.setText(sipPlanModel.getExpectedAmount());
    }

    @Override
    public int getItemCount() {
        return this.sipDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvExpectedAmount;
        TextView tvInvestedAmount;
        TextView tvPeriod;

        public ViewHolder(View view) {
            super(view);
            this.tvExpectedAmount = (TextView) view.findViewById(R.id.tvExpectedAmount);
            this.tvInvestedAmount = (TextView) view.findViewById(R.id.tvInvestedAmount);
            this.tvPeriod = (TextView) view.findViewById(R.id.tvPeriod);
        }
    }
}