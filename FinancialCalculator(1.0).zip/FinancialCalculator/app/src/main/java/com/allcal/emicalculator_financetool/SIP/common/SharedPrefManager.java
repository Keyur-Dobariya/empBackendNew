package com.allcal.emicalculator_financetool.SIP.common;

import android.content.Context;
import android.content.SharedPreferences;

import com.allcal.emicalculator_financetool.SIP.model.HistoryModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class SharedPrefManager {
    public static final String SHARED_HISTORY = "history";
    private static final String SHARED_PREF_NAME = "SipCalc_SharedPref";
    private static Context ctx;
    private static SharedPrefManager mInstance;

    private SharedPrefManager(Context context) {
        ctx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        SharedPrefManager sharedPrefManager;
        synchronized (SharedPrefManager.class) {
            if (mInstance == null) {
                mInstance = new SharedPrefManager(context);
            }
            sharedPrefManager = mInstance;
        }
        return sharedPrefManager;
    }


    public void removeStringPref(String str) {
        ctx.getSharedPreferences(SHARED_PREF_NAME, 0).edit().remove(str).commit();
    }


    public void saveHistoryList(String str, ArrayList<HistoryModel> arrayList) {
        new ArrayList();
        String json = new Gson().toJson(arrayList);
        SharedPreferences.Editor edit = ctx.getSharedPreferences(SHARED_PREF_NAME, 0).edit();
        edit.putString(str, json);
        edit.apply();
    }

    public ArrayList<HistoryModel> getHistoryList(String str) {
        return (ArrayList) new Gson().fromJson(ctx.getSharedPreferences(SHARED_PREF_NAME, 0).getString(str, null), new TypeToken<ArrayList<HistoryModel>>() {
        }.getType());
    }

}