package com.allcal.emicalculator_financetool.SIP.common;

import android.app.Activity;
import android.app.ProgressDialog;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class Utils {
    private static ProgressDialog pDialog = null;

    public static int gainAmount(int i, int i2) {
        return i - i2;
    }

    public static int investedAmount(int i, int i2, boolean z) {
        if (!z) {
            i *= 12;
        }
        return (int) (((double) i) * ((double) i2));
    }

    public static void showProgressDialog(Activity activity, String str, boolean z) {
        ProgressDialog progressDialog = pDialog;
        if (progressDialog == null || !progressDialog.isShowing()) {
            ProgressDialog progressDialog2 = new ProgressDialog(activity);
            pDialog = progressDialog2;
            progressDialog2.setMessage(str);
            pDialog.setCancelable(z);
            pDialog.show();
        }
    }

    public static void dismissProgressDialog() {
        ProgressDialog progressDialog = pDialog;
        if (progressDialog != null && progressDialog.isShowing()) {
            pDialog.dismiss();
        }
    }


    public static void hideKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService("input_method");
        View currentFocus = activity.getCurrentFocus();
        if (currentFocus == null) {
            currentFocus = new View(activity);
        }
        inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
    }

    public static int gainAmountForPlan(int i, int i2, int i3, boolean z) {
        if (!z) {
            i3 *= 12;
        }
        double d = (double) (i - (i2 * i3));
        Log.e("strGainAmount--", "strGainAmount--" + d);
        return (int) d;
    }

    public static int calculateAmount(double d, double d2, double d3, boolean z) {
        if (!z) {
            d3 *= 12.0d;
        }
        double d4 = (d2 / 100.0d) / 12.0d;
        double d5 = d4 + 1.0d;
        return (int) (((d * d5) * (Math.pow(d5, d3) - 1.0d)) / d4);
    }

    public static int calculateOneTimeAmount(double d, double d2, double d3, boolean z) {
        if (!z) {
            d3 *= 12.0d;
        }
        return (int) (d * Math.pow((d2 / 100.0d) + 1.0d, d3 / 12.0d));
    }

    public static int calculatePlanAmount(double d, double d2, double d3, boolean z) {
        double d4 = (d2 / 100.0d) / 12.0d;
        if (!z) {
            d3 *= 12.0d;
        }
        double d5 = d4 + 1.0d;
        return (int) (d / (d5 * ((Math.pow(d5, d3) - 1.0d) / d4)));
    }

}