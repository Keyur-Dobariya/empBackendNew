package com.allcal.emicalculator_financetool.SIP.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.financial.all.calculator.databinding.OneTimeFragmentBinding;
import com.allcal.emicalculator_financetool.SIP.adapter.OneTimePlanDetailAdapter;
import com.allcal.emicalculator_financetool.SIP.common.SharedPrefManager;
import com.allcal.emicalculator_financetool.SIP.common.Utils;
import com.allcal.emicalculator_financetool.SIP.model.HistoryModel;
import com.allcal.emicalculator_financetool.SIP.model.SipPlanModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class OneTimeFragment extends Fragment {
    int expectedValue;
    int gainAmount;
    private boolean isMonthly = false;
    private ArrayList<HistoryModel> mHistoryList = new ArrayList<>();
    int rateOfInterest;
    SharedPreferences sharedpreferences;
    private ArrayList<SipPlanModel> sipDetailsList = new ArrayList<>();
    int timePeriod;
    int totalInvestedAmounts;

    OneTimeFragmentBinding binding;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        binding = OneTimeFragmentBinding.inflate(layoutInflater, viewGroup, false);
        onBtnEventListener();
        declaration();
        return binding.getRoot();
    }

    private void onBtnEventListener() {
        binding.swPeriod.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                isMonthly = z;
                if (isMonthly) {
                    binding.swPeriod.setText("Months");
                } else {
                    binding.swPeriod.setText("Years");
                }
            }
        });
        binding.btnReset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                clearAllData();
            }
        });
        binding.btnDetails.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sipDetailsList.clear();
                sipDetailsList = new ArrayList();
                binding.cvDetails.setVisibility(View.VISIBLE);
                if (isMonthly) {
                    binding.idTvPeriodType.setText("Period (Mnth)");
                } else {
                    binding.idTvPeriodType.setText("Period (Yrs)");
                }
                if (timePeriod != 0) {
                    new SipPlanModel();
                    for (int i = 1; i <= timePeriod; i++) {
                        int calculateOneTimeAmount = Utils.calculateOneTimeAmount((double) totalInvestedAmounts, (double) rateOfInterest, (double) i, isMonthly);
                        int i2 = totalInvestedAmounts;
                        if (!(calculateOneTimeAmount == 0 || i2 == 0)) {
                            SipPlanModel sipPlanModel = new SipPlanModel();
                            sipPlanModel.setExpectedAmount(String.valueOf(calculateOneTimeAmount));
                            sipPlanModel.setId(String.valueOf(i));
                            sipPlanModel.setInvestedAmount(String.valueOf(i2));
                            sipPlanModel.setPeriod(String.valueOf(i));
                            sipDetailsList.add(sipPlanModel);
                        }
                    }
                    if (sipDetailsList != null && sipDetailsList.size() > 0) {
                        OneTimePlanDetailAdapter oneTimePlanDetailAdapter = new OneTimePlanDetailAdapter(sipDetailsList, getActivity());
                        binding.rvOneTimePlan.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rvOneTimePlan.setAdapter(oneTimePlanDetailAdapter);
                    }
                }
            }
        });
        binding.btnCalculate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (checkValidation()) {
                    expectedValue = Utils.calculateOneTimeAmount((double) totalInvestedAmounts, (double) rateOfInterest, (double) timePeriod, isMonthly);
                    if (!(expectedValue == 0 || totalInvestedAmounts == 0)) {
                        gainAmount = Utils.gainAmount(expectedValue, totalInvestedAmounts);
                        binding.cvCalculate.setVisibility(View.VISIBLE);
                        binding.btnDetails.setVisibility(View.VISIBLE);
                        binding.cvDetails.setVisibility(View.GONE);
                        Utils.hideKeyboard(getActivity());
                    }
                    if (expectedValue != 0) {
                        binding.tvExpectedAmount.setText(": " + expectedValue);
                    }
                    if (totalInvestedAmounts != 0) {
                        binding.tvInvestedAmount.setText(": " + totalInvestedAmounts);
                    }
                    if (gainAmount != 0) {
                        binding.tvGainAmount.setText(": " + gainAmount);
                    }
                    String format = new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(Calendar.getInstance().getTime());
                    mHistoryList = new ArrayList();
                    HistoryModel historyModel = new HistoryModel();
                    historyModel.setAmount(String.valueOf(totalInvestedAmounts));
                    historyModel.setId(String.valueOf(System.currentTimeMillis() + 1));
                    historyModel.setPeriod(String.valueOf(timePeriod));
                    historyModel.setRate(String.valueOf(rateOfInterest));
                    historyModel.setLevel("One-Time");
                    historyModel.setDate(format);
                    if (isMonthly) {
                        historyModel.setPeriodType("months");
                    } else {
                        historyModel.setPeriodType("yrs");
                    }
                    mHistoryList.add(historyModel);
                    ArrayList<HistoryModel> historyList = SharedPrefManager.getInstance(getActivity()).getHistoryList(SharedPrefManager.SHARED_HISTORY);
                    if (historyList != null && historyList.size() > 0) {
                        mHistoryList.addAll(historyList);
                    }
                    if (mHistoryList != null && mHistoryList.size() > 0) {
                        SharedPrefManager.getInstance(getActivity()).saveHistoryList(SharedPrefManager.SHARED_HISTORY, mHistoryList);
                    }
                }
            }
        });
    }

    private void clearAllData() {
        binding.edtTotalInvest.getText().clear();
        binding.edtTotalInvest.requestFocus();
        binding.edtReturn.getText().clear();
        binding.edtPeriod.getText().clear();
        totalInvestedAmounts = 0;
        timePeriod = 0;
        rateOfInterest = 0;
        binding.cvCalculate.setVisibility(View.GONE);
        binding.btnDetails.setVisibility(View.GONE);
        binding.cvDetails.setVisibility(View.GONE);
    }

    private boolean checkValidation() {
        String obj = binding.edtPeriod.getText().toString();
        String obj2 = binding.edtTotalInvest.getText().toString();
        String obj3 = binding.edtReturn.getText().toString();
        if (obj2 == null || obj2.length() == 0) {
            binding.edtTotalInvest.setError("Please enter amount");
            binding.edtTotalInvest.requestFocus();
            return false;
        } else if (obj == null || obj.length() == 0) {
            binding.edtPeriod.setError("Please enter time period");
            binding.edtPeriod.requestFocus();
            return false;
        } else if (obj3 == null || obj3.length() == 0) {
            binding.edtReturn.setError("Please enter rate of return");
            binding.edtReturn.requestFocus();
            return false;
        } else {
            timePeriod = Integer.parseInt(obj);
            totalInvestedAmounts = Integer.parseInt(obj2);
            rateOfInterest = Integer.parseInt(obj3);
            return true;
        }
    }

    private void declaration() {
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        this.sharedpreferences = getActivity().getSharedPreferences("Count", 0);
    }


}