package com.allcal.emicalculator_financetool.SIP.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.financial.all.calculator.databinding.PlanFragmentBinding;
import com.allcal.emicalculator_financetool.SIP.adapter.PlanDetailAdapter;
import com.allcal.emicalculator_financetool.SIP.common.SharedPrefManager;
import com.allcal.emicalculator_financetool.SIP.common.Utils;
import com.allcal.emicalculator_financetool.SIP.model.HistoryModel;
import com.allcal.emicalculator_financetool.SIP.model.PlanModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class PlanFragment extends Fragment {
    int expectedReturnAmount;
    int gainAmount;
    private boolean isMonthly = false;
    private ArrayList<HistoryModel> mHistoryList = new ArrayList<>();
    int monthlyInvestment;
    private ArrayList<PlanModel> planDetailsList = new ArrayList<>();
    int rateOfInterest;
    SharedPreferences sharedpreferences;
    int timePeriod;

    PlanFragmentBinding binding;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        binding = PlanFragmentBinding.inflate(layoutInflater, viewGroup, false);
        onBtnEventListener();
        declaration();
        return binding.getRoot();
    }

    private void onBtnEventListener() {
        binding.swPeriod.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                isMonthly = z;
                if (isMonthly) {
                    binding.swPeriod.setText("Months");
                } else {
                    binding.swPeriod.setText("Years");
                }
            }
        });
        binding.btnReset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                clearAllData();
            }
        });
        binding.btnDetails.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                planDetailsList.clear();
                planDetailsList = new ArrayList();
                binding.cvDetails.setVisibility(View.VISIBLE);
                if (isMonthly) {
                    binding.idTvPeriodType.setText("Period (Mnth)");
                } else {
                    binding.idTvPeriodType.setText("Period (Yrs)");
                }
                if (timePeriod != 0) {
                    new PlanModel();
                    for (int i = 1; i <= timePeriod; i++) {
                        int calculateOneTimeAmount = Utils.calculateOneTimeAmount((double) expectedReturnAmount, (double) rateOfInterest, (double) i, isMonthly);
                        int calculatePlanAmount = Utils.calculatePlanAmount((double) expectedReturnAmount, (double) rateOfInterest, (double) timePeriod, isMonthly);
                        if (!(calculateOneTimeAmount == 0 || calculatePlanAmount == 0)) {
                            PlanModel planModel = new PlanModel();
                            planModel.setId(String.valueOf(i));
                            planModel.setOneTimeInvestment(String.valueOf(calculateOneTimeAmount));
                            planModel.setMonthlyInvestment(String.valueOf(calculatePlanAmount));
                            planModel.setPeriod(String.valueOf(i));
                            planDetailsList.add(planModel);
                        }
                    }
                    if (planDetailsList != null && planDetailsList.size() > 0) {
                        PlanDetailAdapter planDetailAdapter = new PlanDetailAdapter(planDetailsList, getActivity());
                        binding.rvPlan.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rvPlan.setAdapter(planDetailAdapter);
                    }
                }
            }
        });
        binding.btnCalculate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (checkValidation()) {
                    PlanFragment planFragment = PlanFragment.this;
                    planFragment.monthlyInvestment = Utils.calculatePlanAmount((double) planFragment.expectedReturnAmount, (double) rateOfInterest, (double) timePeriod, isMonthly);
                    if (!(expectedReturnAmount == 0 || monthlyInvestment == 0)) {
                        gainAmount = Utils.gainAmountForPlan(expectedReturnAmount, monthlyInvestment, timePeriod, isMonthly);
                        binding.cvCalculate.setVisibility(View.VISIBLE);
                        binding.btnDetails.setVisibility(View.VISIBLE);
                        binding.cvDetails.setVisibility(View.GONE);
                        Utils.hideKeyboard(getActivity());
                    }
                    if (expectedReturnAmount != 0) {
                        binding.tvExpectedAmount.setText(": " + expectedReturnAmount);
                    }
                    if (monthlyInvestment != 0) {
                        binding.tvMothlyInvestment.setText(": " + monthlyInvestment);
                    }
                    if (gainAmount != 0) {
                        binding.tvGainAmount.setText(": " + gainAmount);
                    }
                    String format = new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(Calendar.getInstance().getTime());
                    mHistoryList = new ArrayList();
                    HistoryModel historyModel = new HistoryModel();
                    historyModel.setAmount(String.valueOf(expectedReturnAmount));
                    historyModel.setId(String.valueOf(System.currentTimeMillis() + 1));
                    historyModel.setPeriod(String.valueOf(timePeriod));
                    historyModel.setRate(String.valueOf(rateOfInterest));
                    historyModel.setLevel("Plan");
                    historyModel.setDate(format);
                    if (isMonthly) {
                        historyModel.setPeriodType("months");
                    } else {
                        historyModel.setPeriodType("yrs");
                    }
                    mHistoryList.add(historyModel);
                    ArrayList<HistoryModel> historyList = SharedPrefManager.getInstance(getActivity()).getHistoryList(SharedPrefManager.SHARED_HISTORY);
                    if (historyList != null && historyList.size() > 0) {
                        mHistoryList.addAll(historyList);
                    }
                    if (mHistoryList != null && mHistoryList.size() > 0) {
                        SharedPrefManager.getInstance(getActivity()).saveHistoryList(SharedPrefManager.SHARED_HISTORY, mHistoryList);
                    }
                }
            }
        });
    }

    private void clearAllData() {
        binding.edtExpectedReturn.getText().clear();
        binding.edtExpectedReturn.requestFocus();
        binding.edtReturn.getText().clear();
        binding.edtPeriod.getText().clear();
        expectedReturnAmount = 0;
        timePeriod = 0;
        rateOfInterest = 0;
        binding.cvCalculate.setVisibility(View.GONE);
        binding.btnDetails.setVisibility(View.GONE);
        binding.cvDetails.setVisibility(View.GONE);
    }

    private boolean checkValidation() {
        String obj = binding.edtPeriod.getText().toString();
        String obj2 = binding.edtExpectedReturn.getText().toString();
        String obj3 = binding.edtReturn.getText().toString();
        if (obj2 == null || obj2.length() == 0) {
            binding.edtExpectedReturn.setError("Please enter amount");
            binding.edtExpectedReturn.requestFocus();
            return false;
        } else if (obj == null || obj.length() == 0) {
            binding.edtPeriod.setError("Please enter time period");
            binding.edtPeriod.requestFocus();
            return false;
        } else if (obj3 == null || obj3.length() == 0) {
            binding.edtReturn.setError("Please enter rate of return");
            binding.edtReturn.requestFocus();
            return false;
        } else {
            timePeriod = Integer.parseInt(obj);
            expectedReturnAmount = Integer.parseInt(obj2);
            rateOfInterest = Integer.parseInt(obj3);
            return true;
        }
    }

    private void declaration() {
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        sharedpreferences = getActivity().getSharedPreferences("Count", 0);
    }

}