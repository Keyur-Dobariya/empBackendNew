package com.allcal.emicalculator_financetool.SIP.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.financial.all.calculator.databinding.SipFragmentBinding;
import com.allcal.emicalculator_financetool.SIP.adapter.SipPlanDetailAdapter;
import com.allcal.emicalculator_financetool.SIP.common.SharedPrefManager;
import com.allcal.emicalculator_financetool.SIP.common.Utils;
import com.allcal.emicalculator_financetool.SIP.model.HistoryModel;
import com.allcal.emicalculator_financetool.SIP.model.SipPlanModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class SIPFragment extends Fragment {
    int expectedValue;
    int gainAmount;
    private boolean isMonthly = false;
    private ArrayList<HistoryModel> mHistoryList = new ArrayList<>();
    int monthlyInvestAmount;
    int rateOfInterest;
    SharedPreferences sharedpreferences;
    private ArrayList<SipPlanModel> sipDetailsList = new ArrayList<>();
    int timePeriod;
    int totalInvestedAmount;

    SipFragmentBinding binding;

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        binding = SipFragmentBinding.inflate(layoutInflater, viewGroup, false);
        onBtnEventListener();
        declaration();
        return binding.getRoot();
    }

    private void onBtnEventListener() {
        binding.swPeriod.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                isMonthly = z;
                if (z) {
                    binding.swPeriod.setText("Months");
                } else {
                    binding.swPeriod.setText("Years");
                }
            }
        });
        binding.btnReset.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                clearAllData();
            }
        });
        binding.btnDetails.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                sipDetailsList.clear();
                sipDetailsList = new ArrayList<>();
                binding.cvDetails.setVisibility(View.VISIBLE);
                if (isMonthly) {
                    binding.idTvPeriodType.setText("Period (Mnth)");
                } else {
                    binding.idTvPeriodType.setText("Period (Yrs)");
                }
                if (timePeriod != 0) {
                    new SipPlanModel();
                    for (int i = 1; i <= timePeriod; i++) {
                        int calculateAmount = Utils.calculateAmount((double) monthlyInvestAmount, (double) rateOfInterest, (double) i, isMonthly);
                        int investedAmount = Utils.investedAmount(i, monthlyInvestAmount, isMonthly);
                        if (!(calculateAmount == 0 || investedAmount == 0)) {
                            SipPlanModel sipPlanModel = new SipPlanModel();
                            sipPlanModel.setExpectedAmount(String.valueOf(calculateAmount));
                            sipPlanModel.setId(String.valueOf(i));
                            sipPlanModel.setInvestedAmount(String.valueOf(investedAmount));
                            sipPlanModel.setPeriod(String.valueOf(i));
                            sipDetailsList.add(sipPlanModel);
                        }
                    }
                    ArrayList<SipPlanModel> arrayList = sipDetailsList;
                    if (arrayList != null && arrayList.size() > 0) {
                        SipPlanDetailAdapter sipPlanDetailAdapter = new SipPlanDetailAdapter(sipDetailsList, getActivity());
                        binding.rvSipPlan.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rvSipPlan.setAdapter(sipPlanDetailAdapter);
                    }
                }
            }
        });
        binding.btnCalculate.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                if (checkValidation()) {
                    expectedValue = Utils.calculateAmount((double) monthlyInvestAmount, (double) rateOfInterest, (double) timePeriod, isMonthly);
                    int investedAmount = Utils.investedAmount(timePeriod, monthlyInvestAmount, isMonthly);
                    totalInvestedAmount = investedAmount;
                    int i = expectedValue;
                    if (!(i == 0 || investedAmount == 0)) {
                        gainAmount = Utils.gainAmount(i, investedAmount);
                        binding.cvCalculate.setVisibility(View.VISIBLE);
                        binding.btnDetails.setVisibility(View.VISIBLE);
                        binding.cvDetails.setVisibility(View.GONE);
                        Utils.hideKeyboard(getActivity());
                        String format = new SimpleDateFormat("dd MMM yyyy, hh:mm a").format(Calendar.getInstance().getTime());
                        mHistoryList = new ArrayList<>();
                        HistoryModel historyModel = new HistoryModel();
                        historyModel.setAmount(String.valueOf(monthlyInvestAmount));
                        historyModel.setId(String.valueOf(System.currentTimeMillis() + 1));
                        historyModel.setPeriod(String.valueOf(timePeriod));
                        historyModel.setRate(String.valueOf(rateOfInterest));
                        historyModel.setLevel("SIP");
                        if (isMonthly) {
                            historyModel.setPeriodType("months");
                        } else {
                            historyModel.setPeriodType("yrs");
                        }
                        historyModel.setDate(format);
                        mHistoryList.add(historyModel);
                        ArrayList<HistoryModel> historyList = SharedPrefManager.getInstance(getActivity()).getHistoryList(SharedPrefManager.SHARED_HISTORY);
                        if (historyList != null && historyList.size() > 0) {
                            mHistoryList.addAll(historyList);
                        }
                        ArrayList<HistoryModel> arrayList = mHistoryList;
                        if (arrayList != null && arrayList.size() > 0) {
                            SharedPrefManager.getInstance(getActivity()).saveHistoryList(SharedPrefManager.SHARED_HISTORY, mHistoryList);
                        }
                    }
                    if (expectedValue != 0) {
                        binding.tvExpectedAmount.setText(": " + expectedValue);
                    }
                    if (totalInvestedAmount != 0) {
                        binding.tvInvestedAmount.setText(": " + totalInvestedAmount);
                    }
                    if (gainAmount != 0) {
                        binding.tvGainAmount.setText(": " + gainAmount);
                    }
                }
            }
        });
    }


    private void clearAllData() {
        binding.edtMonthlyInvest.getText().clear();
        binding.edtMonthlyInvest.requestFocus();
        binding.edtReturn.getText().clear();
        binding.edtPeriod.getText().clear();
        monthlyInvestAmount = 0;
        timePeriod = 0;
        rateOfInterest = 0;
        binding.cvCalculate.setVisibility(View.GONE);
        binding.btnDetails.setVisibility(View.GONE);
        binding.cvDetails.setVisibility(View.GONE);
    }

    private boolean checkValidation() {
        String obj =  binding.edtPeriod.getText().toString();
        String obj2 = binding.edtMonthlyInvest.getText().toString();
        String obj3 = binding.edtReturn.getText().toString();
        if (obj2 == null || obj2.length() == 0) {
            binding.edtMonthlyInvest.setError("Please enter amount");
            binding.edtMonthlyInvest.requestFocus();
            return false;
        } else if (obj == null || obj.length() == 0) {
            binding.edtPeriod.setError("Please enter time period");
            binding.edtPeriod.requestFocus();
            return false;
        } else if (obj3 == null || obj3.length() == 0) {
            binding.edtReturn.setError("Please enter rate of return");
            binding.edtReturn.requestFocus();
            return false;
        } else {
            timePeriod = Integer.parseInt(obj);
            monthlyInvestAmount = Integer.parseInt(obj2);
            rateOfInterest = Integer.parseInt(obj3);
            return true;
        }
    }

    private void declaration() {
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        sharedpreferences = getActivity().getSharedPreferences("Count", 0);
    }


}