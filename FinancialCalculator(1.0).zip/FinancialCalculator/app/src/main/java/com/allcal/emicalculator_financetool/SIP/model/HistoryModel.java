package com.allcal.emicalculator_financetool.SIP.model;

public class HistoryModel {
    String amount;
    String date;
    String id;
    String level;
    String period;
    String periodType;
    String rate;

    public String getPeriodType() {
        return this.periodType;
    }

    public void setPeriodType(String str) {
        this.periodType = str;
    }

    public String getAmount() {
        return this.amount;
    }

    public void setAmount(String str) {
        this.amount = str;
    }

    public String getRate() {
        return this.rate;
    }

    public void setRate(String str) {
        this.rate = str;
    }

    public String getPeriod() {
        return this.period;
    }

    public void setPeriod(String str) {
        this.period = str;
    }

    public String getLevel() {
        return this.level;
    }

    public void setLevel(String str) {
        this.level = str;
    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String str) {
        this.date = str;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }
}