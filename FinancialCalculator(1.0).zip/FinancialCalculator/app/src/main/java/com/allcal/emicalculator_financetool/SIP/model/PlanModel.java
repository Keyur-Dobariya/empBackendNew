package com.allcal.emicalculator_financetool.SIP.model;

public class PlanModel {
    String id;
    String monthlyInvestment;
    String oneTimeInvestment;
    String period;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getPeriod() {
        return this.period;
    }

    public void setPeriod(String str) {
        this.period = str;
    }

    public String getMonthlyInvestment() {
        return this.monthlyInvestment;
    }

    public void setMonthlyInvestment(String str) {
        this.monthlyInvestment = str;
    }

    public String getOneTimeInvestment() {
        return this.oneTimeInvestment;
    }

    public void setOneTimeInvestment(String str) {
        this.oneTimeInvestment = str;
    }
}