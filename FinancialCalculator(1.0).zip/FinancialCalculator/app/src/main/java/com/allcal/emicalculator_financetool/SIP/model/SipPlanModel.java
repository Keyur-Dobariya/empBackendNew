package com.allcal.emicalculator_financetool.SIP.model;

public class SipPlanModel {
    String expectedAmount;
    String id;
    String investedAmount;
    String period;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getPeriod() {
        return this.period;
    }

    public void setPeriod(String str) {
        this.period = str;
    }

    public String getInvestedAmount() {
        return this.investedAmount;
    }

    public void setInvestedAmount(String str) {
        this.investedAmount = str;
    }

    public String getExpectedAmount() {
        return this.expectedAmount;
    }

    public void setExpectedAmount(String str) {
        this.expectedAmount = str;
    }
}