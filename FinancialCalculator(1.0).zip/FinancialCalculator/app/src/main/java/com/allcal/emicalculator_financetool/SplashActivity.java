package com.allcal.emicalculator_financetool;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.financial.all.calculator.databinding.ActivitySplashBinding;
import com.financial.all.calculator.ui.theme.ads.commons.AdsManager;
import com.financial.all.calculator.ui.theme.ads.interfaces.OnFirstData;

public class SplashActivity extends AppCompatActivity implements OnFirstData {
    ActivitySplashBinding binding;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnRetry.setOnClickListener(view -> {
            binding.btnRetry.setVisibility(View.GONE);
            AdsManager.getFirstData(getApplication(), getApplication(), SplashActivity.this, SplashActivity.this);
        });
        binding.btnRetry.performClick();
    }

    @Override
    public void onSuccess() {
        startActivity(new Intent(SplashActivity.this, DashboardActivity.class));
        new Handler().postDelayed(this::finish, 500);
    }

    @Override
    public void onFailed() {
        binding.progress.setVisibility(View.GONE);
        binding.btnRetry.setVisibility(View.VISIBLE);
    }
}
