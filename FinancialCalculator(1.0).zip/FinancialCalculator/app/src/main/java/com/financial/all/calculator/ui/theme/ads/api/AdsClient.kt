package com.financial.all.calculator.ui.theme.ads.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object AdsClient {

    private var retrofit: Retrofit? = null
    private const val baseUrl = "https://d3kmixgre4hliw.cloudfront.net/"

    fun getClient(): AdsInterface {
        if (retrofit == null) {
            retrofit =
                Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create()).build()
        }
        return retrofit!!.create(AdsInterface::class.java)
    }
}