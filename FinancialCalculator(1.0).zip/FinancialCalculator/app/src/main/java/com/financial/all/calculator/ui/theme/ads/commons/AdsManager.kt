package com.financial.all.calculator.ui.theme.ads.commons

import android.app.Activity
import android.app.Application
import android.content.Context
import com.financial.all.calculator.ui.theme.ads.api.AdsClient
import com.financial.all.calculator.ui.theme.ads.app.MainApplicaton
import com.financial.all.calculator.ui.theme.ads.interfaces.OnFirstData
import com.financial.all.calculator.ui.theme.ads.interstitial.InterstitialAds
import com.financial.all.calculator.ui.theme.ads.model.FirstData
import com.financial.all.calculator.ui.theme.ads.nativee.PreloadNativeAds
import com.financial.all.calculator.ui.theme.ads.nativee.PreloadSmallNativeAds
import com.financial.all.calculator.ui.theme.ads.reward.RewardInterstitialAds
import com.financial.all.calculator.ui.theme.ads.reward.RewardVideoAds
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object AdsManager {
    @JvmStatic
    fun getFirstData(
        application: Application, context: Context, activity: Activity, onFirstData: OnFirstData?
    ) {
        AdsClient.getClient().getFirstDataCall(context.packageName.replace(".", "_").plus("3"))
            .enqueue(object : Callback<FirstData> {
                override fun onResponse(call: Call<FirstData>, response: Response<FirstData>) {
                    if (response.body() != null) {
                        val appData = AdsUtils.decrypt(response.body()!!.data)
                        AdsUtils.saveAdPref(context, appData!!)
                        AdsUtils.initNextAds(context)
                        initAppOpenAd(context, application, activity, onFirstData)
                        RewardVideoAds.load(context)
                        RewardInterstitialAds.load(context)
                        PreloadNativeAds.loadAd(context)
                        PreloadSmallNativeAds.loadAd(context)
                    } else {
                        onFirstData?.onFailed()
                    }
                }

                override fun onFailure(call: Call<FirstData>, t: Throwable) {
                    onFirstData?.onFailed()
                }
            })
        AdsUtils.getMoreApps(context)
    }

    private fun initAppOpenAd(
        context: Context, application: Application, activity: Activity, onFirstData: OnFirstData?
    ) {
        val mainApplication = application as? MainApplicaton
        if (mainApplication == null) {
            handler(4000) { onFirstData?.onSuccess() }
        } else if (AdsUtils.isAppOpenEnabled(context)) {
            if (AdsUtils.isSplashAppOpenEnabled(context)) {
                mainApplication.initAppOpenManager(activity, object : MainApplicaton.OnSplashAd {
                    override fun onAdClosed(isFailed: Boolean) {
                        mainApplication.onSplashAd = null
                        if (isFailed) {
                            AdsUtils.ignoreIntSkip(context)
                        }
                        InterstitialAds.loadAd(context)
                        onFirstData?.onSuccess()
                    }
                })
            } else {
                mainApplication.initAppOpenManager()
            }
        } else {
            handler(4000) { onFirstData?.onSuccess() }
        }
    }

    @JvmStatic
    fun release(application: Application) {
        AdsUtils.reset()
        (application as? MainApplicaton)?.release()
        InterstitialAds.release()
        PreloadNativeAds.release()
        PreloadSmallNativeAds.release()
        RewardInterstitialAds.release()
        RewardVideoAds.release()
    }
}