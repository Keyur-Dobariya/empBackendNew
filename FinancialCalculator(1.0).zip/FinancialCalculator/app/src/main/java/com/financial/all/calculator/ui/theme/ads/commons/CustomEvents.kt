package com.financial.all.calculator.ui.theme.ads.commons

import android.content.Context

//import com.google.firebase.analytics.FirebaseAnalytics

class CustomEvents {

    companion object {
        const val ADMOB = "admob"
        const val META = "meta"

        //TODO uncomment after adding firebase
        fun interstitialAd(context: Context, network: String) {
//            inReleaseMode {
//                val params = Bundle().apply {
////                    putString(FirebaseAnalytics.Param.AD_PLATFORM, network)
////                    putString(FirebaseAnalytics.Param.AD_FORMAT, "interstitial")
//                }
////                FirebaseAnalytics.getInstance(context).logEvent(network + "_interstitial", params)
//            }
        }

        fun nativeAd(context: Context, network: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.AD_PLATFORM, network)
//                    putString(FirebaseAnalytics.Param.AD_FORMAT, "native")
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(network + "_native", params)
            }
        }

        fun bannerAd(context: Context, network: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.AD_PLATFORM, network)
//                    putString(FirebaseAnalytics.Param.AD_FORMAT, "banner")
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(network + "_banner", params)
            }
        }

        fun appOpenAd(context: Context, network: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.AD_PLATFORM, network)
//                    putString(FirebaseAnalytics.Param.AD_FORMAT, "appopen")
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(network + "_appopen", params)
            }
        }

        fun rewardVideoAd(context: Context, network: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.AD_PLATFORM, network)
//                    putString(FirebaseAnalytics.Param.AD_FORMAT, "rewardvideo")
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(network + "_rewardvideo", params)
            }
        }

        fun rewardIntAd(context: Context, network: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.AD_PLATFORM, network)
//                    putString(FirebaseAnalytics.Param.AD_FORMAT, "rewardint")
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(network + "_rewardint", params)
            }
        }

        fun inAppEvent(context: Context, price: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.ITEM_NAME, "remove_ads")
//                    putString(FirebaseAnalytics.Param.PRICE, price)
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(FirebaseAnalytics.Event.PURCHASE, params)
            }
        }

        @JvmStatic
        fun customEvent(context: Context, event: String) {
            inReleaseMode {
//                val params = Bundle().apply {
//                    putString(FirebaseAnalytics.Param.ITEM_NAME, event)
//                }
//                FirebaseAnalytics.getInstance(context).logEvent(event, params)
            }
        }
    }
}