package com.financial.all.calculator.ui.theme.ads.interfaces

interface OnFirstData {
    fun onSuccess()
    fun onFailed()
}