package com.financial.all.calculator.ui.theme.ads.interfaces

interface OnInterstitialAdResponse {
    fun onAdClosed()
    fun onAdImpression()
}