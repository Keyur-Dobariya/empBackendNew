package com.financial.all.calculator.ui.theme.ads.interfaces

interface OnRewardAdResponse {
    fun onRewardEarned()
    fun onAdImpression()
    fun onAdCancelled()
    fun onAdFailed()
}