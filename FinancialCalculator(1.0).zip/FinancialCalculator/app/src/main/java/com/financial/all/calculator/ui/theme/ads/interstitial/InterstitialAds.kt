package com.financial.all.calculator.ui.theme.ads.interstitial

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.facebook.ads.Ad
import com.facebook.ads.InterstitialAdListener
import com.financial.all.calculator.R
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.financial.all.calculator.ui.theme.ads.commons.AdDialog
import com.financial.all.calculator.ui.theme.ads.commons.AdsUtils
import com.financial.all.calculator.ui.theme.ads.commons.CustomEvents
import com.financial.all.calculator.ui.theme.ads.commons.handler
import com.financial.all.calculator.ui.theme.ads.commons.loadWithGlide
import com.financial.all.calculator.ui.theme.ads.commons.loge
import com.financial.all.calculator.ui.theme.ads.commons.openPlayStore
import com.financial.all.calculator.ui.theme.ads.interfaces.OnInterstitialAdResponse
import com.financial.all.calculator.ui.theme.ads.interfaces.OnRewardAdResponse

object InterstitialAds {

    private var googleInterstitialAd: InterstitialAd? = null
    private var metaInterstitialAd: com.facebook.ads.InterstitialAd? = null
    private var isAdLoading = false
    private var isAdFailed = false
    private var intIndex = 0
    private var onRewardAdResponse: OnRewardAdResponse? = null
    private const val adDelay = 200L
    private const val waitDelay = 1000L

    fun loadAd(context: Context) {
        if (!AdsUtils.isAdEnabled(context)) {
            return
        }
        if (AdsUtils.isNextIntGoogle()) {
            loadGoogleAd(context)
        } else if (AdsUtils.isNextIntMeta()) {
            loadMetaAd(context)
        }
    }

    private fun loadMetaAd(context: Context) {
        loge("loadAds:InterstitialAds:loadMetaAd")
        if (metaInterstitialAd != null || isAdLoading) {
            return
        }
        isAdLoading = true
        isAdFailed = false
        metaInterstitialAd =
            com.facebook.ads.InterstitialAd(context, AdsUtils.getAdPref(context).fbInt)
        metaInterstitialAd?.loadAd(
            metaInterstitialAd?.buildLoadAdConfig()
                ?.withAdListener(object : InterstitialAdListener {
                    override fun onError(p0: Ad?, p1: com.facebook.ads.AdError?) {
                        isAdLoading = false
                        isAdFailed = true
                        metaInterstitialAd = null
                        AdsUtils.setNextIntOnMetaFail(context)
                        if (AdsUtils.isNextIntGoogle()) {
                            loadGoogleAd(context)
                        } else {
                            onWaitListener?.onAdFailed()
                        }
                    }

                    override fun onAdLoaded(p0: Ad?) {
                        onWaitListener?.onMetaAdLoaded()
                        isAdLoading = false
                        isAdFailed = false
                    }

                    override fun onAdClicked(p0: Ad?) {}

                    override fun onLoggingImpression(p0: Ad?) {
                        CustomEvents.interstitialAd(context, CustomEvents.META)
                    }

                    override fun onInterstitialDisplayed(p0: Ad?) {
                        AdDialog.dismissAdDialog()
                        if (!isRequired) {
                            AdsUtils.intAdShown()
                        }
                        onInterstitialAdResponse?.onAdImpression()
                        AdsUtils.isInterstitialAdShowing = true
                        AdsUtils.setNextInt(context, AdsUtils.META)
                    }

                    override fun onInterstitialDismissed(p0: Ad?) {
                        metaInterstitialAd = null
                        AdsUtils.isInterstitialAdShowing = false
                        onInterstitialAdResponse?.onAdClosed()
                        onRewardAdResponse?.onRewardEarned()
                        setDelayAd(context)
                    }
                })?.build()
        )
    }

    private fun loadGoogleAd(context: Context) {
        loge("loadAds:InterstitialAds:loadGoogleAd")
        if (googleInterstitialAd != null || isAdLoading) {
            return
        }
        isAdLoading = true
        isAdFailed = false
        val placementId = getPlacementId(context)
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(context, placementId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(p0: InterstitialAd) {
                isAdLoading = false
                isAdFailed = false
                googleInterstitialAd = p0
                onWaitListener?.onGoogleAdLoaded()
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                isAdLoading = false
                isAdFailed = true
                googleInterstitialAd = null
                if (AdsUtils.getAdPref(context).intBackFill) {
                    loadGoogleAdOnFail(context)
                } else {
                    onWaitListener?.onAdFailed()
                }
            }
        })
    }

    private fun loadGoogleAdOnFail(context: Context) {
        if (!AdsUtils.isAdEnabled(context) || googleInterstitialAd != null || isAdLoading) {
            return
        }
        isAdLoading = true
        isAdFailed = false
        val placementId = getPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            onWaitListener?.onAdFailed()
            return
        }
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(context, placementId, adRequest, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(p0: InterstitialAd) {
                isAdLoading = false
                isAdFailed = false
                googleInterstitialAd = p0
                onWaitListener?.onGoogleAdLoaded()
            }

            override fun onAdFailedToLoad(p0: LoadAdError) {
                isAdLoading = false
                isAdFailed = true
                googleInterstitialAd = null
                loadGoogleAdOnFail(context)
            }
        })
    }

    @JvmStatic
    fun showAd(context: Context, onInterstitialAdResponse: OnInterstitialAdResponse?) {
        if (!AdsUtils.isAdEnabled(context)) {
            if (AdsUtils.isInHouseEnabled(context)) {
                showInHouseAd(context, onInterstitialAdResponse)
            } else {
                onInterstitialAdResponse?.onAdClosed()
            }
            return
        }
        if (AdsUtils.isNextIntGoogle()) {
            showGoogleAd(context, onInterstitialAdResponse)
        } else if (AdsUtils.isNextIntMeta()) {
            showMetaAd(context, onInterstitialAdResponse)
        } else {
            onInterstitialAdResponse?.onAdClosed()
        }
    }

    private var onInterstitialAdResponse: OnInterstitialAdResponse? = null

    //todo if failed
    private fun showMetaAd(context: Context, onInterstitialAdResponse: OnInterstitialAdResponse?) {
        loge("InterstitialAds:showMetaAd")
        if (!isRequired) {
            if (!AdsUtils.isIntEligibleToShow(context)) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onInterstitialAdResponse?.onAdClosed()
                return
            }
        }
        if (!AdsUtils.getAdPref(context).forcedInt) {
            if (metaInterstitialAd == null) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onInterstitialAdResponse?.onAdClosed()
            } else if (!metaInterstitialAd?.isAdLoaded!! || metaInterstitialAd?.isAdInvalidated!!) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onInterstitialAdResponse?.onAdClosed()
            } else {
                InterstitialAds.onInterstitialAdResponse = onInterstitialAdResponse
                metaInterstitialAd?.show()
            }
        } else {
            if (metaInterstitialAd == null || (!metaInterstitialAd?.isAdLoaded!! || metaInterstitialAd?.isAdInvalidated!!)) {
                if (isAdLoading) {
                    var isLastTry = true
                    AdDialog.showAdDialog(context)
                    onWaitListener = object : OnWaitListener {
                        override fun onGoogleAdLoaded() {
                            onWaitListener = null
                            handler(waitDelay) {
                                setGoogleCallback(
                                    context,
                                    onInterstitialAdResponse
                                )
                            }
                        }

                        override fun onMetaAdLoaded() {
                            onWaitListener = null
                            handler(waitDelay) {
                                InterstitialAds.onInterstitialAdResponse = onInterstitialAdResponse
                                metaInterstitialAd?.show()
                            }
                        }

                        override fun onAdFailed() {
                            if (isLastTry) {
                                isLastTry = false
                                loadAd(context)
                            } else {
                                AdDialog.dismissAdDialog()
                                onWaitListener = null
                                onInterstitialAdResponse?.onAdClosed()
                            }
                        }
                    }
                } else if (isAdFailed) {
                    AdDialog.showAdDialog(context)
                    onWaitListener = object : OnWaitListener {
                        override fun onGoogleAdLoaded() {
                            onWaitListener = null
                            handler(waitDelay) {
                                setGoogleCallback(
                                    context,
                                    onInterstitialAdResponse
                                )
                            }
                        }

                        override fun onMetaAdLoaded() {
                            onWaitListener = null
                            handler(waitDelay) {
                                InterstitialAds.onInterstitialAdResponse = onInterstitialAdResponse
                                metaInterstitialAd?.show()
                            }
                        }

                        override fun onAdFailed() {
                            AdDialog.dismissAdDialog()
                            onWaitListener = null
                            onInterstitialAdResponse?.onAdClosed()
                        }
                    }
                    loadAd(context)
                }
            } else {
                InterstitialAds.onInterstitialAdResponse = onInterstitialAdResponse
                metaInterstitialAd?.show()
            }
        }
    }

    interface OnWaitListener {
        fun onGoogleAdLoaded()
        fun onMetaAdLoaded()
        fun onAdFailed()
    }

    private var onWaitListener: OnWaitListener? = null

    private fun showGoogleAd(
        context: Context,
        onInterstitialAdResponse: OnInterstitialAdResponse?
    ) {
        loge("InterstitialAds:showGoogleAd")
        if (!isRequired) {
            if (!AdsUtils.isIntEligibleToShow(context)) {
                onInterstitialAdResponse?.onAdClosed()
                return
            }
        }
        if (!AdsUtils.getAdPref(context).forcedInt) {
            if (googleInterstitialAd == null) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onInterstitialAdResponse?.onAdClosed()
            } else {
                AdDialog.showAdDialog(context)
                handler(waitDelay) { setGoogleCallback(context, onInterstitialAdResponse) }
            }
//                setGoogleCallback(context, onInterstitialAdResponse)
        } else {
            if (googleInterstitialAd == null) {
                if (isAdLoading) {
                    var isLastTry = true
                    AdDialog.showAdDialog(context)
                    onWaitListener = object : OnWaitListener {
                        override fun onGoogleAdLoaded() {
                            onWaitListener = null
                            handler(waitDelay) {
                                setGoogleCallback(
                                    context,
                                    onInterstitialAdResponse
                                )
                            }
                        }

                        override fun onMetaAdLoaded() {

                        }

                        override fun onAdFailed() {
                            if (isLastTry) {
                                isLastTry = false
                                loadAd(context)
                            } else {
                                AdDialog.dismissAdDialog()
                                onWaitListener = null
                                onInterstitialAdResponse?.onAdClosed()
                            }
                        }
                    }
                } else if (isAdFailed) {
                    AdDialog.showAdDialog(context)
                    onWaitListener = object : OnWaitListener {
                        override fun onGoogleAdLoaded() {
                            onWaitListener = null
                            handler(waitDelay) {
                                setGoogleCallback(
                                    context,
                                    onInterstitialAdResponse
                                )
                            }
                        }

                        override fun onMetaAdLoaded() {
                        }

                        override fun onAdFailed() {
                            AdDialog.dismissAdDialog()
                            onWaitListener = null
                            onInterstitialAdResponse?.onAdClosed()
                        }
                    }
                    loadAd(context)
                }
            } else {
                AdDialog.showAdDialog(context)
                handler(waitDelay) {
                    setGoogleCallback(context, onInterstitialAdResponse)
                }
            }
        }
    }

    private fun setGoogleCallback(
        context: Context,
        onInterstitialAdResponse: OnInterstitialAdResponse?
    ) {
        googleInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                AdDialog.dismissAdDialog()
                if (!isRequired) {
                    AdsUtils.intAdShown()
                }
                onInterstitialAdResponse?.onAdImpression()
                AdsUtils.isInterstitialAdShowing = true
                AdsUtils.setNextInt(context, AdsUtils.GOOGLE)
            }

            override fun onAdDismissedFullScreenContent() {
                googleInterstitialAd = null
                AdsUtils.isInterstitialAdShowing = false
                onInterstitialAdResponse?.onAdClosed()
                setDelayAd(context)
            }

            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                AdDialog.dismissAdDialog()
                isRequired = false
                onInterstitialAdResponse?.onAdClosed()
            }

            override fun onAdImpression() {
                CustomEvents.interstitialAd(context, CustomEvents.ADMOB)
            }
        }
        googleInterstitialAd?.show(context as Activity)
    }

    private fun setDelayAd(context: Context) {
        if (isRequired) {
            isRequired = false
            handler(adDelay) { loadAd(context) }
            return
        }
        if (AdsUtils.getAdPref(context).intType.equals("click", true)) {
            isAdLoading = true
            handler(adDelay) {
                isAdLoading = false
                loadAd(context)
            }
        } else {
            var delay = AdsUtils.getAdPref(context).intTimeInterval
            if (delay - 5 > 0) {
                delay -= 5
            }
            isAdLoading = true
            handler(delay * 1000L) {
                isAdLoading = false
                loadAd(context)
            }
        }
    }

    @JvmStatic
    fun showBackPressAd(context: Context, onInterstitialAdResponse: OnInterstitialAdResponse?) {
        if (!AdsUtils.isAdEnabled(context)) {
            onInterstitialAdResponse?.onAdClosed()
            return
        }
        if (!AdsUtils.getAdPref(context).backPressEnabled) {
            onInterstitialAdResponse?.onAdClosed()
            return
        }
        showAd(context, onInterstitialAdResponse)
    }

    private var isRequired = false

    @JvmStatic
    fun showRequiredAd(context: Context, onInterstitialAdResponse: OnInterstitialAdResponse?) {
        if (!AdsUtils.isAdEnabled(context)) {
            onInterstitialAdResponse?.onAdClosed()
            return
        }
        isRequired = true
        showAd(context, onInterstitialAdResponse)
    }

    internal fun showForRewardAd(context: Context, onRewardAdResponse: OnRewardAdResponse?) {
        if (AdsUtils.isNextIntGoogle()) {
            if (googleInterstitialAd == null) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onRewardAdResponse?.onAdFailed()
                return
            }
        } else if (AdsUtils.isNextIntMeta()) {
            if (metaInterstitialAd == null) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onRewardAdResponse?.onAdFailed()
                return
            }
            if (!metaInterstitialAd!!.isAdLoaded && !metaInterstitialAd!!.isAdInvalidated) {
                if (isAdFailed) {
                    loadAd(context)
                }
                onRewardAdResponse?.onAdFailed()
                return
            }
        }
        if (AdsUtils.isNextIntGoogle()) {
            googleInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() {
                    onRewardAdResponse?.onAdImpression()
                    AdsUtils.isInterstitialAdShowing = true
                    AdsUtils.setNextInt(context, AdsUtils.GOOGLE)
                }

                override fun onAdDismissedFullScreenContent() {
                    googleInterstitialAd = null
                    AdsUtils.isInterstitialAdShowing = false
                    onRewardAdResponse?.onRewardEarned()
                    handler(adDelay) {
                        loadAd(context)
                    }
                }

                override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                    onRewardAdResponse?.onAdFailed()
                }

                override fun onAdImpression() {
                    CustomEvents.interstitialAd(context, CustomEvents.ADMOB)
                }
            }
            googleInterstitialAd?.show(context as Activity)
        } else if (AdsUtils.isNextIntMeta()) {
            InterstitialAds.onRewardAdResponse = onRewardAdResponse
            metaInterstitialAd?.show()
        }
    }

    private fun showInHouseAd(
        context: Context,
        onInterstitialAdResponse: OnInterstitialAdResponse?
    ) {
        Dialog(context, android.R.style.Theme_Translucent_NoTitleBar).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(R.layout.more_interstitial)
            val win = window
            val params = win!!.attributes
            params.gravity = Gravity.CENTER
            window!!.attributes = params
            window!!.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            val imgInt = findViewById<AppCompatImageView>(R.id.imgInt)
            val icon = findViewById<AppCompatImageView>(R.id.ad_app_icon)
            val title = findViewById<AppCompatTextView>(R.id.ad_headline)
            val des = findViewById<AppCompatTextView>(R.id.ad_body)
            val action = findViewById<MaterialButton>(R.id.ad_call_to_action)
            val cardView = findViewById<CardView>(R.id.card_view)
            val main = findViewById<ConstraintLayout>(R.id.main)
            val btnClose = findViewById<FloatingActionButton>(R.id.btn_close)
            val moreApp = AdsUtils.getMoreAppsPref(context).apps.random()
            val assetUrl = moreApp.appAssetUrl
            val intUrl = assetUrl.plus(moreApp.appInt.random())
            Glide.with(imgInt).asDrawable().load(intUrl).diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(object : CustomTarget<Drawable>() {
                    override fun onResourceReady(
                        resource: Drawable, transition: Transition<in Drawable>?
                    ) {
                        imgInt.background = resource
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {

                    }
                })
            imgInt.loadWithGlide(intUrl)
            icon.loadWithGlide(assetUrl.plus(moreApp.appIcon.random()))
            title.text = moreApp.appTitle.random()
            des.text = moreApp.appDes.random()
            main.setOnClickListener {
                context.openPlayStore(moreApp.appPkgName)
            }
            action.setOnClickListener {
                context.openPlayStore(moreApp.appPkgName)
            }
            cardView.setOnClickListener {
                context.openPlayStore(moreApp.appPkgName)
            }
            btnClose.setOnClickListener {
                dismiss()
            }
            setOnDismissListener {
                onInterstitialAdResponse?.onAdClosed()
            }
            show()
        }
    }

    private fun getPlacementId(context: Context): String {
        val intIds = AdsUtils.getAdPref(context).intIds
        intIndex = 0
        return intIds[intIndex]
    }

    private fun getPlacementIdOnFail(context: Context): String {
        val intIds = AdsUtils.getAdPref(context).intIds
        intIndex++
        return if (intIndex < intIds.size) {
            intIds[intIndex]
        } else {
            ""
        }
    }

    fun release() {
        googleInterstitialAd = null
        metaInterstitialAd?.destroy()
        metaInterstitialAd = null
    }

}