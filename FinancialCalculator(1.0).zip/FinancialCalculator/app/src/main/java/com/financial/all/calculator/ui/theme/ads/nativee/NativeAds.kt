package com.financial.all.calculator.ui.theme.ads.nativee

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.DimenRes
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.financial.all.calculator.ui.theme.ads.commons.AdsUtils
import com.financial.all.calculator.ui.theme.ads.commons.dimen
import com.financial.all.calculator.ui.theme.ads.commons.hide
import com.financial.all.calculator.ui.theme.ads.commons.loadWithGlide
import com.financial.all.calculator.ui.theme.ads.commons.loge
import com.financial.all.calculator.ui.theme.ads.commons.openPlayStore
import com.financial.all.calculator.ui.theme.ads.commons.show
import com.financial.all.calculator.ui.theme.ads.commons.vanish
import com.facebook.ads.*
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textview.MaterialTextView
import com.financial.all.calculator.ui.theme.ads.commons.CustomEvents
import kotlin.random.Random
import com.financial.all.calculator.R

class NativeAds @JvmOverloads constructor(
    private val screenName: String,
    @DimenRes private val minHeight: Int = R.dimen._native_regular,
    @LayoutRes private val admobLayoutId: Int = R.layout.native_google,
    @LayoutRes private val fbLayoutId: Int = R.layout.native_meta,
    @LayoutRes private val loader: Int = R.layout.ads_loader
) {

    private var nativeIndex = 0
    private var bannerIndex = 0

    fun showAd(
        context: Context, adMobNative: FrameLayout, fbNative: NativeAdLayout, parent: View?
    ) {
        if (!AdsUtils.isAdEnabled(context)) {
            if (AdsUtils.isInHouseEnabled(context)) {
                showInHouseAd(context, adMobNative)
            } else {
                parent?.hide()
            }
            return
        }
        val hasNativeScreen = AdsUtils.getAdPref(context).nativeScreens.contains(screenName, true)
        val hasBannerScreen = AdsUtils.getAdPref(context).inlineBannerScreens.contains(screenName, true)

        if (!hasNativeScreen && !hasBannerScreen) {
            parent?.hide()
            return
        }
        if (AdsUtils.isInHouseEnabled(context)) {
            showInHouseAd(context, adMobNative)
        } else {
            addAdLoader(context, adMobNative)
        }
        if (AdsUtils.isNextNativeGoogle()) {
            fbNative.hide()
            if (hasNativeScreen && hasBannerScreen) {
                if (Random.nextBoolean()) {
                    if (PreloadNativeAds.googleNativeAd == null) {
                        showGoogleAd(context, adMobNative)
                    } else {
                        showPreloadedGoogleAd(context, adMobNative)
                    }
                } else {
                    showGoogleInlineBannerAd(context, adMobNative, parent)
                }
            } else if (hasNativeScreen) {
                if (PreloadNativeAds.googleNativeAd == null) {
                    showGoogleAd(context, adMobNative)
                } else {
                    showPreloadedGoogleAd(context, adMobNative)
                }
            } else {
                showGoogleInlineBannerAd(context, adMobNative, parent)
            }
        } else if (AdsUtils.isNextNativeMeta()) {
            if (AdsUtils.getAdPref(context).showFbRectBanner) {
                if (hasNativeScreen && hasBannerScreen) {
                    if (Random.nextBoolean()) {
                        if (PreloadNativeAds.metaNativeAd != null && !PreloadNativeAds.metaNativeAd!!.isAdInvalidated) {
                            showPreloadedMetaAd(context, adMobNative, fbNative)
                        } else {
                            showMetaAd(context, adMobNative, fbNative)
                        }
                    } else {
                        showMetaInlineBanner(context, adMobNative, fbNative, parent)
                    }
                } else if (hasNativeScreen) {
                    if (PreloadNativeAds.metaNativeAd != null && !PreloadNativeAds.metaNativeAd!!.isAdInvalidated) {
                        showPreloadedMetaAd(context, adMobNative, fbNative)
                    } else {
                        showMetaAd(context, adMobNative, fbNative)
                    }
                } else {
                    showMetaInlineBanner(context, adMobNative, fbNative, parent)
                }
            } else {
                if (PreloadNativeAds.metaNativeAd != null && !PreloadNativeAds.metaNativeAd!!.isAdInvalidated) {
                    showPreloadedMetaAd(context, adMobNative, fbNative)
                } else {
                    showMetaAd(context, adMobNative, fbNative)
                }
            }
        } else {
            parent?.hide()
        }
    }

    private fun showPreloadedMetaAd(context: Context, adMobNative: FrameLayout, fbNative: NativeAdLayout) {
        adMobNative.removeAllViews()
        adMobNative.hide()
        fbNative.removeAllViews()
        val nativeAd = PreloadNativeAds.metaNativeAd!!
        inflateMetaAd(context, nativeAd, fbNative)
    }

    private fun showPreloadedGoogleAd(context: Context, adMobNative: FrameLayout) {
        val adView = (context as Activity).layoutInflater.inflate(
            admobLayoutId, null
        ) as NativeAdView
        val nativeAd = PreloadNativeAds.googleNativeAd!!
        populateNativeAdView(context, nativeAd, adView)
        adMobNative.removeAllViews()
        adMobNative.addView(adView)
    }

    private fun showMetaAd(context: Context, adMobNative: FrameLayout, fbNative: NativeAdLayout) {
        loge("loadAds:NativeAds:showMetaAd")
        NativeAd(context, AdsUtils.getAdPref(context).fbNative).apply {
            val nativeAdListener = object : NativeAdListener {
                override fun onError(p0: Ad?, p1: AdError?) {
                    AdsUtils.setNextNativeOnMetaFail(context)
                    if (AdsUtils.isNextNativeGoogle()) {
                        adMobNative.show()
                        showGoogleAd(context, adMobNative)
                    }
                }

                override fun onAdLoaded(p0: Ad?) {
                    if (this@apply != p0) {
                        return
                    }
                    adMobNative.removeAllViews()
                    adMobNative.hide()
                    fbNative.removeAllViews()
                    inflateMetaAd(context, this@apply, fbNative)
                    AdsUtils.setNextNative(context, AdsUtils.META)
                    PreloadNativeAds.loadAd(context)
                }

                override fun onAdClicked(p0: Ad?) {}

                override fun onLoggingImpression(p0: Ad?) {
                    CustomEvents.nativeAd(context, CustomEvents.META)
                }

                override fun onMediaDownloaded(p0: Ad?) {}
            }
            loadAd(this@apply.buildLoadAdConfig().withAdListener(nativeAdListener).build())
        }
    }

    private fun inflateMetaAd(context: Context, nativeAd: com.facebook.ads.NativeAd, fbNative: NativeAdLayout) {
        nativeAd.unregisterView()
        val inflater = LayoutInflater.from(context)
        val adView = inflater.inflate(fbLayoutId, fbNative, false) as LinearLayout
        fbNative.addView(adView)
        // Add the AdOptionsView
        val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
        val adOptionsView = AdOptionsView(context, nativeAd, fbNative)
        adChoicesContainer.removeAllViews()
        adChoicesContainer.addView(adOptionsView, 0)
        // Create native UI using the ad metadata.
        val nativeAdIcon: MediaView? = adView.findViewById(R.id.native_icon_view)
        val nativeAdTitle = adView.findViewById<TextView>(R.id.native_ad_title)
        val nativeAdMedia: MediaView? = adView.findViewById(R.id.native_ad_media)
//        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        //        TextView nativeAdSocialContext = adView.findViewById(R.id.native_ad_social_context);
        val nativeAdBody = adView.findViewById<TextView>(R.id.native_ad_body)
        val sponsoredLabel = adView.findViewById<TextView>(R.id.native_ad_sponsored_label)
        val nativeAdCallToAction: MaterialTextView = adView.findViewById(R.id.native_ad_call_to_action)

//        nativeAdCallToAction.setBackgroundColor(Color.parseColor(AdUtils.getAdPref(context).adBtnBGColor))
//        nativeAdCallToAction.setTextColor(Color.parseColor(AdUtils.getAdPref(context).adBtnTxtColor))
        // Set the Text.
        nativeAdTitle.text = nativeAd.advertiserName
        nativeAdBody.text = nativeAd.adBodyText
//        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        //        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
        nativeAdCallToAction.visibility = if (nativeAd.hasCallToAction()) {
            View.VISIBLE
        } else {
            View.INVISIBLE
        }
        nativeAdCallToAction.text = nativeAd.adCallToAction
        sponsoredLabel.text = nativeAd.sponsoredTranslation
        // Create a list of clickable views
        val clickableViews: MutableList<View> = ArrayList()
        clickableViews.add(nativeAdTitle)
        clickableViews.add(nativeAdCallToAction)
        // Register the Title and CTA button to listen for clicks.
        nativeAd.registerViewForInteraction(
            adView, nativeAdMedia, nativeAdIcon, clickableViews
        )
    }

    private fun showGoogleAd(
        context: Context, adMobNative: FrameLayout
    ) {
        loge("loadAds:NativeAds:showGoogleAd")
        val placementId = getNativePlacementId(context)
        val videoOptions = VideoOptions.Builder().setStartMuted(false).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()
        AdLoader.Builder(context, placementId).forNativeAd {
            val adView = (context as Activity).layoutInflater.inflate(
                admobLayoutId, null
            ) as NativeAdView
            populateNativeAdView(context, it, adView)
            adMobNative.removeAllViews()
            adMobNative.addView(adView)
            AdsUtils.setNextNative(context, AdsUtils.GOOGLE)
            PreloadNativeAds.loadAd(context)
        }.withNativeAdOptions(adOptions).withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                if (AdsUtils.getAdPref(context).nativeBackFill) {
                    showGoogleAdOnFail(context, adMobNative)
                }
            }

            override fun onAdImpression() {
                CustomEvents.nativeAd(context, CustomEvents.ADMOB)
            }
        }).build().apply {
            loadAd(AdRequest.Builder().build())
        }
    }

    private fun showGoogleAdOnFail(
        context: Context, adMobNative: FrameLayout
    ) {
        val placementId = getNativePlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            return
        }
        val videoOptions = VideoOptions.Builder().setStartMuted(false).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()
        AdLoader.Builder(context, placementId).forNativeAd {
            val adView = (context as Activity).layoutInflater.inflate(
                admobLayoutId, null
            ) as NativeAdView
            populateNativeAdView(context, it, adView)
            adMobNative.removeAllViews()
            adMobNative.addView(adView)
            AdsUtils.setNextNative(context, AdsUtils.GOOGLE)
            PreloadNativeAds.loadAd(context)
        }.withNativeAdOptions(adOptions).withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                showGoogleAdOnFail(context, adMobNative)
            }

            override fun onAdImpression() {
                CustomEvents.nativeAd(context, CustomEvents.ADMOB)
            }
        }).build().apply {
            loadAd(AdRequest.Builder().build())
        }
    }

    private fun populateNativeAdView(
        context: Context, nativeAd: NativeAd, adView: NativeAdView
    ) {
        adView.mediaView = adView.findViewById(R.id.ad_media)
        adView.headlineView = adView.findViewById(R.id.ad_headline)
        adView.bodyView = adView.findViewById(R.id.ad_body)
        adView.callToActionView = adView.findViewById(R.id.ad_call_to_action)
        adView.iconView = adView.findViewById(R.id.ad_app_icon)
        //        adView.setPriceView(adView.findViewById(R.id.ad_price));
//        adView.setStoreView(adView.findViewById(R.id.ad_store));
//        val extras = nativeAd.extras
//        if (extras.containsKey(com.google.ads.mediation.facebook.FacebookMediationAdapter.KEY_SOCIAL_CONTEXT_ASSET)) {
//            val socialContext = extras[FacebookMediationAdapter.KEY_SOCIAL_CONTEXT_ASSET] as String
//            (adView.bodyView as TextView).text = socialContext
//        }
//        (adView.findViewById<View>(R.id.ad_call_to_action) as Button).setBackgroundColor(
//            Color.parseColor(AdUtils.getAdPref(context).adBtnBGColor)
//        )
//        (adView.findViewById<View>(R.id.ad_call_to_action) as Button).setTextColor(
//            Color.parseColor(AdUtils.getAdPref(context).adBtnTxtColor)
//        )
//        if (!(nativeAd.mediaContent)?.hasVideoContent()!!) {
//            adView.mediaView?.setImageScaleType(ImageView.ScaleType.CENTER_CROP)
//        }
        ((adView.headlineView) as TextView).text = nativeAd.headline
        nativeAd.mediaContent?.let { adView.mediaView?.mediaContent = it }
        if (nativeAd.body == null) {
            adView.bodyView?.vanish()
        } else {
            adView.bodyView?.show()
            (adView.bodyView as TextView?)?.text = nativeAd.body
        }
        if (nativeAd.callToAction == null) {
            adView.callToActionView?.vanish()
        } else {
            adView.callToActionView?.show()
            (adView.callToActionView as TextView?)!!.text = nativeAd.callToAction
        }
        if (nativeAd.icon == null) {
            adView.iconView?.hide()
        } else {
            ((adView.iconView) as? ImageView)?.setImageDrawable(
                nativeAd.icon!!.drawable
            )
            adView.iconView?.show()
        }
//        if (nativeAd.getPrice() == null) {
//            Objects.requireNonNull(adView.getPriceView()).setVisibility(View.INVISIBLE);
//        } else {
//            Objects.requireNonNull(adView.getPriceView()).setVisibility(View.VISIBLE);
//            ((TextView) adView.getPriceView()).setText(nativeAd.getPrice());
//        }
//        if (nativeAd.getStore() == null) {
//            Objects.requireNonNull(adView.getStoreView()).setVisibility(View.INVISIBLE);
//        } else {
//            Objects.requireNonNull(adView.getStoreView()).setVisibility(View.VISIBLE);
//            ((TextView) adView.getStoreView()).setText(nativeAd.getStore());
//        }
        adView.setNativeAd(nativeAd)
    }

    private fun showGoogleInlineBannerAd(
        context: Context, adMobBanner: FrameLayout, parent: View?
    ) {
        loge("loadAds:NativeAds:showGoogleInlineBannerAd")
        addAdInlineLoader(context, adMobBanner)
        val placementId = getBannerPlacementId(context)
        AdView(context).apply {
            adUnitId = placementId
            val adSize: AdSize = AdSize.getInlineAdaptiveBannerAdSize(300, 250)
            loge("adSize:width:${adSize.width}:height:${adSize.height}")
            setAdSize(adSize)
            val adRequest = AdRequest.Builder().build()
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    parent?.let {
                        val params = it.layoutParams
                        params.width = ViewGroup.LayoutParams.WRAP_CONTENT
                        it.layoutParams = params
                    }
                    adMobBanner.removeAllViews()
                    adMobBanner.addView(this@apply)
                    AdsUtils.setNextNative(context, AdsUtils.GOOGLE)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    if (AdsUtils.getAdPref(context).nativeBackFill) {
                        showGoogleInlineBannerAdOnFail(context, adMobBanner, parent)
                    }
                }

                override fun onAdImpression() {
                    CustomEvents.bannerAd(context, CustomEvents.ADMOB)
                }
            }
            loadAd(adRequest)
        }
    }

    private fun showGoogleInlineBannerAdOnFail(
        context: Context, adMobBanner: FrameLayout, parent: View?
    ) {
        val placementId = getBannerPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            return
        }
        AdView(context).apply {
            adUnitId = placementId
            val adSize: AdSize = AdSize.getInlineAdaptiveBannerAdSize(300, 250)
            setAdSize(adSize)
            val adRequest = AdRequest.Builder().build()
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    parent?.let {
                        val params = it.layoutParams
                        params.width = ViewGroup.LayoutParams.WRAP_CONTENT
                        it.layoutParams = params
                    }
                    adMobBanner.removeAllViews()
                    adMobBanner.addView(this@apply)
                    AdsUtils.setNextNative(context, AdsUtils.GOOGLE)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    showGoogleInlineBannerAdOnFail(context, adMobBanner, parent)
                }

                override fun onAdImpression() {
                    CustomEvents.bannerAd(context, CustomEvents.ADMOB)
                }
            }
            loadAd(adRequest)
        }
    }

    private fun showMetaInlineBanner(
        context: Context, adMobNative: FrameLayout, fbNative: NativeAdLayout, parent: View?
    ) {
        loge("loadAds:NativeAds:showMetaInlineBanner")
        addAdInlineLoader(context, adMobNative)
        com.facebook.ads.AdView(
            context, AdsUtils.getAdPref(context).fbRectBanner, com.facebook.ads.AdSize.RECTANGLE_HEIGHT_250
        ).apply {
            val adListener = object : com.facebook.ads.AdListener {
                override fun onError(p0: Ad?, p1: AdError?) {
                    AdsUtils.setNextNativeOnMetaFail(context)
                    if (AdsUtils.isNextNativeGoogle()) {
                        adMobNative.show()
                        showGoogleInlineBannerAd(context, adMobNative, parent)
                    }
                }

                override fun onAdLoaded(p0: Ad?) {
                    parent?.let {
                        if (it is MaterialCardView) {
                            it.cardElevation = 0F
                        }
                        val params = it.layoutParams
                        params.width = ViewGroup.LayoutParams.WRAP_CONTENT
                        it.layoutParams = params
                    }
                    fbNative.removeAllViews()
                    fbNative.hide()
                    adMobNative.removeAllViews()
                    adMobNative.addView(this@apply)
                    AdsUtils.setNextNative(context, AdsUtils.META)
                }

                override fun onAdClicked(p0: Ad?) {}
                override fun onLoggingImpression(p0: Ad?) {
                    CustomEvents.bannerAd(context, CustomEvents.META)
                }
            }
            loadAd(this@apply.buildLoadAdConfig().withAdListener(adListener).build())
        }
    }

    private fun getInlineAdSize(context: Context, adContainerView: FrameLayout): AdSize {
        // Determine the screen width (less decorations) to use for the ad width.
        if (Build.VERSION.SDK_INT > 29) {
            val windowMetrics = (context as Activity).windowManager.currentWindowMetrics
            val bounds = windowMetrics.bounds

            var adWidthPixels = adContainerView.width.toFloat()

            // If the ad hasn't been laid out, default to the full screen width.
            if (adWidthPixels == 0f) {
                adWidthPixels = bounds.width().toFloat()
            }

            val density = context.resources.displayMetrics.density
            val adWidth = (adWidthPixels / density).toInt()

            return AdSize.getCurrentOrientationInlineAdaptiveBannerAdSize(context, adWidth)
        } else {
            val display = (context as Activity).windowManager.defaultDisplay
            val outMetrics = DisplayMetrics()
            display.getMetrics(outMetrics)
            val density = outMetrics.density
            var adWidthPixels = adContainerView.width.toFloat()

            // If the ad hasn't been laid out, default to the full screen width.
            if (adWidthPixels == 0f) {
                adWidthPixels = outMetrics.widthPixels.toFloat()
            }
            val adWidth = (adWidthPixels / density).toInt()
            return AdSize.getCurrentOrientationInlineAdaptiveBannerAdSize(context, adWidth)
        }
    }

    private fun getNativePlacementId(context: Context): String {
        val ids = AdsUtils.getAdPref(context).nativeIds
        nativeIndex = 0
        return ids[nativeIndex]
    }

    private fun getNativePlacementIdOnFail(context: Context): String {
        val ids = AdsUtils.getAdPref(context).nativeIds
        nativeIndex++
        return if (nativeIndex < ids.size) {
            ids[nativeIndex]
        } else {
            ""
        }
    }

    private fun getBannerPlacementId(context: Context): String {
        val ids = AdsUtils.getAdPref(context).bannerIds
        bannerIndex = 0
        return ids[bannerIndex]
    }

    private fun getBannerPlacementIdOnFail(context: Context): String {
        val ids = AdsUtils.getAdPref(context).bannerIds
        bannerIndex++
        return if (bannerIndex < ids.size) {
            ids[bannerIndex]
        } else {
            ""
        }
    }

    private fun addAdLoader(context: Context, view: FrameLayout) {
        (LayoutInflater.from(context).inflate(loader, view, false) as LinearLayout).apply {
            minimumHeight = context.dimen(minHeight).toInt()
            view.addView(this@apply)
        }
    }

    private fun addAdInlineLoader(context: Context, view: FrameLayout) {
        view.removeAllViews()
        (LayoutInflater.from(context).inflate(loader, view, false) as LinearLayout).apply {
            minimumHeight = context.dimen(R.dimen._inline_banner_height).toInt()
            view.addView(this@apply)
        }
    }

    private fun showInHouseAd(context: Context, adMobNative: FrameLayout) {
        val inHouse = (context as Activity).layoutInflater.inflate(
            R.layout.more_native, null
        ) as ConstraintLayout
        val banner = inHouse.findViewById<AppCompatImageView>(R.id.ad_media)
        val icon = inHouse.findViewById<AppCompatImageView>(R.id.ad_app_icon)
        val title = inHouse.findViewById<AppCompatTextView>(R.id.ad_headline)
        val description = inHouse.findViewById<AppCompatTextView>(R.id.ad_body)
        val action = inHouse.findViewById<MaterialButton>(R.id.ad_call_to_action)
        adMobNative.removeAllViews()
        adMobNative.addView(inHouse)
        val moreApp = AdsUtils.getMoreAppsPref(context).apps.random()
        val assetUrl = moreApp.appAssetUrl
        banner.loadWithGlide(assetUrl.plus(moreApp.appNative.random()))
        icon.loadWithGlide(assetUrl.plus(moreApp.appIcon.random()))
        title.text = moreApp.appTitle.random()
        description.text = moreApp.appDes.random()
        action.apply {
            text = "Install Now"
            setBackgroundColor(
                Color.parseColor(AdsUtils.getAdPref(context).adBtnBGColor)
            )
            setTextColor(
                Color.parseColor(AdsUtils.getAdPref(context).adBtnTxtColor)
            )
            setOnClickListener {
                context.openPlayStore(moreApp.appPkgName)
            }
        }
        inHouse.findViewById<ConstraintLayout>(R.id.main).setOnClickListener {
            context.openPlayStore(moreApp.appPkgName)
        }
    }
}