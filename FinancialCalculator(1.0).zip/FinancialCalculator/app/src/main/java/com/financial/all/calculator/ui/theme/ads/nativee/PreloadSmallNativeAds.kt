package com.financial.all.calculator.ui.theme.ads.nativee

import android.content.Context
import com.financial.all.calculator.ui.theme.ads.commons.AdsUtils
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.NativeAdListener
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.financial.all.calculator.ui.theme.ads.commons.CustomEvents

object PreloadSmallNativeAds {

    private var nativeIndex = 0
    var googleNativeAd: NativeAd? = null
    var metaNativeAd: com.facebook.ads.NativeBannerAd? = null
    var isGoogleAdLoading = false
    var isMetaAdLoading = false

    fun loadAd(context: Context) {
        if (!AdsUtils.isAdEnabled(context)) {
            return
        }
        if (!AdsUtils.getAdPref(context).nativePreload) {
            return
        }
        if (AdsUtils.getAdPref(context).smallNativeScreens.contains("none", true)) {
            return
        }
        if (AdsUtils.isNextSmallNativeGoogle()) {
            loadGoogleAd(context)
        } else if (AdsUtils.isNextSmallNativeMeta()) {
            loadMetaAd(context)
        }
    }

    private fun loadGoogleAd(context: Context) {
        if (googleNativeAd != null) {
            return
        }
        if (isGoogleAdLoading) {
            return
        }
        isGoogleAdLoading = true
        val placementId = getNativePlacementId(context)
        val videoOptions = VideoOptions.Builder().setStartMuted(false).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()
        AdLoader.Builder(context, placementId).forNativeAd {
            isGoogleAdLoading = false
            googleNativeAd = it
        }.withNativeAdOptions(adOptions).withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                isGoogleAdLoading = false
                googleNativeAd = null
                if (AdsUtils.getAdPref(context).smallNativeBackFill) {
                    loadGoogleAdOnFail(context)
                }
            }

            override fun onAdImpression() {
                CustomEvents.nativeAd(context, CustomEvents.ADMOB)
                AdsUtils.setNextSmallNative(context, AdsUtils.GOOGLE)
                googleNativeAd = null
                loadAd(context)
            }
        }).build().apply {
            loadAd(AdRequest.Builder().build())
        }
    }

    private fun loadGoogleAdOnFail(context: Context) {
        if (googleNativeAd != null) {
            return
        }
        if (isGoogleAdLoading) {
            return
        }
        isGoogleAdLoading = true
        val placementId = getNativePlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            return
        }
        val videoOptions = VideoOptions.Builder().setStartMuted(false).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()
        AdLoader.Builder(context, placementId).forNativeAd {
            isGoogleAdLoading = false
            googleNativeAd = it
        }.withNativeAdOptions(adOptions).withAdListener(object : AdListener() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                isGoogleAdLoading = false
                googleNativeAd = null
                loadGoogleAdOnFail(context)
            }

            override fun onAdImpression() {
                CustomEvents.nativeAd(context, CustomEvents.ADMOB)
                AdsUtils.setNextSmallNative(context, AdsUtils.GOOGLE)
                googleNativeAd = null
                loadAd(context)
            }
        }).build().apply {
            loadAd(AdRequest.Builder().build())
        }
    }

    private fun loadMetaAd(context: Context) {
        if (metaNativeAd != null && !metaNativeAd!!.isAdInvalidated) {
            return
        }
        if (isMetaAdLoading) {
            return
        }
        isMetaAdLoading = true
        com.facebook.ads.NativeBannerAd(context, AdsUtils.getAdPref(context).fbNativeBanner).apply {
            val nativeAdListener = object : NativeAdListener {
                override fun onError(p0: Ad?, p1: AdError?) {
                    isMetaAdLoading = false
                    metaNativeAd = null
                    AdsUtils.setNextSmallNativeOnMetaFail(context)
                    if (AdsUtils.isNextSmallNativeGoogle()) {
                        loadGoogleAd(context)
                    }
                }

                override fun onAdLoaded(p0: Ad?) {
                    isMetaAdLoading = false
                    if (this@apply != p0) {
                        return
                    }
                    metaNativeAd = this@apply
                }

                override fun onAdClicked(p0: Ad?) {}

                override fun onLoggingImpression(p0: Ad?) {
                    CustomEvents.nativeAd(context, CustomEvents.META)
                    AdsUtils.setNextSmallNative(context, AdsUtils.META)
                    metaNativeAd = null
                    loadAd(context)
                }

                override fun onMediaDownloaded(p0: Ad?) {}
            }
            loadAd(this@apply.buildLoadAdConfig().withAdListener(nativeAdListener).build())
        }
    }


    private fun getNativePlacementId(context: Context): String {
        val ids = AdsUtils.getAdPref(context).smallNativeIds
        nativeIndex = 0
        return ids[nativeIndex]
    }

    private fun getNativePlacementIdOnFail(context: Context): String {
        val ids = AdsUtils.getAdPref(context).smallNativeIds
        nativeIndex++
        return if (nativeIndex < ids.size) {
            ids[nativeIndex]
        } else {
            ""
        }
    }

    fun release() {
        googleNativeAd?.destroy()
        googleNativeAd = null
        metaNativeAd?.destroy()
        metaNativeAd = null
    }
}