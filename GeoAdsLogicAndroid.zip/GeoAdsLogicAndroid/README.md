# GeoAds Logic Android Implementation

A comprehensive Android application that replicates the web-based geo-targeting and quiz logic with Google Mobile Ads integration.

## Overview

This Android project is a direct implementation of the provided web logic that includes:
- Random geo-targeting from predefined locations
- Quiz data encoding (btoa equivalent)
- Multiple ad slots (banner and rewarded ads)
- Quiz flow with rewarded ad integration
- UI that mirrors the web structure

## Web Logic Analysis

The original web implementation contained several key components:

### 1. Geo Targeting Logic
```javascript
const geoTargets = [
  "California, US", "New York, US", "Melbourne, AU",
  "Victoria, AU", "Toronto, CA", "Ottawa, CA", "Wellington, NZ"
];

googletag.cmd.push(() => {
  if (Math.random() < 1) {
    const randomGeo = geoTargets[Math.floor(Math.random() * geoTargets.length)];
    console.log("GEO Targeted:", randomGeo);
    googletag.pubads().setLocation(randomGeo);
  }
});
```

### 2. Quiz Data Encoding
```javascript
const data = btoa("zeb9") + "|" + btoa("5");
```

### 3. Ad Slots
- `gpt-passback-1`: Top banner ad
- `gpt-passback-2`: Middle banner ad  
- `gpt-passback-3`: Bottom banner ad
- Rewarded ad slot for quiz completion

### 4. Quiz Flow
- Button click triggers rewarded ad
- Timeout fallback (3 seconds)
- Redirect to question.php with encoded data

## Android Implementation

### Project Structure

```
GeoAdsLogicAndroid/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/geoadslogic/
│   │   │   ├── MainActivity.kt              # Main activity integrating all components
│   │   │   ├── GeoTargetingManager.kt       # Random geo targeting logic
│   │   │   ├── QuizLogicManager.kt          # Quiz data encoding and flow
│   │   │   └── AdSlotManager.kt             # Multiple ad slots management
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml        # UI layout mirroring web structure
│   │   │   ├── values/
│   │   │   │   ├── strings.xml              # String resources and ad unit IDs
│   │   │   │   ├── colors.xml               # Color definitions
│   │   │   │   └── themes.xml               # App themes
│   │   │   └── xml/
│   │   │       ├── backup_rules.xml         # Backup configuration
│   │   │       └── data_extraction_rules.xml
│   │   └── AndroidManifest.xml              # App manifest with permissions
│   ├── build.gradle                         # App-level build configuration
│   └── proguard-rules.pro                   # ProGuard rules
├── build.gradle                             # Project-level build configuration
├── settings.gradle                          # Gradle settings
├── gradle.properties                        # Gradle properties
└── README.md                                # This file
```

### Key Components

#### 1. GeoTargetingManager.kt
Replicates the web's random geo targeting logic:

```kotlin
class GeoTargetingManager(private val context: Context) {
    companion object {
        private val GEO_TARGETS = arrayOf(
            "California, US", "New York, US", "Melbourne, AU",
            "Victoria, AU", "Toronto, CA", "Ottawa, CA", "Wellington, NZ"
        )
    }
    
    fun initializeGeoTargeting(): String? {
        return if (shouldApplyGeoTargeting()) {
            selectRandomGeoTarget()
        } else {
            null
        }
    }
    
    private fun selectRandomGeoTarget(): String {
        val randomIndex = Random.nextInt(GEO_TARGETS.size)
        return GEO_TARGETS[randomIndex]
    }
}
```

#### 2. QuizLogicManager.kt
Handles quiz data encoding and flow:

```kotlin
class QuizLogicManager(private val context: Context) {
    fun initializeQuizData(data1: String = "zeb9", data2: String = "5"): String {
        // Android equivalent of JavaScript's btoa() function
        val encodedData1 = Base64.encodeToString(data1.toByteArray(), Base64.NO_WRAP)
        val encodedData2 = Base64.encodeToString(data2.toByteArray(), Base64.NO_WRAP)
        return "$encodedData1|$encodedData2"
    }
    
    fun generateRedirectUrl(baseUrl: String = "question.php", questionIndex: Int = 0): String {
        val data = getQuizData()
        return "$baseUrl?data=$data&q=$questionIndex"
    }
}
```

#### 3. AdSlotManager.kt
Manages multiple ad slots with Google Mobile Ads SDK:

```kotlin
class AdSlotManager(private val context: Context) {
    companion object {
        const val BANNER_AD_UNIT_1 = "ca-app-pub-3940256099942544/6300978111" // Top
        const val BANNER_AD_UNIT_2 = "ca-app-pub-3940256099942544/6300978111" // Middle
        const val BANNER_AD_UNIT_3 = "ca-app-pub-3940256099942544/6300978111" // Bottom
        const val REWARDED_AD_UNIT = "ca-app-pub-3940256099942544/5224354917"
    }
    
    fun loadBannerAd(adView: AdView, slotId: String, onAdLoaded: (() -> Unit)?, onAdFailed: ((String) -> Unit)?)
    fun playRewardedAd(activity: Activity, onRewardEarned: ((String, Int) -> Unit)?, onAdClosed: (() -> Unit)?, onAdFailed: (() -> Unit)?): Boolean
}
```

#### 4. MainActivity.kt
Integrates all components and handles UI interactions:

```kotlin
class MainActivity : AppCompatActivity() {
    private fun startQuizProcess() {
        quizLogicManager.startQuiz(
            onButtonTextChange = { text -> binding.buttonYes.text = text },
            onRewardedAdPlay = { playRewardedAdForQuiz() },
            onRedirect = { url -> handleRedirect(url) }
        )
    }
    
    private fun handleRedirect(url: String) {
        // Show dialog with redirect URL and options to open in browser
        AlertDialog.Builder(this)
            .setTitle("Quiz Redirect")
            .setMessage("Quiz completed! Redirect URL:\n$url")
            .setPositiveButton("Open in Browser") { _, _ -> openUrlInBrowser(url) }
            .show()
    }
}
```

## Features Implemented

### ✅ Direct Web Logic Translation

1. **Random Geo Targeting**: Exact same geo target list and random selection logic
2. **Base64 Encoding**: Android equivalent of JavaScript's `btoa()` function
3. **Multiple Ad Slots**: Three banner ad slots plus rewarded ad
4. **Quiz Flow**: Button click → Rewarded ad → Timeout fallback → Redirect
5. **UI Structure**: Layout mirrors the web page structure

### ✅ Android-Specific Enhancements

1. **Material Design UI**: Modern Android UI with CardViews and proper styling
2. **Real-time Status Display**: Shows geo targeting, quiz data, and ad status
3. **Debug Information**: Comprehensive logging and status displays
4. **Error Handling**: Robust error handling for ad loading and quiz flow
5. **Lifecycle Management**: Proper Android lifecycle handling for ads

### ✅ Ad Integration Features

1. **Google Mobile Ads SDK**: Full integration with banner and rewarded ads
2. **Geo Targeting Parameters**: Passes geo data to ad requests
3. **Ad Callbacks**: Handles ad loading, display, and interaction events
4. **Preloading**: Preloads rewarded ads for better user experience

## Setup Instructions

### 1. Prerequisites
- Android Studio Arctic Fox or later
- Android SDK API level 24 or higher
- Google Play Services installed on target device
- Google AdMob account (for production ads)

### 2. Configuration

#### Replace Test Ad Unit IDs
In `app/src/main/res/values/strings.xml`, replace test ad unit IDs:

```xml
<string name="banner_ad_unit_id">YOUR_BANNER_AD_UNIT_ID</string>
<string name="rewarded_ad_unit_id">YOUR_REWARDED_AD_UNIT_ID</string>
```

#### Update AdMob App ID
In `app/src/main/AndroidManifest.xml`, replace the test app ID:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="YOUR_ADMOB_APP_ID"/>
```

### 3. Build and Run

1. Open project in Android Studio
2. Sync Gradle files
3. Connect Android device or start emulator
4. Run the app

## Usage

### Main Features

1. **Geo Targeting Display**: Shows current randomly selected geo target
2. **Quiz Data Display**: Shows encoded quiz data and decoded values
3. **Ad Controls**: Buttons to manually trigger rewarded ads and refresh all ads
4. **Status Monitoring**: Real-time display of quiz status, ad stats, and geo stats

### Quiz Flow

1. Tap the "Yes" button to start the quiz
2. Button text changes to "Loading..."
3. Rewarded ad plays (if available)
4. After ad completion or timeout, redirect dialog appears
5. Choose to open URL in browser or copy to clipboard

### Geo Targeting

1. App randomly selects a geo target on startup
2. Geo target is displayed in the UI
3. Tap "Refresh Geo Targeting" to select a new random target
4. Geo parameters are passed to ad requests

## Technical Details

### Web-to-Android Mapping

| Web Component | Android Equivalent | Implementation |
|---------------|-------------------|----------------|
| `Math.random()` | `Random.nextInt()` | Kotlin Random class |
| `btoa()` | `Base64.encodeToString()` | Android Base64 utility |
| `googletag.defineSlot()` | `AdView` creation | Google Mobile Ads SDK |
| `setTimeout()` | `Handler.postDelayed()` | Android Handler |
| `window.location.href` | `Intent.ACTION_VIEW` | Android Intent system |
| Console logging | `Log.d()` | Android logging |

### Ad Slot Mapping

| Web Ad Slot | Android Implementation | Ad Type |
|-------------|----------------------|---------|
| `gpt-passback-1` | `adViewTop` | Banner (728x90) |
| `gpt-passback-2` | `adViewMiddle` | Medium Rectangle (300x250) |
| `gpt-passback-3` | `adViewBottom` | Banner (728x90) |
| Rewarded slot | `RewardedAd` | Rewarded video |

### Data Flow

```
App Launch → GeoTargetingManager.initializeGeoTargeting()
           → QuizLogicManager.initializeQuizData()
           → AdSlotManager.preloadAllAds()
           → UI Update

Button Click → QuizLogicManager.startQuiz()
             → AdSlotManager.playRewardedAd()
             → Timeout Handler (3 seconds)
             → Redirect Dialog

Geo Refresh → GeoTargetingManager.refreshGeoTargeting()
            → AdSlotManager.refreshAllAds()
            → UI Update
```

## Testing

### Geo Targeting Testing
- Verify random geo target selection on app launch
- Test geo target refresh functionality
- Check geo parameters in ad requests

### Quiz Logic Testing
- Test quiz data encoding/decoding
- Verify redirect URL generation
- Test timeout fallback mechanism

### Ad Testing
- Test banner ad loading for all three slots
- Test rewarded ad loading and playback
- Test ad refresh functionality
- Verify geo targeting parameters in ad requests

## Troubleshooting

### Common Issues

1. **Ads Not Loading**
   - Check internet connectivity
   - Verify ad unit IDs are correct
   - Check AdMob account status

2. **Rewarded Ad Not Playing**
   - Ensure rewarded ad is preloaded
   - Check device supports video playback
   - Verify rewarded ad unit ID

3. **Geo Targeting Not Working**
   - Check if geo targeting is enabled
   - Verify geo target selection logic
   - Check ad request parameters

### Debug Information

The app provides extensive debug information:
- Real-time geo targeting status
- Quiz data encoding/decoding status
- Ad loading and display status
- Comprehensive logging in Android Logcat

## Production Deployment

Before deploying to production:

1. **Replace Test IDs**: Update all ad unit IDs and app ID with production values
2. **Test Thoroughly**: Test on multiple devices and Android versions
3. **Ad Policy Compliance**: Follow Google AdMob policies
4. **Privacy Compliance**: Ensure compliance with privacy regulations

## Dependencies

- **Google Mobile Ads SDK**: `com.google.android.gms:play-services-ads:22.6.0`
- **AndroidX Libraries**: Core, AppCompat, Material Design, CardView
- **Kotlin Standard Library**: For modern Android development
- **ViewBinding**: For type-safe view references

## License

This project is provided as an example implementation of the web logic in Android. Please ensure compliance with all applicable laws and platform policies.

## Version History

- **v1.0**: Initial implementation with complete web logic translation
  - Random geo targeting
  - Quiz data encoding
  - Multiple ad slots
  - Rewarded ad integration
  - Material Design UI

