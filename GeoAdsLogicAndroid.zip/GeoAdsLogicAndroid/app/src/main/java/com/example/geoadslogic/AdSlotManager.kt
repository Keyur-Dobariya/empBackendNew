package com.example.geoadslogic

import android.content.Context
import android.util.Log
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * AdSlotManager handles multiple ad slots similar to the web implementation.
 * This includes banner ads, rewarded ads, and manages the ad slot lifecycle.
 */
class AdSlotManager(private val context: Context) {
    
    companion object {
        private const val TAG = "AdSlotManager"
        
        // Test Ad Unit IDs - Replace with your actual Ad Unit IDs
        // These correspond to the web implementation's ad slots
        const val BANNER_AD_UNIT_1 = "ca-app-pub-3940256099942544/6300978111" // Top banner
        const val BANNER_AD_UNIT_2 = "ca-app-pub-3940256099942544/6300978111" // Middle banner  
        const val BANNER_AD_UNIT_3 = "ca-app-pub-3940256099942544/6300978111" // Bottom banner
        const val REWARDED_AD_UNIT = "ca-app-pub-3940256099942544/5224354917"  // Rewarded ad
        
        // Ad sizes matching the web implementation
        val BANNER_SIZES = arrayOf(
            AdSize(300, 100), AdSize(300, 250), AdSize(728, 90),
            AdSize(200, 200), AdSize(300, 75), AdSize(320, 50),
            AdSize(336, 280), AdSize(970, 90), AdSize(970, 250),
            AdSize(300, 50), AdSize(320, 100)
        )
    }
    
    private var rewardedAd: RewardedAd? = null
    private var geoTargetingManager: GeoTargetingManager? = null
    private var isRewardedAdReady = false
    
    // Ad slot states
    private val adSlotStates = mutableMapOf<String, Boolean>()
    
    init {
        // Initialize Mobile Ads SDK
        MobileAds.initialize(context) { initializationStatus ->
            Log.d(TAG, "AdMob SDK initialized: ${initializationStatus.adapterStatusMap}")
        }
    }
    
    /**
     * Set geo targeting manager for location-based ads
     */
    fun setGeoTargetingManager(geoManager: GeoTargetingManager) {
        this.geoTargetingManager = geoManager
    }
    
    /**
     * Create ad request with geo targeting (if available)
     */
    private fun createAdRequest(): AdRequest {
        val builder = AdRequest.Builder()
        
        // Add geo targeting parameters if available
        geoTargetingManager?.getGeoTargetingParams()?.forEach { (key, value) ->
            // Note: For Google AdMob, custom targeting is limited
            // For full custom targeting, you would need Google Ad Manager (DFP)
            Log.d(TAG, "Geo targeting param: $key = $value")
        }
        
        return builder.build()
    }
    
    /**
     * Load banner ad for a specific slot (equivalent to gpt-passback-1, 2, 3)
     */
    fun loadBannerAd(
        adView: AdView,
        slotId: String,
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null
    ) {
        val adRequest = createAdRequest()
        
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
                adSlotStates[slotId] = true
                Log.d(TAG, "Banner ad loaded for slot: $slotId")
                onAdLoaded?.invoke()
            }
            
            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                super.onAdFailedToLoad(loadAdError)
                adSlotStates[slotId] = false
                Log.e(TAG, "Banner ad failed for slot $slotId: ${loadAdError.message}")
                onAdFailed?.invoke(loadAdError.message)
            }
            
            override fun onAdClicked() {
                super.onAdClicked()
                Log.d(TAG, "Banner ad clicked for slot: $slotId")
            }
            
            override fun onAdOpened() {
                super.onAdOpened()
                Log.d(TAG, "Banner ad opened for slot: $slotId")
            }
            
            override fun onAdClosed() {
                super.onAdClosed()
                Log.d(TAG, "Banner ad closed for slot: $slotId")
            }
        }
        
        adView.loadAd(adRequest)
        Log.d(TAG, "Loading banner ad for slot: $slotId")
    }
    
    /**
     * Load rewarded ad (equivalent to the rewarded slot in web)
     */
    fun loadRewardedAd(
        onAdLoaded: (() -> Unit)? = null,
        onAdFailed: ((String) -> Unit)? = null
    ) {
        val adRequest = createAdRequest()
        
        RewardedAd.load(
            context,
            REWARDED_AD_UNIT,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    super.onAdLoaded(ad)
                    rewardedAd = ad
                    isRewardedAdReady = true
                    Log.d(TAG, "✅ Rewarded ad is ready")
                    onAdLoaded?.invoke()
                    
                    setupRewardedAdCallbacks(ad)
                }
                
                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    super.onAdFailedToLoad(loadAdError)
                    rewardedAd = null
                    isRewardedAdReady = false
                    Log.e(TAG, "❌ Rewarded ad failed to load: ${loadAdError.message}")
                    onAdFailed?.invoke(loadAdError.message)
                }
            }
        )
    }
    
    /**
     * Play rewarded ad (equivalent to playRewardedAd() function in web)
     */
    fun playRewardedAd(
        activity: android.app.Activity,
        onRewardEarned: ((String, Int) -> Unit)? = null,
        onAdClosed: (() -> Unit)? = null,
        onAdFailed: (() -> Unit)? = null
    ): Boolean {
        return if (rewardedAd != null && isRewardedAdReady) {
            rewardedAd?.show(activity) { rewardItem ->
                Log.d(TAG, "🎉 Reward: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned?.invoke(rewardItem.type, rewardItem.amount)
            }
            true
        } else {
            Log.w(TAG, "❌ Rewarded ads are not supported or not ready")
            onAdFailed?.invoke()
            false
        }
    }
    
    /**
     * Setup rewarded ad callbacks (equivalent to event listeners in web)
     */
    private fun setupRewardedAdCallbacks(ad: RewardedAd) {
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                super.onAdShowedFullScreenContent()
                Log.d(TAG, "Rewarded ad showed full screen content")
            }
            
            override fun onAdDismissedFullScreenContent() {
                super.onAdDismissedFullScreenContent()
                Log.d(TAG, "❎ Rewarded ad closed")
                rewardedAd = null
                isRewardedAdReady = false
                
                // Preload next rewarded ad
                loadRewardedAd()
            }
            
            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                super.onAdFailedToShowFullScreenContent(adError)
                Log.e(TAG, "Rewarded ad failed to show: ${adError.message}")
                rewardedAd = null
                isRewardedAdReady = false
            }
        }
    }
    
    /**
     * Check if rewarded ad is ready
     */
    fun isRewardedAdReady(): Boolean = isRewardedAdReady && rewardedAd != null
    
    /**
     * Get ad slot status
     */
    fun getAdSlotStatus(slotId: String): Boolean = adSlotStates[slotId] ?: false
    
    /**
     * Get all ad slot statuses
     */
    fun getAllAdSlotStatuses(): Map<String, Boolean> = adSlotStates.toMap()
    
    /**
     * Preload all ads (equivalent to the initialization in web)
     */
    fun preloadAllAds() {
        Log.d(TAG, "Preloading all ads...")
        loadRewardedAd(
            onAdLoaded = {
                Log.d(TAG, "Rewarded ad preloaded successfully")
            },
            onAdFailed = { error ->
                Log.e(TAG, "Failed to preload rewarded ad: $error")
            }
        )
    }
    
    /**
     * Enable single request mode (equivalent to googletag.pubads().enableSingleRequest())
     * Note: This is handled automatically by Google Mobile Ads SDK
     */
    fun enableSingleRequest() {
        Log.d(TAG, "Single request mode enabled (handled by SDK)")
    }
    
    /**
     * Enable video ads (equivalent to googletag.pubads().enableVideoAds())
     * Note: Video ads are enabled by default in Google Mobile Ads SDK
     */
    fun enableVideoAds() {
        Log.d(TAG, "Video ads enabled (handled by SDK)")
    }
    
    /**
     * Get ad performance statistics
     */
    fun getAdStats(): Map<String, Any> {
        return mapOf(
            "rewarded_ad_ready" to isRewardedAdReady,
            "loaded_banner_slots" to adSlotStates.count { it.value },
            "total_banner_slots" to adSlotStates.size,
            "geo_targeting_active" to (geoTargetingManager?.isGeoTargetingEnabled() ?: false),
            "current_geo_target" to (geoTargetingManager?.getCurrentGeoTarget() ?: "None")
        )
    }
    
    /**
     * Refresh all ads
     */
    fun refreshAllAds() {
        Log.d(TAG, "Refreshing all ads...")
        
        // Clear current states
        adSlotStates.clear()
        
        // Reload rewarded ad
        loadRewardedAd()
        
        Log.d(TAG, "All ads refresh initiated")
    }
    
    /**
     * Clean up resources
     */
    fun cleanup() {
        rewardedAd = null
        isRewardedAdReady = false
        adSlotStates.clear()
        Log.d(TAG, "AdSlotManager cleaned up")
    }
}

