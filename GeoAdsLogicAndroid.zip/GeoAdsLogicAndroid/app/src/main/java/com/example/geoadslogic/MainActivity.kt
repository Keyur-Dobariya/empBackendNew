package com.example.geoadslogic

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.geoadslogic.databinding.ActivityMainBinding
import com.google.android.gms.ads.AdSize

/**
 * MainActivity integrates all the logic components (GeoTargeting, QuizLogic, AdSlots)
 * to replicate the web implementation functionality in Android.
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var geoTargetingManager: GeoTargetingManager
    private lateinit var quizLogicManager: QuizLogicManager
    private lateinit var adSlotManager: AdSlotManager
    
    companion object {
        private const val TAG = "MainActivity"
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        initializeManagers()
        setupGeoTargeting()
        setupQuizLogic()
        setupAdSlots()
        setupUI()
        
        // Initialize everything (equivalent to the web's initialization)
        initializeApp()
    }
    
    /**
     * Initialize all manager classes
     */
    private fun initializeManagers() {
        geoTargetingManager = GeoTargetingManager(this)
        quizLogicManager = QuizLogicManager(this)
        adSlotManager = AdSlotManager(this)
        
        // Connect geo targeting to ad manager
        adSlotManager.setGeoTargetingManager(geoTargetingManager)
        
        Log.d(TAG, "All managers initialized")
    }
    
    /**
     * Setup geo targeting (equivalent to the web's geo targeting logic)
     */
    private fun setupGeoTargeting() {
        // Initialize geo targeting (equivalent to the random geo selection in web)
        val selectedGeoTarget = geoTargetingManager.initializeGeoTargeting()
        
        // Update UI with geo targeting info
        updateGeoTargetingDisplay(selectedGeoTarget)
        
        Log.d(TAG, "Geo targeting setup complete")
    }
    
    /**
     * Setup quiz logic (equivalent to the web's quiz data preparation)
     */
    private fun setupQuizLogic() {
        // Initialize quiz data (equivalent to btoa encoding in web)
        val quizData = quizLogicManager.initializeQuizData()
        
        // Update UI with quiz info
        updateQuizDataDisplay(quizData)
        
        Log.d(TAG, "Quiz logic setup complete")
    }
    
    /**
     * Setup ad slots (equivalent to the web's GPT ad slot definitions)
     */
    private fun setupAdSlots() {
        // Enable single request and video ads (equivalent to web's pubads settings)
        adSlotManager.enableSingleRequest()
        adSlotManager.enableVideoAds()
        
        // Setup banner ad views with appropriate sizes
        setupBannerAdViews()
        
        // Load all banner ads
        loadAllBannerAds()
        
        // Preload rewarded ad
        adSlotManager.preloadAllAds()
        
        Log.d(TAG, "Ad slots setup complete")
    }
    
    /**
     * Setup banner ad views with sizes matching the web implementation
     */
    private fun setupBannerAdViews() {
        // Top banner (gpt-passback-1 equivalent)
        binding.adViewTop.adSize = AdSize.BANNER
        binding.adViewTop.adUnitId = AdSlotManager.BANNER_AD_UNIT_1
        
        // Middle banner (gpt-passback-2 equivalent)
        binding.adViewMiddle.adSize = AdSize.MEDIUM_RECTANGLE
        binding.adViewMiddle.adUnitId = AdSlotManager.BANNER_AD_UNIT_2
        
        // Bottom banner (gpt-passback-3 equivalent)
        binding.adViewBottom.adSize = AdSize.BANNER
        binding.adViewBottom.adUnitId = AdSlotManager.BANNER_AD_UNIT_3
    }
    
    /**
     * Load all banner ads
     */
    private fun loadAllBannerAds() {
        // Load top banner ad
        adSlotManager.loadBannerAd(
            binding.adViewTop,
            "gpt-passback-1",
            onAdLoaded = {
                Log.d(TAG, "Top banner ad loaded")
                updateAdStatus("Top banner loaded")
            },
            onAdFailed = { error ->
                Log.e(TAG, "Top banner ad failed: $error")
                updateAdStatus("Top banner failed")
            }
        )
        
        // Load middle banner ad
        adSlotManager.loadBannerAd(
            binding.adViewMiddle,
            "gpt-passback-2",
            onAdLoaded = {
                Log.d(TAG, "Middle banner ad loaded")
                updateAdStatus("Middle banner loaded")
            },
            onAdFailed = { error ->
                Log.e(TAG, "Middle banner ad failed: $error")
                updateAdStatus("Middle banner failed")
            }
        )
        
        // Load bottom banner ad
        adSlotManager.loadBannerAd(
            binding.adViewBottom,
            "gpt-passback-3",
            onAdLoaded = {
                Log.d(TAG, "Bottom banner ad loaded")
                updateAdStatus("Bottom banner loaded")
            },
            onAdFailed = { error ->
                Log.e(TAG, "Bottom banner ad failed: $error")
                updateAdStatus("Bottom banner failed")
            }
        )
    }
    
    /**
     * Setup UI components and click listeners
     */
    private fun setupUI() {
        // Setup the main "Yes" button (equivalent to the age button in web)
        binding.buttonYes.setOnClickListener {
            startQuizProcess()
        }
        
        // Setup refresh geo targeting button
        binding.buttonRefreshGeo.setOnClickListener {
            refreshGeoTargeting()
        }
        
        // Setup show rewarded ad button
        binding.buttonShowRewarded.setOnClickListener {
            showRewardedAd()
        }
        
        // Setup close bottom banner button
        binding.buttonCloseBanner.setOnClickListener {
            binding.bottomBannerContainer.visibility = android.view.View.GONE
        }
        
        // Setup refresh ads button
        binding.buttonRefreshAds.setOnClickListener {
            refreshAllAds()
        }
        
        Log.d(TAG, "UI setup complete")
    }
    
    /**
     * Initialize the app (equivalent to the web's page load initialization)
     */
    private fun initializeApp() {
        Log.d(TAG, "🎉 App initialization complete - equivalent to web page load")
        
        // Update all displays
        updateAllDisplays()
        
        // Show initial status
        Toast.makeText(this, "GeoAds Logic App Initialized", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Start quiz process (equivalent to the button click handler in web)
     */
    private fun startQuizProcess() {
        Log.d(TAG, "Starting quiz process...")
        
        quizLogicManager.startQuiz(
            onButtonTextChange = { text ->
                binding.buttonYes.text = text
            },
            onRewardedAdPlay = {
                // Try to play rewarded ad
                playRewardedAdForQuiz()
            },
            onRedirect = { url ->
                // Handle redirect (in Android, we'll show the URL or open browser)
                handleRedirect(url)
            }
        )
    }
    
    /**
     * Play rewarded ad for quiz (equivalent to playRewardedAd() in web)
     */
    private fun playRewardedAdForQuiz() {
        val success = adSlotManager.playRewardedAd(
            this,
            onRewardEarned = { rewardType, rewardAmount ->
                Log.d(TAG, "🎉 Reward: $rewardAmount $rewardType")
                Toast.makeText(this, "Reward earned: $rewardAmount $rewardType", Toast.LENGTH_LONG).show()
                
                // Handle reward completion
                quizLogicManager.onRewardedAdCompleted { url ->
                    handleRedirect(url)
                }
            },
            onAdClosed = {
                Log.d(TAG, "❎ Rewarded ad closed")
            },
            onAdFailed = {
                Log.w(TAG, "❌ Rewarded ad failed or not available")
                
                // Handle reward failure
                quizLogicManager.onRewardedAdFailed { url ->
                    handleRedirect(url)
                }
            }
        )
        
        if (!success) {
            Log.w(TAG, "❌ Rewarded ads are not supported or not ready")
            Toast.makeText(this, "Rewarded ad not available", Toast.LENGTH_SHORT).show()
        }
    }
    
    /**
     * Handle redirect (equivalent to window.location.href in web)
     */
    private fun handleRedirect(url: String) {
        Log.d(TAG, "Handling redirect to: $url")
        
        // In Android, we can either:
        // 1. Open in browser
        // 2. Show in WebView
        // 3. Handle internally
        
        // For this example, we'll show the URL and offer to open in browser
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Quiz Redirect")
            .setMessage("Quiz completed! Redirect URL:\n$url")
            .setPositiveButton("Open in Browser") { _, _ ->
                openUrlInBrowser(url)
            }
            .setNegativeButton("Copy URL") { _, _ ->
                copyUrlToClipboard(url)
            }
            .setNeutralButton("Reset Quiz") { _, _ ->
                resetQuiz()
            }
            .show()
    }
    
    /**
     * Open URL in browser
     */
    private fun openUrlInBrowser(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Error opening URL: ${e.message}")
            Toast.makeText(this, "Error opening URL", Toast.LENGTH_SHORT).show()
        }
    }
    
    /**
     * Copy URL to clipboard
     */
    private fun copyUrlToClipboard(url: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText("Quiz URL", url)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(this, "URL copied to clipboard", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Reset quiz to initial state
     */
    private fun resetQuiz() {
        quizLogicManager.resetQuiz()
        binding.buttonYes.text = "Yes"
        Toast.makeText(this, "Quiz reset", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Refresh geo targeting
     */
    private fun refreshGeoTargeting() {
        val newGeoTarget = geoTargetingManager.refreshGeoTargeting()
        updateGeoTargetingDisplay(newGeoTarget)
        
        // Refresh ads with new geo targeting
        refreshAllAds()
        
        Toast.makeText(this, "Geo targeting refreshed", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Show rewarded ad manually
     */
    private fun showRewardedAd() {
        playRewardedAdForQuiz()
    }
    
    /**
     * Refresh all ads
     */
    private fun refreshAllAds() {
        adSlotManager.refreshAllAds()
        loadAllBannerAds()
        Toast.makeText(this, "Refreshing all ads...", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Update geo targeting display
     */
    private fun updateGeoTargetingDisplay(geoTarget: String?) {
        binding.textGeoTarget.text = "Geo Target: ${geoTarget ?: "None"}"
        
        // Show geo targeting parameters
        val params = geoTargetingManager.getGeoTargetingParams()
        val paramsText = if (params.isNotEmpty()) {
            params.map { "${it.key}: ${it.value}" }.joinToString("\n")
        } else {
            "No geo targeting parameters"
        }
        binding.textGeoParams.text = paramsText
    }
    
    /**
     * Update quiz data display
     */
    private fun updateQuizDataDisplay(quizData: String) {
        binding.textQuizData.text = "Quiz Data: $quizData"
        
        // Show decoded data
        val decoded = quizLogicManager.decodeQuizData(quizData)
        val decodedText = if (decoded != null) {
            "Decoded: ${decoded.first} | ${decoded.second}"
        } else {
            "Decoding failed"
        }
        binding.textDecodedData.text = decodedText
    }
    
    /**
     * Update ad status display
     */
    private fun updateAdStatus(status: String) {
        val currentStatus = binding.textAdStatus.text.toString()
        binding.textAdStatus.text = "$currentStatus\n$status"
    }
    
    /**
     * Update all displays
     */
    private fun updateAllDisplays() {
        // Update geo targeting display
        updateGeoTargetingDisplay(geoTargetingManager.getCurrentGeoTarget())
        
        // Update quiz data display
        updateQuizDataDisplay(quizLogicManager.getQuizData())
        
        // Update status displays
        updateStatusDisplays()
    }
    
    /**
     * Update status displays
     */
    private fun updateStatusDisplays() {
        // Quiz status
        val quizStatus = quizLogicManager.getQuizStatus()
        val quizStatusText = quizStatus.map { "${it.key}: ${it.value}" }.joinToString("\n")
        binding.textQuizStatus.text = quizStatusText
        
        // Ad stats
        val adStats = adSlotManager.getAdStats()
        val adStatsText = adStats.map { "${it.key}: ${it.value}" }.joinToString("\n")
        binding.textAdStats.text = adStatsText
        
        // Geo stats
        val geoStats = geoTargetingManager.getGeoTargetStats()
        val geoStatsText = geoStats.map { "${it.key}: ${it.value}" }.joinToString("\n")
        binding.textGeoStats.text = geoStatsText
    }
    
    override fun onResume() {
        super.onResume()
        // Resume ad views
        binding.adViewTop.resume()
        binding.adViewMiddle.resume()
        binding.adViewBottom.resume()
        
        // Update displays
        updateStatusDisplays()
    }
    
    override fun onPause() {
        super.onPause()
        // Pause ad views
        binding.adViewTop.pause()
        binding.adViewMiddle.pause()
        binding.adViewBottom.pause()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        // Destroy ad views
        binding.adViewTop.destroy()
        binding.adViewMiddle.destroy()
        binding.adViewBottom.destroy()
        
        // Clean up managers
        adSlotManager.cleanup()
        
        Log.d(TAG, "MainActivity destroyed and cleaned up")
    }
}

