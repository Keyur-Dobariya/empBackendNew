package com.example.geoadslogic

import android.content.Context
import android.util.Base64
import android.util.Log
import kotlin.random.Random

/**
 * QuizLogicManager handles the quiz logic and data encoding from the web implementation.
 * This includes the btoa encoding and redirect URL generation.
 */
class QuizLogicManager(private val context: Context) {
    
    companion object {
        private const val TAG = "QuizLogicManager"
        
        // Default values from the web implementation
        private const val DEFAULT_DATA_1 = "zeb9"
        private const val DEFAULT_DATA_2 = "5"
        private const val REDIRECT_TIMEOUT = 3000L // 3 seconds
    }
    
    private var isQuizStarted = false
    private var isRedirecting = false
    private var quizData: String? = null
    
    /**
     * Initialize quiz data (equivalent to the btoa encoding in web)
     * const data = btoa("zeb9") + "|" + btoa("5");
     */
    fun initializeQuizData(data1: String = DEFAULT_DATA_1, data2: String = DEFAULT_DATA_2): String {
        // Android equivalent of JavaScript's btoa() function
        val encodedData1 = Base64.encodeToString(data1.toByteArray(), Base64.NO_WRAP)
        val encodedData2 = Base64.encodeToString(data2.toByteArray(), Base64.NO_WRAP)
        
        quizData = "$encodedData1|$encodedData2"
        Log.d(TAG, "Quiz data initialized: $quizData")
        
        return quizData!!
    }
    
    /**
     * Get the current quiz data
     */
    fun getQuizData(): String {
        return quizData ?: initializeQuizData()
    }
    
    /**
     * Generate redirect URL (equivalent to web implementation)
     * var redirectUrl = "question.php?data=" + data + "&q=0";
     */
    fun generateRedirectUrl(baseUrl: String = "question.php", questionIndex: Int = 0): String {
        val data = getQuizData()
        return "$baseUrl?data=$data&q=$questionIndex"
    }
    
    /**
     * Start quiz process (equivalent to button click handler)
     */
    fun startQuiz(
        onButtonTextChange: (String) -> Unit,
        onRewardedAdPlay: () -> Unit,
        onRedirect: (String) -> Unit
    ) {
        if (isQuizStarted || isRedirecting) {
            Log.w(TAG, "Quiz already started or redirecting")
            return
        }
        
        isQuizStarted = true
        Log.d(TAG, "Quiz started")
        
        // Change button text to "Loading..."
        onButtonTextChange("Loading...")
        
        val redirectUrl = generateRedirectUrl()
        
        // Try to play rewarded ad first
        try {
            onRewardedAdPlay()
            Log.d(TAG, "Rewarded ad play initiated")
        } catch (e: Exception) {
            Log.w(TAG, "Rewarded ad play failed: ${e.message}")
        }
        
        // Set timeout for redirect (equivalent to setTimeout in web)
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!isRedirecting) {
                performRedirect(redirectUrl, onRedirect)
            }
        }, REDIRECT_TIMEOUT)
    }
    
    /**
     * Handle rewarded ad completion
     */
    fun onRewardedAdCompleted(onRedirect: (String) -> Unit) {
        if (!isRedirecting) {
            val redirectUrl = generateRedirectUrl()
            performRedirect(redirectUrl, onRedirect)
        }
    }
    
    /**
     * Handle rewarded ad failure
     */
    fun onRewardedAdFailed(onRedirect: (String) -> Unit) {
        if (!isRedirecting) {
            val redirectUrl = generateRedirectUrl()
            performRedirect(redirectUrl, onRedirect)
        }
    }
    
    /**
     * Perform the actual redirect
     */
    private fun performRedirect(url: String, onRedirect: (String) -> Unit) {
        if (isRedirecting) return
        
        isRedirecting = true
        Log.d(TAG, "Redirecting to: $url")
        onRedirect(url)
    }
    
    /**
     * Reset quiz state
     */
    fun resetQuiz() {
        isQuizStarted = false
        isRedirecting = false
        Log.d(TAG, "Quiz state reset")
    }
    
    /**
     * Check if quiz is in progress
     */
    fun isQuizInProgress(): Boolean = isQuizStarted && !isRedirecting
    
    /**
     * Check if currently redirecting
     */
    fun isCurrentlyRedirecting(): Boolean = isRedirecting
    
    /**
     * Get quiz status information
     */
    fun getQuizStatus(): Map<String, Any> {
        return mapOf(
            "quiz_started" to isQuizStarted,
            "is_redirecting" to isRedirecting,
            "quiz_data" to (quizData ?: "Not initialized"),
            "redirect_url" to generateRedirectUrl()
        )
    }
    
    /**
     * Generate random quiz data (for testing different scenarios)
     */
    fun generateRandomQuizData(): String {
        val randomData1 = "quiz${Random.nextInt(1000)}"
        val randomData2 = Random.nextInt(10).toString()
        return initializeQuizData(randomData1, randomData2)
    }
    
    /**
     * Decode quiz data (reverse of btoa encoding)
     */
    fun decodeQuizData(encodedData: String): Pair<String, String>? {
        return try {
            val parts = encodedData.split("|")
            if (parts.size == 2) {
                val decoded1 = String(Base64.decode(parts[0], Base64.NO_WRAP))
                val decoded2 = String(Base64.decode(parts[1], Base64.NO_WRAP))
                Pair(decoded1, decoded2)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding quiz data: ${e.message}")
            null
        }
    }
    
    /**
     * Validate quiz data format
     */
    fun isValidQuizData(data: String): Boolean {
        return try {
            val parts = data.split("|")
            parts.size == 2 && 
            parts[0].isNotEmpty() && 
            parts[1].isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }
}

