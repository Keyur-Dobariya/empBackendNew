package apps.mobile.number.traker.callerId.Activity;

public class Constant {
    public static String App_link ="market://details?id=\" + appPackageName";
}
