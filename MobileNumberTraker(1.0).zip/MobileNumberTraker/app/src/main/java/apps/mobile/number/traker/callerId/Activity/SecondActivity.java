package apps.mobile.number.traker.callerId.Activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;

import apps.mobile.number.traker.callerId.Audio.MangeraudioActivity;
import apps.mobile.number.traker.callerId.Bank.AllBankActivity;
import apps.mobile.number.traker.callerId.CallInfo.CallInfoActivity;
import apps.mobile.number.traker.callerId.NearPlace.AllNearPlaceActviity;
import apps.mobile.number.traker.callerId.NumberData.ISDCodeActivity;
import apps.mobile.number.traker.callerId.NumberData.Num_SearchActivity;
import apps.mobile.number.traker.callerId.NumberData.STDCodeActivity;
import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.SIM.SimInformation;
import apps.mobile.number.traker.callerId.ads.commons.AdsManager;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.SmallNativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivitySecondBinding;

public class SecondActivity extends AppCompatActivity implements View.OnClickListener {

    ActivitySecondBinding binding;
    private ReviewManager manager;
    private ReviewInfo reviewInfo;
    private static final int STORAGE_REQUEST_CODE = 101;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySecondBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        //        ***********permission*****************************
        if (!CheckStoragePERMISSION()) {
            AskStoragePERMISSION();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.System.canWrite(this)) {
            } else {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        }

        bind();
        goReview();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(SecondActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        showExitDailog();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });

//        ***************samll native*******************
        new SmallNativeAds(screenName).showAd(this, binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);
    }

    private void bind() {
        binding.btnmobileloc.setOnClickListener(this);
        binding.btnstdcode.setOnClickListener(this);
        binding.btnisdcode.setOnClickListener(this);
        binding.btncallinfo.setOnClickListener(this);
        binding.btnaudioinfo.setOnClickListener(this);
        binding.btnbankinfo.setOnClickListener(this);
        binding.btnnearplace.setOnClickListener(this);
        binding.btnsiminfo.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnmobileloc:
                startActivitys(new Intent(SecondActivity.this, Num_SearchActivity.class));
                break;
            case R.id.btnstdcode:
                startActivitys(new Intent(SecondActivity.this, STDCodeActivity.class));
                break;
            case R.id.btnisdcode:
                startActivitys(new Intent(SecondActivity.this, ISDCodeActivity.class));
                break;
            case R.id.btncallinfo:
                startActivitys(new Intent(SecondActivity.this, CallInfoActivity.class));
                break;
            case R.id.btnbankinfo:
                startActivitys(new Intent(SecondActivity.this, AllBankActivity.class));
                break;
            case R.id.btnnearplace:
                startActivitys(new Intent(SecondActivity.this, AllNearPlaceActviity.class));
                break;
            case R.id.btnaudioinfo:
                startActivitys(new Intent(SecondActivity.this, MangeraudioActivity.class));
                break;
            case R.id.btnsiminfo:
                startActivitys(new Intent(SecondActivity.this, SimInformation.class));
                break;
        }
    }


    //  ##---------------Begin: permission configuration for Storage --------

    private String[] StoragePERMISSION() {
        return new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                android.Manifest.permission.READ_EXTERNAL_STORAGE, android.Manifest.permission.CALL_PHONE};
    }

    private void AskStoragePERMISSION() {
        ActivityCompat.requestPermissions(SecondActivity.this, StoragePERMISSION(),
                STORAGE_REQUEST_CODE);
    }

    private boolean CheckStoragePERMISSION() {
        int result, result2, result3;
        result = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
        result2 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        result3 = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
        return result == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED
                && result3 == PackageManager.PERMISSION_GRANTED;
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            }
        }
    }

    //  ##---------------End: permission configuration for Storage --------

    private void goReview() {
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener() {
            @Override
            public final void onComplete(Task task) {
                if (task.isSuccessful()) {
                    reviewInfo = (ReviewInfo) task.getResult();
                    manager.launchReviewFlow(SecondActivity.this, reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                        }
                    });
                }
            }
        });
    }

    private void showExitDailog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.MyTransparentBottomSheetDialogTheme);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_exitdialog);
        TextView btnNo = bottomSheetDialog.findViewById(R.id.btnNo);
        TextView txtYesExit = bottomSheetDialog.findViewById(R.id.txtYesExit);
        txtYesExit.setOnClickListener(v -> {
            AdsManager.release(getApplication());
            finishAffinity();
        });
        btnNo.setOnClickListener(v -> bottomSheetDialog.dismiss());
        bottomSheetDialog.show();
    }


    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(SecondActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }
}