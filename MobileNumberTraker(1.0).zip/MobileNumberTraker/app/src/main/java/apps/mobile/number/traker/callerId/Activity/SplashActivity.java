package apps.mobile.number.traker.callerId.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.commons.AdsManager;
import apps.mobile.number.traker.callerId.ads.interfaces.OnFirstData;
import apps.mobile.number.traker.callerId.databinding.ActivitySplashBinding;

public class SplashActivity extends AppCompatActivity implements OnFirstData {

    ActivitySplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.btnRetry.setVisibility(View.GONE);
                AdsManager.getFirstData(getApplication(), getApplication(), SplashActivity.this, SplashActivity.this);
            }
        });
        binding.btnRetry.performClick();
    }

    @Override
    public void onSuccess() {
        startActivity(new Intent(SplashActivity.this, StartActivity.class));
        new Handler().postDelayed(this::finish, 500);
    }

    @Override
    public void onFailed() {
        binding.progress.setVisibility(View.GONE);
        binding.btnRetry.setVisibility(View.VISIBLE);
    }
}