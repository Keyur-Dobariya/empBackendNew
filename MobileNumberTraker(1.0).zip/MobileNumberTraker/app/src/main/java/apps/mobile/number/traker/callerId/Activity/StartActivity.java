package apps.mobile.number.traker.callerId.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.commons.AdsUtils;
import apps.mobile.number.traker.callerId.ads.commons.MyExtensionsKt;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.databinding.ActivityStartBinding;

public class StartActivity extends AppCompatActivity implements View.OnClickListener {

    ActivityStartBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        find();
    }

    private void find() {
        binding.relstart.setOnClickListener(this);
        binding.privacy.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.relstart:
                startActivitys(new Intent(StartActivity.this, SecondActivity.class));
                break;
            case R.id.privacy:
                MyExtensionsKt.privacyPolicy(this, AdsUtils.getAdPref(this).ppLink);
                break;
        }
    }

    //    *************intetial***********************************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(StartActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {

            }
        });
    }

}