package apps.mobile.number.traker.callerId.Audio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings.System;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import apps.mobile.number.traker.callerId.databinding.FragmentAudioManagerBinding;


public class Audio_Manager extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    Editor ed;
    int i;
    OnFragmentInteractionListener mListener;
    String mParam1;
    String mParam2;
    SharedPreferences sp;
    FragmentAudioManagerBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    public static Audio_Manager newInstance(String str, String str2) {
        Audio_Manager audioManager = new Audio_Manager();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str);
        bundle.putString(ARG_PARAM2, str2);
        audioManager.setArguments(bundle);
        return audioManager;
    }

    public static Audio_Manager newInstance() {
        return new Audio_Manager();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }


    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        binding = FragmentAudioManagerBinding.inflate(layoutInflater, viewGroup, false);

        //        ******************samll native********************
        new NativeAds(screenName).showAd(getActivity(), binding.admobNative, binding.fbNative, binding.cardNative);

        sp = getActivity().getSharedPreferences("vibrate_when_ringing", 0);
        ed = this.sp.edit();
        i = System.getInt(getActivity().getApplicationContext().getContentResolver(), "vibrate_when_ringing", 0);
        StringBuilder sb = new StringBuilder();
        sb.append("sys vibrate value ");
        sb.append(this.i);
        Log.d("Ringer", sb.toString());
        int i2 = this.i;
        if (i2 == 0) {
            binding.virbringing.setChecked(false);
        } else if (i2 == 1) {
            binding.virbringing.setChecked(true);
        }
        binding.virbringing.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ed.putBoolean("vibrate_when_ringing", z);
                ed.commit();
                if (Audio_Manager.this.i == 0) {
                    System.putInt(Audio_Manager.this.getActivity().getApplicationContext().getContentResolver(), "vibrate_when_ringing", 1);
                } else if (Audio_Manager.this.i == 1) {
                    System.putInt(Audio_Manager.this.getActivity().getApplicationContext().getContentResolver(), "vibrate_when_ringing", 0);
                }
            }
        });
        binding.ringtoneselect.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Uri actualDefaultRingtoneUri = RingtoneManager.getActualDefaultRingtoneUri(Audio_Manager.this.getActivity(), 1);
                Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
                intent.putExtra("android.intent.extra.ringtone.TYPE", 1);
                intent.putExtra("android.intent.extra.ringtone.TITLE", "Select Ringtone");
                intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", actualDefaultRingtoneUri);
                intent.putExtra("android.intent.extra.ringtone.SHOW_SILENT", true);
                intent.putExtra("android.intent.extra.ringtone.SHOW_DEFAULT", false);
                startActivityForResult(intent, 1001);
            }
        });
        binding.notificationselect.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
                intent.putExtra("android.intent.extra.ringtone.TYPE", 2);
                intent.putExtra("android.intent.extra.ringtone.TITLE", "Select Notification Tone");
                intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", RingtoneManager.getActualDefaultRingtoneUri(Audio_Manager.this.getActivity(), 2));
                startActivityForResult(intent, 1002);
            }
        });
        binding.alarmselect.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.RINGTONE_PICKER");
                intent.putExtra("android.intent.extra.ringtone.TYPE", 4);
                intent.putExtra("android.intent.extra.ringtone.TITLE", "Select Alarm Tone");
                intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", RingtoneManager.getActualDefaultRingtoneUri(Audio_Manager.this.getActivity(), 4));
                startActivityForResult(intent, 1003);
            }
        });


        return binding.getRoot();
    }


    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            this.mListener = (OnFragmentInteractionListener) context;
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(context.toString());
        sb.append(" must implement OnFragmentInteractionListener");
        throw new RuntimeException(sb.toString());
    }

    public void onDetach() {
        super.onDetach();
        this.mListener = null;
    }

    public void onActivityResult(int i2, int i3, Intent intent) {
        StringBuilder sb = new StringBuilder();
        sb.append("result code ");
        sb.append(i3);
        sb.append("Activity.RESULT_OK");
        sb.append(-1);
        sb.append(" request code ");
        sb.append(i2);
        Log.d("TRing", sb.toString());
        if (i3 == -1) {
            Uri uri = (Uri) intent.getParcelableExtra("android.intent.extra.ringtone.PICKED_URI");
            switch (i2) {
                case 1001:
                    RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 1, uri);
                    return;
                case 1002:
                    RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 2, uri);
                    return;
                case 1003:
                    RingtoneManager.setActualDefaultRingtoneUri(getActivity(), 4, uri);
                    return;
                default:
                    return;
            }
        }
    }


}
