package apps.mobile.number.traker.callerId.Audio;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.databinding.ActivityMangeraudioBinding;

public class MangeraudioActivity extends AppCompatActivity implements Audio_Manager.OnFragmentInteractionListener {

    ActivityMangeraudioBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMangeraudioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(MangeraudioActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        binding.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        FragmentTransaction customAnimations = getSupportFragmentManager().beginTransaction();
        customAnimations.replace(R.id.fragment_container, Audio_Manager.newInstance());
        customAnimations.commit();

    }

    public void onFragmentInteraction(Uri uri) {
    }

}