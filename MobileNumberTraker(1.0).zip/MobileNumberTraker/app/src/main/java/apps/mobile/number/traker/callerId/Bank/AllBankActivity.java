package apps.mobile.number.traker.callerId.Bank;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

import apps.mobile.number.traker.callerId.Bank.adapter.BankListAdapter;
import apps.mobile.number.traker.callerId.Bank.database.MyDatabase;
import apps.mobile.number.traker.callerId.Bank.object.ObjBankList;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.SmallNativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivityAllBankBinding;

public class AllBankActivity extends AppCompatActivity {
    BankListAdapter bankListAdapter;
    ArrayList<ObjBankList> objBankLists = new ArrayList<>();
    MyDatabase db;
    ActivityAllBankBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAllBankBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

//        ********************samll native***********************
        new SmallNativeAds(screenName).showAd(this, binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(AllBankActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bankListAdapter = new BankListAdapter(this, new BankListAdapter.InterfaceClick() {
            @Override
            public void onClick(int position) {
                InterstitialAds.showAd(AllBankActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        Intent i = new Intent(AllBankActivity.this, BankDetailActivity.class);
                        i.putExtra("bankName", objBankLists.get(position).getBankname());
                        i.putExtra("bankLogo", objBankLists.get(position).getBankicon());
                        i.putExtra("bankMiniStm", objBankLists.get(position).getMinistatement());
                        i.putExtra("bankCustomer", objBankLists.get(position).getCustomercare());
                        i.putExtra("bankBalanceCheck", objBankLists.get(position).getBalancecheck());
                        startActivity(i);
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });

        this.db = new MyDatabase(this);
        Cursor bankDetails = this.db.getBankDetails();
        bankDetails.moveToFirst();
        do {
            ObjBankList obj = new ObjBankList();
            obj.setId(bankDetails.getInt(bankDetails.getColumnIndex("no")));
            obj.setBankname(bankDetails.getString(bankDetails.getColumnIndex("bank_name")));
            obj.setBalancecheck(bankDetails.getString(bankDetails.getColumnIndex("balance_check")));
            obj.setMinistatement(bankDetails.getString(bankDetails.getColumnIndex("mini_statement")));
            obj.setCustomercare(bankDetails.getString(bankDetails.getColumnIndex("customer_care")));
            obj.setBankicon(bankDetails.getString(bankDetails.getColumnIndex("icon")));
            this.objBankLists.add(obj);
        } while (bankDetails.moveToNext());

        binding.recbankbalance.setLayoutManager((new GridLayoutManager(this, 1)));
        binding.recbankbalance.setItemAnimator(new DefaultItemAnimator());
        binding.recbankbalance.setAdapter(bankListAdapter);
        bankListAdapter.addAll(objBankLists);
    }

}