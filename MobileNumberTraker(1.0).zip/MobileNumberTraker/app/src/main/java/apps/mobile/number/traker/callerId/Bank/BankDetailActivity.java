package apps.mobile.number.traker.callerId.Bank;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.facebook.ads.NativeAdLayout;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BankDetailActivity extends AppCompatActivity implements View.OnClickListener {
    String bankName, bankLogo, bankMiniStm, bankCustomer, bankBalanceCheck;
    String[] bankBalance, miniStatement;
    String callNumber;

    @BindView(R.id.image_bank_image)
    ImageView image_bank_image;

    @BindView(R.id.ly_balance_checkNo)
    LinearLayout lyBalanceCheckNo;

    @BindView(R.id.ly_mini_stm)
    LinearLayout ly_mini_stm;

    @BindView(R.id.ly_customer_care_number)
    LinearLayout ly_customer_care_number;

    @BindView(R.id.txt_balance_check_no)
    TextView txtBalanceCheckNo;

    @BindView(R.id.txt_mini_stm)
    TextView txt_mini_stm;

    @BindView(R.id.txtCustomerCareNumber)
    TextView txtCustomerCareNumber;

    @BindView(R.id.bank_back)
    ImageView imgback;

    @BindView(R.id.ly_share_balance)
    LinearLayout ly_share_balance;

    @BindView(R.id.ly_share_mini_stm)
    LinearLayout ly_share_mini_stm;

    @BindView(R.id.ll_share_customer_care)
    LinearLayout ll_share_customer_care;

    @BindView(R.id.txt_banknameheader)
    TextView txt_banknameheader;

    CardView cardNative;
    FrameLayout admobNative;
    NativeAdLayout fbNative;

    int counter;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bank_detail);
        ButterKnife.bind(this);
        bind();
//        ((TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE)).listen(new PhoneCallListener(this, null), 32);
        bankName = getIntent().getExtras().getString("bankName");
        bankLogo = getIntent().getExtras().getString("bankLogo");
        bankMiniStm = getIntent().getExtras().getString("bankMiniStm");
        bankCustomer = getIntent().getExtras().getString("bankCustomer");
        bankBalanceCheck = getIntent().getExtras().getString("bankBalanceCheck");
        counter = getIntent().getExtras().getInt("counter");
        txtBalanceCheckNo.setText(bankBalanceCheck);
        txtCustomerCareNumber.setText(bankCustomer);
        txt_mini_stm.setText(bankMiniStm);
        Glide.with(BankDetailActivity.this)
                .load(Uri.parse("file:///android_asset/banklogo/" + bankLogo + ".webp"))
                .into(image_bank_image);
        txt_banknameheader.setText(bankName);

//        **********************native******************
        new NativeAds(screenName).showAd(this, admobNative, fbNative, cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(BankDetailActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        ly_share_balance.setOnClickListener(this);
        ly_share_mini_stm.setOnClickListener(this);
        ll_share_customer_care.setOnClickListener(this);
        ly_customer_care_number.setOnClickListener(this);
        ly_mini_stm.setOnClickListener(this);
        lyBalanceCheckNo.setOnClickListener(this);
        imgback.setOnClickListener(this);

        admobNative = findViewById(R.id.admobNative);
        fbNative = findViewById(R.id.fbNative);
        cardNative = findViewById(R.id.cardNative);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bank_back:
                finish();
                break;
            case R.id.ly_balance_checkNo:
                if (bankBalanceCheck.length() <= 14) {
                    try {
                        callNumber = bankBalanceCheck;
                        onCall();
                        return;
                    } catch (ActivityNotFoundException unused) {
                        return;
                    }
                }
                Intent intent3 = new Intent("android.intent.action.VIEW");
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("sms:");
                stringBuilder3.append(bankBalance[2]);
                intent3.setData(Uri.parse(stringBuilder3.toString()));
                intent3.putExtra("sms_body", bankBalance[0]);
                startActivity(intent3);
                break;
            case R.id.ly_mini_stm:
                if (!bankMiniStm.equals("NA")) {
                    if (bankMiniStm.length() <= 14) {
                        try {
                            callNumber = bankMiniStm;
                            onCall();
                            return;
                        } catch (ActivityNotFoundException unused) {
                            return;
                        }
                    }
                    Intent intent4 = new Intent("android.intent.action.VIEW");
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append("sms:");
                    stringBuilder4.append(miniStatement[2]);
                    intent4.setData(Uri.parse(stringBuilder4.toString()));
                    intent4.putExtra("sms_body", miniStatement[0]);
                    startActivity(intent4);
                }
                break;
            case R.id.ly_customer_care_number:
                if (!txtCustomerCareNumber.getText().toString().equals("NA")) {
                    BankDetailActivity bankDetailActivity = BankDetailActivity.this;
                    bankDetailActivity.callNumber = bankDetailActivity.bankCustomer;
                    onCall();
                }
                break;

            case R.id.ly_share_balance:
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", "Bank Balance");
                StringBuilder stringBuilder;
                if (bankBalanceCheck.length() <= 14) {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(bankName);
                    stringBuilder.append("'s Balance Inquiry Number is ");
                    stringBuilder.append(bankBalanceCheck);
                    intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                } else {
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(bankName);
                    stringBuilder.append(": To Get Bank Balance \n Send SMS ");
                    stringBuilder.append(bankBalance[0]);
                    stringBuilder.append(" to ");
                    stringBuilder.append(bankBalance[2]);
                    intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                }
                startActivity(intent);

                break;
            case R.id.ly_share_mini_stm:
                Intent intent1 = new Intent("android.intent.action.SEND");
                intent1.setType("text/plain");
                intent1.putExtra("android.intent.extra.SUBJECT", "Mini Statement");
                StringBuilder stringBuilder1;
                if (bankMiniStm.length() <= 14) {
                    stringBuilder1 = new StringBuilder();
                    stringBuilder1.append(bankName);
                    stringBuilder1.append("'s Mini Statement Inquiry Number is ");
                    stringBuilder1.append(bankMiniStm);
                    intent1.putExtra("android.intent.extra.TEXT", stringBuilder1.toString());
                } else {
                    stringBuilder1 = new StringBuilder();
                    stringBuilder1.append(bankName);
                    stringBuilder1.append(": To Get Mini Statement \n Send SMS ");
                    stringBuilder1.append(miniStatement[0]);
                    stringBuilder1.append(" to ");
                    stringBuilder1.append(miniStatement[2]);
                    intent1.putExtra("android.intent.extra.TEXT", stringBuilder1.toString());
                }
                startActivity(intent1);

                break;
            case R.id.ll_share_customer_care:
                Intent intent2 = new Intent("android.intent.action.SEND");
                intent2.setType("text/plain");
                intent2.putExtra("android.intent.extra.SUBJECT", "Bank Customer Care Number");
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(bankName);
                stringBuilder2.append("'s Customer Care Number is ");
                stringBuilder2.append(bankCustomer);
                intent2.putExtra("android.intent.extra.TEXT", stringBuilder2.toString());
                startActivity(intent2);

                break;

        }
    }

    public void onCall() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.CALL_PHONE") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.CALL_PHONE"}, 123);
            return;
        }
        Intent intent = new Intent("android.intent.action.CALL");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("tel:");
        stringBuilder.append(this.callNumber);
        startActivity(intent.setData(Uri.parse(stringBuilder.toString())));
    }

    public void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 123) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                Toast.makeText(this, "Call Permission Not Granted", Toast.LENGTH_SHORT).show();
            } else {
                onCall();
            }
        }
    }


    //    private class PhoneCallListener extends PhoneStateListener {
//        private PhoneCallListener(BankDetailActivity bankDetailActivity, Object o) {
//        }
//        public void onCallStateChanged(int i, String str) {
//            super.onCallStateChanged(i, str);
//            switch (i) {
//                case 0:
//                    if (!BankDetailActivity.ring || !BankDetailActivity.callReceived) {
//                        return;
//                    }
//                    return;
//                case 1:
//                    BankDetailActivity.ring = true;
//                    return;
//                case 2:
//                    BankDetailActivity.callReceived = true;
//                    return;
//                default:
//                    return;
//            }
//        }
//    }
}