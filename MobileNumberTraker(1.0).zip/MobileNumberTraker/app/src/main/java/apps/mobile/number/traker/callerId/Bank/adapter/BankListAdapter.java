package apps.mobile.number.traker.callerId.Bank.adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

import apps.mobile.number.traker.callerId.Bank.object.ObjBankList;
import apps.mobile.number.traker.callerId.R;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BankListAdapter extends RecyclerView.Adapter<BankListAdapter.MyViewHolder> {
    Context mcontext;
    InterfaceClick interfaceClick;
    ArrayList<ObjBankList> objBankLists = new ArrayList<>();

    public BankListAdapter(Context mcontext, InterfaceClick interfaceClick) {
        this.mcontext = mcontext;
        this.interfaceClick = interfaceClick;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_banklist, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        try {
            Glide.with(mcontext)
                    .load(Uri.parse("file:///android_asset/banklogo/" + objBankLists.get(position).getBankicon() + ".webp"))
                    .into(holder.bank_image_logo);

            holder.cv_bankname_list.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    interfaceClick.onClick(position);
                }
            });
            holder.txt_bank_name.setText(objBankLists.get(position).getBankname());

        } catch (Exception e) {
        }
    }

    @Override
    public int getItemCount() {
        return objBankLists.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.bank_image_logo)
        ImageView bank_image_logo;

        @BindView(R.id.txt_bank_name)
        TextView txt_bank_name;

        @BindView(R.id.cv_bankname_list)
        LinearLayout cv_bankname_list;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public void addAll(ArrayList<ObjBankList> data) {
        try {
            this.objBankLists.clear();
            this.objBankLists.addAll(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        notifyDataSetChanged();
    }

    public interface InterfaceClick {
        void onClick(int position);
    }
}
