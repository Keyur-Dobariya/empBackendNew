package apps.mobile.number.traker.callerId.Bank.database;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.preference.PreferenceManager;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MyDatabase extends SQLiteOpenHelper {

//    private static String DATABASE_PATH = "/data/data/com.ozon.plus.bankbalancecheck";
    private static String DATABASE_PATH = "/data/data/apps.mobile.number.traker.callerId";

    private static String DATABASE_NAME = "bank_db.sqlite";

    private static final String KEY_DB_VER = "database_version";


    SQLiteDatabase checkDB;

    public boolean dbExist;
    private final Context mContext;

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }

    public MyDatabase(Context context) {
        super(context, DATABASE_NAME, null, 6);
        this.mContext = context;
        initialize();
    }

    private void initialize() {
        if (checkDataBase().booleanValue() && 6 != PreferenceManager.getDefaultSharedPreferences(this.mContext).getInt(KEY_DB_VER, 1)) {
            Context context = this.mContext;
            StringBuilder sb = new StringBuilder();
            sb.append(DATABASE_PATH);
            sb.append("/");
            sb.append(DATABASE_NAME);
            context.getDatabasePath(sb.toString()).delete();
        }
        if (!checkDataBase().booleanValue()) {
            try {
                createDataBase();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void close() {
        if (this.checkDB != null) {
            this.checkDB.close();
        }
        super.close();
    }

    public void createDataBase() throws IOException {
        this.dbExist = checkDataBase().booleanValue();
        if (!this.dbExist) {
            getReadableDatabase();
            close();
            try {
                copyDataBase();
                SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
                edit.putInt(KEY_DB_VER, 6);
                edit.commit();
            } catch (IOException unused) {
                throw new Error("ErrorCopyingDataBase");
            }
        }
    }

    public Boolean checkDataBase() {
        Context context = this.mContext;
        StringBuilder sb = new StringBuilder();
        sb.append(DATABASE_PATH);
        sb.append("/");
        sb.append(DATABASE_NAME);
        return Boolean.valueOf(context.getDatabasePath(sb.toString()).exists());
    }

    private void copyDataBase() throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append(DATABASE_PATH);
        sb.append("/");
        sb.append(DATABASE_NAME);
        FileOutputStream fileOutputStream = new FileOutputStream(sb.toString());
        byte[] bArr = new byte[1024];
        InputStream open = this.mContext.getAssets().open(DATABASE_NAME);
        while (open.read(bArr) > 0) {
            fileOutputStream.write(bArr);
        }
        open.close();
        fileOutputStream.flush();
        fileOutputStream.close();
    }

    public void openDataBase() throws SQLException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(DATABASE_PATH);
        stringBuilder.append("/");
        stringBuilder.append(DATABASE_NAME);
        this.checkDB = SQLiteDatabase.openDatabase(stringBuilder.toString(), null, 0);
    }

    public void CloseDataBase() {
        this.checkDB.close();
    }

    public Cursor getBankDetails() {
        openDataBase();
        return this.checkDB.rawQuery("select * from banktable", null);
    }

}
