package apps.mobile.number.traker.callerId.Bank.object;

public class ObjBankList {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    int id;

    public ObjBankList() {

    }

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    String bankname;

    public String getBankicon() {
        return bankicon;
    }

    public void setBankicon(String bankicon) {
        this.bankicon = bankicon;
    }

    String bankicon;

    public String getBalancecheck() {
        return balancecheck;
    }

    public void setBalancecheck(String balancecheck) {
        this.balancecheck = balancecheck;
    }

    public String getCustomercare() {
        return customercare;
    }

    public void setCustomercare(String customercare) {
        this.customercare = customercare;
    }

    public String getMinistatement() {
        return ministatement;
    }

    public void setMinistatement(String ministatement) {
        this.ministatement = ministatement;
    }

    String balancecheck;
    String customercare;
    String ministatement;


}
