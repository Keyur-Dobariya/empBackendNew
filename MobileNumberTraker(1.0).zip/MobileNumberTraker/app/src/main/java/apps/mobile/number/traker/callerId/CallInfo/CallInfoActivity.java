package apps.mobile.number.traker.callerId.CallInfo;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.databinding.ActivityCallInfoBinding;

public class CallInfoActivity extends AppCompatActivity implements CallerInformation.OnFragmentInteractionListener {

    ActivityCallInfoBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCallInfoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(CallInfoActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        binding.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        FragmentTransaction customAnimations = getSupportFragmentManager().beginTransaction();
        customAnimations.replace(R.id.fragment_container, CallerInformation.newInstance());
        customAnimations.commit();

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

}