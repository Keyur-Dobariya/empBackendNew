package apps.mobile.number.traker.callerId.CallInfo;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

import androidx.fragment.app.Fragment;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import apps.mobile.number.traker.callerId.databinding.FragmentAudioManagerBinding;
import apps.mobile.number.traker.callerId.databinding.FragmentCallerInformationBinding;


public class CallerInformation extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    Editor ed;
    OnFragmentInteractionListener mListener;
    String mParam1;
    String mParam2;
    SharedPreferences sp;

    FragmentCallerInformationBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    public static CallerInformation newInstance(String str2, String str3) {
        CallerInformation callerInformation = new CallerInformation();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PARAM1, str2);
        bundle.putString(ARG_PARAM2, str3);
        callerInformation.setArguments(bundle);
        return callerInformation;
    }

    public static CallerInformation newInstance() {
        return new CallerInformation();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            this.mParam1 = getArguments().getString(ARG_PARAM1);
            this.mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        binding = FragmentCallerInformationBinding.inflate(layoutInflater, viewGroup, false);

//        ***************************native*********************
        new NativeAds(screenName).showAd(getContext(), binding.admobNative, binding.fbNative, binding.cardNative);

        sp = getActivity().getSharedPreferences("call_setings", 0);
        ed = this.sp.edit();
        binding.incheck.setChecked(this.sp.getBoolean("in_call_value", true));
        binding.outcheck.setChecked(this.sp.getBoolean("out_call_value", true));
        binding.incheck.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ed.putBoolean("in_call_value", z);
                ed.commit();
            }
        });
        binding.outcheck.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                ed.putBoolean("out_call_value", z);
                ed.commit();
            }
        });
        //TODO  start
        return binding.getRoot();
    }


    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            this.mListener = (OnFragmentInteractionListener) context;
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(context.toString());
        sb.append(" must implement OnFragmentInteractionListener");
        throw new RuntimeException(sb.toString());
    }

    public void onDetach() {
        super.onDetach();
        this.mListener = null;
    }

}
