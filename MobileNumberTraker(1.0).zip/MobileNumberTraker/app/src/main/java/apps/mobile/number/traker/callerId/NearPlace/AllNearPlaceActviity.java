package apps.mobile.number.traker.callerId.NearPlace;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import apps.mobile.number.traker.callerId.NearPlace.fragment.NearByplacesFragment;
import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.databinding.ActivityAllNearPlaceBinding;

public class AllNearPlaceActviity extends AppCompatActivity {

    ActivityAllNearPlaceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAllNearPlaceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();
    }

    private void bind() {
        binding.ivback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        getFragmentManager().beginTransaction().replace(R.id.near_fragment_container, new NearByplacesFragment()).commit();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}