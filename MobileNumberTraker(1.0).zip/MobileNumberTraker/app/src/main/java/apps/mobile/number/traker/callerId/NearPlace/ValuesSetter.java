package apps.mobile.number.traker.callerId.NearPlace;

public class ValuesSetter {
    private int img;
    private String mapstring;
    private String name;

    public ValuesSetter(String str, String str2, int i) {
        this.img = i;
        this.name = str;
        this.mapstring = str2;
    }

    public String getMapstring() {
        return this.mapstring;
    }

    public void setMapstring(String str) {
        this.mapstring = str;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public int getImg() {
        return this.img;
    }

    public void setImg(int i) {
        this.img = i;
    }
}