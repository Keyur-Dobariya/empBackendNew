package apps.mobile.number.traker.callerId.NearPlace.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import apps.mobile.number.traker.callerId.NearPlace.ValuesSetter;
import apps.mobile.number.traker.callerId.R;

public class GridviewAdapter extends ArrayAdapter<ValuesSetter> {
    private ArrayList<ValuesSetter> arraylist;
    Context context;
    String intent_passing_value;
    private List<ValuesSetter> worldpopulationlist = null;

    Click_item item;
    ViewHolder viewHolder;
    View inflate;

    public interface Click_item {
        void click_item(int pos, String s1);
    }

    static class ViewHolder {
        private ImageView Img;
        RelativeLayout relGrid;
        private TextView txtname;

        ViewHolder() {
        }
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public GridviewAdapter(Context context, ArrayList<ValuesSetter> arrayList, Click_item item) {
        super(context, R.layout.custom_list);
        this.context = context;
        this.worldpopulationlist = arrayList;
        this.arraylist = new ArrayList();
        this.arraylist.addAll(this.worldpopulationlist);
        this.item = item;
    }


    public int getCount() {
        return this.worldpopulationlist.size();
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final ValuesSetter valuesSetter = this.worldpopulationlist.get(i);
        if (view == null) {
            viewHolder = new ViewHolder();
            inflate = layoutInflater.inflate(R.layout.custom_gridview, viewGroup, false);
            viewHolder.txtname = inflate.findViewById(R.id.txt1);
            viewHolder.Img = inflate.findViewById(R.id.grid_image);
            viewHolder.relGrid = inflate.findViewById(R.id.rel_grid);
            inflate.setTag(viewHolder);
        } else {
            inflate = view;
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.txtname.setText(valuesSetter.getName());
        viewHolder.Img.setImageResource(valuesSetter.getImg());
        viewHolder.relGrid.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                intent_passing_value = valuesSetter.getMapstring();
//                showmap(intent_passing_value);
                item.click_item(i, intent_passing_value);

            }
        });
        return inflate;
    }

    public List<ValuesSetter> filter(String str) {
        CharSequence toLowerCase = str.toLowerCase(Locale.getDefault());
        this.worldpopulationlist.clear();
        if (toLowerCase.length() == 0) {
            this.worldpopulationlist.addAll(this.arraylist);
            notifyDataSetChanged();
            return this.worldpopulationlist;
        }
        Iterator it = this.arraylist.iterator();
        while (it.hasNext()) {
            ValuesSetter valuesSetter = (ValuesSetter) it.next();
            if (valuesSetter.getName().toLowerCase(Locale.getDefault()).contains(toLowerCase)) {
                this.worldpopulationlist.add(valuesSetter);
            }
        }
        return this.worldpopulationlist;
    }


}