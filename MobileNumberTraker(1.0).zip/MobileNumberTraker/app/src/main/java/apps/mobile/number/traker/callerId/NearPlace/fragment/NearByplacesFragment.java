package apps.mobile.number.traker.callerId.NearPlace.fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.Toast;

import androidx.annotation.Nullable;


import java.util.ArrayList;

import apps.mobile.number.traker.callerId.NearPlace.ValuesSetter;
import apps.mobile.number.traker.callerId.NearPlace.adapter.GridviewAdapter;
import apps.mobile.number.traker.callerId.NearPlace.utils.ExpandableHeightGridView;
import apps.mobile.number.traker.callerId.R;

public class NearByplacesFragment extends Fragment implements GridviewAdapter.Click_item {
    public static SearchView sv;
    ExpandableHeightGridView gv;
    int[] images = new int[]{R.drawable.airport, R.drawable.art_gallery, R.drawable.atm, R.drawable.bakers,
            R.drawable.bank, R.drawable.saloon,
            R.drawable.book_store, R.drawable.cafe, R.drawable.clothing_store, R.drawable.curch,
            R.drawable.dentist, R.drawable.doctor, R.drawable.electician, R.drawable.embassy,
            R.drawable.fire_station, R.drawable.furniture_shop, R.drawable.petrol_station,
            R.drawable.gym, R.drawable.hospital, R.drawable.hotel, R.drawable.jewellary,
            R.drawable.lodging, R.drawable.medical_store, R.drawable.mosque, R.drawable.museam,
            R.drawable.painter, R.drawable.park, R.drawable.pet_house, R.drawable.police_station,
            R.drawable.post_office, R.drawable.public_toilet, R.drawable.schools, R.drawable.service_station,
            R.drawable.shoe_store, R.drawable.shopping_mall, R.drawable.subway_station, R.drawable.university,
            R.drawable.zoo};
    int[] images_values = new int[]{R.drawable.searchnew};
    String[] map_values = new String[0];
    String[] mapstr = new String[]{"airport", "art gallery", "atm", "bakery", "bank", "beauty salon", "book store", "cafe", "clothing store", "church", "dentist", "doctor", "electrician", "embassy", "fire station", "furniture store", "gas station", "gym", "hospital", "hotel", "jewelry store", "lodging", "medical store", "mosque", "museum", "painter", "parks", "pet store", "police", "post office", "toilet", "school", "service station", "shoe store", "shopping mall", "subway station", "university", "zoo"};
    String[] names = new String[]{"Airport", "Art Gallery", "Atm", "Bakery", "Bank", "Beauty Salon", "Book Store", "Cafe", "Clothing Store", "Church", "Dentist", "Doctor", "Electrician", "Embassy", "Fire Station", "Furniture Store", "Gas Station", "Gym", "Hospital", "Hotel", "Jewelry Store", "Lodging", "Medical Store", "Mosque", "Museum", "Painter", "Parks", "Pet Store", "Police", "Post Office", "Public Toilet", "School", "Service Station", "Shoes Store", "Shopping Mall", "Subway Station", "University", "Zoo"};
    String[] search_values = new String[]{"Search"};
    View view;

    Uri gmmIntentUri;
    Intent mapIntent;
    String MarketLink = "market://details?id=";
    public String string;

    public NearByplacesFragment() {
    }

    private ArrayList<ValuesSetter> getListPlayers() {
        ArrayList<ValuesSetter> arrayList = new ArrayList();
        for (int i = 0; i < this.names.length; i++) {
            arrayList.add(new ValuesSetter(this.names[i], this.mapstr[i], this.images[i]));
        }
        return arrayList;
    }

    @Nullable
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        view = layoutInflater.inflate(R.layout.fragment_near_byplaces, null);
        gv = (ExpandableHeightGridView) view.findViewById(R.id.grid_view_phone_select);
        gv.setExpanded(true);
        sv = (SearchView) this.view.findViewById(R.id.searchView);
        sv.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                NearByplacesFragment.sv.setIconified(false);
            }
        });
        final GridviewAdapter gridviewAdapter = new GridviewAdapter(getActivity(), getListPlayers(), this);
        gv.setAdapter(gridviewAdapter);
        sv.setOnQueryTextListener(new OnQueryTextListener() {
            public boolean onQueryTextSubmit(String str) {
                return false;
            }

            public boolean onQueryTextChange(String str) {
                if (gridviewAdapter.filter(str).isEmpty()) {
                    String[] strArr = new String[]{str.toString()};
                    map_values = strArr;
                    gv.setAdapter(new GridviewAdapter(getActivity(), searchgetListPlayers(), NearByplacesFragment.this));
                } else {
                    gv.setAdapter(gridviewAdapter);
                    gridviewAdapter.filter(str);
                }
                gridviewAdapter.filter(str);
                return true;
            }
        });
        return this.view;
    }

    private ArrayList<ValuesSetter> searchgetListPlayers() {
        ArrayList<ValuesSetter> arrayList = new ArrayList();
        for (int i = 0; i < this.search_values.length; i++) {
            arrayList.add(new ValuesSetter(this.search_values[i], this.map_values[i], this.images_values[i]));
        }
        return arrayList;
    }

    @SuppressLint("WrongConstant")
    public void showmap(String str) {
        try {
            sv.setQuery("", false);
            sv.clearFocus();
            sv.onActionViewCollapsed();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("geo:0,0?q=");
            stringBuilder.append(str);
            this.gmmIntentUri = Uri.parse(stringBuilder.toString());
            this.mapIntent = new Intent("android.intent.action.VIEW", this.gmmIntentUri);
            this.mapIntent.setPackage("com.google.android.apps.maps");
            getActivity().startActivity(this.mapIntent);
        } catch (Exception unused) {
            Toast.makeText(getActivity(), "Install this First", 1).show();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(this.MarketLink);
            stringBuilder2.append("com.google.android.apps.maps");
            getActivity().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringBuilder2.toString())));
        }
    }
    @Override
    public void click_item(int pos, String s1) {
        string = s1;
        showmap(s1);
    }
}