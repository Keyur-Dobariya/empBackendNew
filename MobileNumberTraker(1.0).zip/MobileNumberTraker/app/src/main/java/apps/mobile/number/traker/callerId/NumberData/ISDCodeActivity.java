package apps.mobile.number.traker.callerId.NumberData;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import apps.mobile.number.traker.callerId.Activity.Constant;
import apps.mobile.number.traker.callerId.NumberData.Utilss.DatabaseHelper;
import apps.mobile.number.traker.callerId.NumberData.model.AppConst;
import apps.mobile.number.traker.callerId.NumberData.model.Contact;
import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivityIsdcodeBinding;

public class ISDCodeActivity extends AppCompatActivity implements View.OnClickListener {
    String searchtext;
    DatabaseHelper dbHelper;
    String[] country;
    String[] codes;
    Boolean isradiocountry = true;
    List<Contact> listisd;
    String copytext;

    ActivityIsdcodeBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityIsdcodeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

        //        ***********big native******************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(ISDCodeActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        dbHelper = new DatabaseHelper(ISDCodeActivity.this);
        dbHelper.openDataBase();
        binding.ivback.setOnClickListener(this);
        binding.btnsearch.setOnClickListener(this);
        binding.btncopy.setOnClickListener(this);
        binding.btnshare.setOnClickListener(this);

        dbHelper = new DatabaseHelper(ISDCodeActivity.this);
        country = dbHelper.getCountryVal();
        binding.edtsearch.setAdapter(new ArrayAdapter<>(ISDCodeActivity.this, R.layout.autocomplete_item, this.country));

        binding.radiocoutry.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isradiocountry = true;
                    binding.radioISD.setChecked(false);
                    binding.radiocoutry.setChecked(true);
                    country = null;
                    country = dbHelper.getCountryVal();
                    binding.edtsearch.setAdapter(new ArrayAdapter<>(ISDCodeActivity.this, R.layout.autocomplete_item, country));
                    binding.edtsearch.setText("");
                    binding.edtsearch.setHint("Enter Country Name");
                    binding.edtsearch.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
                    binding.lytdetails.setVisibility(View.GONE);
                }
            }
        });
        binding.radioISD.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isradiocountry = false;
                    binding.radioISD.setChecked(true);
                    binding.radiocoutry.setChecked(false);
                    codes = null;
                    dbHelper = new DatabaseHelper(ISDCodeActivity.this);
                    codes = dbHelper.getIsdCodes();
                    binding.edtsearch.setAdapter(new ArrayAdapter<>(ISDCodeActivity.this, R.layout.autocomplete_item, codes));
                    binding.edtsearch.setText("");
                    binding.edtsearch.setHint("Enter ISD Code");
                    binding.edtsearch.setInputType(InputType.TYPE_CLASS_NUMBER);
                    binding.lytdetails.setVisibility(View.GONE);
                }
            }
        });
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivback:
                finish();
                break;
            case R.id.btnsearch:
                searchtext = binding.edtsearch.getText().toString().trim();
                if (TextUtils.isEmpty(searchtext)) {
                    Toast.makeText(ISDCodeActivity.this, "Enter Find By City/STD Code", Toast.LENGTH_SHORT).show();
                } else {
                    if (isradiocountry) {
                        new SearchCountryCode().execute();
                    } else {
                        new SearchCodeCountry().execute();
                    }
                }
                AppConst.hideSoftKeyBoard(ISDCodeActivity.this);
                break;
            case R.id.btncopy:
                copytext = "Mobile Number Tracker App Download Click here: " + Constant.App_link + "\nCountry Name : " + binding.tvcountry.getText().toString().trim() + "\nISD Code : " + binding.tvisd.getText().toString().trim();
                int sdk = android.os.Build.VERSION.SDK_INT;
                if (sdk < android.os.Build.VERSION_CODES.HONEYCOMB) {
                    android.text.ClipboardManager clipboard = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboard.setText("" + copytext);
                } else {
                    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    android.content.ClipData clip = android.content.ClipData.newPlainText("MobileNumberTracker", "" + copytext);
                    clipboard.setPrimaryClip(clip);
                }
                Toast.makeText(ISDCodeActivity.this, "ISD Code Details Copy", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnshare:
                copytext = "Mobile Number Tracker App Download Click here: " + Constant.App_link + "\nCountry Name : " + binding.tvcountry.getText().toString().trim() + "\nISD Code : " + binding.tvisd.getText().toString().trim();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/*");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, copytext);
                startActivity(Intent.createChooser(sharingIntent, "Share Details using"));
                break;
        }
    }

    private class SearchCountryCode extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            binding.progress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                listisd = new ArrayList<>();
                listisd.clear();
                listisd = dbHelper.getISDCODEVal(searchtext);

                if (listisd.size() == 0) {
                    binding.lytdetails.setVisibility(View.INVISIBLE);
                    binding.lytempty.setVisibility(View.VISIBLE);
                } else {
                    binding.lytempty.setVisibility(View.GONE);
                    for (Contact ci : listisd) {
                        binding.tvcountry.setText(binding.edtsearch.getText().toString().trim());
                        binding.tvisd.setText("" + ci.getIconVal());

                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            binding.progress.setVisibility(View.GONE);
            binding.lytdetails.setVisibility(View.VISIBLE);
        }
    }

    private class SearchCodeCountry extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            binding.progress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                listisd = new ArrayList<>();
                listisd.clear();
                listisd = dbHelper.getCountry(searchtext);
                if (listisd.size() == 0) {
                    binding.lytdetails.setVisibility(View.GONE);
                    binding.lytempty.setVisibility(View.VISIBLE);
                } else {
                    binding.lytempty.setVisibility(View.GONE);
                    for (Contact ci : listisd) {
                        binding.tvisd.setText(searchtext);
                        binding.tvcountry.setText(ci.getStatename());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            binding.progress.setVisibility(View.GONE);
            binding.lytdetails.setVisibility(View.VISIBLE);
        }
    }

}