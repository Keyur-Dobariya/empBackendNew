package apps.mobile.number.traker.callerId.NumberData;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

import apps.mobile.number.traker.callerId.NumberData.Utilss.DatabaseHelper;
import apps.mobile.number.traker.callerId.NumberData.model.AppConst;
import apps.mobile.number.traker.callerId.NumberData.model.Contact;
import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivityNumSearchBinding;

public class Num_SearchActivity extends AppCompatActivity implements View.OnClickListener {
    String lat, lng, area;
    String countrycode, number;

    DatabaseHelper dbHelper;
    List<Contact> contacts;

    ActivityNumSearchBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNumSearchBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

//        ***********big native******************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Num_SearchActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        dbHelper = new DatabaseHelper(Num_SearchActivity.this);
        dbHelper.openDataBase();
        binding.ivback.setOnClickListener(this);
        binding.btnsearch.setOnClickListener(this);
        binding.btnmap.setOnClickListener(this);
        binding.btncall.setOnClickListener(this);
        binding.btnmessage.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivback:
                finish();
                break;
            case R.id.btnsearch:
                countrycode = binding.edtcountrycode.getSelectedCountryCode();
                number = binding.edtsearchnumber.getText().toString().trim();
                if (TextUtils.isEmpty(number)) {
                    Toast.makeText(Num_SearchActivity.this, "Please enter search number", Toast.LENGTH_SHORT).show();
                    binding.edtsearchnumber.requestFocus();
                } else {
                    new SearchNumber().execute();
                }
                AppConst.hideSoftKeyBoard(Num_SearchActivity.this);
                break;
            case R.id.btnmap:
                InterstitialAds.showAd(Num_SearchActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        Intent intent = new Intent(Num_SearchActivity.this, NumberMapActivity.class);
                        intent.putExtra("lat", "" + lat);
                        intent.putExtra("lng", "" + lng);
                        intent.putExtra("area", "" + area);
                        startActivity(intent);
                    }
                    @Override
                    public void onAdImpression() {
                    }
                });
                break;
            case R.id.btncall:
                callPhone();
                break;
            case R.id.btnmessage:
                callMessage();
                break;
        }
    }

    private class SearchNumber extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            binding.progress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String first2 = number.substring(0, 2);
                        contacts = dbHelper.getContactVal(first2);
                        if (contacts.size() == 0) {
                            String first3 = number.substring(0, 3);
                            contacts = dbHelper.getContactVal(first3);
                        }
                        if (contacts.size() == 0) {
                            try {
                                String first4 = number.substring(0, 4);
                                contacts = dbHelper.getContactVal(first4);
                            } catch (Exception e) {

                            }

                        }
                        if (contacts.size() == 0) {
                            binding.lytdetails.setVisibility(View.GONE);
                            binding.lytempty.setVisibility(View.VISIBLE);
                        } else {
                            binding.lytempty.setVisibility(View.GONE);
                            for (Contact ci : contacts) {
                                binding.tvnumber.setText(number);
                                binding.tvcarrier.setText(ci.getOperatorname());
                                binding.tvlocation.setText(ci.getStatename());
                                binding.tvvalid.setText("True");
                                lat = ci.getLat();
                                lng = ci.getLang();
                                area = ci.getStatename();
                            }
                            String currentDateTimeString = DateFormat.getDateTimeInstance().format(new Date());
                            String s1, s2, s3;
                            s1 = binding.tvnumber.getText().toString().trim();
                            s2 = binding.tvcarrier.getText().toString().trim();
                            s3 = binding.tvlocation.getText().toString().trim();
                            dbHelper.addSearchHistory(s1, s2, s3, currentDateTimeString);
                        }

                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            binding.progress.setVisibility(View.GONE);
            binding.lytdetails.setVisibility(View.VISIBLE);
        }
    }

    public void callPhone() {
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + number));
        startActivity(intent);
    }

    //--- call message
    public void callMessage() {
        Intent sharingIntent = new Intent("android.intent.action.SENDTO");
        sharingIntent.setType("text/plain");
        sharingIntent.setData(Uri.parse("sms:" + number));
        startActivity(Intent.createChooser(sharingIntent, "Complete action using"));
    }

}