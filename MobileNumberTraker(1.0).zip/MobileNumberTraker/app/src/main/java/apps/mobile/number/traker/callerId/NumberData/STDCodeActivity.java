package apps.mobile.number.traker.callerId.NumberData;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import apps.mobile.number.traker.callerId.Activity.Constant;
import apps.mobile.number.traker.callerId.NumberData.Utilss.DatabaseHelper;
import apps.mobile.number.traker.callerId.NumberData.model.AppConst;
import apps.mobile.number.traker.callerId.NumberData.model.Contact;
import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivityStdcodeBinding;

public class STDCodeActivity extends AppCompatActivity implements View.OnClickListener {
    String searchtext;
    DatabaseHelper dbHelper;
    String[] cities;
    String[] codes;
    Boolean isradiocity = true;
    List<Contact> liststd;
    List<Contact> listcity;

    String copytext;

    ActivityStdcodeBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStdcodeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        bind();

        //        ***********big native******************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(STDCodeActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        dbHelper = new DatabaseHelper(STDCodeActivity.this);
        dbHelper.openDataBase();
        binding.ivback.setOnClickListener(this);
        binding.btnsearch.setOnClickListener(this);
        binding.btncopy.setOnClickListener(this);
        binding.btnshare.setOnClickListener(this);

        dbHelper = new DatabaseHelper(STDCodeActivity.this);
        cities = dbHelper.getCityVal();
        binding.editsearch.setAdapter(new ArrayAdapter<>(STDCodeActivity.this, R.layout.autocomplete_item, this.cities));
        binding.radiocity.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isradiocity = true;
                    binding.radioSTD.setChecked(false);
                    binding.radiocity.setChecked(true);
                    cities = null;
                    cities = dbHelper.getCityVal();
                    binding.editsearch.setAdapter(new ArrayAdapter<>(STDCodeActivity.this, R.layout.autocomplete_item, cities));
                    binding.editsearch.setText("");
                    binding.editsearch.setHint("Enter City Name");
                    binding.editsearch.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
                    binding.lytdetails.setVisibility(View.GONE);
                }
            }
        });
        binding.radioSTD.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isradiocity = false;
                    binding.radioSTD.setChecked(true);
                    binding.radiocity.setChecked(false);
                    codes = null;
                    dbHelper = new DatabaseHelper(STDCodeActivity.this);
                    codes = dbHelper.getStdCodes();
                    binding.editsearch.setAdapter(new ArrayAdapter<>(STDCodeActivity.this, R.layout.autocomplete_item, codes));
                    binding.editsearch.setText("");
                    binding.editsearch.setHint("Enter STD Code");
                    binding.editsearch.setInputType(InputType.TYPE_CLASS_NUMBER);
                    binding.lytdetails.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ivback:
                finish();
                break;
            case R.id.btnsearch:
                searchtext = binding.editsearch.getText().toString().trim();
                if (TextUtils.isEmpty(searchtext)) {
                    Toast.makeText(STDCodeActivity.this, "Enter Find By City/STD Code", Toast.LENGTH_SHORT).show();
                } else {
                    if (isradiocity) {
                        new SearchCityCode().execute();
                    } else {
                        new SearchCodeCity().execute();
                    }
                }
                AppConst.hideSoftKeyBoard(STDCodeActivity.this);
                break;
            case R.id.btncopy:
                copytext = "Mobile Number Tracker App Download Click here: " + Constant.App_link + "\nSTD Code : " + binding.tvstd.getText().toString().trim() + "\nCity Name : " + binding.tvcity.getText().toString().trim();
                int sdk = android.os.Build.VERSION.SDK_INT;
                if (sdk < android.os.Build.VERSION_CODES.HONEYCOMB) {
                    android.text.ClipboardManager clipboard = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboard.setText("" + copytext);
                } else {
                    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    android.content.ClipData clip = android.content.ClipData.newPlainText("MobileNumberTracker", "" + copytext);
                    clipboard.setPrimaryClip(clip);
                }
                Toast.makeText(STDCodeActivity.this, "STD Code Details Copy", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnshare:
                copytext = "Mobile Number Tracker App Download Click here: " + Constant.App_link + "\nSTD Code : " + binding.tvstd.getText().toString().trim() + "\nCity Name : " + binding.tvcity.getText().toString().trim();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/*");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, copytext);
                startActivity(Intent.createChooser(sharingIntent, "Share Details using"));
                break;
        }
    }

    private class SearchCityCode extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            binding.progress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        liststd = new ArrayList<>();
                        liststd.clear();
                        liststd = dbHelper.getSTDCODEVal(searchtext);
                        if (liststd.size() == 0) {
                            binding.lytdetails.setVisibility(View.INVISIBLE);
                            binding.lytempty.setVisibility(View.VISIBLE);
                        } else {
                            binding.lytempty.setVisibility(View.GONE);
                            for (Contact ci : liststd) {
                                binding.tvstd.setText("0" + ci.getStdcode());
                                binding.tvcity.setText(searchtext);
                                binding.tvcountry.setText("India");
                            }
                        }
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            binding.progress.setVisibility(View.GONE);
            binding.lytdetails.setVisibility(View.VISIBLE);
        }
    }

    private class SearchCodeCity extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            binding.progress.setVisibility(View.VISIBLE);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                listcity = new ArrayList<>();
                listcity.clear();
                listcity = dbHelper.getCity(searchtext);

                if (listcity.size() == 0) {
                    binding.lytdetails.setVisibility(View.INVISIBLE);
                    binding.lytempty.setVisibility(View.VISIBLE);
                } else {
                    binding.lytempty.setVisibility(View.GONE);
                    for (Contact ci : listcity) {
                        binding.tvstd.setText(searchtext);
                        binding.tvcity.setText(ci.getStatename());
                        binding.tvcountry.setText("India");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            binding.progress.setVisibility(View.GONE);
            binding.lytdetails.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
