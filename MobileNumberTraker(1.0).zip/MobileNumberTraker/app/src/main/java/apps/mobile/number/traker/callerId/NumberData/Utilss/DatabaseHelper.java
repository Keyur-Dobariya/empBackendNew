package apps.mobile.number.traker.callerId.NumberData.Utilss;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import apps.mobile.number.traker.callerId.NumberData.model.Contact;
import apps.mobile.number.traker.callerId.NumberData.model.HistoryItem;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "mobilenumbertrackerdb.sqlite";
    private static final String DB_PATH_SUFFIX = "/databases/";
    static Context ctx;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        ctx = context;
    }

    public void CopyDataBaseFromAsset() throws IOException {
        InputStream myInput = ctx.getAssets().open(DATABASE_NAME);
        String outFileName = getDatabasePath();

        File f = new File(ctx.getApplicationInfo().dataDir + DB_PATH_SUFFIX);
        if (!f.exists())
            f.mkdir();

        OutputStream myOutput = new FileOutputStream(outFileName);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }
        // Close the streams
        myOutput.flush();
        myOutput.close();
        myInput.close();

    }

    private static String getDatabasePath() {
        return ctx.getApplicationInfo().dataDir + DB_PATH_SUFFIX
                + DATABASE_NAME;
    }

    public SQLiteDatabase openDataBase() throws SQLException {
        File dbFile = ctx.getDatabasePath(DATABASE_NAME);
        if (!dbFile.exists()) {
            try {
                CopyDataBaseFromAsset();
                System.out.println("Copying sucess from Assets folder");
            } catch (IOException e) {
                throw new RuntimeException("Error creating source database", e);
            }
        }
        return SQLiteDatabase.openDatabase(dbFile.getPath(), null, SQLiteDatabase.NO_LOCALIZED_COLLATORS | SQLiteDatabase.CREATE_IF_NECESSARY);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    //--- get ContactVal
    public List<Contact> getContactVal(String str) {
        List<Contact> arrayList = new ArrayList();
        try {
            Cursor rawQuery = getWritableDatabase().rawQuery("SELECT operatorname, statename,iconval,lat,lang FROM mobileNumberfinder WHERE mobilenumber = " + str, null);
            if (rawQuery.getCount() <= 0) {
                return arrayList;
            } else {
                if (rawQuery.moveToFirst()) {
                    do {
                        Contact contact = new Contact();
                        contact.setOperatorname(rawQuery.getString(0));
                        contact.setStatename(rawQuery.getString(1));
                        contact.setIconVal(Integer.parseInt(rawQuery.getString(2)));
                        contact.setLat(rawQuery.getString(3));
                        contact.setLang(rawQuery.getString(4));
                        arrayList.add(contact);
                    } while (rawQuery.moveToNext());
                }
            }
            return arrayList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    //--- get CityVal
    public String[] getCityVal() {
        int i = 0;
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT city FROM stdcodes", null);
        if (rawQuery.getCount() <= 0) {
            return new String[0];
        }
        String[] strArr = new String[rawQuery.getCount()];
        while (rawQuery.moveToNext()) {
            strArr[i] = rawQuery.getString(rawQuery.getColumnIndex("city"));
            i++;
        }
        return strArr;
    }

    //-- get STDVal
    public List<Contact> getSTDCODEVal(String str) {
        List<Contact> arrayList = new ArrayList();
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT stdcode FROM stdcodes WHERE city LIKE '" + str + "'", null);
        if (rawQuery.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setStdcode(rawQuery.getString(0));
                arrayList.add(contact);
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }

    //--- get STD Code
    public String[] getStdCodes() {
        int i = 0;
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT stdcode FROM stdcodes", null);
        if (rawQuery.getCount() <= 0) {
            return new String[0];
        }
        String[] strArr = new String[rawQuery.getCount()];
        while (rawQuery.moveToNext()) {
            strArr[i] = rawQuery.getString(rawQuery.getColumnIndex("stdcode"));
            i++;
        }
        return strArr;
    }

    //--- get City
    public List<Contact> getCity(String str) {
        List<Contact> arrayList = new ArrayList();
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT city FROM stdcodes WHERE stdcode =" + str, null);
        if (rawQuery.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setStatename(rawQuery.getString(0));
                arrayList.add(contact);
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }

    public String[] getCountryVal() {
        int i = 0;
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT country FROM isdcodes", null);
        if (rawQuery.getCount() <= 0) {
            return new String[0];
        }
        String[] strArr = new String[rawQuery.getCount()];
        while (rawQuery.moveToNext()) {
            strArr[i] = rawQuery.getString(rawQuery.getColumnIndex("country"));
            i++;
        }
        return strArr;
    }

    public List<Contact> getISDCODEVal(String str) {
        List<Contact> arrayList = new ArrayList();
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT isdcode FROM isdcodes WHERE country LIKE '" + str + "'", null);
        if (rawQuery.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setIconVal(Integer.parseInt(rawQuery.getString(0)));
                arrayList.add(contact);
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }

    public String[] getIsdCodes() {
        int i = 0;
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT isdcode FROM isdcodes", null);
        if (rawQuery.getCount() <= 0) {
            return new String[0];
        }
        String[] strArr = new String[rawQuery.getCount()];
        while (rawQuery.moveToNext()) {
            strArr[i] = rawQuery.getString(rawQuery.getColumnIndex("isdcode"));
            i++;
        }
        return strArr;
    }

    public List<Contact> getCountry(String str) {
        List<Contact> arrayList = new ArrayList();
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT country FROM isdcodes WHERE isdcode =" + str, null);
        if (rawQuery.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setStatename(rawQuery.getString(0));
                arrayList.add(contact);
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }


    public void addSearchHistory(String number, String operator, String location, String time) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("number", number);
        values.put("operator", operator);
        values.put("location", location);
        values.put("time", time);
        long id = db.insert("searchhistory", null, values);
        Log.e("---insertid",""+id);
        db.close();
        return;
    }

    public List<HistoryItem> getSearchHistory() {
        List<HistoryItem> arrayList = new ArrayList();
        Cursor rawQuery = getWritableDatabase().rawQuery("SELECT * FROM searchhistory", null);
        if (rawQuery.moveToFirst()) {
            do {
                HistoryItem hi = new HistoryItem();
                hi.setId(rawQuery.getString(0));
                hi.setNumber(rawQuery.getString(1));
                hi.setOperator(rawQuery.getString(2));
                hi.setLocation(rawQuery.getString(3));
                hi.setTime(rawQuery.getString(4));
                arrayList.add(hi);
            } while (rawQuery.moveToNext());
        }
        return arrayList;
    }
}


