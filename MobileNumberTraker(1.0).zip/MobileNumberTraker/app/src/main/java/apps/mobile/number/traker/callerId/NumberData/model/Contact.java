package apps.mobile.number.traker.callerId.NumberData.model;

public class Contact {
    public int iconval;
    String lang;
    String lat;
    String operatorname;
    String statename;
    String stdcode;

    public String getOperatorname() {
        return this.operatorname;
    }

    public void setOperatorname(String str) {
        this.operatorname = str;
    }

    public String getStatename() {
        return this.statename;
    }

    public void setStatename(String str) {
        this.statename = str;
    }

    public int getIconVal() {
        return this.iconval;
    }

    public void setIconVal(int i) {
        this.iconval = i;
    }

    public String getLat() {
        return this.lat;
    }

    public void setLat(String str) {
        this.lat = str;
    }

    public String getLang() {
        return this.lang;
    }

    public void setLang(String str) {
        this.lang = str;
    }

    public String getStdcode() {
        return stdcode;
    }

    public void setStdcode(String stdcode) {
        this.stdcode = stdcode;
    }
}
