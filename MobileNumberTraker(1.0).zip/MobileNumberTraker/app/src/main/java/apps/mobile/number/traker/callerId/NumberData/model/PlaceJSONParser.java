package apps.mobile.number.traker.callerId.NumberData.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PlaceJSONParser {
    public List<HashMap<String, String>> parse(JSONObject jSONObject) {
        JSONArray jSONArray;
        try {
            jSONArray = jSONObject.getJSONArray("results");
        } catch (JSONException e) {
            e.printStackTrace();
            jSONArray = null;
        }
        return getPlaces(jSONArray);
    }

    private List<HashMap<String, String>> getPlaces(JSONArray jSONArray) {
        int length = jSONArray.length();
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < length; i++) {
            try {
                arrayList.add(getPlace((JSONObject) jSONArray.get(i)));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return arrayList;
    }

    private HashMap<String, String> getPlace(JSONObject jSONObject) {
        String str = "lng";
        String str2 = "lat";
        String str3 = "location";
        String str4 = "geometry";
        String str5 = "name";
        String str6 = "vicinity";
        HashMap hashMap = new HashMap();
        try {
            Object obj = "-NA-";
            Object string = !jSONObject.isNull(str5) ? jSONObject.getString(str5) : obj;
            if (!jSONObject.isNull(str6)) {
                obj = jSONObject.getString(str6);
            }
            String string2 = jSONObject.getJSONObject(str4).getJSONObject(str3).getString(str2);
            String string3 = jSONObject.getJSONObject(str4).getJSONObject(str3).getString(str);
            hashMap.put("place_name", string);
            hashMap.put(str6, obj);
            hashMap.put(str2, string2);
            hashMap.put(str, string3);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return hashMap;
    }
}