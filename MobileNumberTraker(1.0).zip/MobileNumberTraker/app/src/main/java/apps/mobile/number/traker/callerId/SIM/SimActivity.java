package apps.mobile.number.traker.callerId.SIM;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.SIM.adapter.Detailadapter;
import apps.mobile.number.traker.callerId.SIM.modal.Simmodal;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.NativeAds;
import apps.mobile.number.traker.callerId.ads.nativee.SmallNativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivitySecondBinding;
import apps.mobile.number.traker.callerId.databinding.ActivitySimBinding;


public class SimActivity extends AppCompatActivity {
    String[] data = new String[8];
    private int position;

    ActivitySimBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivitySimBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        position = getIntent().getExtras().getInt("position");
        binding.back.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        setView();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(SimActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });

//        ********************big native********************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);
    }

    private void setView() {
        binding.tvfree.setText(((Simmodal) SimInformation.dataModels.get(this.position)).getName());
        binding.rcDetailList.setLayoutManager(new GridLayoutManager(this, 1));
        data = ((Simmodal) SimInformation.dataModels.get(this.position)).getDatamodels1().getTitles();
        binding.rcDetailList.setAdapter(new Detailadapter(this, this.data));
    }

}