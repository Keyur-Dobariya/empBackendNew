package apps.mobile.number.traker.callerId.SIM;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.SIM.adapter.ItemAdapter;
import apps.mobile.number.traker.callerId.SIM.modal.Simmodal;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;
import apps.mobile.number.traker.callerId.ads.nativee.SmallNativeAds;
import apps.mobile.number.traker.callerId.databinding.ActivitySimInformationBinding;
import apps.mobile.number.traker.callerId.databinding.ActivityStartBinding;

public class SimInformation extends AppCompatActivity {
    public static int abc;
    public static String[] arr = {"How To Recharge", "Main Balance Enquiry", "Message Balance Enquiry", "Net Balance Enquiry", "How to Know your number", "Customer care number"};
    public static ArrayList<Simmodal> dataModels;
    public static int[] images = {R.drawable.airtel, R.drawable.jioo, R.drawable.aircel, R.drawable.idea, R.drawable.vodafone, R.drawable.uninor, R.drawable.docomo, R.drawable.bsnl};
    public static String[] names = {"Airtel", "Jio", "Aircel", "Idea", "Vodafone", "Telenor/Uninor", "Tata Docomo", "Bsnl"};
    String[] n;
    String[] o;
    String[] p;
    String[] q = {"*140*(16 digits code)#", "*145# or *146#", "*142#", "*111*6# or *111*6*2#", "*777*0#", "198 or 9825098250"};
    String[] r;
    String[] t;
    String[] u;
    String[] v;

    ActivitySimInformationBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySimInformationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.icback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        dataModels = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            Simmodal simmodal = new Simmodal();
            simmodal.setName(names[i]);
            simmodal.setImage(images[i]);
            Simmodal simmodal2 = new Simmodal();
            if (i == 0) {
                abc = 0;
                simmodal2.setTitles(this.n);
            } else if (i == 1) {
                abc = 1;
                simmodal2.setTitles(this.u);
            } else if (i == 2) {
                abc = 2;
                simmodal2.setTitles(this.o);
            } else if (i == 3) {
                abc = 3;
                simmodal2.setTitles(this.p);
            } else if (i == 4) {
                abc = 4;
                simmodal2.setTitles(this.q);
            } else if (i == 5) {
                abc = 5;
                simmodal2.setTitles(this.r);
            } else if (i == 6) {
                abc = 6;
                simmodal2.setTitles(this.t);
            } else if (i == 7) {
                abc = 7;
                simmodal2.setTitles(this.v);
            } else if (i == 8) {
                abc = 8;
                simmodal2.setTitles(this.v);
            }
            simmodal.setDatamodels1(simmodal2);
            dataModels.add(simmodal);
            setView();
        }

        //******************samll native********************
        new SmallNativeAds(screenName).showAd(this, binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(SimInformation.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });

    }

    private void setView() {
        binding.myrecyclerview.setLayoutManager(new GridLayoutManager(this, 1));
        binding.myrecyclerview.setAdapter(new ItemAdapter(this, dataModels));
    }

    public SimInformation() {
        String str = "*123#";
        String str2 = "121 or 198";
        this.n = new String[]{"*120*(16 digits code)#", str, "*555#", "*123*10#/*123*11#", "*121*9#", str2};
        String str3 = "*1#";
        this.u = new String[]{"*123*(16 digits code)#", "*333#", "*112# then press 3", "*333# then press 2", str3, "1800 889 9999"};
        String str4 = "*124*(16 digits code)#";
        String str5 = "*125#";
        String str6 = "*123*1#";
        this.o = new String[]{str4, str5, "*111*5#and*111*12#", str6, str3, str2};
        String str7 = "*111#";
        this.p = new String[]{str4, str7, "*167*3#", str5, str3, "12345"};
        String str8 = "*222*2#";
        this.r = new String[]{"*222*3*(16 digits code)#", str8, str8, str, str3, "121 or 9059090590"};
        this.t = new String[]{"*135*2*(16 digits code)#", str7, "*111*1#", str6, "*580#", "121"};
        this.v = new String[]{"*124*2*(16 digits code)#", str, "*123*10# ", "*124#", str3, "1503 or 1800-345-1500"};

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
