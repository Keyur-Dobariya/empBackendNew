package apps.mobile.number.traker.callerId.SIM.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.SIM.SimInformation;


public class Detailadapter extends Adapter<Detailadapter.MyViewHolder> {
    String[] a = new String[8];
    Activity activity;
    private LayoutInflater inflater;

    class MyViewHolder extends ViewHolder {
        LinearLayout layoutMain;
        private final TextView txtTitle;
        private final TextView txtdesc;

        public MyViewHolder(Detailadapter detailadapter, Detailadapter detailadapter2, View view) {
            super(view);
            layoutMain = (LinearLayout) view.findViewById(R.id.layoutMain);
            txtTitle = (TextView) view.findViewById(R.id.txtTitle);
            txtdesc = (TextView) view.findViewById(R.id.txtdesc);
        }
    }

    public Detailadapter(Activity activity, String[] strArr) {
        this.activity = activity;
        this.inflater = LayoutInflater.from(activity);
        this.a = strArr;
    }

    public int getItemCount() {
        return this.a.length;
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        myViewHolder.txtTitle.setText(SimInformation.arr[i]);
        myViewHolder.txtdesc.setText(this.a[i]);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(this, this, this.inflater.inflate(R.layout.item2, viewGroup, false));
    }
}