package apps.mobile.number.traker.callerId.SIM.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;


import java.util.ArrayList;
import java.util.List;

import apps.mobile.number.traker.callerId.R;
import apps.mobile.number.traker.callerId.SIM.SimActivity;
import apps.mobile.number.traker.callerId.SIM.modal.Simmodal;
import apps.mobile.number.traker.callerId.ads.interfaces.OnInterstitialAdResponse;
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds;

public class ItemAdapter extends Adapter<ItemAdapter.MyViewHolder> {
    private Activity activity;
    List<Simmodal> data = new ArrayList();
    private LayoutInflater inflater;

    class MyViewHolder extends ViewHolder {
        private final ImageView bank_image_logo;
        private final LinearLayout layout_main;
        private final TextView text_view_name;

        public MyViewHolder(View view) {
            super(view);
            this.layout_main = (LinearLayout) view.findViewById(R.id.layout_main);
            this.bank_image_logo = (ImageView) view.findViewById(R.id.bank_image_logo);
            this.text_view_name = (TextView) view.findViewById(R.id.text_view_name);
        }
    }

    public ItemAdapter(Activity activity, List<Simmodal> list) {
        this.activity = activity;
        this.inflater = LayoutInflater.from(activity);
        this.data = list;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(this.inflater.inflate(R.layout.simitem, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, final int i) {
        myViewHolder.text_view_name.setText(((Simmodal) this.data.get(i)).getName());
        myViewHolder.bank_image_logo.setImageResource(((Simmodal) this.data.get(i)).getImage());
        myViewHolder.layout_main.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                InterstitialAds.showAd(activity, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        Intent intent = new Intent(ItemAdapter.this.activity, SimActivity.class);
                        intent.putExtra("position", i);
                        ItemAdapter.this.activity.startActivity(intent);
                    }
                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public int getItemCount() {
        return this.data.size();
    }
}