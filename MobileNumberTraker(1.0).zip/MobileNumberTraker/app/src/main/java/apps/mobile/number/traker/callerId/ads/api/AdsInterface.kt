package apps.mobile.number.traker.callerId.ads.api

import apps.mobile.number.traker.callerId.ads.model.FirstData
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface AdsInterface {

    @GET("{packageName}.json")
    fun getFirstDataCall(@Path("packageName") packageName: String): Call<FirstData>

    @GET("more_apps.json")
    fun getMoreApps(): Call<FirstData>
}