package apps.mobile.number.traker.callerId.ads.commons

import android.app.Activity
import android.app.Application
import android.content.Context
import apps.mobile.number.traker.callerId.ads.api.AdsClient
import apps.mobile.number.traker.callerId.ads.app.MainApplicationClass
import apps.mobile.number.traker.callerId.ads.interfaces.OnFirstData
import apps.mobile.number.traker.callerId.ads.interstitial.InterstitialAds
import apps.mobile.number.traker.callerId.ads.model.FirstData
import apps.mobile.number.traker.callerId.ads.nativee.PreloadNativeAds
import apps.mobile.number.traker.callerId.ads.nativee.PreloadSmallNativeAds
import apps.mobile.number.traker.callerId.ads.reward.RewardInterstitialAds
import apps.mobile.number.traker.callerId.ads.reward.RewardVideoAds
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object AdsManager {
    @JvmStatic
    fun getFirstData(
        application: Application, context: Context, activity: Activity, onFirstData: OnFirstData?
    ) {
        AdsClient.getClient().getFirstDataCall(context.packageName.replace(".", "_").plus("3"))
            .enqueue(object : Callback<FirstData> {
                override fun onResponse(call: Call<FirstData>, response: Response<FirstData>) {
                    if (response.body() != null) {
                        val appData = AdsUtils.decrypt(response.body()!!.data)
                        AdsUtils.saveAdPref(context, appData!!)
                        AdsUtils.initNextAds(context)
                        initAppOpenAd(context, application, activity, onFirstData)
                        RewardVideoAds.load(context)
                        RewardInterstitialAds.load(context)
                        PreloadNativeAds.loadAd(context)
                        PreloadSmallNativeAds.loadAd(context)
                    } else {
                        onFirstData?.onFailed()
                    }
                }

                override fun onFailure(call: Call<FirstData>, t: Throwable) {
                    onFirstData?.onFailed()
                }
            })
        AdsUtils.getMoreApps(context)
    }

    private fun initAppOpenAd(
        context: Context, application: Application, activity: Activity, onFirstData: OnFirstData?
    ) {
        val mainApplicationClass = application as? MainApplicationClass
        if (mainApplicationClass == null) {
            handler(4000) { onFirstData?.onSuccess() }
        } else if (AdsUtils.isAppOpenEnabled(context)) {
            if (AdsUtils.isSplashAppOpenEnabled(context)) {
                mainApplicationClass.initAppOpenManager(activity, object : MainApplicationClass.OnSplashAd {
                    override fun onAdClosed(isFailed: Boolean) {
                        mainApplicationClass.onSplashAd = null
                        if (isFailed) {
                            AdsUtils.ignoreIntSkip(context)
                        }
                        InterstitialAds.loadAd(context)
                        onFirstData?.onSuccess()
                    }
                })
            } else {
                mainApplicationClass.initAppOpenManager()
            }
        } else {
            handler(4000) { onFirstData?.onSuccess() }
        }
    }

    @JvmStatic
    fun release(application: Application) {
        AdsUtils.reset()
        (application as? MainApplicationClass)?.release()
        InterstitialAds.release()
        PreloadNativeAds.release()
        PreloadSmallNativeAds.release()
        RewardInterstitialAds.release()
        RewardVideoAds.release()
    }
}