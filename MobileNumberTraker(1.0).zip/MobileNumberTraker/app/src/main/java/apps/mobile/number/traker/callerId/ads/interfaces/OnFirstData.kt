package apps.mobile.number.traker.callerId.ads.interfaces

interface OnFirstData {
    fun onSuccess()
    fun onFailed()
}