package apps.mobile.number.traker.callerId.ads.interfaces

interface OnInterstitialAdResponse {
    fun onAdClosed()
    fun onAdImpression()
}