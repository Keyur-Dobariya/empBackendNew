package apps.mobile.number.traker.callerId.ads.interfaces

interface OnRewardAdResponse {
    fun onRewardEarned()
    fun onAdImpression()
    fun onAdCancelled()
    fun onAdFailed()
}