package apps.mobile.number.traker.callerId.ads.model

import com.google.gson.annotations.SerializedName

data class FirstData(@JvmField @field:SerializedName("data") val data: String)
