package com.hd.video.downloader.play.video.BWhatsapp.fragment;

import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.view.PointerIconCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.hd.video.downloader.play.video.NewWp.Ads_constant;
import com.hd.video.downloader.play.video.NewWp.l.a.a;
import com.hd.video.downloader.play.video.NewWp.l.a.c;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BWhatsappActivty extends AppCompatActivity {
    public static ArrayList<Uri> statusObjectsList = new ArrayList<>();
    public static String statuspath;
    LinearLayout home;
    ImageView home_ic;
    TextView home_text;
    ImageView stu_ic;
    TextView stu_txt;
    LinearLayout stus;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    ImageView wa_ic;
    LinearLayout wa_tools;
    TextView wa_txt;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_bwhatsapps);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.ivOpenWhatsapp).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                final Dialog dialog = new Dialog(BWhatsappActivty.this);
                dialog.setContentView(R.layout.redirect_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.show();
                dialog.setCancelable(true);
                ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                        try {
                            Intent intent = new Intent("android.intent.action.VIEW");
                            intent.setData(Uri.parse("android-app://".concat("com.whatsapp.w4b")));
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(BWhatsappActivty.this, "App not found", 0).show();
                        }
                    }
                });
            }
        });
        home_ic = (ImageView) findViewById(R.id.homeic);
        wa_ic = (ImageView) findViewById(R.id.waic);
        home_text = (TextView) findViewById(R.id.hometext);
        wa_txt = (TextView) findViewById(R.id.watxt);
        stu_ic = (ImageView) findViewById(R.id.stuic);
        stu_txt = (TextView) findViewById(R.id.stutxt);
        stu_txt = (TextView) findViewById(R.id.stutxt);
        home = (LinearLayout) findViewById(R.id.home);
        wa_tools = (LinearLayout) findViewById(R.id.watools);
        stus = (LinearLayout) findViewById(R.id.stus);
        home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                viewPager.setCurrentItem(0, true);
            }
        });
        wa_tools.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                viewPager.setCurrentItem(1, true);
            }
        });
        stus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                viewPager.setCurrentItem(2, true);
            }
        });
        statusObjectsList.clear();
        statuspath = "Whatsapp";
        tabLayout = (TabLayout) findViewById(R.id.tablayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tabLayout.addTab(tabLayout.newTab().setText("Image"));
        tabLayout.addTab(tabLayout.newTab().setText("Video"));
        tabLayout.addTab(tabLayout.newTab().setText("Saved"));
        this.tabLayout.setTabGravity(0);
        if (Build.VERSION.SDK_INT < 30) {
            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp/Media/.Statuses/");
            if (!file.exists()) {
                file.mkdirs();
            }
            File[] listFiles = file.listFiles();
            if (listFiles != null) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                for (int i = 0; i < listFiles.length; i++) {
                    if (!listFiles[i].getName().equals(".nomedia")) {
                        statusObjectsList.add(Uri.fromFile(listFiles[i]));
                    }
                    Log.d("PRIYANSU", "size: " + statusObjectsList.size());
                }
            }
            this.viewPager.setAdapter(new TabLayoutAdapter(this, getSupportFragmentManager(), this.tabLayout.getTabCount()));
        } else if (Ads_constant.bwget_Setpermissin(this).equalsIgnoreCase("true")) {
            Uri parse = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia/document/primary%3AAndroid%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp%20Business%2FMedia%2F.Statuses");
            if (Build.VERSION.SDK_INT >= 21) {
                getDataForAndroid11OnlyStatus(parse);
            }
        } else {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            dialog.setCancelable(false);
            dialog.setContentView(R.layout.dialog_permisson);
            ((TextView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    dialog.dismiss();
                    finish();
                }
            });
            ((AppCompatButton) dialog.findViewById(R.id.btn_permissio)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Intent intent;
                    dialog.dismiss();
                    try {
                        if (Build.VERSION.SDK_INT >= 29) {
                            int i = Build.VERSION.SDK_INT;
                            StorageManager storageManager = (StorageManager) getSystemService("storage");
                            StringBuilder sb = new StringBuilder();
                            sb.append(Environment.getExternalStorageDirectory());
                            sb.append(File.separator);
                            sb.append("Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses");
                            String str = new File(sb.toString()).isDirectory() ? "Android%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp%20Business%2FMedia%2F.Statuses" : "WhatsApp%2FMedia%2F.Statuses";
                            if (i >= 29) {
                                intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                                str = intent.getParcelableExtra("android.provider.extra.INITIAL_URI").toString().replace("/root/", "/document/") + "%3A" + str;
                            } else {
                                intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                            }
                            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(str));
                            intent.addFlags(2);
                            intent.addFlags(1);
                            intent.addFlags(128);
                            intent.addFlags(64);
                            try {
                                startActivityForResult(intent, PointerIconCompat.TYPE_COPY);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (Exception unused) {
                        Toast.makeText(BWhatsappActivty.this, "can't find an app to select media, please active your 'Files' app and/or update your phone Google play services", 1).show();
                    }
                }
            });
            dialog.show();
        }
        this.viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(this.tabLayout));
        this.tabLayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }
        });
        setupViewPager(this.viewPager);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(BWhatsappActivty.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (Build.VERSION.SDK_INT > 29 && i != 1239 && i == 1011 && i2 == -1) {
            Uri data = intent.getData();
            if (data.toString().equals("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp%20Business%2FMedia%2F.Statuses")) {
                try {
                    getContentResolver().takePersistableUriPermission(data, 1);
                    if (new File("/storage/emulated/0/WhatsApp Business/Media/.Statuses/").exists()) {
                        Environment.getExternalStorageDirectory().getAbsolutePath();
                    }
                    Uri parse = Uri.parse(data.toString());
                    Cursor cursor = null;
                    c cVar = new c(null, this, DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse)));
                    ContentResolver contentResolver = cVar.f5a.getContentResolver();
                    Uri uri = cVar.b;
                    Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
                    ArrayList arrayList = new ArrayList();
                    try {
                        cursor = contentResolver.query(buildChildDocumentsUriUsingTree, new String[]{"document_id"}, null, null, null);
                        while (cursor.moveToNext()) {
                            arrayList.add(DocumentsContract.buildDocumentUriUsingTree(cVar.b, cursor.getString(0)));
                        }
                    } catch (Exception e) {
                        Log.w("DocumentFile", "Failed query: " + e);
                    }
                    c.c(cursor);
                    Uri[] uriArr = (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
                    int length = uriArr.length;
                    a[] aVarArr = new a[length];
                    for (int i3 = 0; i3 < uriArr.length; i3++) {
                        aVarArr[i3] = new c(cVar, cVar.f5a, uriArr[i3]);
                    }
                    for (int i4 = 0; i4 < length; i4++) {
                        a aVar = aVarArr[i4];
                        aVar.b();
                        if (!aVar.b().toString().contains(".nomedia") && !aVar.b().toString().equals("")) {
                            statusObjectsList.add(aVar.b());
                        }
                    }
                    Ads_constant.bwset_Setpermissin(this, "true");
                    this.viewPager.setAdapter(new TabLayoutAdapter(this, getSupportFragmentManager(), this.tabLayout.getTabCount()));
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            } else {
                Toast.makeText(this, "You Give Wrong Folder Permission", 0).show();
            }
        }
    }

    private void getDataForAndroid11OnlyStatus(Uri uri) {
        Uri parse = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp%20Business%2FMedia%2F.Statuses");
        Cursor cursor = null;
        c cVar = new c(null, this, DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse)));
        ContentResolver contentResolver = cVar.f5a.getContentResolver();
        Uri uri2 = cVar.b;
        Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri2, DocumentsContract.getDocumentId(uri2));
        ArrayList arrayList = new ArrayList();
        try {
            cursor = contentResolver.query(buildChildDocumentsUriUsingTree, new String[]{"document_id"}, null, null, null);
            while (cursor.moveToNext()) {
                arrayList.add(DocumentsContract.buildDocumentUriUsingTree(cVar.b, cursor.getString(0)));
            }
        } catch (Exception e) {
            Log.w("DocumentFile", "Failed query: " + e);
        }
        c.c(cursor);
        Uri[] uriArr = (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
        int length = uriArr.length;
        a[] aVarArr = new a[length];
        for (int i = 0; i < uriArr.length; i++) {
            aVarArr[i] = new c(cVar, cVar.f5a, uriArr[i]);
        }
        for (int i2 = 0; i2 < length; i2++) {
            a aVar = aVarArr[i2];
            aVar.b();
            if (!aVar.b().toString().contains(".nomedia") && !aVar.b().toString().equals("")) {
                statusObjectsList.add(aVar.b());
            }
        }
        this.viewPager.setAdapter(new TabLayoutAdapter(this, getSupportFragmentManager(), this.tabLayout.getTabCount()));
    }

    public static String getPathFromURI(Context context, Uri uri) {
        Uri uri2 = null;
        if (Build.VERSION.SDK_INT < 19 || !DocumentsContract.isDocumentUri(context, uri)) {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                return getDataColumn(context, uri, null, null);
            }
            if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        } else if (isExternalStorageDocument(uri)) {
            String[] split = DocumentsContract.getDocumentId(uri).split(":");
            if ("primary".equalsIgnoreCase(split[0])) {
                return Environment.getExternalStorageDirectory() + "/" + split[1];
            }
        } else if (isDownloadsDocument(uri)) {
            return getDataColumn(context, ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.parseLong(DocumentsContract.getDocumentId(uri))), null, null);
        } else {
            if (isMediaDocument(uri)) {
                String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
                String str = split2[0];
                if ("image".equals(str)) {
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(str)) {
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(str)) {
                    uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                return getDataColumn(context, uri2, "_id=?", new String[]{split2[1]});
            }
        }
        return null;
    }

    public static String getDataColumn(Context context, Uri uri, String str, String[] strArr) {
        Cursor query = context.getContentResolver().query(uri, new String[]{"_data"}, str, strArr, null);
        if (query != null && query.moveToFirst()) {
            String string = query.getString(query.getColumnIndexOrThrow("_data"));
            if (query != null) {
                query.close();
            }
            return string;
        } else if (query == null) {
            return null;
        } else {
            query.close();
            return null;
        }
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public class TabLayoutAdapter extends FragmentPagerAdapter {
        Context mContext;
        int mTotalTabs;

        public TabLayoutAdapter(Context context, FragmentManager fragmentManager, int i) {
            super(fragmentManager);
            this.mContext = context;
            this.mTotalTabs = i;
        }

        @Override
        public Fragment getItem(int i) {
            Log.d("asasas", i + "");
            if (i == 0) {
                return new BImagesFragment();
            }
            if (i == 1) {
                return new BVideosFragment();
            }
            if (i != 2) {
                return null;
            }
            return new SavedFragment();
        }

        @Override
        public int getCount() {
            return this.mTotalTabs;
        }
    }


    private void setupViewPager(ViewPager viewPager2) {
        int i = 1;
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), 1);
        viewPagerAdapter.addFragment(new BImagesFragment(), "");
        viewPagerAdapter.addFragment(new BVideosFragment(), "");
        viewPagerAdapter.addFragment(new SavedFragment(), "");
        viewPager2.setAdapter(viewPagerAdapter);
        if (viewPagerAdapter.getCount() > 1) {
            i = viewPagerAdapter.getCount() - 1;
        }
        viewPager2.setOffscreenPageLimit(i);
        viewPager2.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
                Log.d("ORANGES", "onPageScrollStateChanged: " + i);
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
                Log.d("ORANGES", "onPageScrolled: " + i);
            }

            @Override
            public void onPageSelected(int i) {
                Log.d("ORANGES", "onPageSelected: " + i);
                if (i == 0) {
                    home_text.setTextColor(getResources().getColor(R.color.tint));
                    wa_txt.setTextColor(getResources().getColor(R.color.tint1));
                    stu_txt.setTextColor(getResources().getColor(R.color.tint1));
                    home_ic.setColorFilter(getResources().getColor(R.color.tint));
                    wa_ic.setColorFilter(getResources().getColor(R.color.tint1));
                    stu_ic.setColorFilter(getResources().getColor(R.color.tint1));
                    stu_ic.setColorFilter(getResources().getColor(R.color.tint1));
                } else if (i == 1) {
                    home_text.setTextColor(getResources().getColor(R.color.tint1));
                    wa_txt.setTextColor(getResources().getColor(R.color.tint));
                    stu_txt.setTextColor(getResources().getColor(R.color.tint1));
                    home_ic.setColorFilter(getResources().getColor(R.color.tint1));
                    wa_ic.setColorFilter(getResources().getColor(R.color.tint));
                    stu_ic.setColorFilter(getResources().getColor(R.color.tint1));
                } else if (i == 2) {
                    home_text.setTextColor(getResources().getColor(R.color.tint1));
                    wa_txt.setTextColor(getResources().getColor(R.color.tint1));
                    stu_txt.setTextColor(getResources().getColor(R.color.tint));
                    home_ic.setColorFilter(getResources().getColor(R.color.tint1));
                    wa_ic.setColorFilter(getResources().getColor(R.color.tint1));
                    stu_ic.setColorFilter(getResources().getColor(R.color.tint));
                }
            }
        });
    }

    public static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        public ViewPagerAdapter(FragmentManager fragmentManager, int i) {
            super(fragmentManager, i);
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        @Override
        public int getCount() {
            return this.mFragmentList.size();
        }

        @Override
        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        @Override
        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }
}