package com.hd.video.downloader.play.video.Mainvideos;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;


import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ActivityFullScreenBinding;
import com.hd.video.downloader.play.video.fragments_downloader.bean_downloader.WAStatus;

import java.io.File;

public class Activity_Image_Screen extends AppCompatActivity implements View.OnClickListener {
    private WAStatus mStatus;
    private String mWhoIs = "";
    ActivityFullScreenBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityFullScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setClickListeners();
        this.mStatus = (WAStatus) getIntent().getSerializableExtra("status_info");
        this.mWhoIs = getIntent().getStringExtra("who_is");
        WAStatus wAStatus = this.mStatus;
        if (wAStatus != null) {
            if (wAStatus.getStatusType().contains("image")) {
                Bitmap decodeFile = BitmapFactory.decodeFile(this.mStatus.getFilePath());
                if (decodeFile != null) {
                    binding.imgStatusThumbFullScreenActivity.setImageBitmap(decodeFile);
                } else {
                    Toast.makeText(this, "Error Loading Picture!", Toast.LENGTH_SHORT).show();
                }
                binding.imgIcPlayButtonFullScreenActivity.setVisibility(View.GONE);
            } else {
                Bitmap createVideoThumbnail = ThumbnailUtils.createVideoThumbnail(this.mStatus.getFilePath(), 1);
                if (bundle != null) {
                    binding.imgStatusThumbFullScreenActivity.setImageBitmap(createVideoThumbnail);
                }
                binding.imgIcPlayButtonFullScreenActivity.setVisibility(View.VISIBLE);
            }
            checkIfAlreadyDownloaded();
            return;
        }
        Toast.makeText(this, "Error Loading Picture/Video!", Toast.LENGTH_SHORT).show();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Activity_Image_Screen.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void checkIfAlreadyDownloaded() {
        binding.imgIcDownloadFullScreenActivity.setVisibility(View.VISIBLE);
        if (new File(this.mStatus.getDestPath()).exists()) {
            binding.imgIcDownloadFullScreenActivity.setImageResource(R.drawable.downloadicon_white);
        } else {
            binding.imgIcDownloadFullScreenActivity.setImageResource(R.drawable.finished_icon1);
        }
    }

    public static void newIntent(Context context, WAStatus wAStatus, String str) {
        Intent intent = new Intent(context, Activity_Image_Screen.class);
        intent.putExtra("status_info", wAStatus);
        intent.putExtra("who_is", str);
        context.startActivity(intent);
    }

    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.imgIcDownloadFullScreenActivity) {
            binding.imgIcDownloadFullScreenActivity.setImageResource(R.drawable.downloadicon_white);
        } else if (id == R.id.imgIcShareFullScreenActivity) {
            doShareFile();
        } else if (id == R.id.imgStatusThumbFullScreenActivity) {
            shiftVisibility();
        }
    }

    private void doShareFile() {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            if (this.mStatus.getStatusType().contains("image")) {
                intent.setType("image/jpeg");
            }
            if (this.mStatus.getStatusType().contains("video")) {
                intent.setType("mp4");
            }
            intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(this.mStatus.getFilePath())));
            startActivity(Intent.createChooser(intent, "Share Using"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void shiftVisibility() {
        if (binding.layoutBottomFullScreenActivity.getVisibility() == View.VISIBLE) {
            binding.layoutBottomFullScreenActivity.setVisibility(View.GONE);
        } else {
            binding.layoutBottomFullScreenActivity.setVisibility(View.VISIBLE);
        }
    }

    private void setClickListeners() {
        binding.imgIcDownloadFullScreenActivity.setOnClickListener(this);
        binding.imgIcShareFullScreenActivity.setOnClickListener(this);
        binding.imgStatusThumbFullScreenActivity.setOnClickListener(this);
        binding.imgIcPlayButtonFullScreenActivity.setOnClickListener(this);
    }
}