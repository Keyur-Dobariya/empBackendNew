package com.hd.video.downloader.play.video.Mainvideos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;


import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ActivityVideoLocalPlayBinding;
import com.hd.video.downloader.play.video.downloader_downloader.AppConstant;

import java.io.File;

import cn.jzvd.JZVideoPlayer;
import cn.jzvd.JZVideoPlayerStandard;

public class Activity_VideoLocalPlay extends AppCompatActivity {
    private String url;
    ActivityVideoLocalPlayBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityVideoLocalPlayBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        data();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Activity_VideoLocalPlay.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void data() {
        this.url = getIntent().getStringExtra(AppConstant.KEY.URL);
        binding.share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                shareVideo(url);
            }
        });
        binding.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Activity_VideoLocalPlay.this.finish();
            }
        });

        JZVideoPlayerStandard jZVideoPlayerStandard = (JZVideoPlayerStandard) findViewById(R.id.videoplayer);
        jZVideoPlayerStandard.setUp(this.url, 0, "");
        jZVideoPlayerStandard.startVideo();
        jZVideoPlayerStandard.backButton.setVisibility(View.GONE);
        JZVideoPlayerStandard.FULLSCREEN_ORIENTATION = 0;
        JZVideoPlayerStandard.NORMAL_ORIENTATION = 1;
    }

    private void shareVideo(String str) {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("video/mp4");
            intent.putExtra("android.intent.extra.STREAM", FileProvider.getUriForFile(this, getPackageName() + ".provider", new File(str)));
            startActivity(Intent.createChooser(intent, "Share Using"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onBackPressed() {
        if (!JZVideoPlayer.backPress()) {
            super.onBackPressed();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        JZVideoPlayer.releaseAllVideos();
    }
}
