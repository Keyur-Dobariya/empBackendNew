package com.hd.video.downloader.play.video.Mainvideos;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ActivityGalleryBinding;
import com.hd.video.downloader.play.video.downloader_downloader.AppConstant;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadConfig;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadManager;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadService;
import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;
import com.hd.video.downloader.play.video.fragments_downloader.fb_download_frag;
import com.hd.video.downloader.play.video.fragments_downloader.pin_download_frag;
import com.hd.video.downloader.play.video.fragments_downloader.tik_download_frag;
import com.hd.video.downloader.play.video.fragments_downloader.twit_download_frag;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AllDownLoadVideo extends AppCompatActivity {
    public static DownloadService mService;
    private int currnetItem = 0;
    public StringBuilder sb;
    public String sb2;
    public Fragment[] fragments;
    public String[] titles = new String[]{"Facebook", "Twitter", "Tiktok", "PinTrest"};
    PageAdapter pageAdapter;
    DownloadEntry downloadEntry;
    ActivityGalleryBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityGalleryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init_data();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(AllDownLoadVideo.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    //    ************intetial*******************************
    public void init_data() {
        Log.i("vitime1", "Vitime1===" + System.currentTimeMillis());
        fragments = new Fragment[4];
        sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().toString());
        sb.append("/" + getResources().getString(R.string.app_name) + "wp");
        sb2 = sb.toString();
        fragments[0] = new fb_download_frag();
        fragments[1] = new twit_download_frag();
        fragments[2] = new tik_download_frag();
        fragments[3] = new pin_download_frag();

        binding.back.setOnClickListener(v -> finish());
        pageAdapter = new PageAdapter(getSupportFragmentManager(), titles, fragments);
        binding.viewPager.setAdapter(pageAdapter);
        binding.tabLayout.setupWithViewPager(binding.viewPager);

        List<DownloadEntry> entries;
        if (this.currnetItem == 1) {
            ArrayList<DownloadEntry> queryAllDownloadingEntries = DownloadManager.getInstance(this).queryAllDownloadingEntries();
            if (queryAllDownloadingEntries == null || queryAllDownloadingEntries.size() <= 0) {
                binding.viewPager.setCurrentItem(0);
                downloadEntry = (DownloadEntry) this.getIntent().getSerializableExtra(AppConstant.KEY.ENTRY);
                if (downloadEntry != null && downloadEntry.status == DownloadEntry.DownloadStatus.completed) {
                    File downloadFile = DownloadConfig.getConfig().getDownloadFile(downloadEntry.name);
                    if (this.currnetItem == 0) {
                        InterstitialAds.showAd(AllDownLoadVideo.this, new OnInterstitialAdResponse() {
                            @Override
                            public void onAdClosed() {
                                Intent intent = new Intent(AllDownLoadVideo.this, Activity_VideoLocalPlay.class);
                                intent.putExtra(AppConstant.KEY.URL, downloadFile.getAbsolutePath());
                                startActivity(intent);
                            }

                            @Override
                            public void onAdImpression() {

                            }
                        });
                    }
                }
                Log.e("str", "Vitime2===" + System.currentTimeMillis());
            }
        }
        binding.viewPager.setCurrentItem(this.currnetItem);
        downloadEntry = (DownloadEntry) this.getIntent().getSerializableExtra(AppConstant.KEY.ENTRY);
        if (this.currnetItem == 0) {
        }
        Log.e("str", "Vitime2===" + System.currentTimeMillis());

        this.currnetItem = this.getIntent().getIntExtra(AppConstant.KEY.CURREUNT_ITEM, 0);
        currnetItem = this.getIntent().getIntExtra(AppConstant.KEY.CURREUNT_ITEM, 0);
        if (currnetItem == 2) {
            entries = DownloadManager.getInstance(this).queryAllDownloadingEntries();
            if (entries == null || entries.size() <= 0) {
                binding.viewPager.setCurrentItem(0);
                DownloadEntry downloadEntry = (DownloadEntry) this.getIntent().getSerializableExtra(AppConstant.KEY.ENTRY);
                if (downloadEntry != null && downloadEntry.status == DownloadEntry.DownloadStatus.completed) {
                    File downloadFile = DownloadConfig.getConfig().getDownloadFile(downloadEntry.name);
                    if (this.currnetItem == 0) {
                        InterstitialAds.showAd(AllDownLoadVideo.this, new OnInterstitialAdResponse() {
                            @Override
                            public void onAdClosed() {
                                Intent intent = new Intent(AllDownLoadVideo.this, Activity_VideoLocalPlay.class);
                                intent.putExtra(AppConstant.KEY.URL, downloadFile.getAbsolutePath());
                                startActivity(intent);
                            }

                            @Override
                            public void onAdImpression() {

                            }
                        });

                    }
                }
            }
        }
    }

    private final ServiceConnection connection = new ServiceConnection() {

        public void onServiceDisconnected(ComponentName componentName) {
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            AllDownLoadVideo.mService = ((DownloadService.MyBinder) iBinder).getService();
            Log.e("str", "service===" + iBinder);
        }
    };

    static class PageAdapter extends FragmentPagerAdapter {
        final Fragment[] fragments;
        private final String[] titles;

        public PageAdapter(FragmentManager fragmentManager, String[] strArr, Fragment[] fragmentArr) {
            super(fragmentManager);
            this.titles = strArr;
            this.fragments = fragmentArr;
        }

        @Override
        public int getCount() {
            return this.titles.length;
        }

        @Override
        public Fragment getItem(int position) {
            Fragment fragment = new Fragment();
            if (position == 0) {
                fragment = new fb_download_frag();
            } else if (position == 1) {
                fragment = new twit_download_frag();
            } else if (position == 2) {
                fragment = new tik_download_frag();
            } else if (position == 3) {
                fragment = new pin_download_frag();
            }
            return fragment;
        }

        @Override
        public CharSequence getPageTitle(int i) {
            String[] strArr = this.titles;
            return strArr[i % strArr.length].toUpperCase();
        }
    }

    private void bindService() {
        this.bindService(new Intent(this, DownloadService.class), this.connection, 1);
    }

    private void unbindPlayService() {
        if (mService != null) {
            this.unbindService(this.connection);
        }
    }

    public static AllDownLoadVideo newInstance() {
        return new AllDownLoadVideo();
    }


    @Override
    public void onPause() {
        super.onPause();
        unbindPlayService();
    }

    @Override
    public void onResume() {
        super.onResume();
        bindService();
    }
}