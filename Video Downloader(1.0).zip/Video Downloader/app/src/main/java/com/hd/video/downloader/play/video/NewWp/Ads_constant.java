package com.hd.video.downloader.play.video.NewWp;

import android.content.Context;
import android.content.SharedPreferences;

public class Ads_constant {
    private static String SetBWPermission = "SetBWPermission";
    private static String Setpermissin = "Setpermissin";

    public static String get_Setpermissin(Context context) {
        try {
            return context.getSharedPreferences(Setpermissin, 0).getString("color", "false");
        } catch (Exception unused) {
            return "false";
        }
    }
    public static String bwget_Setpermissin(Context context) {
        try {
            return context.getSharedPreferences(SetBWPermission, 0).getString("color", "false");
        } catch (Exception unused) {
            return "false";
        }
    }
    public static void set_Setpermissin(Context context, String str) {
        SharedPreferences.Editor edit = context.getSharedPreferences(Setpermissin, 0).edit();
        edit.putString("color", str);
        edit.apply();
    }
    public static void bwset_Setpermissin(Context context, String str) {
        SharedPreferences.Editor edit = context.getSharedPreferences(SetBWPermission, 0).edit();
        edit.putString("color", str);
        edit.apply();
    }

}