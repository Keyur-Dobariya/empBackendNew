package com.hd.video.downloader.play.video.NewWp;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import androidx.loader.content.CursorLoader;

public class RealPathUtil {
    public static String getRealPath(Context context, Uri uri) {
        if (Build.VERSION.SDK_INT < 11) {
            return getRealPathFromURI_BelowAPI11(context, uri);
        }
        if (Build.VERSION.SDK_INT < 19) {
            return getRealPathFromURI_API11to18(context, uri);
        }
        return getRealPathFromURI_API19(context, uri);
    }

    public static String getRealPathFromURI_API11to18(Context context, Uri uri) {
        Cursor loadInBackground = new CursorLoader(context, uri, new String[]{"_data"}, (String) null, (String[]) null, (String) null).loadInBackground();
        if (loadInBackground == null) {
            return null;
        }
        int columnIndexOrThrow = loadInBackground.getColumnIndexOrThrow("_data");
        loadInBackground.moveToFirst();
        String string = loadInBackground.getString(columnIndexOrThrow);
        loadInBackground.close();
        return string;
    }

    public static String getRealPathFromURI_BelowAPI11(Context context, Uri uri) {
        Cursor query = context.getContentResolver().query(uri, new String[]{"_data"}, (String) null, (String[]) null, (String) null);
        if (query == null) {
            return "";
        }
        int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
        query.moveToFirst();
        String string = query.getString(columnIndexOrThrow);
        query.close();
        return string;
    }

    public static String getRealPathFromURI_API19(Context context, Uri uri) {
        Uri uri2 = null;
        if (Build.VERSION.SDK_INT < 19 || !DocumentsContract.isDocumentUri(context, uri)) {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                if (isGooglePhotosUri(uri)) {
                    return uri.getLastPathSegment();
                }
                return getDataColumn(context, uri, (String) null, (String[]) null);
            } else if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        } else if (isExternalStorageDocument(uri)) {
            String[] split = DocumentsContract.getDocumentId(uri).split(":");
            if ("primary".equalsIgnoreCase(split[0])) {
                return Environment.getExternalStorageDirectory() + "/" + split[1];
            }
        } else if (isDownloadsDocument(uri)) {
            return getDataColumn(context, ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(DocumentsContract.getDocumentId(uri)).longValue()), (String) null, (String[]) null);
        } else {
            if (isMediaDocument(uri)) {
                String[] split2 = DocumentsContract.getDocumentId(uri).split(":");
                String str = split2[0];
                if ("image".equals(str)) {
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(str)) {
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(str)) {
                    uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                return getDataColumn(context, uri2, "_id=?", new String[]{split2[1]});
            }
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0031, code lost:
        r7 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0032, code lost:
        r7.printStackTrace();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0035, code lost:
        return r9;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static String getDataColumn(Context r7, Uri r8, String r9, String[] r10) {
        /*
            java.lang.String r0 = "_data"
            android.content.ContentResolver r1 = r7.getContentResolver()     // Catch:{ all -> 0x002f }
            java.lang.String[] r3 = new java.lang.String[]{r0}     // Catch:{ all -> 0x002f }
            r6 = 0
            r2 = r8
            r4 = r9
            r5 = r10
            android.database.Cursor r7 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ all -> 0x002f }
            if (r7 == 0) goto L_0x0028
            boolean r8 = r7.moveToFirst()     // Catch:{ all -> 0x002f }
            if (r8 == 0) goto L_0x0028
            int r8 = r7.getColumnIndexOrThrow(r0)     // Catch:{ all -> 0x002f }
            java.lang.String r8 = r7.getString(r8)     // Catch:{ all -> 0x002f }
            if (r7 == 0) goto L_0x0027
            r7.close()     // Catch:{ all -> 0x002f }
        L_0x0027:
            return r8
        L_0x0028:
            if (r7 == 0) goto L_0x002d
            r7.close()     // Catch:{ all -> 0x002f }
        L_0x002d:
            r7 = 0
            return r7
        L_0x002f:
            r7 = move-exception
            throw r7     // Catch:{ all -> 0x0031 }
        L_0x0031:
            r7 = move-exception
            r7.printStackTrace()
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.innovateinfosoft.statusdownloader.NewWp.RealPathUtil.getDataColumn(android.content.Context, android.net.Uri, java.lang.String, java.lang.String[]):java.lang.String");
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }
}
