package com.hd.video.downloader.play.video.NewWp.Utils;

import java.io.File;

public interface FileListClickInterface {
    void getPosition(int i, File file);
}