package com.hd.video.downloader.play.video.NewWp.activity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.hd.video.downloader.play.video.NewWp.Utils.Utils;
import com.hd.video.downloader.play.video.NewWp.adpter.ShowImagesAdapter;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ActivityFullViewBinding;
import com.hd.video.downloader.play.video.databinding.InstaActivityMainBinding;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;

public class ActivityFullView extends AppCompatActivity {
    public int Position = 0;
    public ActivityFullView activity;
    public ArrayList<File> fileArrayList;
    public String fileImage;
    ShowImagesAdapter showImagesAdapter;

    ActivityFullViewBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityFullViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        int i = 0;
        if (getIntent().getExtras() != null) {
            this.fileArrayList = (ArrayList) getIntent().getSerializableExtra("ImageDataFile");
            this.fileImage = getIntent().getStringExtra("fileImage");
            this.Position = getIntent().getIntExtra("Position", 0);
        }
        while (true) {
            if (i >= this.fileArrayList.size()) {
                break;
            } else if (this.fileArrayList.get(i).toString().equals(this.fileImage)) {
                this.Position = i;
                break;
            } else {
                i++;
            }
        }
        initViews();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(ActivityFullView.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void initViews() {
        showImagesAdapter = new ShowImagesAdapter(this, this.fileArrayList, ActivityFullView.this);
        binding.vpView.setAdapter(showImagesAdapter);
        binding.vpView.setCurrentItem(this.Position);
        binding.vpView.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override
            public void onPageSelected(int i) {
                Position = i;
                PrintStream printStream = System.out;
                printStream.println("Current position==" + Position);
            }
        });
        binding.imDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (fileArrayList.get(Position).delete()) {
                            deleteFileAA(Position);
                        }
                    }
                });
                builder.setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog create = builder.create();
                create.setTitle(getResources().getString(R.string.do_u_want_to_dlt));
                create.show();
            }
        });
        binding.imShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (fileArrayList.get(Position).getName().contains("video/*")) {
                    Log.d("SSSSS", "onClick: " + fileArrayList.get(Position) + "");
                    Utils.newshareVideo(activity, fileArrayList.get(Position).getPath(), true);
                    return;
                }
                Utils.newshareImage(activity, fileArrayList.get(Position).getPath(), false);
            }
        });
        binding.imWhatsappShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (fileArrayList.get(Position).getName().contains(".mp4")) {
                    Utils.shareImageVideoOnWhatsapp(activity, fileArrayList.get(Position).getPath(), true);
                } else {
                    Utils.shareImageVideoOnWhatsapp(activity, fileArrayList.get(Position).getPath(), false);
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        this.activity = this;
    }

    public void deleteFileAA(int i) {
        this.fileArrayList.remove(i);
        this.showImagesAdapter.notifyDataSetChanged();
        Utils.setToast(this.activity, getResources().getString(R.string.file_deleted));
        if (this.fileArrayList.size() == 0) {
            onBackPressed();
        }
    }

}