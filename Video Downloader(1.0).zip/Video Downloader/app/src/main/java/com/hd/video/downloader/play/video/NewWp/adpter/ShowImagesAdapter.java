package com.hd.video.downloader.play.video.NewWp.adpter;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.NewWp.Utils.Utils;
import com.hd.video.downloader.play.video.NewWp.activity.ActivityFullView;
import com.hd.video.downloader.play.video.NewWp.activity.ActivityVideoPlayer;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;

import java.io.File;
import java.util.ArrayList;

public class ShowImagesAdapter extends PagerAdapter {
    ActivityFullView activityFullView;
    public Activity context;
    public ArrayList<File> imageList;
    private LayoutInflater inflater;
    Intent intent;

    @Override
    public int getItemPosition(Object obj) {
        return -2;
    }

    @Override
    public void restoreState(Parcelable parcelable, ClassLoader classLoader) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }

    public ShowImagesAdapter(Activity activity, ArrayList<File> arrayList, ActivityFullView activityFullView2) {
        this.context = activity;
        this.imageList = arrayList;
        this.activityFullView = activityFullView2;
        this.inflater = LayoutInflater.from(activity);
    }

    @Override
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) obj);
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, final int i) {
        View inflate = this.inflater.inflate(R.layout.slidingimages_layout, viewGroup, false);
        ImageView im_vpPlay = (ImageView) inflate.findViewById(R.id.im_vpPlay);
        ImageView im_share = (ImageView) inflate.findViewById(R.id.im_share);
        Glide.with(this.context).load(this.imageList.get(i).getPath()).into((ImageView) inflate.findViewById(R.id.im_fullViewImage));
        viewGroup.addView(inflate, 0);
        if (this.imageList.get(i).getName().substring(this.imageList.get(i).getName().lastIndexOf(".")).equals(".mp4")) {
            im_vpPlay.setVisibility(View.VISIBLE);
        } else {
            im_vpPlay.setVisibility(View.GONE);
        }
        //        ***********intetial**********************

        im_vpPlay.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                InterstitialAds.showAd(context, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        intent = new Intent(context, ActivityVideoPlayer.class);
                        intent.putExtra("PathVideo", imageList.get(i).getPath());
                        context.startActivity(intent);
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });

            }
        });
        im_share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (imageList.get(i).getName().substring(imageList.get(i).getName().lastIndexOf(".")).equals(".mp4")) {
                    Utils.newshareVideo(context, imageList.get(i).getPath(), true);
                } else {
                    Utils.newshareImage(context, imageList.get(i).getPath(), false);
                }
            }
        });
        return inflate;
    }


    @Override
    public int getCount() {
        return this.imageList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view.equals(obj);
    }
}