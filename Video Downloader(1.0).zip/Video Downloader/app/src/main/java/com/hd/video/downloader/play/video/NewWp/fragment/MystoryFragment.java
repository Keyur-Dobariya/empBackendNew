package com.hd.video.downloader.play.video.NewWp.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.icu.text.DateFormat;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.facebook.ads.NativeAdLayout;
import com.google.android.material.card.MaterialCardView;
import com.hd.video.downloader.play.video.NewWp.Utils.FileListClickInterface;
import com.hd.video.downloader.play.video.NewWp.activity.ActivityFullView;
import com.hd.video.downloader.play.video.NewWp.activity.WhatsappActivty;
import com.hd.video.downloader.play.video.NewWp.adpter.FileListAdapter;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.SmallNativeAds;

import java.io.File;
import java.util.ArrayList;

public class MystoryFragment extends Fragment implements FileListClickInterface {
    private WhatsappActivty activity;
    private ArrayList<File> fileArrayList;
    private ArrayList<File> fileArrayList22;
    FileListAdapter fileListAdapter;
    View inflate;
    RelativeLayout nodata;
    String path;
    RecyclerView rvFileList;
    MaterialCardView cardSmallNative;
    FrameLayout admobSmallNative;
    NativeAdLayout fbSmallNative;

    private final String screenName = this.getClass().getSimpleName();


    public void onAttach(Context context) {
        super.onAttach(context);
        this.activity = (WhatsappActivty) context;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (getArguments() != null) {
            getArguments().getString(DateFormat.MINUTE);
        }
    }

    public void onResume() {
        super.onResume();
        this.activity = (WhatsappActivty) getActivity();
        getAllFiles();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.inflate = layoutInflater.inflate(R.layout.fragment_historys, viewGroup, false);
        this.path = getActivity().getIntent().getStringExtra("path");
        Log.d("BENNNN", "onCreateView: " + this.path);
        this.rvFileList = (RecyclerView) this.inflate.findViewById(R.id.rvFileList);
        this.nodata = (RelativeLayout) this.inflate.findViewById(R.id.nodata);
//          *******small native*********************
        this.cardSmallNative =  this.inflate.findViewById(R.id.cardSmallNative);
        this.admobSmallNative =  this.inflate.findViewById(R.id.admobSmallNative);
        this.fbSmallNative =  this.inflate.findViewById(R.id.fbSmallNative);

        getAllFiles();

        //        *********Smallnative*************
        new SmallNativeAds(screenName).showAd(getContext(), admobSmallNative, fbSmallNative,cardSmallNative);
        return this.inflate;
    }

    private void getAllFiles() {
        this.fileArrayList = new ArrayList<>();
        this.fileArrayList22 = new ArrayList<>();
        File[] listFiles = new File(Environment.getExternalStorageDirectory() + "/Download/Status Downloader/" + WhatsappActivty.statuspath).listFiles();
        StringBuilder sb = new StringBuilder();
        sb.append("getAllFiles: ");
        sb.append(listFiles);
        Log.d("ANJALIIIIIIII", sb.toString());
        this.rvFileList.setVisibility(View.VISIBLE);
        if (listFiles != null) {
            for (File add : listFiles) {
                this.fileArrayList.add(add);
            }
            for (int i2 = 0; i2 < this.fileArrayList.size(); i2++) {
                this.fileArrayList22.add(this.fileArrayList.get(i2));
            }
            if (this.fileArrayList22.size() > 0) {
                this.nodata.setVisibility(View.GONE);
                this.rvFileList.setVisibility(View.VISIBLE);
                final GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
                this.rvFileList.setLayoutManager(gridLayoutManager);
                this.rvFileList.setItemAnimator(new DefaultItemAnimator());
                final FileListAdapter fileListAdapter2 = new FileListAdapter(this.activity, this.fileArrayList22, MystoryFragment.this, getActivity());
                gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                    public int getSpanSize(int i) {
                        int itemViewType = fileListAdapter2.getItemViewType(i);
                        if (itemViewType == 1) {
                            return 1;
                        }
                        if (itemViewType != 2) {
                            return -1;
                        }
                        return gridLayoutManager.getSpanCount();
                    }
                });
                this.fileListAdapter = fileListAdapter2;
                this.rvFileList.setAdapter(fileListAdapter2);
                return;
            }
            this.nodata.setVisibility(View.VISIBLE);
            this.rvFileList.setVisibility(View.GONE);
        }
    }

    public void getPosition(int i, File file) {
        CallIntent(getActivity(), ActivityFullView.class, i);
    }

    public void CallIntent(Activity activity2, Class<?> cls, int i) {
        InterstitialAds.showAd(getActivity(), new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                final Intent intent = new Intent(activity2, cls);
                intent.putExtra("ImageDataFile", fileArrayList);
                intent.putExtra("Position", i);
                intent.putExtra("fileImage", fileArrayList22.get(i).toString());
                MystoryFragment.this.startActivity(intent);
            }
            @Override
            public void onAdImpression() {
            }
        });
    }
}
