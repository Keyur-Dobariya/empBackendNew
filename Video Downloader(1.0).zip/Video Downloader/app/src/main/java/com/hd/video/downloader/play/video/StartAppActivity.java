package com.hd.video.downloader.play.video;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.hd.video.downloader.play.video.BWhatsapp.fragment.BWhatsappActivty;
import com.hd.video.downloader.play.video.Mainvideos.AllDownLoadVideo;
import com.hd.video.downloader.play.video.NewWp.activity.WhatsappActivty;
import com.hd.video.downloader.play.video.ads.commons.AdsManager;
import com.hd.video.downloader.play.video.ads.commons.AdsUtils;
import com.hd.video.downloader.play.video.ads.commons.MyExtensionsKt;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.NativeAds;
import com.hd.video.downloader.play.video.databinding.ActivityStartAppBinding;
import com.hd.video.downloader.play.video.downloader_downloader.AppConfig;
import com.hd.video.downloader.play.video.downloader_downloader.AppConstant;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadManager;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadService;
import com.hd.video.downloader.play.video.facebook.Activity_Search;
import com.hd.video.downloader.play.video.instagram.Activity.Insta_MainActivity;
import com.hd.video.downloader.play.video.pinterest.PinActivity;
import com.hd.video.downloader.play.video.tiktok.TikTokActivity;
import com.hd.video.downloader.play.video.twiter.activity.Twitter_Activity;

import java.io.File;

public class StartAppActivity extends AppCompatActivity implements View.OnClickListener {
    private ReviewManager manager;
    private ReviewInfo reviewInfo;

    public static String DownloadPath;
    DownloadManager downloadManager;
    ActivityStartAppBinding binding;
    private static final int STORAGE_REQUEST_CODE = 101;

    private final String screenName = this.getClass().getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStartAppBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Window window = StartAppActivity.this.getWindow();
        window.setStatusBarColor(ContextCompat.getColor(StartAppActivity.this, R.color.bg));
        //        ***********permission*****************************
        if (!CheckStoragePERMISSION()) {
            AskStoragePERMISSION();
        }
        //*********fb**************
        regexVideo();
        getfbStorageDir();
        bind();
        goReview();

//        *********************native*********************************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(StartAppActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        showExitDailog();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void bind() {
        binding.fbapp.setOnClickListener(this);
        binding.insta.setOnClickListener(this);
        binding.whastapp.setOnClickListener(this);
        binding.wabusiness.setOnClickListener(this);
        binding.tiktok.setOnClickListener(this);
        binding.tiwtter.setOnClickListener(this);
        binding.pintrest.setOnClickListener(this);
        binding.alldownvideo.setOnClickListener(this);
        binding.more.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fbapp:
                InterstitialAds.showAd(StartAppActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        Intent intent5 = new Intent(StartAppActivity.this, Activity_Search.class);
                        DownloadPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/FaceBook Video Downloader";
                        intent5.putExtra(AppConstant.KEY.URL, "https://www.facebook.com/facebook/videos/");
                        startActivity(intent5);
                    }

                    @Override
                    public void onAdImpression() {
                    }
                });
                break;
            case R.id.insta:
                startActivitys(new Intent(StartAppActivity.this, Insta_MainActivity.class));
                break;
            case R.id.whastapp:
                InterstitialAds.showAd(StartAppActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        if (getPackageManager().getLaunchIntentForPackage("com.whatsapp") != null) {
                            Intent intent = new Intent(StartAppActivity.this, WhatsappActivty.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(StartAppActivity.this, "App Not Found.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onAdImpression() {
                    }
                });

                break;
            case R.id.wabusiness:
                InterstitialAds.showAd(StartAppActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        if (getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b") != null) {
                            Intent intent = new Intent(StartAppActivity.this, BWhatsappActivty.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(StartAppActivity.this, "App Not Found.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onAdImpression() {
                    }
                });
                break;
            case R.id.tiktok:
                startActivitys(new Intent(StartAppActivity.this, TikTokActivity.class));
                break;
            case R.id.tiwtter:
                startActivitys(new Intent(StartAppActivity.this, Twitter_Activity.class));
                break;
            case R.id.pintrest:
                startActivitys(new Intent(StartAppActivity.this, PinActivity.class));
                break;
            case R.id.alldownvideo:
                startActivitys(new Intent(StartAppActivity.this, AllDownLoadVideo.class));
                break;
            case R.id.more:
                PopupMenu popupMenu = new PopupMenu(StartAppActivity.this, binding.more);
                popupMenu.inflate(R.menu.popup_privacy);
                popupMenu.setOnMenuItemClickListener(menuItem -> {
                    int itemId = menuItem.getItemId();
                    if (itemId == R.id.share) {
                        shareApp();
                        return false;
                    } else if (itemId == R.id.rate) {
                        rateUs();
                        return false;
                    } else if (itemId == R.id.privacy) {
                        MyExtensionsKt.privacyPolicy(this, AdsUtils.getAdPref(this).ppLink);
                        return false;
                    } else {
                        return false;
                    }
                });
                popupMenu.show();
                break;
        }
    }

    public void shareApp() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", "Download this awesome app\n https://play.google.com/store/apps/details?id=" + getPackageName() + " \n");
        startActivity(intent);
    }

    public void rateUs() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + getPackageName())));
        } catch (ActivityNotFoundException unused) {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void onDestroy() {
        super.onDestroy();
        DownloadManager instance = DownloadManager.getInstance(this);
        this.downloadManager = instance;
        instance.pauseAll();
        stopService(new Intent(this, DownloadService.class));
    }

    //  ##---------------Begin: permission configuration for Storage --------

    private String[] StoragePERMISSION() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return new String[]{android.Manifest.permission.READ_MEDIA_IMAGES, android.Manifest.permission.READ_MEDIA_AUDIO, android.Manifest.permission.READ_MEDIA_VIDEO};
        } else {
            return new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE};
        }
    }

    private void AskStoragePERMISSION() {
        ActivityCompat.requestPermissions(StartAppActivity.this, StoragePERMISSION(), STORAGE_REQUEST_CODE);
    }

    private boolean CheckStoragePERMISSION() {
        int result, result2, result3;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            result = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_IMAGES);
            result3 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_VIDEO);
            return result == PackageManager.PERMISSION_GRANTED && result3 == PackageManager.PERMISSION_GRANTED;
        } else {
            result = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
            result2 = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED && result2 == PackageManager.PERMISSION_GRANTED;
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            }
        }
    }
//  ##---------------End: permission configuration for Storage --------

    public File getfbStorageDir() {
        File file = new File((Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/FaceBook Video Downloader"));
        if (!file.mkdirs()) {
            Log.e("Error", "Directory not created");
        }
        return file;
    }

//    ***********fb*********************

    private void regexVideo() {
        AppConfig.REGEXVIDEOS.add(".*//vssauth.waqu\\.com/.*/normal\\.mp4.*");
        AppConfig.REGEXVIDEOS.add(".*365yg.com.*/video/[a-z]/.*");
        AppConfig.REGEXVIDEOS.add(".*hotsoon\\.snssdk\\.com/hotsoon/item/video.*");
        AppConfig.REGEXVIDEOS.add(".*music.qqvideo.tc\\.qq\\.com/.*\\.mp4.*");
        AppConfig.REGEXVIDEOS.add(".*v7\\.pstatp.com.*/origin/.*");
        AppConfig.REGEXVIDEOS.add(".*pstatp.com.*/video/.*");
        AppConfig.REGEXVIDEOS.add(".*googlevideo.com.*");
        AppConfig.REGEXVIDEOS.add(".*//video.weibo.com/media/.*");
        AppConfig.REGEXVIDEOS.add(".*tumblr.com/video_file/.*");
        AppConfig.REGEXVIDEOS.add(".*//baobab.kaiyanapp.com.*vid=.*");
        AppConfig.REGEXVIDEOS.add("^((?!vmind\\.qqvideo|btrace\\.video|www\\.facebook\\.com|data\\.video\\.qiyi\\.com).)*(\\.mp4|\\.3gp|\\.swf|\\.flv)(?!\\?vframe|%3F|%22%2C|v=).*$");
    }

    private void showExitDailog() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(R.layout.bottomsheet_exit);
        MaterialButton btnNo = bottomSheetDialog.findViewById(R.id.btnNo);
        TextView txtYesExit = bottomSheetDialog.findViewById(R.id.txtYesExit);
        txtYesExit.setOnClickListener(v -> {
            AdsManager.release(getApplication());
            finishAffinity();
            bottomSheetDialog.dismiss();
        });
        btnNo.setOnClickListener(v -> bottomSheetDialog.dismiss());
        bottomSheetDialog.show();
    }

    private void goReview() {
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener() {
            @Override
            public final void onComplete(Task task) {
                if (task.isSuccessful()) {
                    reviewInfo = (ReviewInfo) task.getResult();
                    manager.launchReviewFlow(StartAppActivity.this, reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                        }
                    });
                }
            }
        });
    }


    //    ***********intetial******************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(StartAppActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                startActivity(intent);
            }

            @Override
            public void onAdImpression() {
            }
        });
    }

}