package com.hd.video.downloader.play.video.Utils;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.awesomedialog.blennersilva.awesomedialoglibrary.AwesomeErrorDialog;
import com.hd.video.downloader.play.video.R;

public class ShowDialog {
    public void show(final Context context, final String str, final String str2, final String str3) {
        new Handler(Looper.getMainLooper()).post(() -> {
            String str1 = str3;
            str1.hashCode();
            char c = 65535;
            switch (str1.hashCode()) {
                case -1867169789:
                    if (str1.equals("success")) {
                        c = 0;
                        break;
                    }
                    break;
                case 96784904:
                    if (str1.equals("error")) {
                        c = 1;
                        break;
                    }
                    break;
                case 1124446108:
                    if (str1.equals("warning")) {
                        c = 2;
                        break;
                    }
                    break;
            }
            int i = R.drawable.ic_close_white_24dp;
            int i2 = R.color.dialogErrorBackgroundColor;
            switch (c) {
                case 0:
                    i2 = R.color.dialogSuccessBackgroundColor;
                    i = R.drawable.ic_check_white_24dp;
                    break;
                case 2:
                    i2 = R.color.dialogNoticeBackgroundColor;
                    i = R.drawable.ic_info_black_24dp;
                    break;
            }
            ((AwesomeErrorDialog) ((AwesomeErrorDialog) ((AwesomeErrorDialog) ((AwesomeErrorDialog) ((AwesomeErrorDialog) new AwesomeErrorDialog(context).setTitle(str1)).setMessage(str2)).setColoredCircle(i2)).setDialogIconAndColor(i, R.color.white)).setCancelable(true)).setButtonText(context.getString(R.string.okay)).setButtonBackgroundColor(i2).setButtonText(context.getString(R.string.okay)).setErrorButtonClick(() -> {
            }).show();
        });
    }
}