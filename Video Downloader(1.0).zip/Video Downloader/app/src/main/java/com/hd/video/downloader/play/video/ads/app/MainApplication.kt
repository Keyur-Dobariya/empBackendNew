package com.hd.video.downloader.play.video.ads.app

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.firebase.FirebaseApp
import com.hd.video.downloader.play.video.ads.commons.AdsUtils
import com.hd.video.downloader.play.video.ads.commons.CustomEvents
import com.hd.video.downloader.play.video.ads.commons.loge
import com.hd.video.downloader.play.video.facebook.module.App_Module_di
import com.hd.video.downloader.play.video.facebook.utilss.AppComponent
import com.hd.video.downloader.play.video.facebook.utilss.Dagger_App__Component
import com.pixplicity.easyprefs.library.Prefs
import java.util.*

class MainApplication : Application(), Application.ActivityLifecycleCallbacks,

    LifecycleEventObserver {

    override fun onCreate() {
        super.onCreate()
        //        ********app uses********************
        instance = this
        Prefs.Builder().setContext(this).setMode(0).setPrefsName(packageName)
            .setUseDefaultSharedPreference(true).build()
        FirebaseApp.initializeApp(this)
        fun getScreenWidth() = screenWidth
        initMemorySize()
        initAppComponent()
        //        *************end*********************
        initLifeCycle()
    }

    private var googleAppOpenAdManager: GoogleAppOpenAdManager? = null
    private var currentActivity: Activity? = null
    private var instance: MainApplication? = null
    private var maxMemory: Long = 0
    private var screenWidth = 0
    var appComponent: AppComponent? = null

    private fun initLifeCycle() {
        registerActivityLifecycleCallbacks(this)
        MobileAds.setRequestConfiguration(
            RequestConfiguration.Builder().setTestDeviceIds(
                listOf(
                    "DA7B57B06E17103976189AA6E7778043",
                    "B141F0F1C5B72CC46D59C5C9CE6B17F4",
                    "CF7A4226193E1A07D6F634F8464005E4"
                )
            ).build()
        )
        MobileAds.initialize(this) {}
        MobileAds.setAppMuted(false)
        MobileAds.setAppVolume(0.5F)
        AudienceNetworkAds.initialize(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    interface OnSplashAd {
        fun onAdClosed(isFailed: Boolean)
    }

    var onSplashAd: OnSplashAd? = null

    fun initAppOpenManager(activity: Activity? = null, onSplashAd: OnSplashAd? = null) {
        this@MainApplication.currentActivity = activity
        this@MainApplication.onSplashAd = onSplashAd
        loadGoogleAd()
    }

    private fun loadGoogleAd() {
        if (!AdsUtils.isAdEnabled(this)) {
            return
        }
        if (!AdsUtils.getAdPref(this).appOpenEnabled && AdsUtils.getAdPref(this).splashAppOpenEnabled) {
            return
        }
        if (googleAppOpenAdManager == null) {
            googleAppOpenAdManager = GoogleAppOpenAdManager()
            googleAppOpenAdManager?.loadAd(this)
        }
    }

    fun release() {
        googleAppOpenAdManager?.release()
        googleAppOpenAdManager = null
    }

    override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
        if (event == Lifecycle.Event.ON_START) {
            if (AdsUtils.isBackPressAdShowing || AdsUtils.isInterstitialAdShowing || !AdsUtils.appOpenAllowed) {
                AdsUtils.appOpenAllowed = true
                return
            }
            if (currentActivity?.javaClass?.simpleName.equals("SplashActivity", true)) {
                return
            }
            currentActivity?.let { googleAppOpenAdManager?.showAdIfAvailable(it) }
        }
    }


    fun showAdIfAvailable(
        activity: Activity, onShowAdCompleteListener: OnShowAdCompleteListener?
    ) {
        googleAppOpenAdManager?.showAdIfAvailable(activity, onShowAdCompleteListener)
    }

    fun isAdAvailable(activity: Activity): Boolean {
        return googleAppOpenAdManager?.isAdAvailable()!!
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

    override fun onActivityStarted(activity: Activity) {
        if (googleAppOpenAdManager != null) {
            if (!googleAppOpenAdManager!!.isShowingAd) currentActivity = activity
        } else {
            currentActivity = activity
        }
    }

    override fun onActivityResumed(activity: Activity) {
//        currentActivity = activity
    }

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {}

    interface OnShowAdCompleteListener {
        fun onShowAdComplete(isFailed: Boolean)
    }

    private inner class GoogleAppOpenAdManager {

        private var appOpenAd: AppOpenAd? = null
        private var isLoadingAd = false
        var isShowingAd = false
        private var appOpenIndex = 0

        private var loadTime: Long = 0

        fun loadAd(context: Context) {
            if (isLoadingAd || isAdAvailable()) {
                return
            }
            isLoadingAd = true
            val request = AdRequest.Builder().build()
            val placementId = getPlacementId(context)
            AppOpenAd.load(context,
                placementId,
                request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        loge("AppOpenAdManager:onAdLoaded")
                        appOpenAd = ad
                        isLoadingAd = false
                        loadTime = Date().time
                        if (onSplashAd != null) {
                            showAdIfAvailable(currentActivity!!)
                        }
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        loge("AppOpenAdManager:onAdFailedToLoad:${loadAdError.message}")
                        appOpenAd = null
                        isLoadingAd = false
                        if (AdsUtils.getAdPref(context).appOpenBackFill) {
                            loadAdOnFail(context)
                        } else {
                            onSplashAd?.onAdClosed(true)
                        }
                    }
                })
        }

        private fun loadAdOnFail(context: Context) {
            if (isLoadingAd || isAdAvailable()) {
                return
            }
            isLoadingAd = true
            val request = AdRequest.Builder().build()
            val placementId = getPlacementIdOnFail(context)
            if (placementId.equals("", true)) {
                onSplashAd?.onAdClosed(true)
                return
            }
            AppOpenAd.load(context,
                placementId,
                request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        loge("AppOpenAdManager:onAdLoaded")
                        appOpenAd = ad
                        isLoadingAd = false
                        loadTime = Date().time
                        if (onSplashAd != null) {
                            showAdIfAvailable(currentActivity!!)
                        }
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        loge("AppOpenAdManager:onAdFailedToLoad:${loadAdError.message}")
                        appOpenAd = null
                        isLoadingAd = false
                        loadAdOnFail(context)
                    }
                })
        }

        private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
            val dateDifference: Long = Date().time - loadTime
            val numMilliSecondsPerHour: Long = 3600000
            return dateDifference < numMilliSecondsPerHour * numHours
        }

        fun isAdAvailable(): Boolean {
            return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
        }

        fun showAdIfAvailable(activity: Activity) {
            showAdIfAvailable(activity, object : OnShowAdCompleteListener {
                override fun onShowAdComplete(isFailed: Boolean) {
                    onSplashAd?.onAdClosed(isFailed)
                }
            })
        }

        fun showAdIfAvailable(
            activity: Activity, onShowAdCompleteListener: OnShowAdCompleteListener?
        ) {
            if (!AdsUtils.isAdEnabled(this@MainApplication)) {
                onShowAdCompleteListener?.onShowAdComplete(false)
                return
            }
            if (isShowingAd) {
                loge("AppOpenAdManager : The app open ad is already showing.")
                return
            }

            if (!isAdAvailable()) {
                loge("AppOpenAdManager : The app open ad is not ready yet.")
                onShowAdCompleteListener?.onShowAdComplete(true)
                loadAd(activity)
                return
            }
            loge("AppOpenAdManager : Will show ad.")
            appOpenAd!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    isShowingAd = false
                    loge("AppOpenAdManager : onAdDismissedFullScreenContent.")
                    onShowAdCompleteListener?.onShowAdComplete(false)
                    loadAd(activity)
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    appOpenAd = null
                    isShowingAd = false
                    loge("AppOpenAdManager : onAdFailedToShowFullScreenContent: ${adError.message}")
                    onShowAdCompleteListener?.onShowAdComplete(true)
                    loadAd(activity)
                }

                override fun onAdShowedFullScreenContent() {
                    isShowingAd = true
                    loge("AppOpenAdManager : onAdShowedFullScreenContent.")
                }

                override fun onAdImpression() {
                    CustomEvents.appOpenAd(this@MainApplication, CustomEvents.ADMOB)
                }
            }
            appOpenAd!!.show(activity)
        }

        fun release() {
            currentActivity = null
            appOpenAd = null
        }

        private fun getPlacementId(context: Context): String {
            val ids = AdsUtils.getAdPref(context).appOpenIds
            appOpenIndex = 0
            return ids[appOpenIndex]
        }

        private fun getPlacementIdOnFail(context: Context): String {
            val ids = AdsUtils.getAdPref(context).appOpenIds
            appOpenIndex++
            return if (appOpenIndex < ids.size) {
                ids[appOpenIndex]
            } else {
                ""
            }
        }
    }


//    *********app uses***************

    companion object {
        private var instance: MainApplication? = null

        @JvmStatic
        fun getInstance(): MainApplication? {
            return instance
        }

        @JvmStatic
        fun getScreenWidth(): Int {
            return screenWidth
        }

        private const val screenWidth = 1920
    }

    private fun initMemorySize() {
        maxMemory = Runtime.getRuntime().maxMemory()
        Log.e(
            "str",
            "Maximum application memory:" + java.lang.Long.toString(maxMemory / 1 shl 10) + "MB"
        )
    }

    override fun attachBaseContext(context: Context?) {
        super.attachBaseContext(context)
    }

    private fun initAppComponent() {
        this.appComponent =
            Dagger_App__Component.builder().appModule(App_Module_di(MainApplication.instance))
                .build()
    }


//********************end**********************
}