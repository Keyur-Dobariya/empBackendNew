package com.hd.video.downloader.play.video.ads.commons

import android.app.Activity
import android.app.Application
import android.content.Context
import com.hd.video.downloader.play.video.ads.api.AdsClient
import com.hd.video.downloader.play.video.ads.app.MainApplication
import com.hd.video.downloader.play.video.ads.interfaces.OnFirstData
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds
import com.hd.video.downloader.play.video.ads.model.FirstData
import com.hd.video.downloader.play.video.ads.nativee.PreloadNativeAds
import com.hd.video.downloader.play.video.ads.nativee.PreloadSmallNativeAds
import com.hd.video.downloader.play.video.ads.reward.RewardInterstitialAds
import com.hd.video.downloader.play.video.ads.reward.RewardVideoAds
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object AdsManager {
    @JvmStatic
    fun getFirstData(
        application: Application, context: Context, activity: Activity, onFirstData: OnFirstData?
    ) {
        AdsClient.getClient().getFirstDataCall(context.packageName.replace(".", "_").plus("3"))
            .enqueue(object : Callback<FirstData> {
                override fun onResponse(call: Call<FirstData>, response: Response<FirstData>) {
                    if (response.body() != null) {
                        val appData = AdsUtils.decrypt(response.body()!!.data)
                        AdsUtils.saveAdPref(context, appData!!)
                        AdsUtils.initNextAds(context)
                        initAppOpenAd(context, application, activity, onFirstData)
                        RewardVideoAds.load(context)
                        RewardInterstitialAds.load(context)
                        PreloadNativeAds.loadAd(context)
                        PreloadSmallNativeAds.loadAd(context)
                    } else {
                        onFirstData?.onFailed()
                    }
                }

                override fun onFailure(call: Call<FirstData>, t: Throwable) {
                    onFirstData?.onFailed()
                }
            })
        AdsUtils.getMoreApps(context)
    }

    private fun initAppOpenAd(
        context: Context, application: Application, activity: Activity, onFirstData: OnFirstData?
    ) {
        val mainApplication = application as? MainApplication
        if (mainApplication == null) {
            handler(4000) { onFirstData?.onSuccess() }
        } else if (AdsUtils.isAppOpenEnabled(context)) {
            if (AdsUtils.isSplashAppOpenEnabled(context)) {
                mainApplication.initAppOpenManager(activity, object : MainApplication.OnSplashAd {
                    override fun onAdClosed(isFailed: Boolean) {
                        mainApplication.onSplashAd = null
                        if (isFailed) {
                            AdsUtils.ignoreIntSkip(context)
                        }
                        InterstitialAds.loadAd(context)
                        onFirstData?.onSuccess()
                    }
                })
            } else {
                mainApplication.initAppOpenManager()
            }
        } else {
            handler(4000) { onFirstData?.onSuccess() }
        }
    }

    @JvmStatic
    fun release(application: Application) {
        AdsUtils.reset()
        (application as? MainApplication)?.release()
        InterstitialAds.release()
        PreloadNativeAds.release()
        PreloadSmallNativeAds.release()
        RewardInterstitialAds.release()
        RewardVideoAds.release()
    }
}