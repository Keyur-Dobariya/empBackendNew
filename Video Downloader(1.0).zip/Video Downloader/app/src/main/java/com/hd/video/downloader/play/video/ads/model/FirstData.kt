package com.hd.video.downloader.play.video.ads.model

import com.google.gson.annotations.SerializedName

data class FirstData(@JvmField @field:SerializedName("data") val data: String)
