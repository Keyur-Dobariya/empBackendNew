package com.hd.video.downloader.play.video.downloader_downloader;

import java.util.ArrayList;
import java.util.List;

public class AppConfig {
    public static final String DAILIMOTION_UA = "Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>";
    public static final String M4A = ".m4a";
    public static final String MP3 = ".mp3";
    public static final String MP4 = ".mp4";
    public static String MUSIC = "music";
    public static List<String> REGEXVIDEOS = new ArrayList();
    public static final String Tag = "VideoDownloader";
    public static String VIDEO = "video";
}
