package com.hd.video.downloader.play.video.downloader_downloader;

import android.util.Log;


import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConnectThread implements Runnable {
    private volatile boolean isRunning;
    private final ConnectListener listener;
    private final String url;

    public interface ConnectListener {
        void onConnectError(String str);

        void onConnected(boolean z, int i);
    }

    public ConnectThread(String str, ConnectListener connectListener) {
        this.url = str;
        this.listener = connectListener;
    }

    public void cancel() {
        Thread.currentThread().interrupt();
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    HttpURLConnection httpURLConnection;

    public void run() {
        this.isRunning = true;
        try {
            Log.e("kkkkkkkkkkkkkkk", "this.url::::::::" + this.url);
            httpURLConnection = (HttpURLConnection) new URL(this.url).openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setReadTimeout(10000);
            int responseCode = httpURLConnection.getResponseCode();
            int contentLength = httpURLConnection.getContentLength();
            Log.e("kkkkkkkkkkkkkkk", "responseCode::::::::" + responseCode);
            Log.e("kkkkkkkkkkkkkkk", "contentLength::::::::" + contentLength);
            if (responseCode == 200) {
                this.listener.onConnected("bytes".equals(httpURLConnection.getHeaderField("Accept-Ranges")), contentLength);
            } else {
                this.listener.onConnectError("server error:" + responseCode);
            }
            this.isRunning = false;
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
        } catch (IOException e) {
            IOException e2 = e;
            Log.e("kkkkkkkkkkkkkkk", "responseCode:::eeeeeeee:::::" + e2);
            this.isRunning = false;
            this.listener.onConnectError(e2.getMessage());
            if (httpURLConnection == null) {
            }
        } catch (Throwable ignored) {
        }
    }
}