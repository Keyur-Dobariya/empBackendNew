package com.hd.video.downloader.play.video.downloader_downloader;

import android.util.Log;


import com.hd.video.downloader.play.video.StartAppActivity;

import java.io.File;

public class DownloadConfig {
    private static DownloadConfig mConfig;
    private File downloadDir = null;
    private int max_download_tasks = 5;
    private int max_download_threads = 3;
    private int max_retry_count = 5;
    private int min_operate_interval = 1000;
    private boolean recoverDownloadWhenStart = true;

    private DownloadConfig() {
        File file = new File((StartAppActivity.DownloadPath));
        this.downloadDir = file;
        if (!file.exists()) {
            this.downloadDir.mkdir();
        }
        Log.e("sssssssssssss", "downloadocnfig::::::::::::" + this.downloadDir);
    }

    public static DownloadConfig getConfig() {
        if (mConfig == null) {
            mConfig = new DownloadConfig();
        }
        return mConfig;
    }

    public File getDownloadFile(String str) {
        return new File(this.downloadDir, str);
    }

    public String getDownloadPath(String str) {
        return new File(this.downloadDir, str).getAbsolutePath();
    }

    public int getMaxDownloadTasks() {
        return this.max_download_tasks;
    }

    public int getMaxDownloadThreads() {
        return this.max_download_threads;
    }

    public int getMaxRetryCount() {
        return this.max_retry_count;
    }

    public int getMinOperateInterval() {
        return this.min_operate_interval;
    }

    public boolean isRecoverDownloadWhenStart() {
        return this.recoverDownloadWhenStart;
    }

}
