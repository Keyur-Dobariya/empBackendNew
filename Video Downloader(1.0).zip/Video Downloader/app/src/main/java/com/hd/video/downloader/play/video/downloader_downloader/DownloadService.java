package com.hd.video.downloader.play.video.downloader_downloader;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.documentfile.provider.DocumentFile;

import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.StartAppActivity;
import com.hd.video.downloader.play.video.downloader_downloader.db.DBController;
import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;
import com.hd.video.downloader.play.video.downloader_downloader.notify.DataChanger;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

public class DownloadService extends Service {
    BroadcastReceiver a = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            Log.e("sssssssss", "onReceive.onReceive:::::DownloadService:::::" + context);
            String action = intent.getAction();
            int hashCode = action.hashCode();
            if (hashCode == -1172645946) {
                action.equals("android.net.conn.CONNECTIVITY_CHANGE");
            } else if (hashCode == 81044240 && action.equals(AppConstant.ACTION.NOTIFICATION_DELETED_ACTION) && (intent.getSerializableExtra(AppConstant.KEY.ENTRY) instanceof DownloadEntry)) {
                DownloadEntry downloadEntry = (DownloadEntry) intent.getSerializableExtra(AppConstant.KEY.ENTRY);
                Log.e("str", "cancel---" + downloadEntry.name);
                notificationManager.cancel(downloadEntry.name, downloadEntry.name.hashCode());
            }
        }
    };
    private NotificationCompat.Builder builder;
    private MyBinder mBinder = new MyBinder();
    private DBController mDBController;
    public DataChanger mDataChanger;
    private HashMap<String, DownloadTask> mDownloadingTasks = new HashMap<>();
    private ExecutorService mExecutors;
    @SuppressLint({"WrongConstant", "HandlerLeak"})
    private Handler mHandler = new Handler() {

        public void handleMessage(Message message) {
            super.handleMessage(message);
            @SuppressLint("HandlerLeak") final DownloadEntry downloadEntry = (DownloadEntry) message.obj;
            @SuppressLint("HandlerLeak") int i = message.what;
            Log.e("sssssssss", "i.onReceive:::::i:::::" + i);
            if (i != 6) {
                if (i != 2) {
                    if (i != 3) {
                        if (i == 4) {
                            synchronized (this) {
                                Log.e("str", "completed_path===" + downloadEntry.path);
                                if (SharedConfig.getInstance(DownloadService.this).readBoolean(AppConstant.KEY.AUTOSAVEALUM, true)) {
                                    new Thread(new Runnable() {
                                        public void run() {
                                            @SuppressLint("HandlerLeak") File file = new File(StartAppActivity.DownloadPath);
                                            Log.e("hhhhhhhhhhhhhhh", "pathname::file::::::::" + file);
                                            if (!file.exists()) {
                                                file.mkdirs();
                                            }
                                        }
                                    }).start();
                                }
                                setNotifyCompleted(downloadEntry);
                                sendBroadcast(new Intent(AppConstant.ACTION.DOWNLOAD_COMPLETE));
                                checkNext(downloadEntry);
                            }
                            Toast.makeText(getApplicationContext(), "Download completed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    Log.e("sssssssss", "i.notificationManager:::::i:::::" + i);
                    notificationManager.cancelAll();
                    builder.setOngoing(false);
                    notificationManager.cancel(downloadEntry.name.hashCode());
                    stopForeground(true);
                } else {
                    setNotify(downloadEntry.percent, downloadEntry);
                }
            } else if (downloadEntry.retry < DownloadConfig.getConfig().getMaxRetryCount() && downloadEntry.status == DownloadEntry.DownloadStatus.error) {
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        downloadEntry.retry++;
                        DownloadManager.getInstance(DownloadService.this).newOrUpdate(downloadEntry);
                        startDownload(downloadEntry);
                    }
                }, 20000);
                mDataChanger.postStatus(downloadEntry);
            }
            checkNext(downloadEntry);
            mDataChanger.postStatus(downloadEntry);
        }
    };
    private LinkedBlockingDeque<DownloadEntry> mWaitingQueue = new LinkedBlockingDeque<>();
    public NotificationManager notificationManager;

    private static void scanFile(Uri uri, Context context) {
        context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", uri));
    }

    public static void scanFile(String str, Context context) {
        if (str != null) {
            DocumentFile documentFile = getDocumentFile(new File(str), false, context);
            if (documentFile == null) {
                documentFile = DocumentFile.fromFile(new File(str));
            }
            scanFile(documentFile.getUri(), context);
        }
    }

    public static DocumentFile getDocumentFile(File file, boolean z, Context context) {
        String str;
        boolean z2;
        Uri parse = null;
        String extSdCardFolder = getExtSdCardFolder(file, context);
        if (extSdCardFolder == null) {
            return null;
        }
        int i = 0;
        try {
            String canonicalPath = file.getCanonicalPath();
            if (!extSdCardFolder.equals(canonicalPath)) {
                str = canonicalPath.substring(extSdCardFolder.length() + 1);
                z2 = false;
                String string = PreferenceManager.getDefaultSharedPreferences(context).getString("URI", null);
                parse = string == null ? Uri.parse(string) : null;
                if (parse != null) {
                    return null;
                }
                DocumentFile fromTreeUri = DocumentFile.fromTreeUri(context, parse);
                if (z2) {
                    return fromTreeUri;
                }
                String[] split = str.split("\\/");
                while (i < split.length) {
                    DocumentFile findFile = fromTreeUri.findFile(split[i]);
                    fromTreeUri = findFile == null ? (i < split.length - 1 || z) ? fromTreeUri.createDirectory(split[i]) : fromTreeUri.createFile("image", split[i]) : findFile;
                    i++;
                }
                return fromTreeUri;
            }
        } catch (IOException unused) {
            return null;
        } catch (Exception unused2) {
        }
        str = null;
        z2 = true;
        String string2 = PreferenceManager.getDefaultSharedPreferences(context).getString("URI", null);
        if (string2 == null) {
        }
        if (parse != null) {
        }
        return null;
    }

    private static String getExtSdCardFolder(File file, Context context) {
        String[] extSdCardPaths = getExtSdCardPaths(context);
        for (int i = 0; i < extSdCardPaths.length; i++) {
            try {
                if (file.getCanonicalPath().startsWith(extSdCardPaths[i])) {
                    return extSdCardPaths[i];
                }
            } catch (IOException unused) {
            }
        }
        return null;
    }

    private static String[] getExtSdCardPaths(Context context) {
        int lastIndexOf;
        ArrayList arrayList = new ArrayList();
        File[] externalFilesDirs = context.getExternalFilesDirs("external");
        for (File file : externalFilesDirs) {
            if (file != null && !file.equals(context.getExternalFilesDir("external")) && (lastIndexOf = file.getAbsolutePath().lastIndexOf("/Android/data")) >= 0) {
                String substring = file.getAbsolutePath().substring(0, lastIndexOf);
                try {
                    substring = new File(substring).getCanonicalPath();
                } catch (IOException unused) {
                }
                arrayList.add(substring);
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.add("/storage/sdcard1");
        }
        return (String[]) arrayList.toArray(new String[0]);
    }

    public class MyBinder extends Binder {
        public MyBinder() {
        }

        public DownloadService getService() {
            return DownloadService.this;
        }
    }

    private void addDownload(DownloadEntry downloadEntry) {
        Log.e("str", "addDownload");
        initNotify(downloadEntry);
        if (this.mDownloadingTasks.size() >= DownloadConfig.getConfig().getMaxDownloadTasks()) {
            this.mWaitingQueue.offer(downloadEntry);
            downloadEntry.status = DownloadEntry.DownloadStatus.waiting;
            this.mDataChanger.postStatus(downloadEntry);
            return;
        }
        Log.e("kkkkkkkkkkkkkkk", "addDownload:::addDownload:::::" + downloadEntry);
        startDownload(downloadEntry);
    }

    public void checkNext(DownloadEntry downloadEntry) {
        Log.e("kkkkkkkkk", "checkNext:::::checkNext:::::" + this.mDownloadingTasks);
        DownloadEntry poll = this.mWaitingQueue.poll();
        if (poll != null) {
            startDownload(poll);
        }
    }

    private void doAction(int i, DownloadEntry downloadEntry) {
        Log.e("kkkkkkkk", "doAction:::::22222:::::" + i);
        switch (i) {
            case 1:
                addDownload(downloadEntry);
                return;
            case 2:
                pauseDownload(downloadEntry);
                return;
            case 3:
                resumeDownload(downloadEntry);
                return;
            case 4:
                cancelDownload(downloadEntry);
                return;
            case 5:
                pauseAll();
                return;
            case 6:
                recoverAll();
                return;
            default:
                return;
        }
    }

    private synchronized void initNotify(DownloadEntry downloadEntry) {
        Log.e("str", "initNotify");
        NotificationCompat.Builder builder2 = new NotificationCompat.Builder(this);
        this.builder = builder2;
        builder2.setTicker(downloadEntry.name);
        this.builder.setContentTitle(downloadEntry.name);
        this.builder.setContentText("0/100");
        this.builder.setWhen(System.currentTimeMillis());
        this.builder.setSmallIcon(R.mipmap.ic_launcher);
        this.builder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher));
        this.builder.setProgress(100, 0, false);
        this.builder.setOngoing(true);

        PendingIntent activity = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity = PendingIntent.getBroadcast
                    (this, downloadEntry.name.hashCode(), new Intent(AppConstant.ACTION.NOTIFICATION_DELETED_ACTION).putExtra(AppConstant.KEY.ENTRY, downloadEntry), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_CANCEL_CURRENT);
        } else {
            activity = PendingIntent.getBroadcast
                    (this, downloadEntry.name.hashCode(), new Intent(AppConstant.ACTION.NOTIFICATION_DELETED_ACTION).putExtra(AppConstant.KEY.ENTRY, downloadEntry), PendingIntent.FLAG_CANCEL_CURRENT);
        }

        this.builder.setDeleteIntent(activity);
        Intent intent = new Intent(this, StartAppActivity.class);
        intent.putExtra(AppConstant.KEY.CURREUNT_ITEM, 1);

        PendingIntent activity1 = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity1 = PendingIntent.getActivity
                    (this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_CANCEL_CURRENT);
        } else {
            activity1 = PendingIntent.getActivity
                    (this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        }

        this.builder.setContentIntent(activity1);
        if (Build.VERSION.SDK_INT >= 26) {
            Log.e("uuuuuuuuuuuuuu", "NotificationListener:::::::");
            NotificationChannel notificationChannel = new NotificationChannel("10001", "NOTIFICATION_CHANNEL_NAME", NotificationManager.IMPORTANCE_DEFAULT);
            this.builder.setChannelId("10001");
            notificationChannel.enableLights(false);
            notificationChannel.enableVibration(false);
            notificationChannel.setVibrationPattern(new long[]{0});
            notificationChannel.setSound(null, null);
            this.notificationManager.createNotificationChannel(notificationChannel);
        }
        this.notificationManager.notify(downloadEntry.name, downloadEntry.name.hashCode(), this.builder.build());
    }

    private void initReceiver() {
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        IntentFilter intentFilter2 = new IntentFilter(AppConstant.ACTION.DOWNLOAD_FAILED);
        IntentFilter intentFilter3 = new IntentFilter(AppConstant.ACTION.DOWNLOAD_CANCEL);
        IntentFilter intentFilter4 = new IntentFilter(AppConstant.ACTION.NOTIFICATION_DELETED_ACTION);
        registerReceiver(this.a, intentFilter);
        registerReceiver(this.a, intentFilter2);
        registerReceiver(this.a, intentFilter4);
        registerReceiver(this.a, intentFilter3);
    }

    private void intializeDownload() {
        ArrayList<DownloadEntry> queryAll = this.mDBController.queryAll();
        if (queryAll != null) {
            Iterator<DownloadEntry> it = queryAll.iterator();
            while (it.hasNext()) {
                DownloadEntry next = it.next();
                if (next.status == DownloadEntry.DownloadStatus.downloading || next.status == DownloadEntry.DownloadStatus.waiting) {
                    if (DownloadConfig.getConfig().isRecoverDownloadWhenStart()) {
                        if (next.isSupportRange) {
                            next.status = DownloadEntry.DownloadStatus.paused;
                        } else {
                            next.status = DownloadEntry.DownloadStatus.idle;
                            next.reset();
                        }
                        addDownload(next);
                    } else {
                        if (next.isSupportRange) {
                            next.status = DownloadEntry.DownloadStatus.paused;
                        } else {
                            next.status = DownloadEntry.DownloadStatus.idle;
                            next.reset();
                        }
                        this.mDBController.newOrUpdate(next);
                    }
                }
                this.mDataChanger.addToOperatedEntryMap(next.id, next);
            }
        }
    }

    private void pauseAll() {
        while (this.mWaitingQueue.iterator().hasNext()) {
            DownloadEntry poll = this.mWaitingQueue.poll();
            poll.status = DownloadEntry.DownloadStatus.paused;
            this.mDataChanger.postStatus(poll);
        }
        for (Map.Entry<String, DownloadTask> entry : this.mDownloadingTasks.entrySet()) {
            entry.getValue().pause();
        }
        this.mDownloadingTasks.clear();
    }

    private void pauseDownload(DownloadEntry downloadEntry) {
        Log.e("sssssssss", "mDownloadingTasks:::::mDownloadingTasks:::::" + this.mDownloadingTasks);
        DownloadTask remove = this.mDownloadingTasks.remove(downloadEntry.id);
        Log.e("sssssssss", "mDownloadingTasks:::::22222:::::" + this.mDownloadingTasks);
        Log.e("sssssssss", "mDownloadingTasks:::::downloadTask:::::" + remove);
        if (remove != null) {
            Log.e("sssssssss", "downloadTask:::::22222:::::" + remove);
            remove.pause();
            return;
        }
        this.mWaitingQueue.remove(downloadEntry);
        downloadEntry.status = DownloadEntry.DownloadStatus.paused;
        this.mDataChanger.postStatus(downloadEntry);
    }

    private void recoverAll() {
        ArrayList<DownloadEntry> queryAllRecoverableEntries = this.mDataChanger.queryAllRecoverableEntries();
        if (queryAllRecoverableEntries != null) {
            Iterator<DownloadEntry> it = queryAllRecoverableEntries.iterator();
            while (it.hasNext()) {
                addDownload(it.next());
            }
        }
    }

    public void recoverDownloadError() {
        ArrayList<DownloadEntry> queryAllRecoverableEntries = this.mDataChanger.queryAllRecoverableEntries();
        if (queryAllRecoverableEntries != null) {
            Iterator<DownloadEntry> it = queryAllRecoverableEntries.iterator();
            while (it.hasNext()) {
                Log.e("kkkkkkkkkkkkkkk", "responseCode:::ititititititititititit:::::" + it);
                addDownload(it.next());
            }
        }
    }

    private void resumeDownload(DownloadEntry downloadEntry) {
        addDownload(downloadEntry);
    }

    public void startDownload(DownloadEntry downloadEntry) {
        DownloadTask downloadTask = new DownloadTask(downloadEntry, this.mHandler, this.mExecutors);
        downloadTask.start();
        Log.e("sssssssss", "startDownload:::::startDownload:::::" + downloadTask);
        Log.e("kkkkkkkkkkkkkkk", "startDownload:::startDownload:::::" + downloadEntry);
        this.mDownloadingTasks.put(downloadEntry.id, downloadTask);
    }

    public void cancelDownload(DownloadEntry downloadEntry) {
        DownloadManager.getInstance(this).deleteDownloadEntry(true, downloadEntry);
        this.notificationManager.cancel(downloadEntry.name, downloadEntry.name.hashCode());
        DownloadTask remove = this.mDownloadingTasks.remove(downloadEntry.id);
        if (remove != null) {
            remove.cancel();
            return;
        }
        this.mWaitingQueue.remove(downloadEntry);
        downloadEntry.status = DownloadEntry.DownloadStatus.cancelled;
        this.mDataChanger.postStatus(downloadEntry);
    }

    public IBinder onBind(Intent intent) {
        return this.mBinder;
    }

    public void onCreate() {
        super.onCreate();
        initReceiver();
        this.notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        this.mExecutors = Executors.newCachedThreadPool();
        this.mDataChanger = DataChanger.getInstance(getApplication());
        this.mDBController = DBController.getInstance(getApplication());
        intializeDownload();
    }

    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(this.a);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent != null) {
            DownloadEntry downloadEntry = (DownloadEntry) intent.getSerializableExtra(AppConstant.KEY_DOWNLOAD_ENTRY);
            if (downloadEntry != null && this.mDataChanger.containsDownloadEntry(downloadEntry.id)) {
                downloadEntry = this.mDataChanger.queryDownloadEntryById(downloadEntry.id);
            }
            doAction(intent.getIntExtra(AppConstant.KEY_DOWNLOAD_ACTION, -1), downloadEntry);
        }
        return super.onStartCommand(intent, i, i2);
    }

    public void setNotify(int i, DownloadEntry downloadEntry) {
        this.builder.setProgress(100, i, false);
        this.builder.setContentTitle(downloadEntry.name);
        NotificationCompat.Builder builder2 = this.builder;
        builder2.setContentText(i + "/100");
        Intent intent = new Intent(this, StartAppActivity.class);
        intent.putExtra(AppConstant.KEY.CURREUNT_ITEM, 1);

        PendingIntent activity = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity = PendingIntent.getActivity
                    (this, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_CANCEL_CURRENT);
        } else {
            activity = PendingIntent.getActivity
                    (this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        }


        this.builder.setContentIntent(activity);
        if (Build.VERSION.SDK_INT >= 26) {
            Log.e("uuuuuuuuuuuuuu", "NotificationListener:::::::");
            NotificationChannel notificationChannel = new NotificationChannel("10001", "NOTIFICATION_CHANNEL_NAME", NotificationManager.IMPORTANCE_DEFAULT);
            builder2.setChannelId("10001");
            notificationChannel.enableLights(false);
            notificationChannel.enableVibration(false);
            notificationChannel.setVibrationPattern(new long[]{0});
            notificationChannel.setSound(null, null);
            this.notificationManager.createNotificationChannel(notificationChannel);
        }
        this.notificationManager.notify(downloadEntry.name, downloadEntry.name.hashCode(), this.builder.build());
    }

    public void setNotifyCompleted(DownloadEntry downloadEntry) {
        Intent intent = new Intent(this, StartAppActivity.class);
        if (!TextUtils.isEmpty(downloadEntry.type)) {
            if (downloadEntry.type.equals(AppConfig.MUSIC)) {
                intent.putExtra(AppConstant.KEY.CURREUNT_ITEM, 1);
            } else if (downloadEntry.type.equals(AppConfig.VIDEO)) {
                intent.putExtra(AppConstant.KEY.CURREUNT_ITEM, 0);
            }
        }
        intent.putExtra(AppConstant.KEY.ENTRY, downloadEntry);
        Log.e("str", "entry.name.hashCode()===" + downloadEntry.name.hashCode());
        Log.e("str", "entry.name===" + downloadEntry.name);


        PendingIntent activity1 = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity1 = PendingIntent.getActivity
                    (this, downloadEntry.name.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_CANCEL_CURRENT);
        } else {
            activity1 = PendingIntent.getActivity
                    (this, downloadEntry.name.hashCode(), intent, PendingIntent.FLAG_CANCEL_CURRENT);
        }


        this.builder.setContentIntent(activity1);
        this.builder.setContentTitle(downloadEntry.name);
        this.builder.setAutoCancel(true);
        this.builder.setOngoing(false);
        this.builder.setContentText(getResources().getString(R.string.downloaded)).setProgress(0, 0, false);
        if (Build.VERSION.SDK_INT >= 26) {
            Log.e("uuuuuuuuuuuuuu", "NotificationListener:::::::");
            NotificationChannel notificationChannel = new NotificationChannel("10001", "NOTIFICATION_CHANNEL_NAME", NotificationManager.IMPORTANCE_DEFAULT);
            this.builder.setChannelId("10001");
            notificationChannel.enableLights(false);
            notificationChannel.enableVibration(false);
            notificationChannel.setVibrationPattern(new long[]{0});
            notificationChannel.setSound(null, null);
            this.notificationManager.createNotificationChannel(notificationChannel);
        }
        this.notificationManager.notify(downloadEntry.name, downloadEntry.name.hashCode(), this.builder.build());
    }
}