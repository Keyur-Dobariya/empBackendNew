package com.hd.video.downloader.play.video.downloader_downloader;

import android.os.Handler;
import android.os.Message;
import android.util.Log;


import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;

import java.io.File;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;

public class DownloadTask implements ConnectThread.ConnectListener, DownloadThread.DownloadListener {
    private File destFile;
    private final DownloadEntry entry;
    private volatile boolean isCancelled;
    private volatile boolean isPaused;
    private ConnectThread mConnectThread;
    private DownloadEntry.DownloadStatus[] mDownloadStatus;
    private DownloadThread[] mDownloadThreads;
    private final ExecutorService mExecutor;
    private final Handler mHandler;

    public DownloadTask(DownloadEntry downloadEntry, Handler handler, ExecutorService executorService) {
        this.entry = downloadEntry;
        this.mHandler = handler;
        this.mExecutor = executorService;
        this.destFile = DownloadConfig.getConfig().getDownloadFile(downloadEntry.name);
    }

    private void notifyUpdate(DownloadEntry downloadEntry, int i) {
        int i2;
        if (downloadEntry.totalLength != 0 && (i2 = (downloadEntry.currentLength * 100) / downloadEntry.totalLength) >= 0 && i2 <= 100) {
            downloadEntry.percent = i2;
        }
        Log.e("sssssssss", "notifyUpdate:::::notifyUpdate:::::" + i);
        Message obtainMessage = this.mHandler.obtainMessage();
        obtainMessage.what = i;
        obtainMessage.obj = downloadEntry;
        this.mHandler.sendMessage(obtainMessage);
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void resetDownload() {
        this.entry.reset();
    }

    private void startDownload() {
        StringBuilder sb = new StringBuilder();
        sb.append("startDownload:::this.entry.isSupportRange:::::");
        sb.append(this.entry.isSupportRange);
        Log.e("kkkkkkkkkkkkkkk", sb.toString());
        if (this.entry.isSupportRange) {
            startMultiDownload();
        } else {
            startSingleDownload();
        }
    }

    private void startMultiDownload() {
        this.entry.status = DownloadEntry.DownloadStatus.downloading;
        notifyUpdate(this.entry, 1);
        int maxDownloadThreads = this.entry.totalLength / DownloadConfig.getConfig().getMaxDownloadThreads();
        int i = 0;
        if (this.entry.ranges == null) {
            this.entry.ranges = new HashMap<>();
            for (int i2 = 0; i2 < DownloadConfig.getConfig().getMaxDownloadThreads(); i2++) {
                this.entry.ranges.put(Integer.valueOf(i2), 0);
            }
        }
        this.mDownloadThreads = new DownloadThread[DownloadConfig.getConfig().getMaxDownloadThreads()];
        this.mDownloadStatus = new DownloadEntry.DownloadStatus[DownloadConfig.getConfig().getMaxDownloadThreads()];
        Log.e("kkkkkkkkkkkkkkk", "startSingleDownload:::this.entry.mDownloadStatus:::::" + this.mDownloadStatus);
        while (i < DownloadConfig.getConfig().getMaxDownloadThreads()) {
            int intValue = (i * maxDownloadThreads) + this.entry.ranges.get(Integer.valueOf(i)).intValue();
            int i3 = i == DownloadConfig.getConfig().getMaxDownloadThreads() - 1 ? this.entry.totalLength : ((i + 1) * maxDownloadThreads) - 1;
            if (intValue < i3) {
                this.mDownloadThreads[i] = new DownloadThread(this.entry.url, this.destFile, i, intValue, i3, this);
                this.mDownloadStatus[i] = DownloadEntry.DownloadStatus.downloading;
                this.mExecutor.execute(this.mDownloadThreads[i]);
            } else {
                this.mDownloadStatus[i] = DownloadEntry.DownloadStatus.completed;
            }
            i++;
        }
    }

    private void startSingleDownload() {
        this.entry.status = DownloadEntry.DownloadStatus.downloading;
        notifyUpdate(this.entry, 1);
        DownloadEntry.DownloadStatus[] downloadStatusArr = new DownloadEntry.DownloadStatus[1];
        this.mDownloadStatus = downloadStatusArr;
        downloadStatusArr[0] = this.entry.status;
        DownloadThread[] downloadThreadArr = new DownloadThread[1];
        this.mDownloadThreads = downloadThreadArr;
        DownloadThread downloadThread = new DownloadThread(this.entry.url, this.destFile, 0, 0, 0, this);
        downloadThreadArr[0] = downloadThread;
        Log.e("kkkkkkkkkkkkkkk", "startSingleDownload:::this.entry.downloadThread:::::" + downloadThread);
        this.mExecutor.execute(this.mDownloadThreads[0]);
    }

    public void cancel() {
        this.isCancelled = true;
        ConnectThread connectThread = this.mConnectThread;
        if (connectThread != null && connectThread.isRunning()) {
            this.mConnectThread.cancel();
        }
        DownloadThread[] downloadThreadArr = this.mDownloadThreads;
        if (downloadThreadArr != null && downloadThreadArr.length > 0) {
            int i = 0;
            while (true) {
                DownloadThread[] downloadThreadArr2 = this.mDownloadThreads;
                if (i < downloadThreadArr2.length) {
                    if (downloadThreadArr2[i] != null && downloadThreadArr2[i].isRunning()) {
                        this.mDownloadThreads[i].cancel();
                    }
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    @Override
    public void onConnectError(String str) {
        DownloadEntry downloadEntry;
        int i;
        Log.e("kkkkkkkkkkkkkkk", "onDownloadCompleted:::onConnectError:::::" + str);
        if (this.isPaused || this.isCancelled) {
            this.entry.status = this.isPaused ? DownloadEntry.DownloadStatus.paused : DownloadEntry.DownloadStatus.cancelled;
            downloadEntry = this.entry;
            i = 3;
        } else {
            this.entry.status = DownloadEntry.DownloadStatus.error;
            downloadEntry = this.entry;
            i = 6;
        }
        notifyUpdate(downloadEntry, i);
    }

    @Override
    public void onConnected(boolean z, int i) {
        this.entry.isSupportRange = z;
        this.entry.totalLength = i;
        startDownload();
    }

    @Override
    public synchronized void onDownloadCancelled(int i) {
        this.mDownloadStatus[i] = DownloadEntry.DownloadStatus.cancelled;
        for (int i2 = 0; i2 < this.mDownloadStatus.length; i2++) {
            if (this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.completed && this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.cancelled) {
                return;
            }
        }
        this.entry.status = DownloadEntry.DownloadStatus.cancelled;
        resetDownload();
        notifyUpdate(this.entry, 3);
    }

    @Override
    public void onDownloadCompleted(int i) {
        Log.e("kkkkkkkkkkkkkkk", "onDownloadCompleted:::onDownloadError:::::" + i);
        synchronized (this) {
            this.mDownloadStatus[i] = DownloadEntry.DownloadStatus.completed;
            for (int i2 = 0; i2 < this.mDownloadStatus.length; i2++) {
                if (this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.completed) {
                    return;
                }
            }
            if (this.entry.totalLength > 0) {
                if (this.entry.currentLength != this.entry.totalLength) {
                    this.entry.status = DownloadEntry.DownloadStatus.error;
                    resetDownload();
                    notifyUpdate(this.entry, 6);
                }
            }
            this.entry.status = DownloadEntry.DownloadStatus.completed;
            notifyUpdate(this.entry, 4);
        }
    }

    @Override
    public void onDownloadError(int i, String str) {
        synchronized (this) {
            Log.e("kkkkkkkkkkkkkkk", "responseCode:::onDownloadError:::::" + str);
            this.mDownloadStatus[i] = DownloadEntry.DownloadStatus.error;
            int i2 = 0;
            while (i2 < this.mDownloadStatus.length) {
                if (this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.completed) {
                    if (this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.error) {
                        if (this.mDownloadThreads[i2] != null) {
                            this.mDownloadThreads[i2].cancelByError();
                        }
                    }
                }
                i2++;
            }
            this.entry.status = DownloadEntry.DownloadStatus.error;
            notifyUpdate(this.entry, 6);
        }
    }

    @Override
    public synchronized void onDownloadPaused(int i) {
        this.mDownloadStatus[i] = DownloadEntry.DownloadStatus.paused;
        for (int i2 = 0; i2 < this.mDownloadStatus.length; i2++) {
            if (this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.completed && this.mDownloadStatus[i2] != DownloadEntry.DownloadStatus.paused) {
                return;
            }
        }
        this.entry.status = DownloadEntry.DownloadStatus.paused;
        notifyUpdate(this.entry, 3);
    }

    @Override
    public void onProgressChanged(int i, int i2) {
        synchronized (this) {
            if (this.entry.isSupportRange && this.entry.ranges != null) {
                this.entry.ranges.put(Integer.valueOf(i), Integer.valueOf(this.entry.ranges.get(Integer.valueOf(i)).intValue() + i2));
            }
            this.entry.currentLength += i2;
            if (TickTack.getInstance().needToNotify()) {
                if (this.entry.totalLength != 0 && this.entry.currentLength >= this.entry.totalLength) {
                    this.entry.status = DownloadEntry.DownloadStatus.completed;
                }
                notifyUpdate(this.entry, 2);
            }
        }
    }

    public void pause() {
        this.isPaused = true;
        ConnectThread connectThread = this.mConnectThread;
        if (connectThread != null && connectThread.isRunning()) {
            this.mConnectThread.cancel();
        }
        DownloadThread[] downloadThreadArr = this.mDownloadThreads;
        if (downloadThreadArr != null && downloadThreadArr.length > 0) {
            int i = 0;
            while (true) {
                DownloadThread[] downloadThreadArr2 = this.mDownloadThreads;
                if (i < downloadThreadArr2.length) {
                    if (downloadThreadArr2[i] != null && downloadThreadArr2[i].isRunning()) {
                        if (this.entry.isSupportRange) {
                            Log.e("sssssssss", "mDownloadThreads:::::22222:::::" + i);
                            this.mDownloadThreads[i].pause();
                        } else {
                            this.mDownloadThreads[i].cancel();
                        }
                    }
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    public void start() {
        if (this.entry.totalLength > 0) {
            startDownload();
            return;
        }
        this.entry.status = DownloadEntry.DownloadStatus.connecting;
        notifyUpdate(this.entry, 5);
        ConnectThread connectThread = new ConnectThread(this.entry.url, this);
        this.mConnectThread = connectThread;
        this.mExecutor.execute(connectThread);
    }
}
