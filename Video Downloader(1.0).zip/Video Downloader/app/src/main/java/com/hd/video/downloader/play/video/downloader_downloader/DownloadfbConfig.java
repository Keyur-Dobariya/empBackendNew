package com.hd.video.downloader.play.video.downloader_downloader;

import android.os.Environment;
import android.util.Log;

import java.io.File;

public class DownloadfbConfig {
    private static DownloadfbConfig mConfig;
    private File downloadDir = null;
    private int max_download_tasks = 5;
    private int max_download_threads = 3;
    private int max_retry_count = 5;
    private int min_operate_interval = 1000;
    private boolean recoverDownloadWhenStart = true;
    private DownloadfbConfig() {
        File file = new File((Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/FaceBook Video Downloader"));
        this.downloadDir = file;
        if (!file.exists()) {
            this.downloadDir.mkdir();
        }
        Log.e("sssssssssssss", "downloadocnfig::::::::::::" + this.downloadDir);
    }

    public static DownloadfbConfig getConfig() {
        if (mConfig == null) {
            mConfig = new DownloadfbConfig();
        }
        return mConfig;
    }

    public File getDownloadFile(String str) {
        return new File(this.downloadDir, str);
    }

    public String getDownloadPath(String str) {
        return new File(this.downloadDir, str).getAbsolutePath();
    }

    public int getMaxDownloadTasks() {
        return this.max_download_tasks;
    }

    public int getMaxDownloadThreads() {
        return this.max_download_threads;
    }

    public int getMaxRetryCount() {
        return this.max_retry_count;
    }

    public int getMinOperateInterval() {
        return this.min_operate_interval;
    }

    public boolean isRecoverDownloadWhenStart() {
        return this.recoverDownloadWhenStart;
    }

}
