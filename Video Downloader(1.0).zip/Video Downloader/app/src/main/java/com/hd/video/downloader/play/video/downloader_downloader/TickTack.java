package com.hd.video.downloader.play.video.downloader_downloader;

public class TickTack {
    private static TickTack mInstance;
    private long mLastStamp;

    private TickTack() {
    }

    public static synchronized TickTack getInstance() {
        TickTack tickTack;
        synchronized (TickTack.class) {
            synchronized (TickTack.class) {
                synchronized (TickTack.class) {
                    if (mInstance == null) {
                        mInstance = new TickTack();
                    }
                    tickTack = mInstance;
                }
                return tickTack;
            }
        }
    }

    public synchronized boolean needToNotify() {
        boolean z;
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.mLastStamp <= 1000) {
            z = false;
        } else {
            this.mLastStamp = currentTimeMillis;
            z = true;
        }
        return z;
    }
}
