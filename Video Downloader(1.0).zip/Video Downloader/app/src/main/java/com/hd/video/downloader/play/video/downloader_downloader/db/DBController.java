package com.hd.video.downloader.play.video.downloader_downloader.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.hd.video.downloader.play.video.downloader_downloader.DownloadConfig;
import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;
import com.hd.video.downloader.play.video.downloader_downloader.entities.SearchHistoryEntry;
import com.hd.video.downloader.play.video.downloader_downloader.entities.VideoFolderEntry;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

public class DBController {
    private static DBController instance;
    private SQLiteDatabase mDB;
    private OrmDBHelper mDBhelper;
    private Dao<VideoFolderEntry, Integer> videoFolderDao;

    private DBController(Context context) {
        mDBhelper = new OrmDBHelper(context);
        this.mDB = mDBhelper.getWritableDatabase();
    }

    public static DBController getInstance(Context context) {
        if (instance == null) {
            instance = new DBController(context);
        }
        return instance;
    }

    public void deleteByEntry(SearchHistoryEntry searchHistoryEntry) {
        try {
            this.mDBhelper.getDao(SearchHistoryEntry.class).delete(searchHistoryEntry);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteById(String str) {
        try {
            this.mDBhelper.getDao(DownloadEntry.class).deleteBuilder();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Dao<VideoFolderEntry, Integer> getVideoFolderDao() {
        if (this.videoFolderDao == null) {
            try {
                this.videoFolderDao = this.mDBhelper.getDao(VideoFolderEntry.class);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return this.videoFolderDao;
    }

    public synchronized void newOrUpdate(DownloadEntry downloadEntry) {
        try {
            this.mDBhelper.getDao(DownloadEntry.class).createOrUpdate(downloadEntry);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return;
    }

    public synchronized void newOrUpdate(SearchHistoryEntry searchHistoryEntry) {
        try {
            this.mDBhelper.getDao(SearchHistoryEntry.class).createOrUpdate(searchHistoryEntry);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return;
    }

    public synchronized ArrayList<DownloadEntry> queryAll() {
        ArrayList<DownloadEntry> arrayList;
        try {
            Dao dao = this.mDBhelper.getDao(DownloadEntry.class);
            arrayList = (ArrayList) dao.query(dao.queryBuilder().prepare());
        } catch (SQLException e) {
            arrayList = null;
        }
        return arrayList;
    }

    public ArrayList<DownloadEntry> queryAllCompletedEntriesByVideo() {
        ArrayList<DownloadEntry> arrayList = new ArrayList<>();
        ArrayList<DownloadEntry> queryAll = queryAll();
        if (queryAll != null && queryAll.size() > 0) {
            Iterator<DownloadEntry> it = queryAll.iterator();
            while (it.hasNext()) {
                DownloadEntry next = it.next();
                if (next.status == DownloadEntry.DownloadStatus.completed) {
                    if (DownloadConfig.getConfig().getDownloadFile(next.name).exists()) {
                        arrayList.add(next);
                    } else {
                        Log.e("str","Not  exists");
                        Log.e("str","entry.name====" + next.name);
                    }
                }
            }
        }
        return arrayList;
    }

    public synchronized ArrayList<SearchHistoryEntry> querySearchHistoryAllByFive() {
        ArrayList<SearchHistoryEntry> arrayList;
        try {
            Dao dao = this.mDBhelper.getDao(SearchHistoryEntry.class);
            arrayList = (ArrayList) dao.query(dao.queryBuilder().prepare());
            if (arrayList.size() >= 5) {
                ArrayList<SearchHistoryEntry> arrayList2 = new ArrayList<>();
                int size = arrayList.size();
                while (true) {
                    size--;
                    if (size < arrayList.size() - 5) {
                        break;
                    }
                    arrayList2.add(arrayList.get(size));
                }
                arrayList = arrayList2;
            }
        } catch (SQLException e) {
            arrayList = null;
        }
        return arrayList;
    }
}
