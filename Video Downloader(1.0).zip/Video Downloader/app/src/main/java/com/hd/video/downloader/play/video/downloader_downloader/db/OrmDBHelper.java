package com.hd.video.downloader.play.video.downloader_downloader.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;
import com.hd.video.downloader.play.video.downloader_downloader.entities.SearchHistoryEntry;
import com.hd.video.downloader.play.video.downloader_downloader.entities.VideoSiteEntry;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;

public class OrmDBHelper extends OrmLiteSqliteOpenHelper {
    public static final String DB_NAME = "DB_NAME";
    private Context context;

    public OrmDBHelper(Context context2) {
        super(context2, DB_NAME, null, 3);
        this.context = context2;
    }

    @Override
    public void onCreate(SQLiteDatabase sQLiteDatabase, ConnectionSource connectionSource) {
        try {
            TableUtils.createTableIfNotExists(connectionSource, DownloadEntry.class);
            TableUtils.createTableIfNotExists(connectionSource, SearchHistoryEntry.class);
            TableUtils.createTableIfNotExists(connectionSource, VideoSiteEntry.class);
            TableUtils.createTableIfNotExists(connectionSource, StatusDownloadEntry.class);
        } catch (SQLException e) {
            Log.e("str","SQLException===" + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, ConnectionSource connectionSource, int i, int i2) {
        onCreate(sQLiteDatabase, connectionSource);
    }
}
