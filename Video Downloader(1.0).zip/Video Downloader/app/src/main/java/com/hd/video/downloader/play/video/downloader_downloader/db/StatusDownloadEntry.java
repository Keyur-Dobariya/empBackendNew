package com.hd.video.downloader.play.video.downloader_downloader.db;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.io.Serializable;

@DatabaseTable(tableName = "StatusDownloadEntry")
public class StatusDownloadEntry implements Serializable, Cloneable {
    @DatabaseField(id = true)
    public String id;
    @DatabaseField
    public String name;
    @DatabaseField
    public String path;
    @DatabaseField
    public String type;

    public StatusDownloadEntry() {
    }
    public StatusDownloadEntry(String str, String str2, String str3) {
        this.path = str;
        this.id = str2;
        this.name = str2;
        this.type = str3;
    }

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean equals(Object obj) {
        return obj.hashCode() == hashCode() ? true : null;
    }

    public int hashCode() {
        return this.id.hashCode();
    }

    public String toString() {
        return this.name + " is " + this.name;
    }
}
