package com.hd.video.downloader.play.video.downloader_downloader.entities;

import com.hd.video.downloader.play.video.downloader_downloader.DownloadConfig;
import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.io.File;
import java.io.Serializable;
import java.util.HashMap;

@DatabaseTable(tableName = "downloadentry")
public class DownloadEntry implements Serializable, Cloneable {
    @DatabaseField
    public int cid;
    @DatabaseField
    public int currentLength;
    @DatabaseField
    public String folder_name;
    @DatabaseField(id = true)
    public String id;
    @DatabaseField
    public boolean isChecked;
    @DatabaseField
    public boolean isPrivate;
    @DatabaseField
    public boolean isShare;
    @DatabaseField
    public boolean isSupportRange;
    @DatabaseField
    public String name;
    @DatabaseField
    public String nameNoEx;
    @DatabaseField
    public String path;
    @DatabaseField
    public int percent;
    @DatabaseField(dataType = DataType.SERIALIZABLE)
    public HashMap<Integer, Integer> ranges;
    @DatabaseField
    public int retry;
    @DatabaseField
    public String source_url;
    @DatabaseField
    public DownloadStatus status;
    @DatabaseField
    public int totalLength;
    @DatabaseField
    public String type;
    @DatabaseField
    public String url;
    @DatabaseField(foreign = true, foreignAutoRefresh = true)
    public VideoFolderEntry videoFolderEntry;

    public enum DownloadStatus {
        idle,
        waiting,
        connecting,
        downloading,
        paused,
        resumed,
        cancelled,
        completed,
        error,
        no_memory
    }

    public DownloadEntry() {
        this.isChecked = false;
        this.isPrivate = false;
        this.isShare = false;
        this.isSupportRange = false;
        this.status = DownloadStatus.idle;
        this.status = DownloadStatus.idle;
        this.isSupportRange = false;
        this.isShare = false;
        this.isPrivate = false;
        this.isChecked = false;
    }

    public DownloadEntry(String str, String str2, String str3, String str4, boolean z, boolean z2, String str5) {
        this.isChecked = false;
        this.isPrivate = false;
        this.isShare = false;
        this.isSupportRange = false;
        this.status = DownloadStatus.idle;
        this.url = str2;
        this.path = str3;
        this.id = str4;
        this.source_url = str;
        this.name = str4;
        this.isShare = z;
        this.isPrivate = z2;
        this.type = str5;
    }

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean equals(Object obj) {
        return obj.hashCode() == hashCode();
    }

    public int hashCode() {
        return this.id.hashCode();
    }

    public void reset() {
        this.currentLength = 0;
        this.ranges = null;
        this.percent = 0;
        File downloadFile = DownloadConfig.getConfig().getDownloadFile(this.name);
        if (downloadFile.exists()) {
            downloadFile.delete();
        }
    }

    public String toString() {
        return this.name + " is " + this.status.name() + " with " + this.currentLength + "/" + this.totalLength;
    }
}
