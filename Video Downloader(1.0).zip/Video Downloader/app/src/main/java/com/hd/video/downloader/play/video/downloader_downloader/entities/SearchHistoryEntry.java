package com.hd.video.downloader.play.video.downloader_downloader.entities;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.io.Serializable;

@DatabaseTable(tableName = "searchhistoryentry")
public class SearchHistoryEntry implements Serializable, Cloneable {
    @DatabaseField(id = true)
    public String id;
    @DatabaseField
    public String str;

    public SearchHistoryEntry() {
    }
    public SearchHistoryEntry(String str2, String str3) {
        this.id = str2;
        this.str = str3;
    }

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean equals(Object obj) {
        return (obj.hashCode() == hashCode() ? true : null).booleanValue();
    }

    public int hashCode() {
        return this.id.hashCode();
    }

    public String toString() {
        return this.str + " is " + this.str;
    }
}