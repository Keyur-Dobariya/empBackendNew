package com.hd.video.downloader.play.video.downloader_downloader.notify;

import android.content.Context;
import android.util.Log;


import com.hd.video.downloader.play.video.downloader_downloader.db.DBController;
import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Observable;

public class DataChanger extends Observable {
    private static DataChanger mInstance;
    private final Context context;
    private LinkedHashMap<String, DownloadEntry> mOperatedEntries = new LinkedHashMap<>();

    private DataChanger(Context context2) {
        this.context = context2;
    }

    public static DataChanger getInstance(Context context2) {
        DataChanger dataChanger;
        synchronized (DataChanger.class) {
            if (mInstance == null) {
                mInstance = new DataChanger(context2);
            }
            dataChanger = mInstance;
        }
        return dataChanger;
    }

    public void addToOperatedEntryMap(String str, DownloadEntry downloadEntry) {
        this.mOperatedEntries.put(str, downloadEntry);
    }

    public boolean containsDownloadEntry(String str) {
        return this.mOperatedEntries.containsKey(str);
    }

    public void deleteDownloadEntry(String str) {
        this.mOperatedEntries.remove(str);
        DBController.getInstance(this.context).deleteById(str);
    }

    public void newOrUpdate(DownloadEntry downloadEntry) {
        DBController.getInstance(this.context).newOrUpdate(downloadEntry);
    }

    public void postStatus(DownloadEntry downloadEntry) {
        this.mOperatedEntries.put(downloadEntry.id, downloadEntry);
        DBController.getInstance(this.context).newOrUpdate(downloadEntry);
        setChanged();
        Log.e("kkkkkkkkkkkkkkk", "responseCode:::postStatus:::::" + downloadEntry);
        notifyObservers(downloadEntry);
    }

    public ArrayList<DownloadEntry> queryAll() {
        return DBController.getInstance(this.context).queryAll();
    }

    public ArrayList<DownloadEntry> queryAllCompletedEntriesByVideo() {
        return DBController.getInstance(this.context).queryAllCompletedEntriesByVideo();
    }

    public ArrayList<DownloadEntry> queryAllDownloadingEntries() {
        ArrayList<DownloadEntry> arrayList = new ArrayList<>();
        ArrayList<DownloadEntry> queryAll = queryAll();
        if (queryAll != null && queryAll.size() > 0) {
            Iterator<DownloadEntry> it = queryAll.iterator();
            while (it.hasNext()) {
                DownloadEntry next = it.next();
                if (!(next.status == DownloadEntry.DownloadStatus.completed || next.status == DownloadEntry.DownloadStatus.cancelled || next.status == DownloadEntry.DownloadStatus.no_memory)) {
                    Log.e("str", "queryAllDownloadingEntries===" + next.status);
                    arrayList.add(next);
                }
            }
        }
        return arrayList;
    }

    public ArrayList<DownloadEntry> queryAllRecoverableEntries() {
        ArrayList<DownloadEntry> arrayList = null;
        for (Map.Entry<String, DownloadEntry> entry : this.mOperatedEntries.entrySet()) {
            if (entry.getValue().status == DownloadEntry.DownloadStatus.paused || entry.getValue().status == DownloadEntry.DownloadStatus.error || entry.getValue().status == DownloadEntry.DownloadStatus.waiting || entry.getValue().status == DownloadEntry.DownloadStatus.connecting) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(entry.getValue());
            }
        }
        return arrayList;
    }

    public DownloadEntry queryDownloadEntryById(String str) {
        return this.mOperatedEntries.get(str);
    }
}
