package com.hd.video.downloader.play.video.downloader_downloader.notify;


import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;

import java.util.Observable;
import java.util.Observer;

public abstract class DataWatcher implements Observer {
    public abstract void notifyUpdate(DownloadEntry downloadEntry);

    public void update(Observable observable, Object obj) {
        if (obj instanceof DownloadEntry) {
            notifyUpdate((DownloadEntry) obj);
        }
    }
}