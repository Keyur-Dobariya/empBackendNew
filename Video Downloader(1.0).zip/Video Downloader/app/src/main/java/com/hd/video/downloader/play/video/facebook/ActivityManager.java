package com.hd.video.downloader.play.video.facebook;


import java.util.LinkedList;
import java.util.List;

public class ActivityManager {
    private static ActivityManager instance = new ActivityManager();
    private List<DefaultBaseAct> activities = new LinkedList();

    private ActivityManager() {
    }

    public static ActivityManager getInstance() {
        return instance;
    }

    public void addActivity(DefaultBaseAct defaultBaseAct) {
        this.activities.add(defaultBaseAct);
    }

    public void clean() {
        for (DefaultBaseAct defaultBaseAct : this.activities) {
            defaultBaseAct.finish();
        }
    }

    public void delActivity(DefaultBaseAct defaultBaseAct) {
        this.activities.remove(defaultBaseAct);
    }
}