package com.hd.video.downloader.play.video.facebook;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.hd.video.downloader.play.video.Mainvideos.AllDownLoadVideo;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.downloader_downloader.AppConfig;
import com.hd.video.downloader.play.video.downloader_downloader.AppConstant;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadConfig;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadManager;
import com.hd.video.downloader.play.video.downloader_downloader.SharedConfig;
import com.hd.video.downloader.play.video.downloader_downloader.db.DBController;
import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;
import com.hd.video.downloader.play.video.downloader_downloader.entities.SearchHistoryEntry;
import com.hd.video.downloader.play.video.fragments_downloader.bean_downloader.UrlInformation;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Activity_Search extends DefaultBaseAct implements interact, View.OnFocusChangeListener {
    private static final int API = Build.VERSION.SDK_INT;
    public String GOOGLE_CUSTOM_URL = "https://www.google.com/search?num=20&q=";
    private Adapter adapter;
    public interact con;
    public String haven1080;
    public String haven480;
    public String haven720;
    public String haver360;
    public boolean isDialogShow = false;
    boolean isFirst = true;
    public boolean isVimeo = false;

    ArrayList arrayList = new ArrayList();
    String str;
    UrlInformation urlInformation = new UrlInformation();
    VideoInformation videoInformation;
    String str2 = "";
    VideoInformation videoInformation2 = null;
    String str4 = "xnxx.com";

    ImageView title_back;
    CardView mcv;
    EditText edittext;

    ImageView img_search, img_clear, img_refresh, image_downloaded2;
    ProgressBar progressBar;
    LinearLayout brows;
    WebView webview;
    RecyclerView recyclerView;
    ImageView img_previous, img_next;
    FloatingActionButton img_download;
    ConstraintLayout root;

    @Override
    public void onCrete() {
        setContentView(R.layout.activity_search);
        title_back = findViewById(R.id.title_back);
        mcv = findViewById(R.id.mcv);
        edittext = findViewById(R.id.edittext);
        img_search = findViewById(R.id.img_search);
        img_clear = findViewById(R.id.img_clear);
        img_refresh = findViewById(R.id.img_refresh);
        image_downloaded2 = findViewById(R.id.image_downloaded2);
        progressBar = findViewById(R.id.progressBar);
        brows = findViewById(R.id.brows);
        webview = findViewById(R.id.webview);
        recyclerView = findViewById(R.id.recyclerView);
        img_download = findViewById(R.id.img_download);
        img_previous = findViewById(R.id.img_previous);
        img_next = findViewById(R.id.img_next);
        root = findViewById(R.id.root);

        edittext.setOnLongClickListener(v -> {
            edittext.requestFocus();
            return true;
        });
        this.url11 = getIntent().getStringExtra(AppConstant.KEY.URL);
        this.searchHistoryEntries = new ArrayList<>();
        this.website = getIntent().getStringExtra(AppConstant.KEY.WEBSITE);
    }

    public Handler mHandler = new Handler() {
        public void handleMessage(Message message) {
            super.handleMessage(message);
            int i = message.what;
            if (i == 2) {
            } else if (i == 8) {
                setDownloadUnable();
            } else {
                if (TextUtils.isEmpty(pageStartUrl) || (!pageStartUrl.contains("youtube.com") && !pageStartUrl.contains("youtu.be") && !pageStartUrl.contains("timesofindia"))) {
                    img_download.setSelected(true);
                    image_downloaded2.setSelected(true);
                    animateDownloadIcon();
                }
            }
        }
    };
    private String mUrl;
    VideoInformation n = new VideoInformation();
    public String pageStartUrl = "";
    DownloadDialog downloadDialog;
    public ArrayList<SearchHistoryEntry> searchHistoryEntries = new ArrayList<>();
    public String text_search;
    public String url11;
    private String website;
    public String xnxxHighUrl;
    public String xnxxLowUrl;

    public static String script() {
        return "javascript:function toAbsoluteUrl(url)\n{\n    if(url.search(/^\\/\\//) != -1) return window.location.protocol + url;\n    if(url.search(/:\\/\\//) != -1) return url;\n    if(url.search(/^\\//)   != -1) return window.location.origin + url;\n\n    return window.location.href.match(/(.*\\/)/)[0] + url;\n}\n\nfunction getSources(mediaTag)\n{\n    var sources = mediaTag.getElementsByTagName(\"source\");\n    var sourceUrls = [];\n\n    if(sources.length == 0)\n    {\n        return null;\n    }\n\n    for(var i = 0; i < sources.length; ++i)\n    {\n        if(sources[i].hasAttribute(\"src\"))\n        {\n            sourceUrls.push(toAbsoluteUrl(sources[i].getAttribute(\"src\")));\n        }\n    }\n\n    return sourceUrls;\n}\n\nfunction processMediaTag(mediaTag, srcCallBack, sourcesCallBack)\n{\n    if(!mediaTag)\n    {\n        return;\n    }\n    \n    if(mediaTag.hasAttribute(\"src\"))\n    {\n        srcCallBack(toAbsoluteUrl(mediaTag.getAttribute(\"src\")));\n        return;\n    }\n\n    var sourceUrls = getSources(mediaTag);\n\n    if(sourceUrls)\n    {\n        sourcesCallBack(JSON.stringify(sourceUrls));\n        return;\n    }\n}\n\nfunction getFirstPlayingMediaTag(mediaTags)\n{\n    for(var i = 0; i < mediaTags.length; ++i)\n    {\n        if(!mediaTags[i].paused && !mediaTags[i].ended)\n        {\n            return mediaTags[i];\n        }\n    }\n    \n    return null;\n}\n\nfunction onVideoSrcItercept(url)     { window.MyBridg.onVideoSrcItercept(url,document.title);     }\nfunction onVideoSourcesItercept(url) { window.MyBridg.onVideoSourcesItercept(url,document.title); }\n\nfunction onAudioSrcItercept(url)     { window.MyBridg.onAudioSrcItercept(url,document.title);     }\nfunction onAudioSourcesItercept(url) { window.MyBridg.onAudioSourcesItercept(url,document.title); }\n\nfunction processVideoEvent(event)\n{\n    if(event.target.nodeName.toUpperCase() === \"VIDEO\")\n    {\n        processMediaTag(event.target, onVideoSrcItercept, onVideoSourcesItercept);\n    }\n    else if(event.target.contentDocument && event.target.contentDocument.getElementsByTagName('VIDEO').length > 0)\n    {\n        var videoTags = event.target.contentDocument.getElementsByTagName('VIDEO');\n        processMediaTag(getFirstPlayingMediaTag(videoTags), onVideoSrcItercept, onVideoSourcesItercept);\n    }\n}\n\nfunction processAudioEvent(event)\n{\n    if(event.target.nodeName.toUpperCase() === \"AUDIO\")\n    {\n        processMediaTag(event.target, onAudioSrcItercept, onAudioSourcesItercept);\n    }\n    else if(event.target.contentDocument && event.target.contentDocument.getElementsByTagName('AUDIO').length > 0)\n    {\n        var audioTags = event.target.contentDocument.getElementsByTagName('AUDIO');\n        processMediaTag(getFirstPlayingMediaTag(audioTags), onAudioSrcItercept, onAudioSourcesItercept);\n    }\n}\n\ndocument.addEventListener(\"play\", processVideoEvent, true);\ndocument.addEventListener(\"play\", processAudioEvent, true);";
    }

    @Override
    public void OnStart(WebView webView) {
    }

    @Override
    public void OnStartsite(WebView webView) {
    }

    @Override
    public void Onfinesh(WebView webView) {
    }

    @Override
    public void onAudioSrcItercept(String str, String str2) {
    }

    @Override
    public void onItemClick(String str, int i, ArrayList<HashMap<String, String>> arrayList) {
    }

    @Override
    public void oncreate(WebView webView) {
    }

    @Override
    public void onplay(String str, String str2, String str3) {
    }

    public void animateDownloadIcon() {
        Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.bounce);
        image_downloaded2.setAnimation(loadAnimation);
        image_downloaded2.startAnimation(loadAnimation);
        img_download.startAnimation(loadAnimation);
        img_download.startAnimation(loadAnimation);
    }

    @Override
    public void OnreciveVideourl(WebView webView, String str, String str2, String str3) {
        this.url11 = str;
        Ajax.title = "";
    }

    @Override
    public void onAudioSourcesItercept(String str, String str2) {
        this.url11 = str;
        Ajax.title = "";
    }

    @Override
    public void onVideoSourcesItercept(String str, String str2) {
        if (str.startsWith("[")) {
            str = str.replace("[", "");
        }
        String[] split = str.replace("]", "").split(",");
        for (int i = 0; i < split.length; i++) {
            split[i] = split[i].replace("\"", "");
        }
        this.url11 = split[0];
    }

    @Override
    public void onVideoSrcItercept(String str, String str2) {
        Log.e("iiiiiiiiiiiiiiiii", "onVideoSrcItercept.....str...." + str);
        if (str.contains(AppConfig.MP4)) {
            this.url11 = str.replace("[", "").replace("]", "");
            Log.e("iiiiiiiiiiiiiiiii", "onVideoSrcItercept.....11111....url11......" + this.url11);
            this.mUrl = this.url11;
            Log.e("str", "mUrl===" + this.mUrl);
            Log.e("str", str);
            runOnUiThread(new Runnable() {
                public void run() {
                    img_download.setSelected(true);
                    animateDownloadIcon();
                    image_downloaded2.setSelected(true);
                }
            });
        } else {
            Log.e("iiiiiiiiiiiiiiiii", "onVideoSrcItercept.........url11......" + this.url11);
        }
        Ajax.title = "";
    }

    public class Adapter extends BaseQuickAdapter<SearchHistoryEntry, BaseViewHolder> {
        public Adapter(int i, List<SearchHistoryEntry> list) {
            super(i, list);
        }

        public void convert(BaseViewHolder baseViewHolder, final SearchHistoryEntry searchHistoryEntry) {
            baseViewHolder.setText(R.id.text_str, searchHistoryEntry.str);
            AdapterUtils.getAdapterView(baseViewHolder.getConvertView(), R.id.btn_remove).setOnClickListener(view -> {
                DBController.getInstance(w).deleteByEntry(searchHistoryEntry);
                refreshSearchData();
            });
            AdapterUtils.getAdapterView(baseViewHolder.getConvertView(), R.id.root).setOnClickListener(view -> {
                String str;
                text_search = searchHistoryEntry.str;
                if (text_search.contains(HttpHost.DEFAULT_SCHEME_NAME)) {
                    str = text_search;
                } else {
                    str = GOOGLE_CUSTOM_URL + text_search;
                }
                edittext.setText(text_search);
                recyclerView.setVisibility(View.GONE);
                Log.e("kkkkkkkkkkk", "str::::::22222" + str);
                search(str);
            });
        }
    }

    private void ShowDownloadWindows() {
        if (downloadDialog == null || !downloadDialog.isShowing()) {
            downloadDialog = new DownloadDialog(this.w, this.n);
            downloadDialog.Myshow();
            downloadDialog.setOnclickListner(new DownloadDialog.OnclickListner() {
                @Override
                public void Download(Dialog dialog, String str, String str2) {
                    DownloadEntry downloadEntry;
                    dialog.dismiss();
                    DownloadEntry queryDownloadEntry = DownloadManager.getInstance(w).queryDownloadEntry(str2);
                    Log.e("TAG", "DownloadEntry: " + n);
                    String str3 = str2.endsWith(AppConfig.MP3) ? AppConfig.MUSIC : AppConfig.VIDEO;
                    if (queryDownloadEntry != null) {
                        String str4 = System.currentTimeMillis() + "-" + str2;
                        downloadEntry = new DownloadEntry("", str, DownloadConfig.getConfig().getDownloadPath(str4), str4, false, false, str3);
                    } else {
                        downloadEntry = new DownloadEntry("", str, DownloadConfig.getConfig().getDownloadPath(str2), str2, false, false, str3);
                    }
                    DownloadManager.getInstance(w).add(downloadEntry);
                    Toast.makeText(w, "Downloading...", Toast.LENGTH_SHORT);
                    mHandler.sendEmptyMessage(2);
                }

                @Override
                public void cancel(Dialog dialog, String str) {
                    dialog.dismiss();
                }
            });
        }
    }

    private void addHeaderAndFooter() {
        View inflate = LayoutInflater.from(this.w).inflate(R.layout.header_search, null);
        View inflate2 = LayoutInflater.from(this.w).inflate(R.layout.footer_search, null);
        this.adapter.addHeaderView(inflate);
        this.adapter.addFooterView(inflate2);
        inflate2.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                recyclerView.setVisibility(View.GONE);
            }
        });
    }

    public void changeButtons(int i) {
        if (i == 0) {
            img_search.setVisibility(View.GONE);
            img_refresh.setVisibility(View.GONE);
            img_clear.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);
        } else if (i == 1) {
            progressBar.setVisibility(View.GONE);
            img_search.setVisibility(View.GONE);
            if (!edittext.hasFocus()) {
                img_refresh.setVisibility(View.VISIBLE);
                img_clear.setVisibility(View.GONE);
            }
        } else if (i == 2) {
            img_search.setVisibility(View.GONE);
            img_refresh.setVisibility(View.GONE);
            img_clear.setVisibility(View.VISIBLE);
            edittext.setHint("");
        } else if (i == 3) {
            img_search.setVisibility(View.GONE);
            img_refresh.setVisibility(View.VISIBLE);
            img_clear.setVisibility(View.GONE);
            edittext.setHint(R.string.input_url_hint);
        } else if (i == 4) {
            img_search.setVisibility(View.VISIBLE);
            img_refresh.setVisibility(View.GONE);
            img_clear.setVisibility(View.GONE);
            edittext.setHint(R.string.input_url_hint);
        } else if (i == 5) {
            progressBar.setVisibility(View.GONE);
            img_search.setVisibility(View.VISIBLE);
            img_refresh.setVisibility(View.GONE);
            img_clear.setVisibility(View.GONE);
            edittext.setText("");
        }
    }

    private String getUrlString(String str) {
        if (str.contains(".")) {
            if (str.contains(" ")) {
                str = str.replaceAll("\\s+", "");
            }
            if (str.startsWith("http://") || str.startsWith("https://") || str.startsWith("about") || str.startsWith("javascript") || str.startsWith("content") || str.startsWith("file")) {
                return str;
            }
            return "http://" + str;
        }
        return this.GOOGLE_CUSTOM_URL + str;
    }

    public void injectCode(WebView webView) {
        webView.loadUrl("javascript:var appJs = document.createElement(\"script\");appJs.type = \"text/javascript\";appJs.src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js\";appJs.onload=function(){function schedule(){\n      \tsetInterval(function(){\n      \t\taddBtn()\n      \t}, 1000)\n      }\n      \n      function addBtn(){\n      \ttry{\n      \t\tvar clip_wrapper = $('.player_container');\n      \t\tclip_wrapper.map(function(index, item){\n      \t\t\tvar button = $('<button class=\"download-btn\" style=\"position: static;font-weight:bold; top: 80px;left: 10px;width: 6em;height: 4em;color: #fff;background: #ff7302;border-radius: 10px;\">Download</button>');\n      \t\t\tbutton.on('click', function(e){\n      \t\t\t\tvar url = $(this).parents('.clip_wrapper').find('.js-player').attr('data-config-url');\n      \t\t\t\tjavascript:window.local_obj.getVimeoUrl(url);\n      \t\t\t});\n      \t\t\tif($(item).find('.download-btn') && $(item).find('.download-btn').length){}else{\n      \t\t\t\t$(item).append(button);\n      \t\t\t}\n      \t\t});\n      \t}catch(ex){\n      \n      \t}\n      }addBtn();\n      \t\tschedule()};document.body.appendChild(appJs);");
        Log.e("kkkkkkkkkkkkk", "inject::::::::::" + webView.getUrl());
    }

    public void refreshSearchData() {
        ArrayList<SearchHistoryEntry> querySearchHistoryAllByFive = DBController.getInstance(this.w).querySearchHistoryAllByFive();
        this.searchHistoryEntries = querySearchHistoryAllByFive;
        this.adapter.setNewData(querySearchHistoryAllByFive);
    }

    @SuppressLint({"JavascriptInterface", "SetJavaScriptEnabled"})
    public void search(String str) {
        this.url11 = str;
        webview.requestFocus();
        WebSettings settings = webview.getSettings();
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        settings.setJavaScriptEnabled(true);
        webview.getSettings().setPluginState(WebSettings.PluginState.ON);
        webview.getSettings().setUseWideViewPort(true);
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setAllowFileAccess(true);
        webview.getSettings().setSupportMultipleWindows(true);
        webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webview.getSettings().setSupportZoom(true);
        webview.getSettings().setBuiltInZoomControls(true);
        settings.setDomStorageEnabled(true);
        settings.setMixedContentMode(0);
        webview.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView webView, int i) {
                progressBar.setProgress(i);
                if (i == 100) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
        this.con = this;
        Ajax ajax = new Ajax(this, this.con);
        webview.addJavascriptInterface(new Ajax(this.getApplication(), this), "MyBridg");
        interact interact = this.con;
        if (interact != null) {
            interact.oncreate(webview);
        }
        initWeb();
        webview.setWebViewClient(new WebViewClient() {

            @SuppressLint("LongLogTag")
            public void onLoadResource(WebView webView, String str) {
                super.onLoadResource(webView, str);
                Log.e("onLoadResource===", "::_____" + webview.getUrl());
                if (str.contains("dailymotion") && str.contains("video") && ((!str.startsWith("https://youtu.be/") || !str.contains("youtube.com") || !str.contains("timesofindia")) && str.toLowerCase().contains("https://www.dailymotion.com/player/metadata/video".toLowerCase()))) {
                    mUrl = str;
                    Log.e("str", "mUrl===" + mUrl);
                    Log.e("str", str);
                    runOnUiThread(() -> {
                        img_download.setSelected(true);
                        animateDownloadIcon();
                        image_downloaded2.setSelected(true);
                    });
                    Log.e("yyyyyyyyyyyy", "runOnUiThread.1111.....");
                    Log.e("mUrl", "mUrl....." + mUrl);
                }
                if (!FileUtil.isVideo(str, AppConfig.REGEXVIDEOS) || str.contains(".m3u8") || url11.contains("hentaihaven.org")) {
                    if (!isDialogShow && !str.contains("pornhub.com") && !url11.contains("hentaihaven.org")) {
                        webView.loadUrl("javascript:window.local_obj.showSource(document.querySelector('video').querySelector('source[type=\"video/mp4\"]').src)");
                        webView.loadUrl("javascript:window.local_obj.showSource(document.querySelector('video').src)");
                    }
                } else if (!isDialogShow) {
                    Log.e("str", "Rule matching video address===" + str);
                    Log.e("Rule matching video address===", "onLoadResource: " + str);
                    setDownloadEnable(str);
                }
                if (str.contains("xnxx.com") || str.contains("xvideos.com")) {
                    webView.loadUrl("javascript:window.local_obj.getXnxxHighUrl(html5player.url_high)");
                    webView.loadUrl("javascript:window.local_obj.getXnxxLowUrl(html5player.url_low)");
                }
                if (url11.contains("hentaihaven.org")) {
                    webView.loadUrl("javascript:window.local_obj.gethaven1080(document.querySelector('video').querySelector('source[res=\"1080p\"]').src)");
                    webView.loadUrl("javascript:window.local_obj.gethaven720(document.querySelector('video').querySelector('source[res=\"720p\"]').src)");
                    webView.loadUrl("javascript:window.local_obj.gethaven480(document.querySelector('video').querySelector('source[res=\"480p\"]').src)");
                    webView.loadUrl("javascript:window.local_obj.gethaven360(document.querySelector('video').querySelector('source[res=\"360p\"]').src)");
                }
                webView.loadUrl(Activity_Search.script());
                Ajax.title = "";
            }

            public void onPageFinished(WebView webView, String str) {
                if (str.contains("vimeo.com")) {
                    injectCode(webView);
                } else if (str.contains("xnxx.com") || str.contains("xvideos.com")) {
                    webView.loadUrl("javascript:window.local_obj.getXnxxHighUrl(html5player.url_high)");
                    webView.loadUrl("javascript:window.local_obj.getXnxxLowUrl(html5player.url_low)");
                }
                changeButtons(1);
                super.onPageFinished(webView, str);
                progressBar.setVisibility(View.GONE);
            }

            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
                super.onPageStarted(webView, str, bitmap);
                pageStartUrl = str;
                Log.e("str", "onPageStarted===" + str);
                vimeoOrFaceInsTips(str);
                progressBar.setVisibility(View.VISIBLE);
            }
        });
        webview.loadUrl(str);
    }

    public void searchOnclick() {
        this.img_download.setSelected(false);
        this.image_downloaded2.setSelected(false);
        this.text_search = edittext.getText().toString();
        this.text_search = !TextUtils.isEmpty(edittext.getText().toString()) ? getUrlString(edittext.getText().toString()) : "https://www.google.com/";
        Log.e("kkkkkkkkkkk", "text_search::::::text_search" + this.text_search);
        search(this.text_search);
        recyclerView.setVisibility(View.GONE);
        DBController instance = DBController.getInstance(this.w);
        String str = this.text_search;
        instance.newOrUpdate(new SearchHistoryEntry(str, str));
        SystemUtils.hideInputmethod(edittext);
    }

    public void initWeb() {
        webview.setDrawingCacheBackgroundColor(-1);
        webview.setFocusableInTouchMode(true);
        webview.setFocusable(true);
        webview.setDrawingCacheEnabled(false);
        webview.setWillNotCacheDrawing(true);
        if (Build.VERSION.SDK_INT <= 22) {
            webview.setAnimationCacheEnabled(false);
            webview.setAlwaysDrawnWithCacheEnabled(false);
        }
        webview.setBackgroundColor(-1);
        webview.setScrollbarFadingEnabled(true);
        webview.setSaveEnabled(true);
        webview.setNetworkAvailable(true);
        initializeSettings(webview.getSettings(), this);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initializeSettings(WebSettings webSettings, Context context) {
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setUserAgentString("Mozilla/5.0 (Linux; U; Android 4.2.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30");
        webSettings.setJavaScriptCanOpenWindowsAutomatically(false);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (API < 17) {
            webSettings.setEnableSmoothTransition(true);
        }
        if (API > 16) {
            webSettings.setMediaPlaybackRequiresUserGesture(true);
        }
        if (API >= 21) {
            webSettings.setMixedContentMode(2);
        }
        webSettings.setDomStorageEnabled(true);
        webSettings.setCacheMode(-1);
        webSettings.setDatabaseEnabled(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccess(true);
        if (API >= 16) {
            webSettings.setAllowFileAccessFromFileURLs(false);
            webSettings.setAllowUniversalAccessFromFileURLs(false);
        }
        webSettings.setGeolocationDatabasePath(context.getDir("geolocation", 0).getPath());
        if (API < 19) {
            webSettings.setDatabasePath(context.getDir("databases", 0).getPath());
        }
    }

    public void setDownloadEnable(String str) {
        Runnable runnable;
        Log.e("str123", "url11===" + str);
        if (!this.pageStartUrl.contains("youtube.com") && !this.pageStartUrl.contains("youtu.be") && !this.pageStartUrl.contains("timesofindia") && !str.startsWith("blob:") && !this.mUrl.equals(str) && !str.contains("/ad?") && !str.equals("https://www.vine.co/") && !str.contains("dailymotion.com/cdn")) {
            String fileExtensionFromUrl = MimeTypeMap.getFileExtensionFromUrl(str);
            String mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtensionFromUrl);
            Log.e("str", "extension===" + fileExtensionFromUrl);
            Log.e("str", "mimeType===" + mimeTypeFromExtension);
            Log.e("kkkkkkkkkkkkk", "url11:22222:::::::::" + this.url11);
            if (this.url11.contains("gifshow.com")) {
                this.mUrl = str;
                Log.e("kkkkkkkkkkkkk", "url11:22222::::::00000:::" + this.mUrl);
                Log.e("str", "mUrl===" + this.mUrl);
                runnable = new Runnable() {
                    public void run() {
                        img_download.setSelected(true);
                        animateDownloadIcon();
                        image_downloaded2.setSelected(true);
                    }
                };
            } else if (TextUtils.isEmpty(mimeTypeFromExtension)) {
                Log.e("str", "Empty mimeType===" + mimeTypeFromExtension);
                return;
            } else if (mimeTypeFromExtension.equals("video/3gpp") || mimeTypeFromExtension.equals("video/mp4")) {
                this.mUrl = str;
                Log.e("kkkkkkkkkkkkk", "url11:22222::::::444444:::" + this.mUrl);
                Log.e("str", "mUrl===" + this.mUrl);
                Log.e("str", str);
                runnable = new Runnable() {

                    public void run() {
                        img_download.setSelected(true);
                        animateDownloadIcon();
                        image_downloaded2.setSelected(true);
                    }
                };
            } else {
                Log.e("str", "===" + str);
                return;
            }
            runOnUiThread(runnable);
        }
    }

    public void setDownloadUnable() {
        this.mUrl = "";
        this.img_download.setSelected(false);
        this.image_downloaded2.setSelected(false);
    }

    private void showAlertDialog() {
        new AlertDialog.Builder(this).setTitle(HttpHeaders.WARNING).setMessage("Due to copyright issue. content can not be downloaded").setPositiveButton(getResources().getString(R.string.confirm), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).create().show();
    }

    public void vimeoOrFaceInsTips(String str) {
        this.url11 = str;
        if (str.contains("vimeo.com")) {
            img_download.setSelected(false);
            image_downloaded2.setSelected(false);
            isVimeo = true;
            if (!SharedConfig.getInstance(this.w).readBoolean(AppConstant.KEY.VIMEO_TIPS, false)) {
                SharedConfig.getInstance(this.w).writeData(AppConstant.KEY.VIMEO_TIPS, true);
                return;
            }
            return;
        }
        this.isVimeo = false;
        if (str.contains("dailymotion") || str.contains("metacafe.com")) {
            Log.e("str", "DAILIMOTION_UA");
            webview.getSettings().setUserAgentString(AppConfig.DAILIMOTION_UA);
        } else if (str.contains("instagram.com")) {
            if (!SharedConfig.getInstance(this.w).readBoolean(AppConstant.KEY.INSTAGRAM_TIPS, false)) {
                SharedConfig.getInstance(this.w).writeData(AppConstant.KEY.INSTAGRAM_TIPS, true);
                new MaterialDialog.Builder(this).content(getResources().getString(R.string.ins_tips)).positiveText("OK").show();
            }
        } else if (str.contains("facebook.com")) {
            if (!SharedConfig.getInstance(this.w).readBoolean(AppConstant.KEY.FACEBOOK_TIPS, false)) {
                SharedConfig.getInstance(this.w).writeData(AppConstant.KEY.FACEBOOK_TIPS, true);
                new MaterialDialog.Builder(this).content(getResources().getString(R.string.face_tips)).positiveText("OK").show();
            }
        } else if (this.url11.contains("youtube.com") || this.url11.contains("youtu.be") || this.url11.contains("timesofindia")) {
            this.img_download.setSelected(false);
            this.image_downloaded2.setSelected(false);
        }
    }

    @Override
    public void d() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this.w, 1, false));
        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL));
//        recyclerView.addItemDecoration(new DividerItemDecoration(Activity_Search.this.getDrawable(R.drawable.shape_recycler_linear_devider)));
        title_back.setOnClickListener(v -> {
            SystemUtils.hideInputmethod(edittext);
            finish();
        });
        img_search.setOnClickListener(v -> {
            if (TextUtils.isEmpty(edittext.getText().toString())) {
                ToastFactory.showToast(this.w, "Search data is empty");
                return;
            } else {
                searchOnclick();
                return;
            }
        });
        img_previous.setOnClickListener(v -> {
            if (!webview.canGoBack()) {
                finish();
                return;
            }
            webview.goBack();
            String userAgentString = webview.getSettings().getUserAgentString();
            if (!TextUtils.isEmpty(userAgentString) && userAgentString.equals("Mozilla/5.0 (Linux; ; ) AppleWebKit/ (KHTML, like Gecko) Chrome/ Mobile Safari/")) {
                webview.reload();
            }
        });
        img_refresh.setOnClickListener(v -> {
            this.isFirst = true;
            webview.reload();
        });
        img_clear.setOnClickListener(v -> {
            edittext.setText(str2);
            edittext.setSelection(0);
        });
        img_next.setOnClickListener(v -> {
            if (webview.canGoForward()) {
                webview.goForward();
                return;
            }
        });
        progressBar.setProgress(0);
        progressBar.setMax(100);
        img_download.setOnClickListener(v -> {
            Log.e("yyyyyyyyyyyy", "downloadFromDM.1111....url11." + webview.getUrl());
            Toast.makeText(this.w, "Downloading...", Toast.LENGTH_SHORT);
            if (webview.getUrl().contains("twitter.com")) {
                Toast.makeText(u, "Click on Share button then copy link", Toast.LENGTH_SHORT).show();
            } else if (webview.getUrl().contains("www.instagram.com")) {
                Toast.makeText(u, "copy link and go back", Toast.LENGTH_SHORT).show();
            } else if (!TextUtils.isEmpty(this.url11) && this.url11.contains("youtube.com") && (this.url11.contains("timesofindia") || this.url11.contains("youtu.be"))) {
                showAlertDialog();
                return;
            } else if (TextUtils.isEmpty(this.pageStartUrl) || (!this.pageStartUrl.contains("youtube.com") && !this.pageStartUrl.contains("youtu.be") && !this.pageStartUrl.contains("timesofindia"))) {
                Log.e("str", "url11===" + this.url11);
                if (this.img_download.isSelected()) {
                    if (this.url11.contains(str4) || this.url11.contains("xvideos.com")) {
                        this.n = new VideoInformation();
                        if (this.url11.contains(str4)) {
                            videoInformation = this.n;
                        } else {
                            if (this.url11.contains("xvideos.com")) {
                                videoInformation2 = this.n;
                                str2 = "xvideos.com";
                            }
                            this.n.setVideoname(System.currentTimeMillis() + AppConfig.MP4);
                            ArrayList arrayList2 = new ArrayList();
                            UrlInformation urlInformation2 = new UrlInformation();
                            urlInformation2.setFormat("MP4 High Quality");
                            urlInformation2.setUrl(this.xnxxHighUrl);
                            arrayList2.add(urlInformation2);
                            new UrlInformation().setFormat("MP4 Low Quality");
                            str4 = str2;
                            videoInformation = videoInformation2;
                        }
                        videoInformation.setWebsite(str4);
                        this.n.setVideoname(System.currentTimeMillis() + AppConfig.MP4);
                        arrayList = new ArrayList();
                        UrlInformation urlInformation3 = new UrlInformation();
                        urlInformation3.setFormat("MP4 High Quality");
                        urlInformation3.setUrl(this.xnxxHighUrl);
                        arrayList.add(urlInformation3);
                        urlInformation = new UrlInformation();
                        urlInformation.setFormat("MP4 Low Quality");
                        str = this.xnxxLowUrl;
                    } else if (this.url11.contains("hentaihaven.org")) {
                        VideoInformation videoInformation3 = new VideoInformation();
                        this.n = videoInformation3;
                        videoInformation3.setWebsite("hentaihaven");
                        this.n.setVideoname(System.currentTimeMillis() + AppConfig.MP4);
                        ArrayList arrayList3 = new ArrayList();
                        UrlInformation urlInformation4 = new UrlInformation();
                        if (!TextUtils.isEmpty(this.haven1080)) {
                            urlInformation4.setFormat("1080P");
                            urlInformation4.setUrl(this.haven1080);
                            arrayList3.add(urlInformation4);
                        }
                        if (!TextUtils.isEmpty(this.haven720)) {
                            UrlInformation urlInformation5 = new UrlInformation();
                            urlInformation5.setFormat("720P");
                            urlInformation5.setUrl(this.haven720);
                            arrayList3.add(urlInformation5);
                        }
                        if (!TextUtils.isEmpty(this.haven480)) {
                            UrlInformation urlInformation6 = new UrlInformation();
                            urlInformation6.setFormat("480P");
                            urlInformation6.setUrl(this.haven480);
                            arrayList3.add(urlInformation6);
                        }
                        if (!TextUtils.isEmpty(this.haver360)) {
                            new UrlInformation().setFormat("360P");
                        }
                        this.n.setUrlInfos(arrayList3);
                        ShowDownloadWindows();
                        return;
                    } else {
                        n = new VideoInformation();
                        n.setWebsite(this.website);
                        n.setVideoname(System.currentTimeMillis() + AppConfig.MP4);
                        arrayList = new ArrayList();
                        urlInformation = new UrlInformation();
                        urlInformation.setFormat("MP4");
                        str = this.mUrl;
                    }
                    urlInformation.setUrl(str);
                    arrayList.add(urlInformation);
                    n.setUrlInfos(arrayList);
                    ShowDownloadWindows();
                    Log.e("yyyyyyyyyyyy", "mUrl.1111....url11." + this.mUrl);
                } else if (this.url11.contains("vimeo.com")) {
//                    startActivity(new Intent(Activity_Search.this, HelpActivity.class));
                } else {
//                    startActivity(new Intent(Activity_Search.this, HelpActivity.class));
                }
            } else {
                showAlertDialog();
            }
        });
        this.img_download.setSelected(false);
        this.image_downloaded2.setSelected(false);
        setDownloadUnable();
        edittext.setOnEditorActionListener((textView, i, keyEvent) -> {
            if (i != 3 && i != 0 && i != 2) {
                return false;
            }
            searchOnclick();
            return true;
        });
        edittext.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (searchHistoryEntries != null && searchHistoryEntries.size() > 0) {
                    recyclerView.setVisibility(View.VISIBLE);
                }
            }
        });
        edittext.setOnFocusChangeListener(this);
        getWindow().setSoftInputMode(2);
    }

    @Override
    public void e() {
        String str;
        super.e();
        this.searchHistoryEntries = DBController.getInstance(this.w).querySearchHistoryAllByFive();
        adapter = new Adapter(R.layout.adapter_search_history_item, this.searchHistoryEntries);
        recyclerView.setAdapter(adapter);
        Log.e("str", "url11===" + this.url11);
        String str2 = this.url11;
        if (str2 != null) {
            edittext.setText(str2);
        }
        if (TextUtils.isEmpty(this.url11)) {
            this.url11 = "";
            ArrayList<SearchHistoryEntry> arrayList = this.searchHistoryEntries;
            if (arrayList != null) {
                arrayList.size();
            }
            Log.e("kkkkkkkkkkk", "url11::::::" + this.url11);
            search(this.url11);
            addHeaderAndFooter();
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    edittext.setFocusable(true);
                    edittext.setFocusableInTouchMode(true);
                    SystemUtils.showInputmethod(edittext);
                }
            }, 300);
        }
        if (this.url11.contains(HttpHost.DEFAULT_SCHEME_NAME)) {
            String str3 = this.url11;
            str = str3.substring(str3.indexOf(HttpHost.DEFAULT_SCHEME_NAME), this.url11.length());
        } else {
            str = this.GOOGLE_CUSTOM_URL + this.url11;
        }
        this.url11 = str;
        recyclerView.setVisibility(View.GONE);
        Log.e("kkkkkkkkkkk", "url11::::::22222" + this.url11);
        search(this.url11);
        addHeaderAndFooter();
        new Handler().postDelayed(new Runnable() {
            public void run() {
                edittext.setFocusable(true);
                edittext.setFocusableInTouchMode(true);
                SystemUtils.showInputmethod(edittext);
            }
        }, 300);
    }

    @Override
    public void onDestroy() {
        webview.destroy();
        super.onDestroy();
    }

    public void onFocusChange(View view, boolean z) {
        if (view == edittext) {
            try {
                ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 2);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            if (z) {
                changeButtons(2);
            } else {
                changeButtons(edittext.getText().toString().length() > 0 ? 3 : 4);
            }
        }
    }

    @Override
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4) {
            return super.onKeyDown(i, keyEvent);
        }
        Fragment findFragmentByTag = getSupportFragmentManager().findFragmentByTag(AllDownLoadVideo.newInstance().getClass().getName());
        Log.e("kkkkkkkkkkkkk", "ffragment::::::::" + findFragmentByTag);
        if (findFragmentByTag != null) {
            getSupportFragmentManager().popBackStack();
            return true;
        } else if (webview.canGoBack()) {
            webview.goBack();
            String userAgentString = webview.getSettings().getUserAgentString();
            if (TextUtils.isEmpty(userAgentString) || !userAgentString.equals("Mozilla/5.0 (Linux; ; ) AppleWebKit/ (KHTML, like Gecko) Chrome/ Mobile Safari/")) {
                return true;
            }
            webview.reload();
            return true;
        } else {
            finish();
            return true;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (webview != null) {
            webview.onPause();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (webview != null) {
            webview.onResume();
        }
        this.isFirst = true;
    }

}
