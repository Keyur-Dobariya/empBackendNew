package com.hd.video.downloader.play.video.facebook;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;

import androidx.appcompat.app.AppCompatActivity;

public abstract class Base_Activity extends AppCompatActivity {
    protected Activity s;
    protected Context t;

    public abstract void onCrete();

    public abstract void d();

    public void e() {
    }

    public void g() {
    }

    public boolean h() {
        return false;
    }

    public void f() {
        this.t = this;
        this.s = this;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        f();
        onCrete();
        d();
        e();
        g();
    }

    @Override
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !h()) {
            return super.onKeyDown(i, keyEvent);
        }
        return true;
    }
}
