package com.hd.video.downloader.play.video.facebook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;

public abstract class DefaultBaseAct extends Base_Activity {
    public Activity u;
    protected boolean v = true;
    public Context w;

    @Override
    public void f() {
        super.f();
        this.w = this;
        this.u = this;
    }

    public void finish() {
        finish(true);
    }

    public void finish(boolean z2) {
        super.finish();
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        if (this.v) {
            ActivityManager.getInstance().addActivity(this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (this.v) {
            ActivityManager.getInstance().delActivity(this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void startActivity(Intent intent) {
        startActivity(intent, true);
    }

    public void startActivity(Intent intent, boolean z2) {
        super.startActivity(intent);
    }

    @Override
    public void startActivityForResult(Intent intent, int i) {
        startActivityForResult(intent, i, true);
    }

    public void startActivityForResult(Intent intent, int i, boolean z2) {
        super.startActivityForResult(intent, i);
    }
}