package com.hd.video.downloader.play.video.facebook.module;


import com.hd.video.downloader.play.video.ads.app.MainApplication;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class AppModule_ProvideApplicationFactory_di implements Factory<MainApplication> {
    private final App_Module_di module;

    public AppModule_ProvideApplicationFactory_di(App_Module_di app_Module_di) {
        this.module = app_Module_di;
    }

    @Override
    public MainApplication get() {
        return provideInstance(this.module);
    }

    public static MainApplication provideInstance(App_Module_di app_Module_di) {
        return proxyProvideApplication(app_Module_di);
    }

    public static AppModule_ProvideApplicationFactory_di create(App_Module_di app_Module_di) {
        return new AppModule_ProvideApplicationFactory_di(app_Module_di);
    }

    public static MainApplication proxyProvideApplication(App_Module_di app_Module_di) {
        return (MainApplication) Preconditions.checkNotNull(app_Module_di.provideApplication(), "Cannot return null from a non-@Nullable @Provides method");
    }
}