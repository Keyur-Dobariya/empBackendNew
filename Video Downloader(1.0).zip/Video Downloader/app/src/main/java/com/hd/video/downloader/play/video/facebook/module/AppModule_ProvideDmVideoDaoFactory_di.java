package com.hd.video.downloader.play.video.facebook.module;


import com.hd.video.downloader.play.video.facebook.utilss.DmVideoDao;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class AppModule_ProvideDmVideoDaoFactory_di implements Factory<DmVideoDao> {
    private final App_Module_di module;

    public AppModule_ProvideDmVideoDaoFactory_di(App_Module_di app_Module_di) {
        this.module = app_Module_di;
    }

    @Override
    public DmVideoDao get() {
        return provideInstance(this.module);
    }

    public static DmVideoDao provideInstance(App_Module_di app_Module_di) {
        return proxyProvideDmVideoDao(app_Module_di);
    }

    public static AppModule_ProvideDmVideoDaoFactory_di create(App_Module_di app_Module_di) {
        return new AppModule_ProvideDmVideoDaoFactory_di(app_Module_di);
    }

    public static DmVideoDao proxyProvideDmVideoDao(App_Module_di app_Module_di) {
        return (DmVideoDao) Preconditions.checkNotNull(app_Module_di.provideDmVideoDao(), "Cannot return null from a non-@Nullable @Provides method");
    }
}