package com.hd.video.downloader.play.video.facebook.module;

import dagger.internal.Factory;
import dagger.internal.Preconditions;
import okhttp3.OkHttpClient;

public final class AppModule_ProvideOkHttpClientFactory_di implements Factory<OkHttpClient> {
    private final App_Module_di module;

    public AppModule_ProvideOkHttpClientFactory_di(App_Module_di app_Module_di) {
        this.module = app_Module_di;
    }

    @Override
    public OkHttpClient get() {
        return provideInstance(this.module);
    }

    public static OkHttpClient provideInstance(App_Module_di app_Module_di) {
        return proxyProvideOkHttpClient(app_Module_di);
    }

    public static AppModule_ProvideOkHttpClientFactory_di create(App_Module_di app_Module_di) {
        return new AppModule_ProvideOkHttpClientFactory_di(app_Module_di);
    }

    public static OkHttpClient proxyProvideOkHttpClient(App_Module_di app_Module_di) {
        return (OkHttpClient) Preconditions.checkNotNull(app_Module_di.provideOkHttpClient(), "Cannot return null from a non-@Nullable @Provides method");
    }
}