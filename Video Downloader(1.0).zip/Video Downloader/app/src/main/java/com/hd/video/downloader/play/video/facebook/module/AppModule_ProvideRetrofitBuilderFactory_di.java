package com.hd.video.downloader.play.video.facebook.module;

import javax.inject.Provider;

import dagger.internal.Factory;
import dagger.internal.Preconditions;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

public final class AppModule_ProvideRetrofitBuilderFactory_di implements Factory<Retrofit> {
    private final App_Module_di module;
    private final Provider<OkHttpClient> okHttpClientProvider;

    public AppModule_ProvideRetrofitBuilderFactory_di(App_Module_di app_Module_di, Provider<OkHttpClient> provider) {
        this.module = app_Module_di;
        this.okHttpClientProvider = provider;
    }

    @Override
    public Retrofit get() {
        return provideInstance(this.module, this.okHttpClientProvider);
    }

    public static Retrofit provideInstance(App_Module_di app_Module_di, Provider<OkHttpClient> provider) {
        return proxyProvideRetrofitBuilder(app_Module_di, provider.get());
    }

    public static AppModule_ProvideRetrofitBuilderFactory_di create(App_Module_di app_Module_di, Provider<OkHttpClient> provider) {
        return new AppModule_ProvideRetrofitBuilderFactory_di(app_Module_di, provider);
    }

    public static Retrofit proxyProvideRetrofitBuilder(App_Module_di app_Module_di, OkHttpClient okHttpClient) {
        return (Retrofit) Preconditions.checkNotNull(app_Module_di.provideRetrofitBuilder(okHttpClient), "Cannot return null from a non-@Nullable @Provides method");
    }
}