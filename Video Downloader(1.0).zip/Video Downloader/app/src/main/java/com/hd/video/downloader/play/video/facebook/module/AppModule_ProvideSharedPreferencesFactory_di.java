package com.hd.video.downloader.play.video.facebook.module;

import android.content.SharedPreferences;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class AppModule_ProvideSharedPreferencesFactory_di implements Factory<SharedPreferences> {
    private final App_Module_di module;

    public AppModule_ProvideSharedPreferencesFactory_di(App_Module_di app_Module_di) {
        this.module = app_Module_di;
    }

    @Override
    public SharedPreferences get() {
        return provideInstance(this.module);
    }

    public static SharedPreferences provideInstance(App_Module_di app_Module_di) {
        return proxyProvideSharedPreferences(app_Module_di);
    }

    public static AppModule_ProvideSharedPreferencesFactory_di create(App_Module_di app_Module_di) {
        return new AppModule_ProvideSharedPreferencesFactory_di(app_Module_di);
    }

    public static SharedPreferences proxyProvideSharedPreferences(App_Module_di app_Module_di) {
        return (SharedPreferences) Preconditions.checkNotNull(app_Module_di.provideSharedPreferences(), "Cannot return null from a non-@Nullable @Provides method");
    }
}