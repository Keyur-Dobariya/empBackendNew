package com.hd.video.downloader.play.video.facebook.utilss;

import android.content.Context;


import com.hd.video.downloader.play.video.facebook.module.App_Module_di;
import com.hd.video.downloader.play.video.facebook.module.SharedPref_database_model;

import javax.inject.Singleton;

import dagger.Component;

@Component(modules = {App_Module_di.class})
@Singleton
public interface AppComponent {
    Context context();

    DatabaseModel getDatabaseModel();

    DmVideoDao getDmVideoDao();

    SharedPref_database_model getSharedPref();
}
