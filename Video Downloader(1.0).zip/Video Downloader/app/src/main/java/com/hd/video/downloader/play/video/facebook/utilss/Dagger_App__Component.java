package com.hd.video.downloader.play.video.facebook.utilss;

import android.content.Context;
import android.content.SharedPreferences;


import com.hd.video.downloader.play.video.ads.app.MainApplication;
import com.hd.video.downloader.play.video.facebook.module.AppModule_ProvideApplicationContextFactory_di;
import com.hd.video.downloader.play.video.facebook.module.AppModule_ProvideApplicationFactory_di;
import com.hd.video.downloader.play.video.facebook.module.AppModule_ProvideDmVideoDaoFactory_di;
import com.hd.video.downloader.play.video.facebook.module.AppModule_ProvideOkHttpClientFactory_di;
import com.hd.video.downloader.play.video.facebook.module.AppModule_ProvideRetrofitBuilderFactory_di;
import com.hd.video.downloader.play.video.facebook.module.AppModule_ProvideSharedPreferencesFactory_di;
import com.hd.video.downloader.play.video.facebook.module.App_Module_di;
import com.hd.video.downloader.play.video.facebook.module.SharedPref_database_model;

import javax.inject.Provider;

import dagger.internal.DoubleCheck;
import dagger.internal.Preconditions;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

public final class Dagger_App__Component implements AppComponent {
    public static Provider<MainApplication> provideApplicationProvider;
    private Provider<Context> provideApplicationContextProvider;
    private Provider<DmVideoDao> provideDmVideoDaoProvider;
    private Provider<OkHttpClient> provideOkHttpClientProvider;
    Provider<Retrofit> provideRetrofitBuilderProvider;
    private Provider<SharedPreferences> provideSharedPreferencesProvider;

    public static final class Builder {
        public App_Module_di appModule;

        private Builder() {
        }

        public AppComponent build() {
            if (this.appModule != null) {
                return new Dagger_App__Component(this);
            }
            throw new IllegalStateException(App_Module_di.class.getCanonicalName() + " must be set");
        }

        public Builder appModule(App_Module_di app_Module_di) {
            this.appModule = (App_Module_di) Preconditions.checkNotNull(app_Module_di);
            return this;
        }
    }

    private Dagger_App__Component(Builder builder) {
        initialize(builder);
    }

    public static Builder builder() {
        return new Builder();
    }

    private void initialize(Builder builder) {
        this.provideApplicationContextProvider = DoubleCheck.provider(AppModule_ProvideApplicationContextFactory_di.create(builder.appModule));
        this.provideOkHttpClientProvider = DoubleCheck.provider(AppModule_ProvideOkHttpClientFactory_di.create(builder.appModule));
        this.provideRetrofitBuilderProvider = DoubleCheck.provider(AppModule_ProvideRetrofitBuilderFactory_di.create(builder.appModule, this.provideOkHttpClientProvider));
        this.provideSharedPreferencesProvider = DoubleCheck.provider(AppModule_ProvideSharedPreferencesFactory_di.create(builder.appModule));
        provideApplicationProvider = DoubleCheck.provider(AppModule_ProvideApplicationFactory_di.create(builder.appModule));
        this.provideDmVideoDaoProvider = DoubleCheck.provider(AppModule_ProvideDmVideoDaoFactory_di.create(builder.appModule));
    }

    @Override
    public Context context() {
        return this.provideApplicationContextProvider.get();
    }

    @Override
    public DatabaseModel getDatabaseModel() {
        return new DatabaseModel(this.provideApplicationContextProvider.get());
    }

    @Override
    public SharedPref_database_model getSharedPref() {
        return new SharedPref_database_model(this.provideSharedPreferencesProvider.get());
    }

    @Override
    public DmVideoDao getDmVideoDao() {
        return this.provideDmVideoDaoProvider.get();
    }
}
