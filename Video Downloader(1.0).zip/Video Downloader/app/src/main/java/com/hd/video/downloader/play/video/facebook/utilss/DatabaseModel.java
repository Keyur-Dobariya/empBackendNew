package com.hd.video.downloader.play.video.facebook.utilss;

import android.content.Context;


import javax.inject.Inject;

public class DatabaseModel {
    private DaoMaster.DevOpenHelper openHelper;
    @Inject
    public DatabaseModel(Context context) {
        this.openHelper = new DaoMaster.DevOpenHelper(context, "downtube_video", null);
    }
}
