package com.hd.video.downloader.play.video.facebook.utilss;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DmVideo implements Serializable {
    public boolean favorite;
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("thumbnail_480_url")
    @Expose
    public String thumbnail480 = "";
    @SerializedName("title")
    @Expose
    public String title;
    public boolean watchLater;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getThumbnail480() {
        return this.thumbnail480;
    }

    public void setThumbnail480(String str) {
        this.thumbnail480 = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public boolean isFavorite() {
        return this.favorite;
    }

    public void setFavorite(boolean z) {
        this.favorite = z;
    }

    public boolean isWatchLater() {
        return this.watchLater;
    }

    public void setWatchLater(boolean z) {
        this.watchLater = z;
    }

    public String toString() {
        return "DmVideo{id='" + this.id + '\'' + ", thumbnail480='" + this.thumbnail480 + '\'' + ", title='" + this.title + '\'' + ", favorite=" + this.favorite + ", watchLater=" + this.watchLater + '}';
    }
}
