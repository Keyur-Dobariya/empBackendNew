package com.hd.video.downloader.play.video.facebook.utilss;

import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.database.DatabaseStatement;
import org.greenrobot.greendao.internal.DaoConfig;

public class DownloadMissionItemDao extends AbstractDao<DownloadMissionItem, Long> {

    public void a(int i) {
    }

    public boolean a() {
        return false;
    }

    public boolean a(DownloadMissionItem downloadMissionItem) {
        return false;
    }

    public void bindValues(SQLiteStatement sQLiteStatement, DownloadMissionItem downloadMissionItem) {
    }

    public void bindValues(DatabaseStatement databaseStatement, DownloadMissionItem downloadMissionItem) {
    }

    public boolean hasKey(DownloadMissionItem downloadMissionItem) {
        return false;
    }

    @Override
    public boolean isEntityUpdateable() {
        return false;
    }

    public void readEntity(Cursor cursor, DownloadMissionItem downloadMissionItem, int i) {
    }

    public Long updateKeyAfterInsert(DownloadMissionItem downloadMissionItem, long j) {
        return null;
    }

    public DownloadMissionItemDao(DaoConfig daoConfig, DaoSession daoSession) {
        super(daoConfig, daoSession);
    }

    public static void createTable(Database database, boolean z) {
        String str = z ? "IF NOT EXISTS " : "";
        database.execSQL("CREATE TABLE " + str + "\"DOWNLOAD_MISSION_ITEM\" (\"_id\" INTEGER PRIMARY KEY NOT NULL ,\"URL\" TEXT,\"NAME\" TEXT,\"THUMBNAIL\" TEXT,\"RESULT\" INTEGER NOT NULL );");
    }

    public static void dropTable(Database database, boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append("DROP TABLE ");
        sb.append(z ? "IF EXISTS " : "");
        sb.append("\"DOWNLOAD_MISSION_ITEM\"");
        database.execSQL(sb.toString());
    }

    public final void a(DatabaseStatement databaseStatement, DownloadMissionItem downloadMissionItem) {
        databaseStatement.clearBindings();
        databaseStatement.bindLong(1, downloadMissionItem.getMissionId());
        String url = downloadMissionItem.getUrl();
        if (url != null) {
            databaseStatement.bindString(2, url);
        }
        String name = downloadMissionItem.getName();
        if (name != null) {
            databaseStatement.bindString(3, name);
        }
        String thumbnail = downloadMissionItem.getThumbnail();
        if (thumbnail != null) {
            databaseStatement.bindString(4, thumbnail);
        }
        databaseStatement.bindLong(5, (long) downloadMissionItem.getResult());
    }

    public final void a(SQLiteStatement sQLiteStatement, DownloadMissionItem downloadMissionItem) {
        sQLiteStatement.clearBindings();
        sQLiteStatement.bindLong(1, downloadMissionItem.getMissionId());
        String url = downloadMissionItem.getUrl();
        if (url != null) {
            sQLiteStatement.bindString(2, url);
        }
        String name = downloadMissionItem.getName();
        if (name != null) {
            sQLiteStatement.bindString(3, name);
        }
        String thumbnail = downloadMissionItem.getThumbnail();
        if (thumbnail != null) {
            sQLiteStatement.bindString(4, thumbnail);
        }
        sQLiteStatement.bindLong(5, (long) downloadMissionItem.getResult());
    }

    @Override
    public Long readKey(Cursor cursor, int i) {
        return Long.valueOf(cursor.getLong(i + 0));
    }

    @Override
    public DownloadMissionItem readEntity(Cursor cursor, int i) {
        long j = cursor.getLong(i + 0);
        int i2 = i + 1;
        String string = cursor.isNull(i2) ? null : cursor.getString(i2);
        int i3 = i + 2;
        String string2 = cursor.isNull(i3) ? null : cursor.getString(i3);
        int i4 = i + 3;
        return new DownloadMissionItem(j, string, string2, cursor.isNull(i4) ? null : cursor.getString(i4), cursor.getInt(i + 4));
    }

    public final Long a(DownloadMissionItem downloadMissionItem, long j) {
        downloadMissionItem.setMissionId(j);
        return j;
    }

    public Long getKey(DownloadMissionItem downloadMissionItem) {
        if (downloadMissionItem != null) {
            return downloadMissionItem.getMissionId();
        }
        return null;
    }
}