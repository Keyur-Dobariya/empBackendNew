package com.hd.video.downloader.play.video.fragments_downloader.adapter_downloader;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.Selection;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ItemWaStatusListBinding;
import com.hd.video.downloader.play.video.downloader_downloader.AppConfig;
import com.hd.video.downloader.play.video.downloader_downloader.AppConstant;
import com.hd.video.downloader.play.video.fragments_downloader.bean_downloader.WAStatus;
import com.hd.video.downloader.play.video.fragments_downloader.download_file_util;
import com.hd.video.downloader.play.video.Mainvideos.Activity_Image_Screen;
import com.hd.video.downloader.play.video.Mainvideos.Activity_VideoLocalPlay;
import com.hd.video.downloader.play.video.fragments_downloader.fb_download_frag;
import com.hd.video.downloader.play.video.fragments_downloader.twit_download_frag;

import java.io.File;
import java.util.ArrayList;

@SuppressLint("WrongConstant")
public class adapter_twit_video_download extends RecyclerView.Adapter<adapter_twit_video_download.WA_StatusViewHolder> {
    public static ArrayList<WAStatus> mWAStatusesList;
    ActionMode actionMode;
    public Context mContext;
    public String mWhoIs;
    boolean multiSelect;
    ArrayList<Integer> selectedItem = new ArrayList<>();

    public adapter_twit_video_download(Context context, ArrayList<WAStatus> mStatusesList, String mPath, OnClickListener listener) {
        this.mContext = context;
        mWAStatusesList = mStatusesList;
        this.mWhoIs = mPath;
        this.listener = listener;
    }

    public interface OnClickListener {
        void onItemClick(int position);
    }

    OnClickListener listener;

    public class WA_StatusViewHolder extends RecyclerView.ViewHolder {
        ItemWaStatusListBinding binding;

        public WA_StatusViewHolder(ItemWaStatusListBinding view) {
            super(view.getRoot());
            binding = view;
        }

        public void bindItem(final WAStatus wAStatus) {
            binding.more.setVisibility(View.VISIBLE);
            Glide.with(this.itemView.getContext()).load(new File(wAStatus.getFilePath())).into(binding.imgStatusThumbItemWAStatusList);
            String mimeType = download_file_util.getMimeType(new File(adapter_twit_video_download.mWAStatusesList.get(getAdapterPosition()).getFilePath()));
            if (mimeType != null) {
            }
            binding.tvFileSizeWAStatusItem.setText(wAStatus.getFileSize());
            binding.more.setOnClickListener(view -> {
                twit_download_frag.positionfromclick = getAdapterPosition();
                PopupMenu popupMenu = new PopupMenu(mContext, binding.more);
                popupMenu.inflate(R.menu.popup_menu);
                popupMenu.getMenu().add("Rename");
                popupMenu.setOnMenuItemClickListener(menuItem -> {
                    int itemId = menuItem.getItemId();
                    if (itemId == R.id.plaay) {
                        String mimeType1 = download_file_util.getMimeType(new File(adapter_twit_video_download.mWAStatusesList.get(getAdapterPosition()).getFilePath()));
                        Log.e("kkkkkkkkkkkkk", "downloadVideo/...............str.....mimeTypemimeTypemimeType......" + mimeType1);
                        if (mimeType1.contains("image") || mimeType1.contains("gif")) {
                            openInFullScreen(adapter_twit_video_download.mWAStatusesList.get(getAdapterPosition()));
                            return false;
                        }
                        mContext.startActivity(new Intent(mContext, Activity_VideoLocalPlay.class).putExtra(AppConstant.KEY.URL, adapter_twit_video_download.mWAStatusesList.get(getAdapterPosition()).getFilePath()));
                        return false;
                    } else if (itemId == R.id.delete) {
                        listener.onItemClick(getAdapterPosition());
                        return false;
                    } else if (itemId == R.id.share) {
                        shareVideo(getAdapterPosition());
                        return false;
                    } else if (itemId == R.id.property) {
                        showDialog(mContext, getAdapterPosition());
                        return false;
                    } else {
                        renameFile(getAdapterPosition());
                        return false;
                    }
                });
                popupMenu.show();
            });
        }

        public void showDialog(Context context, int i) {
            Dialog dialog = new Dialog(context);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.propertydialog);
            dialog.setCancelable(true);
            ((TextView) dialog.findViewById(R.id.type)).setText("Type          :");
            ((TextView) dialog.findViewById(R.id.resoulution)).setText("Size          :");
            WAStatus wAStatus = adapter_twit_video_download.mWAStatusesList.get(i);
            ((TextView) dialog.findViewById(R.id.filename)).setText(wAStatus.getFileName());
            ((TextView) dialog.findViewById(R.id.title)).setText(wAStatus.getFileName());
            ((TextView) dialog.findViewById(R.id.path)).setText(wAStatus.getFilePath());
            ((TextView) dialog.findViewById(R.id.size)).setText(wAStatus.getFileSize());
            ((TextView) dialog.findViewById(R.id.time)).setText(wAStatus.getStatusType());
            double d = (double) mContext.getResources().getDisplayMetrics().widthPixels;
            Double.isNaN(d);
            double d2 = (double) mContext.getResources().getDisplayMetrics().heightPixels;
            Double.isNaN(d2);
            int i2 = (int) (d2 * 0.6d);
            dialog.getWindow().setLayout((int) (d * 0.85d), i2);
            dialog.show();
        }

        private void deleteDownloadedFile(final int i) {
            new AlertDialog.Builder(mContext).setMessage("Are you sure want to Delete").setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i1) {
                    if (new File(adapter_twit_video_download.mWAStatusesList.get(i).getFilePath()).delete()) {
                        adapter_twit_video_download.mWAStatusesList.remove(i);
                        notifyItemRemoved(i1);
                        Toast.makeText(mContext, "Delete sucessfully", Toast.LENGTH_SHORT).show();
                    }
                }
            }).setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) null).show();
        }

        private void shareVideo(int i) {
            Uri photoURI = FileProvider.getUriForFile(mContext,
                    mContext.getPackageName() + ".provider", // Over here
                    new File(adapter_twit_video_download.mWAStatusesList.get(i).getFilePath()));

            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("video/mp4");
            intent.putExtra("android.intent.extra.STREAM", photoURI);
            mContext.startActivity(Intent.createChooser(intent, "Share Using"));
        }

        public void renameFile(final int i) {
            final String valueOf = String.valueOf(adapter_twit_video_download.mWAStatusesList.get(i).getFilePath());
            String fileName = adapter_twit_video_download.mWAStatusesList.get(i).getFileName();
            String substring = fileName.substring(0, fileName.lastIndexOf(46));
            final EditText editText = new EditText(mContext);
            editText.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            editText.setText(substring);
            editText.setCursorVisible(true);
            Selection.setSelection(editText.getText(), substring.length());
            new AlertDialog.Builder(mContext).setView(editText).setMessage("Type new name:").setPositiveButton("OK", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialogInterface, int i1) {
                    File file;
                    String obj = editText.getText().toString();
                    if (obj.equals("")) {
                        Toast.makeText(mContext, "Name cannot be blank", 1).show();
                        return;
                    }
                    File file2 = new File(valueOf);
                    String mimeType = download_file_util.getMimeType(new File(adapter_twit_video_download.mWAStatusesList.get(getAdapterPosition()).getFilePath()));
                    if (mimeType.contains("image")) {
                        StringBuilder sb = new StringBuilder();
                        String str = valueOf;
                        sb.append(str.substring(0, str.lastIndexOf("/") + 1));
                        sb.append(obj);
                        sb.append(".jpg");
                        file = new File(sb.toString());
                    } else if (mimeType.contains("gif")) {
                        StringBuilder sb2 = new StringBuilder();
                        String str2 = valueOf;
                        sb2.append(str2.substring(0, str2.lastIndexOf("/") + 1));
                        sb2.append(obj);
                        sb2.append(".gif");
                        file = new File(sb2.toString());
                    } else {
                        StringBuilder sb3 = new StringBuilder();
                        String str3 = valueOf;
                        sb3.append(str3.substring(0, str3.lastIndexOf("/") + 1));
                        sb3.append(obj);
                        sb3.append(AppConfig.MP4);
                        file = new File(sb3.toString());
                    }
                    if (file.exists()) {
                        Toast.makeText(mContext, "File name already exists", 1).show();
                    } else if (file2.renameTo(file)) {
                        adapter_twit_video_download.mWAStatusesList.get(i).mFileName = file.getName();
                        adapter_twit_video_download.mWAStatusesList.get(i).mFilePath = file.getPath();
                        Toast.makeText(mContext, "Rename sucessfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(mContext, "File can't be renamed.", 1).show();
                    }
                    notifyDataSetChanged();
                    try {
                        mContext.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(file)));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    ((InputMethodManager) mContext.getSystemService("input_method")).hideSoftInputFromWindow(editText.getWindowToken(), 0);
                    notifyItemChanged(i1);
                }
            }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).create().show();
        }

        public void openInFullScreen(WAStatus wAStatus) {
            Activity_Image_Screen.newIntent(this.itemView.getContext(), wAStatus, mWhoIs);
        }
    }

    @Override
    public int getItemViewType(int i) {
        Log.e("kkkkkkkkkkkkk", "getItemViewType.........." + i);
        return i;
    }

    @Override
    public WA_StatusViewHolder onCreateViewHolder(ViewGroup parent, int i) {
        return new WA_StatusViewHolder(ItemWaStatusListBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    public void onBindViewHolder(final WA_StatusViewHolder wA_StatusViewHolder, final int i) {
        Log.e("kkkkkkkkkkkkk", "onBindViewHolder.........." + i);
        wA_StatusViewHolder.bindItem(mWAStatusesList.get(i));
        wA_StatusViewHolder.binding.rlSelect.setOnClickListener(view -> {
            Log.e("kkkkkkkkkkkkk", "setOnClickListener.........." + i);
            if (multiSelect) {
                setSelectedItem(i);
                return;
            }
            bindholder(i, wA_StatusViewHolder, view);
        });
    }

    private void setSelectedItem(int i) {
        Log.i("setSelectedItem", "setSelectedItem: " + this.selectedItem);
        if (this.multiSelect) {
            if (this.selectedItem.contains(i)) {
                this.selectedItem.remove(Integer.valueOf(i));
            } else {
                this.selectedItem.add(i);
            }
        }
        notifyItemChanged(i);
        ActionMode actionMode2 = this.actionMode;
        if (actionMode2 != null) {
            actionMode2.setTitle(this.selectedItem.size() + " selected");
            if (this.selectedItem.size() == 0) {
                actionMode2.finish();
            }
        }
    }

    public void bindholder(int i, WA_StatusViewHolder wA_StatusViewHolder, View view) {
        String mimeType = download_file_util.getMimeType(new File(mWAStatusesList.get(i).getFilePath()));
        Log.e("kkkkkkkkkkkkk", "downloadVideo/...............str.....mimeTypemimeTypemimeType......" + mimeType);
        if (mimeType.contains("image")) {
            wA_StatusViewHolder.openInFullScreen(mWAStatusesList.get(i));
        } else {
            startActivitys(new Intent(this.mContext, Activity_VideoLocalPlay.class).putExtra(AppConstant.KEY.URL, mWAStatusesList.get(i).getFilePath()));
        }
    }

    @Override
    public int getItemCount() {
        return mWAStatusesList.size();
    }


    //    ***********intetial******************
    private void startActivitys(Intent intent) {
        InterstitialAds.showAd(mContext, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                mContext.startActivity(intent);
            }

            @Override
            public void onAdImpression() {
            }
        });
    }
}
