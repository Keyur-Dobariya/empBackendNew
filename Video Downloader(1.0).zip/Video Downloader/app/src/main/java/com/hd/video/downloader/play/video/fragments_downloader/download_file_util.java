package com.hd.video.downloader.play.video.fragments_downloader;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.preference.PreferenceManager;
import android.webkit.MimeTypeMap;

import androidx.documentfile.provider.DocumentFile;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class download_file_util {
    public static String getMimeType(File file) {
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(file).toString()));
    }

    @SuppressLint("WrongConstant")

    public static void scanFile(String str, Context context) {
        if (str != null) {
            DocumentFile documentFile = getDocumentFile(new File(str), false, context);
            if (documentFile == null) {
                documentFile = DocumentFile.fromFile(new File(str));
            }
            scanFile(documentFile.getUri(), context);
        }
    }

    private static void scanFile(Uri uri, Context context) {
        context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", uri));
    }
    public static Uri parse ;

    public static DocumentFile getDocumentFile(File file, boolean z, Context context) {
        String str;
        boolean z2;
        if (Build.VERSION.SDK_INT <= 19) {
            return DocumentFile.fromFile(file);
        }
        String extSdCardFolder = getExtSdCardFolder(file, context);
        if (extSdCardFolder == null) {
            return null;
        }
        int i = 0;
        try {
            String canonicalPath = file.getCanonicalPath();
            if (!extSdCardFolder.equals(canonicalPath)) {
                str = canonicalPath.substring(extSdCardFolder.length() + 1);
                z2 = false;
                String string = PreferenceManager.getDefaultSharedPreferences(context).getString("URI", null);
                parse = string == null ? Uri.parse(string) : null;
                if (parse != null) {
                    return null;
                }
                DocumentFile fromTreeUri = DocumentFile.fromTreeUri(context, parse);
                if (z2) {
                    return fromTreeUri;
                }
                String[] split = str.split("\\/");
                while (i < split.length) {
                    DocumentFile findFile = fromTreeUri.findFile(split[i]);
                    fromTreeUri = findFile == null ? (i < split.length - 1 || z) ? fromTreeUri.createDirectory(split[i]) : fromTreeUri.createFile("image", split[i]) : findFile;
                    i++;
                }
                return fromTreeUri;
            }
        } catch (IOException unused) {
            return null;
        } catch (Exception unused2) {
        }
        str = null;
        z2 = true;
        String string2 = PreferenceManager.getDefaultSharedPreferences(context).getString("URI", null);
        if (string2 == null) {
        }
        if (parse != null) {
        }
        return null;
    }

    private static String getExtSdCardFolder(File file, Context context) {
        String[] extSdCardPaths = getExtSdCardPaths(context);
        for (int i = 0; i < extSdCardPaths.length; i++) {
            try {
                if (file.getCanonicalPath().startsWith(extSdCardPaths[i])) {
                    return extSdCardPaths[i];
                }
            } catch (IOException unused) {
            }
        }
        return null;
    }

    private static String[] getExtSdCardPaths(Context context) {
        int lastIndexOf;
        ArrayList arrayList = new ArrayList();
        File[] externalFilesDirs = context.getExternalFilesDirs("external");
        for (File file : externalFilesDirs) {
            if (file != null && !file.equals(context.getExternalFilesDir("external")) && (lastIndexOf = file.getAbsolutePath().lastIndexOf("/Android/data")) >= 0) {
                String substring = file.getAbsolutePath().substring(0, lastIndexOf);
                try {
                    substring = new File(substring).getCanonicalPath();
                } catch (IOException unused) {
                }
                arrayList.add(substring);
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.add("/storage/sdcard1");
        }
        return (String[]) arrayList.toArray(new String[0]);
    }
}