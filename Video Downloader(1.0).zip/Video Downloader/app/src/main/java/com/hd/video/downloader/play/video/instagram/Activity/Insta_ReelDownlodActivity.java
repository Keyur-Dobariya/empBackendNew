package com.hd.video.downloader.play.video.instagram.Activity;

import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.InstaActivityPhotosVideoDownloadBinding;
import com.hd.video.downloader.play.video.databinding.InstaActivityReelDownlodBinding;
import com.hd.video.downloader.play.video.instagram.Models.Insta_JsonObjectRootModel;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class Insta_ReelDownlodActivity extends AppCompatActivity {
    private AlertDialog dialog;
    Insta_JsonObjectRootModel finalresponse;
    ProgressBar progressbar;
    String stringobj;
    View view;

    InstaActivityReelDownlodBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = InstaActivityReelDownlodBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        view = LayoutInflater.from(this).inflate(R.layout.insta_progress_dailog, null);
        progressbar = view.findViewById(R.id.progressbar);
        init();
        onclick();
    }


    private void init() {
        this.stringobj = getIntent().getStringExtra("FINALRESPONSE");
        this.finalresponse = new Gson().fromJson(this.stringobj, new TypeToken<Insta_JsonObjectRootModel>() {
        }.getType());
        Picasso.get().load(this.finalresponse.getThumb()).into(binding.reelthumbnil, new Callback() {

            @Override
            public void onError(Exception exc) {
            }

            @Override
            public void onSuccess() {
                binding.pbHeaderProgress.setVisibility(View.GONE);
                binding.imgcardview.setVisibility(View.VISIBLE);
                binding.btndownload.setVisibility(View.VISIBLE);
            }
        });
    }

    private void onclick() {
        binding.back.setOnClickListener(view -> finish());
        binding.btntrynew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        binding.btndownload.setOnClickListener(view -> {
            if (finalresponse.getUrl().get(0).getExt().equals("mp4")) {
                downloading(finalresponse.getUrl().get(0).getUrl(), ".mp4", Environment.DIRECTORY_MOVIES);
                return;
            }
            downloading(finalresponse.getUrl().get(0).getUrl(), ".jpg", Environment.DIRECTORY_PICTURES);
        });

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Insta_ReelDownlodActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void downloading(final String str, final String str2, final String str3) {
        progressdailog();
        ScheduledExecutorService newSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        newSingleThreadScheduledExecutor.execute(new Runnable() {
            int count;

            public void run() {
                try {
                    URLConnection openConnection = new URL(str).openConnection();
                    openConnection.connect();
                    int contentLength = openConnection.getContentLength();
                    InputStream inputStream = openConnection.getInputStream();
                    File file = new File(Environment.getExternalStoragePublicDirectory(str3).getAbsolutePath() + File.separator + "Insta Video Downloader");
                    if (!file.exists()) {
                        file.mkdir();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(file + "/download_" + generateFileName() + str2);
                    byte[] bArr = new byte[1024];
                    long j = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        this.count = read;
                        if (read != -1) {
                            j += read;
                            Insta_ReelDownlodActivity reelDownlodActivity = Insta_ReelDownlodActivity.this;
                            reelDownlodActivity.publishProgress(Integer.valueOf("" + ((int) ((100 * j) / ((long) contentLength)))));
                            fileOutputStream.write(bArr, 0, this.count);
                        } else {
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            inputStream.close();
                            handler.post(new Runnable() {
                                public void run() {
                                    hideDialog();
                                    finish();
                                }
                            });
                            return;
                        }
                    }
                } catch (Exception unused) {
                }
            }
        });
    }

    private String generateFileName() {
        return new SimpleDateFormat("hh_mm_ss").format(new Date());
    }

    private void publishProgress(Integer... numArr) {
        progressbar.setProgress(numArr[0].intValue());
    }

    private void progressdailog() {
        dialog = new AlertDialog.Builder(this).setView(this.view).setCancelable(false).show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
    }

    private void hideDialog() {
        if (dialog != null) {
            if (dialog.isShowing()) {
                this.dialog.dismiss();
            }
            this.dialog = null;
        }
    }
}