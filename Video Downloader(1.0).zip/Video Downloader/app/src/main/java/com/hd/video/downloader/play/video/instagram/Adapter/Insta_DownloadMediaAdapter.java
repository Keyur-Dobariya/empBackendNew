package com.hd.video.downloader.play.video.instagram.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.databinding.InstaItemDownloadFragmentBinding;
import com.hd.video.downloader.play.video.instagram.Models.Insta_JsonArrayRootModel;

import java.util.ArrayList;
import java.util.List;

public class Insta_DownloadMediaAdapter extends RecyclerView.Adapter {
    Context context;
    List<Insta_JsonArrayRootModel> downloadimagelist = new ArrayList();
    List<Insta_JsonArrayRootModel> finalresponse;
    private OnClickListener onClickListener;

    public interface OnClickListener {
        void onClick(List<Insta_JsonArrayRootModel> list);
    }

    public void setOnClickListener(OnClickListener onClickListener2) {
        this.onClickListener = onClickListener2;
    }

    public Insta_DownloadMediaAdapter(List<Insta_JsonArrayRootModel> list, Context context2) {
        this.finalresponse = list;
        this.context = context2;
    }

    @Override
    public Adapter_ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(InstaItemDownloadFragmentBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, @SuppressLint("RecyclerView") final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        Glide.with(this.context).load(this.finalresponse.get(i).getUrl().get(0).getUrl()).into(adapter_ViewHolder.binding.imageView);
        adapter_ViewHolder.binding.checkbox.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (adapter_ViewHolder.binding.checkbox.isChecked()) {
                    downloadimagelist.add(finalresponse.get(i));
                } else if (downloadimagelist.contains(finalresponse.get(i))) {
                    downloadimagelist.remove(finalresponse.get(i));
                }
                onClickListener.onClick(downloadimagelist);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.finalresponse.size();
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        InstaItemDownloadFragmentBinding binding;

        public Adapter_ViewHolder(InstaItemDownloadFragmentBinding view) {
            super(view.getRoot());
            binding = view;
            DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
            ViewGroup.LayoutParams layoutParams = binding.imageView.getLayoutParams();
            layoutParams.width = displayMetrics.widthPixels / 3;
            layoutParams.height = displayMetrics.widthPixels / 3;
            binding.imageView.setLayoutParams(layoutParams);
        }
    }

}
