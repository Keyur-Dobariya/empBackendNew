package com.hd.video.downloader.play.video.instagram.Adapter;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.InstaItemGalleryFragmentBinding;
import com.hd.video.downloader.play.video.instagram.Activity.Insta_OpenFileActivity;

import java.util.ArrayList;

public class Insta_GalleryViewAdapter extends RecyclerView.Adapter {
    FragmentActivity activity;
    Context context;
    ArrayList<String> filelist;

    public Insta_GalleryViewAdapter(ArrayList<String> arrayList, Context context2, FragmentActivity fragmentActivity) {
        this.filelist = arrayList;
        this.context = context2;
        this.activity = fragmentActivity;
    }

    @Override
    public Adapter_ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(InstaItemGalleryFragmentBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }


    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        if (this.filelist.get(i).endsWith(".mp4")) {
            adapter_ViewHolder.binding.videoView.setVisibility(View.VISIBLE);
            adapter_ViewHolder.binding.imageView.setVisibility(View.GONE);
            adapter_ViewHolder.binding.videoView.setVideoPath(this.filelist.get(i));
            adapter_ViewHolder.binding.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.setVolume(0.0f, 0.0f);
                    mediaPlayer.setLooping(true);
                }
            });
            adapter_ViewHolder.binding.videoView.start();
        } else {
            adapter_ViewHolder.binding.imageView.setVisibility(View.VISIBLE);
            adapter_ViewHolder.binding.videoView.setVisibility(View.GONE);
            Glide.with(this.context).load(this.filelist.get(i)).into(adapter_ViewHolder.binding.imageView);
        }

//        **************intetial****************************
        adapter_ViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                InterstitialAds.showAd(context, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        Intent intent = new Intent(Insta_GalleryViewAdapter.this.context, Insta_OpenFileActivity.class);
                        intent.putExtra("CURRENTPOSSITION", i);
                        intent.putStringArrayListExtra("FILELIST", Insta_GalleryViewAdapter.this.filelist);
                        Insta_GalleryViewAdapter.this.context.startActivity(intent);
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });

            }
        });
    }

    @Override
    public int getItemCount() {
        return this.filelist.size();
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        InstaItemGalleryFragmentBinding binding;

        public Adapter_ViewHolder(InstaItemGalleryFragmentBinding view) {
            super(view.getRoot());
            binding = view;
            DisplayMetrics displayMetrics = Insta_GalleryViewAdapter.this.context.getResources().getDisplayMetrics();
            ViewGroup.LayoutParams layoutParams = binding.imageView.getLayoutParams();
            layoutParams.width = displayMetrics.widthPixels / 3;
            layoutParams.height = displayMetrics.widthPixels / 3;
            binding.imageView.setLayoutParams(layoutParams);
            DisplayMetrics displayMetrics2 = Insta_GalleryViewAdapter.this.context.getResources().getDisplayMetrics();
            ViewGroup.LayoutParams layoutParams2 = binding.videoView.getLayoutParams();
            layoutParams2.width = displayMetrics2.widthPixels / 3;
            layoutParams2.height = displayMetrics2.widthPixels / 3;
            binding.videoView.setLayoutParams(layoutParams2);
        }
    }

}