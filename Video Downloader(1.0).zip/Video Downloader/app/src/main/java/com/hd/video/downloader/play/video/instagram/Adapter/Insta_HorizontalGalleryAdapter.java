package com.hd.video.downloader.play.video.instagram.Adapter;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.databinding.InstaItemHorizontalGalleryBinding;

import java.util.ArrayList;

public class Insta_HorizontalGalleryAdapter extends RecyclerView.Adapter {
    Context context;
    ArrayList<String> filelist;
    private OnClickListener onClickListener;

    public interface OnClickListener {
        void onClick(int i);
    }

    public void setOnClickListener(OnClickListener onClickListener2) {
        this.onClickListener = onClickListener2;
    }

    public Insta_HorizontalGalleryAdapter(ArrayList<String> arrayList, Context context2) {
        this.filelist = arrayList;
        this.context = context2;
    }

    @Override
    public Adapter_ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(InstaItemHorizontalGalleryBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        if (this.filelist.get(i).endsWith(".mp4")) {
            adapter_ViewHolder.binding.videoView.setVisibility(View.VISIBLE);
            adapter_ViewHolder.binding.imageView.setVisibility(View.GONE);
            adapter_ViewHolder.binding.videoView.setVideoPath(this.filelist.get(i));
            adapter_ViewHolder.binding.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.setVolume(0.0f, 0.0f);
                    mediaPlayer.setLooping(true);
                }
            });
            adapter_ViewHolder.binding.videoView.start();
        } else {
            Glide.with(this.context).load(this.filelist.get(i)).into(adapter_ViewHolder.binding.imageView);
        }
        adapter_ViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Insta_HorizontalGalleryAdapter.this.onClickListener.onClick(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.filelist.size();
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        InstaItemHorizontalGalleryBinding binding;

        public Adapter_ViewHolder(InstaItemHorizontalGalleryBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

}