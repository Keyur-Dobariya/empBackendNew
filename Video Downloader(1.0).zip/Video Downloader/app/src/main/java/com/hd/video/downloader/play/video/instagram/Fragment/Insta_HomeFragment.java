package com.hd.video.downloader.play.video.instagram.Fragment;

import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.gson.JsonElement;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.NativeAds;
import com.hd.video.downloader.play.video.databinding.InstaFragmentHomeBinding;
import com.hd.video.downloader.play.video.instagram.Activity.Insta_PhotosVideoDownloadActivity;
import com.hd.video.downloader.play.video.instagram.Activity.Insta_ReelDownlodActivity;
import com.hd.video.downloader.play.video.instagram.retrofit.insta_Responseapi;
import com.hd.video.downloader.play.video.instagram.retrofit.insta_RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Insta_HomeFragment extends Fragment {
    Context context;
    ProgressDialog progressDialog;
    InstaFragmentHomeBinding binding;

    private final String screenName = this.getClass().getSimpleName();

    public Insta_HomeFragment(Context context2) {
        this.context = context2;
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        binding = InstaFragmentHomeBinding.inflate(layoutInflater, viewGroup, false);
        onclick();
        //        ******native**************************
        new NativeAds(screenName).showAd(context, binding.admobNative, binding.fbNative, binding.cardNative);
        return binding.getRoot();
    }

    private void onclick() {
        binding.btnpaste.setOnClickListener(view -> {
            try {
                binding.etlink.setText(((ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE)).getPrimaryClip().getItemAt(0).getText());
            } catch (Exception unused) {
            }
        });
        binding.btnfind.setOnClickListener(view -> {
            String obj = binding.etlink.getText().toString();
            if (obj.contains("https://www.instagram.com")) {
                progressDialog = new ProgressDialog(context);
                progressDialog.setTitle("Fetching Data");
                progressDialog.setMessage("Please Wait");
                progressDialog.setProgressStyle(0);
                progressDialog.setCancelable(false);
                progressDialog.show();
                apicall(obj);
                return;
            }
            Toast.makeText(context, "Please enter correct link", Toast.LENGTH_SHORT).show();
        });
    }


//    *************intetial*********************************
    private void apicall(String str) {
        insta_RetrofitClient.getRetrofitInstance().create(insta_Responseapi.class).responseapi(str).enqueue(new Callback<JsonElement>() {
            @Override
            public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                JsonElement body = response.body();
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
                if (response.code() == 200) {
                    if (body.isJsonObject()) {
                        InterstitialAds.showAd(getActivity(), new OnInterstitialAdResponse() {
                            @Override
                            public void onAdClosed() {
                                Intent intent = new Intent(context, Insta_ReelDownlodActivity.class);
                                intent.putExtra("FINALRESPONSE", response.body().toString());
                                getContext().startActivity(intent);
                            }
                            @Override
                            public void onAdImpression() {

                            }
                        });
                    } else if (body.isJsonArray()) {
                        InterstitialAds.showAd(getActivity(), new OnInterstitialAdResponse() {
                            @Override
                            public void onAdClosed() {
                                Intent intent2 = new Intent(context, Insta_PhotosVideoDownloadActivity.class);
                                intent2.putExtra("FINALRESPONSE", response.body().toString());
                                getContext().startActivity(intent2);
                            }
                            @Override
                            public void onAdImpression() {

                            }
                        });
                    } else if (body.isJsonNull()) {
                        Toast.makeText(context, "data empty", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Try again", Toast.LENGTH_SHORT).show();
                    }
                } else if (response.code() == 400) {
                    Toast.makeText(context, "Invalid Instagram URL", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Server error", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonElement> call, Throwable th) {
                progressDialog.dismiss();
                Toast.makeText(context, "" + th.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}