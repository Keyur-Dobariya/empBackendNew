package com.hd.video.downloader.play.video.instagram.Models;

import android.os.Parcel;
import android.os.Parcelable;

public class Insta_ImageDataModel implements Parcelable {
    public static final Creator<Insta_ImageDataModel> CREATOR = new Creator<Insta_ImageDataModel>() {

        @Override
        public Insta_ImageDataModel createFromParcel(Parcel parcel) {
            return new Insta_ImageDataModel(parcel);
        }

        @Override
        public Insta_ImageDataModel[] newArray(int i) {
            return new Insta_ImageDataModel[i];
        }
    };
    String date;
    long dateValue;
    String fileName;
    String filePath;
    public String folderName;
    String id;
    boolean isCheckboxVisible;
    boolean isFavorite;
    boolean isSelected;
    long size;

    public int describeContents() {
        return 0;
    }

    protected Insta_ImageDataModel(Parcel parcel) {
        this.folderName = "";
        this.date = null;
        boolean z = false;
        this.isCheckboxVisible = false;
        this.isFavorite = false;
        this.id = parcel.readString();
        this.fileName = parcel.readString();
        this.filePath = parcel.readString();
        this.folderName = parcel.readString();
        this.size = parcel.readLong();
        this.date = parcel.readString();
        this.dateValue = parcel.readLong();
        this.isCheckboxVisible = parcel.readByte() != 0;
        this.isSelected = parcel.readByte() != 0;
        this.isFavorite = parcel.readByte() != 0 ? true : z;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String toString() {
        return "ImageData{id='" + this.id + '\'' + ", fileName='" + this.fileName + '\'' + ", filePath='" + this.filePath + '\'' + ", folderName='" + this.folderName + '\'' + ", size=" + this.size + ", date='" + this.date + '\'' + ", isCheckboxVisible=" + this.isCheckboxVisible + ", isSelected;=" + this.isSelected + ", isFavorite;=" + this.isFavorite + ", dateValue;=" + this.dateValue + '}';
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.id);
        parcel.writeString(this.fileName);
        parcel.writeString(this.filePath);
        parcel.writeString(this.folderName);
        parcel.writeLong(this.size);
        parcel.writeString(this.date);
        parcel.writeLong(this.dateValue);
        parcel.writeByte(this.isCheckboxVisible ? (byte) 1 : 0);
        parcel.writeByte(this.isSelected ? (byte) 1 : 0);
        parcel.writeByte(this.isFavorite ? (byte) 1 : 0);
    }
}