package com.hd.video.downloader.play.video.instagram.Models;

import java.util.ArrayList;
import java.util.List;

public class Insta_JsonArrayRootModel {
    private Insta_Meta meta;
    private Insta_Sd sd;
    private String thumb;
    private List<Insta_Url> url = new ArrayList();

    public List<Insta_Url> getUrl() {
        return this.url;
    }

    public void setUrl(List<Insta_Url> list) {
        this.url = list;
    }

    public Insta_Meta getMeta() {
        return this.meta;
    }

    public void setMeta(Insta_Meta meta2) {
        this.meta = meta2;
    }

    public String getThumb() {
        return this.thumb;
    }

    public void setThumb(String str) {
        this.thumb = str;
    }

    public Insta_Sd getSd() {
        return this.sd;
    }

    public void setSd(Insta_Sd sd2) {
        this.sd = sd2;
    }
}