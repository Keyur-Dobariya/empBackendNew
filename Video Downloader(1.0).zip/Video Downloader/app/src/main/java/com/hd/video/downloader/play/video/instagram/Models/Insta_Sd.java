package com.hd.video.downloader.play.video.instagram.Models;

public class Insta_Sd {
    private String url;

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String str) {
        this.url = str;
    }
}