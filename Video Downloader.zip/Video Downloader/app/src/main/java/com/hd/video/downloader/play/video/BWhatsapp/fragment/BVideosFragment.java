package com.hd.video.downloader.play.video.BWhatsapp.fragment;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.facebook.ads.NativeAdLayout;
import com.google.android.material.card.MaterialCardView;
import com.hd.video.downloader.play.video.NewWp.activity.WhatsappvideoView;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.SmallNativeAds;

import java.util.ArrayList;

public class BVideosFragment extends Fragment {
    public static ArrayList<Uri> statusObjectsList1 = new ArrayList<>();
    public static ArrayList<Uri> statusObjectsList12 = new ArrayList<>();
    View inflate;
    MoviesAdapter mAdapter;
    RelativeLayout nodata;
    private RecyclerView recyclerView;


    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate2 = layoutInflater.inflate(R.layout.bw_videosfragment_layout, viewGroup, false);
        this.inflate = inflate2;
        this.recyclerView = (RecyclerView) inflate2.findViewById(R.id.recyclerview);
        this.nodata = (RelativeLayout) this.inflate.findViewById(R.id.nodata);

        for (int i = 0; i < BWhatsappActivty.statusObjectsList.size(); i++) {
            Log.e("my_log", "onCreateView: " + BWhatsappActivty.statusObjectsList.get(i));
        }
        statusObjectsList1.clear();
        if (BWhatsappActivty.statusObjectsList.size() > 0) {
            for (int i2 = 0; i2 < BWhatsappActivty.statusObjectsList.size(); i2++) {
                if (BWhatsappActivty.statusObjectsList.get(i2).toString().contains(".mp4")) {
                    statusObjectsList1.add(BWhatsappActivty.statusObjectsList.get(i2));
                }
            }
        }
        statusObjectsList12 = new ArrayList<>();
        for (int i4 = 0; i4 < statusObjectsList1.size(); i4++) {
            statusObjectsList12.add(statusObjectsList1.get(i4));
        }
        if (statusObjectsList12.size() > 0) {
            this.nodata.setVisibility(View.GONE);
            this.recyclerView.setVisibility(View.VISIBLE);
            final GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
            this.recyclerView.setLayoutManager(gridLayoutManager);
            this.recyclerView.setItemAnimator(new DefaultItemAnimator());
            final MoviesAdapter moviesAdapter = new MoviesAdapter(statusObjectsList12);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                public int getSpanSize(int i) {
                    int itemViewType = moviesAdapter.getItemViewType(i);
                    if (itemViewType == 1) {
                        return 1;
                    }
                    if (itemViewType != 2) {
                        return -1;
                    }
                    return gridLayoutManager.getSpanCount();
                }
            });
            this.mAdapter = moviesAdapter;
            this.recyclerView.setAdapter(moviesAdapter);
        } else {
            this.nodata.setVisibility(View.VISIBLE);
            this.recyclerView.setVisibility(View.GONE);
        }
        return this.inflate;
    }

    public void onResume() {
        super.onResume();
    }

    public class MoviesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        int TYPE_CONTENT = 1;
        Intent intent;
        private ArrayList<Uri> moviesList = new ArrayList<>();

        public class MyViewHolder extends RecyclerView.ViewHolder {
            public ImageView iv_play;
            public ImageView title;
            public TextView tv_download;

            public MyViewHolder(View view) {
                super(view);
                this.title = (ImageView) view.findViewById(R.id.pcw);
                this.iv_play = (ImageView) view.findViewById(R.id.ivplay);
                this.tv_download = (TextView) view.findViewById(R.id.tvdownload);
            }
        }

        public MoviesAdapter(ArrayList<Uri> arrayList) {
            this.moviesList = arrayList;
        }

        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.items_bwhatsapp_view, viewGroup, false));
        }

        public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
            if (getItemViewType(i) == this.TYPE_CONTENT) {
                MyViewHolder myViewHolder = (MyViewHolder) viewHolder;
                myViewHolder.tv_download.setVisibility(View.GONE);
                if (this.moviesList.get(i).toString().contains(".mp4")) {
                    myViewHolder.iv_play.setVisibility(View.VISIBLE);
                } else {
                    myViewHolder.iv_play.setVisibility(View.GONE);
                }
                Glide.with(BVideosFragment.this.getActivity()).load(this.moviesList.get(i)).into(myViewHolder.title);
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        CallIntent(BVideosFragment.this.getActivity(), WhatsappvideoView.class, i);
                    }
                });
            }
        }

        public int getItemViewType(int i) {
            return this.TYPE_CONTENT;
        }

        public int getItemCount() {
            return this.moviesList.size();
        }

        public void CallIntent(Activity activity, Class<?> cls, int i) {
            InterstitialAds.showAd(getActivity(), new OnInterstitialAdResponse() {
                @Override
                public void onAdClosed() {
                    intent = new Intent(activity, cls);
                    intent.putExtra("ImageDataFile", moviesList.get(i).toString());
                    BVideosFragment.this.startActivity(intent);
                }
                @Override
                public void onAdImpression() {

                }
            });

        }
    }
}
