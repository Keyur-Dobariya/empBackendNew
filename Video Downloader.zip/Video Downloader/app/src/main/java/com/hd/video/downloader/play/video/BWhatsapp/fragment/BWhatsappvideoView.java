package com.hd.video.downloader.play.video.BWhatsapp.fragment;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.hd.video.downloader.play.video.NewWp.RealPathUtil;
import com.hd.video.downloader.play.video.NewWp.Utils.Utils;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

public class BWhatsappvideoView extends AppCompatActivity {
    ImageView btnBack;
    MediaController mediaController;
    public String stringExtra;
    public String type;
    VideoView videoView;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.videoplayer);
        btnBack = (ImageView) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        videoView = (VideoView) findViewById(R.id.videoView);
        String stringExtra2 = getIntent().getStringExtra("ImageDataFile");
        this.stringExtra = stringExtra2;
        if (stringExtra2.toString().contains(".mp4")) {
            this.type = "video";
        } else {
            this.type = "image";
        }
        String realPath = RealPathUtil.getRealPath(this, Uri.parse(this.stringExtra));
        String substring = realPath.substring(realPath.lastIndexOf("/") + 1);
        TextView textView = (TextView) findViewById(R.id.txtname);
        textView.setText(substring);
        textView.setSelected(true);
        try {
            this.mediaController = new MediaController(this);
            MediaController r5 = new MediaController(this) {
                public void hide() {
                    mediaController.show();
                }

                public boolean dispatchKeyEvent(KeyEvent keyEvent) {
                    if (keyEvent.getKeyCode() != 4) {
                        return super.dispatchKeyEvent(keyEvent);
                    }
                    super.hide();
                    ((Activity) getContext()).finish();
                    return true;
                }
            };
            this.mediaController = r5;
            r5.setAnchorView(this.videoView);
            this.videoView.setVideoURI(Uri.parse(this.stringExtra));
            this.videoView.requestFocus();
            this.videoView.start();
            findViewById(R.id.imWhatsappShare).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    if (type.equals("image")) {
                        Utils.shareImageVideoOnWhatsapp(BWhatsappvideoView.this, RealPathUtil.getRealPath(BWhatsappvideoView.this, Uri.parse(stringExtra)), false);
                        return;
                    }
                    Utils.shareImageVideoOnWhatsapp(BWhatsappvideoView.this, RealPathUtil.getRealPath(BWhatsappvideoView.this, Uri.parse(stringExtra)), true);
                }
            });
            findViewById(R.id.imShare).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    if (type.equals("image")) {
                        intent.setType("image/*");
                    } else {
                        intent.setType("video/*");
                    }
                    intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(new File(RealPathUtil.getRealPath(BWhatsappvideoView.this, Uri.parse(stringExtra)))));
                    startActivity(Intent.createChooser(intent, "Share to"));
                }
            });
            findViewById(R.id.videodownload).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    new Download().execute(new String[0]);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(BWhatsappvideoView.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public class Download extends AsyncTask<String, String, String> {
        public Download() {
        }

        public void onPreExecute() {
            super.onPreExecute();
        }

        public String doInBackground(String... strArr) {
            String str;
            File file = new File(RealPathUtil.getRealPath(BWhatsappvideoView.this, Uri.parse(BWhatsappvideoView.this.stringExtra)));
            int nextInt = new Random().nextInt(10000);
            if (type.equals("image")) {
                str = Environment.getExternalStorageDirectory() + "/Download/" + Utils.RootDirectoryWhatsapp + "Image-" + nextInt + ".jpg";
            } else if (type.equals("video")) {
                str = Environment.getExternalStorageDirectory() + "/Download/" + Utils.RootDirectoryWhatsapp + "Video-" + nextInt + ".mp4";
            } else {
                str = null;
            }
            File file2 = new File(str);
            MediaScannerConnection.scanFile(getApplicationContext(), new String[]{file2.toString()}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
                public void onScanCompleted(String str, Uri uri) {
                }
            });
            i(String.valueOf(file), Environment.getExternalStorageDirectory() + "/Download/" + Utils.RootDirectoryWhatsapp);
            try {
                MediaScannerConnection.scanFile(getApplicationContext(), new String[]{file2.toString()}, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String str, Uri uri) {
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPostExecute(String str) {
            Toast.makeText(BWhatsappvideoView.this, BWhatsappvideoView.this.getResources().getString(R.string.download), Toast.LENGTH_SHORT).show();
            super.onPostExecute(str);
        }
    }

    public void i(String str, String str2) {
        try {
            File file = new File(str);
            File file2 = new File(str2, file.getName());
            if (file.isDirectory()) {
                for (String file3 : file.list()) {
                    i(new File(file, file3).getPath(), file2.getPath());
                }
                return;
            }
            files(file, file2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void files(File file, File file2) {
        if (!file2.getParentFile().exists()) {
            file2.getParentFile().mkdirs();
        }
        if (!file2.exists()) {
            try {
                file2.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            InputStream openInputStream = getContentResolver().openInputStream(Uri.parse(this.stringExtra));
            if (openInputStream != null) {
                try {
                    OutputStream openOutputStream = getContentResolver().openOutputStream(Uri.fromFile(file2));
                    if (openOutputStream == null) {
                        if (openOutputStream != null) {
                            openOutputStream.close();
                        }
                        if (openInputStream != null) {
                            openInputStream.close();
                            return;
                        }
                        return;
                    }
                    byte[] bArr = new byte[1024];
                    while (true) {
                        int read = openInputStream.read(bArr);
                        if (read <= 0) {
                            break;
                        }
                        openOutputStream.write(bArr, 0, read);
                    }
                    if (openOutputStream != null) {
                        openOutputStream.close();
                    }
                    if (openInputStream != null) {
                        openInputStream.close();
                    }
                } catch (Throwable unused) {
                }
            } else if (openInputStream != null) {
                openInputStream.close();
            }
        } catch (FileNotFoundException e2) {
            e2.printStackTrace();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
    }

}
