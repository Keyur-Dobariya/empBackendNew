package com.hd.video.downloader.play.video.BWhatsapp.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.NewWp.Utils.Utils;
import com.hd.video.downloader.play.video.NewWp.activity.ActivityVideoPlayer;
import com.hd.video.downloader.play.video.R;

import java.io.File;
import java.util.ArrayList;

public class ShowBWImagesAdapter extends PagerAdapter {
    ActivityBWFullView activityFullView;
    public Activity context;
    public ArrayList<File> imageList;
    private LayoutInflater inflater;
    Intent intent;

    @Override
    public int getItemPosition(Object obj) {
        return -2;
    }

    @Override
    public void restoreState(Parcelable parcelable, ClassLoader classLoader) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }

    public ShowBWImagesAdapter(Activity activity, ArrayList<File> arrayList, ActivityBWFullView activityBWFullView) {
        this.context = activity;
        this.imageList = arrayList;
        this.activityFullView = activityBWFullView;
        this.inflater = LayoutInflater.from(activity);
    }

    @Override
    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        viewGroup.removeView((View) obj);
    }

    @Override
    public Object instantiateItem(ViewGroup viewGroup, final int i) {
        View inflate = this.inflater.inflate(R.layout.slidingimages_layout, viewGroup, false);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.im_vpPlay);
        ImageView imageView2 = (ImageView) inflate.findViewById(R.id.im_share);
        ImageView imageView3 = (ImageView) inflate.findViewById(R.id.im_delete);
        Glide.with(this.context).load(this.imageList.get(i).getPath()).into((ImageView) inflate.findViewById(R.id.im_fullViewImage));
        viewGroup.addView(inflate, 0);
        if (this.imageList.get(i).getName().substring(this.imageList.get(i).getName().lastIndexOf(".")).equals(".mp4")) {
            imageView.setVisibility(View.VISIBLE);
        } else {
            imageView.setVisibility(View.GONE);
        }
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                intent = new Intent(context, ActivityVideoPlayer.class);
                intent.putExtra("PathVideo", imageList.get(i).getPath());
                context.startActivity(intent);
            }
        });
        imageView3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (imageList.get(i).delete()) {
                    activityFullView.deleteFileAA(i);
                }
            }
        });
        imageView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (imageList.get(i).getName().substring(imageList.get(i).getName().lastIndexOf(".")).equals(".mp4")) {
                    Utils.newshareVideo(context, imageList.get(i).getPath(), true);
                } else {
                    Utils.newshareImage(context, imageList.get(i).getPath(), false);
                }
            }
        });
        return inflate;
    }


    @Override
    public int getCount() {
        return this.imageList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object obj) {
        return view.equals(obj);
    }
}