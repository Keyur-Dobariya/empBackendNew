package com.hd.video.downloader.play.video.NewWp.activity;

import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ActivityFullViewBinding;
import com.hd.video.downloader.play.video.databinding.ActivityVideoPlayerBinding;


public class ActivityVideoPlayer extends AppCompatActivity {
    ActivityVideoPlayerBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityVideoPlayerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        String stringExtra = getIntent().getStringExtra("PathVideo");
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        try {
            new MediaController(this).setMediaPlayer(binding.videoView);
            new MediaController(this).setAnchorView(binding.videoView);
            binding.videoView.setVideoURI(Uri.parse(stringExtra));
            binding.videoView.requestFocus();
            binding.videoView.start();
        } catch (Exception e) {
            e.printStackTrace();
        }


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(ActivityVideoPlayer.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        binding.videoView.pause();
                        finish();
                    }
                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

}