package com.hd.video.downloader.play.video.NewWp.activity;

import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.view.PointerIconCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.hd.video.downloader.play.video.NewWp.Ads_constant;
import com.hd.video.downloader.play.video.NewWp.fragment.ImageFragment;
import com.hd.video.downloader.play.video.NewWp.fragment.MystoryFragment;
import com.hd.video.downloader.play.video.NewWp.fragment.VideoFragment;
import com.hd.video.downloader.play.video.NewWp.l.a.a;
import com.hd.video.downloader.play.video.NewWp.l.a.c;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.ActivityFullViewBinding;
import com.hd.video.downloader.play.video.databinding.ActivityWhatsappBinding;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class WhatsappActivty extends AppCompatActivity {
    public static ArrayList<Uri> statusObjectsList = new ArrayList<>();
    public static String statuspath;
    ActivityWhatsappBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityWhatsappBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.ivOpenWhatsapp).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                final Dialog dialog = new Dialog(WhatsappActivty.this);
                dialog.setContentView(R.layout.redirect_dialog);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                dialog.show();
                dialog.setCancelable(true);
                ((TextView) dialog.findViewById(R.id.btnNo)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                ((TextView) dialog.findViewById(R.id.btnYes)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                        try {
                            Intent intent = new Intent("android.intent.action.VIEW");
                            intent.setData(Uri.parse("android-app://".concat("com.whatsapp")));
                            startActivity(intent);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(WhatsappActivty.this, "App not found", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        binding.home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                binding.viewPager.setCurrentItem(0, true);
            }
        });
        binding.watools.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                binding.viewPager.setCurrentItem(1, true);
            }
        });
        binding.stus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                binding.viewPager.setCurrentItem(2, true);
            }
        });
        statusObjectsList.clear();
        statuspath = "Whatsapp";
        binding.tablayout.addTab(binding.tablayout.newTab().setText("Image"));
        binding.tablayout.addTab(binding.tablayout.newTab().setText("Video"));
        binding.tablayout.addTab(binding.tablayout.newTab().setText("Saved"));
        binding.tablayout.setTabGravity(0);
        if (Build.VERSION.SDK_INT < 30) {
            File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/WhatsApp/Media/.Statuses/");
            if (!file.exists()) {
                file.mkdirs();
            }
            File[] listFiles = file.listFiles();
            if (listFiles != null) {
                Arrays.sort(listFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                for (int i = 0; i < listFiles.length; i++) {
                    if (!listFiles[i].getName().equals(".nomedia")) {
                        statusObjectsList.add(Uri.fromFile(listFiles[i]));
                    }
                    Log.d("PRIYANSU", "size: " + statusObjectsList.size());
                }
            }
            binding.viewPager.setAdapter(new TabLayoutAdapter(this, getSupportFragmentManager(), binding.tablayout.getTabCount()));
        } else if (Ads_constant.get_Setpermissin(this).equalsIgnoreCase("true")) {
            Uri parse = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia/document/primary%3AAndroid%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses");
            if (Build.VERSION.SDK_INT >= 21) {
                getDataForAndroid11OnlyStatus(parse);
            }
        } else {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            dialog.setCancelable(false);
            dialog.setContentView(R.layout.dialog_permisson);
            ((TextView) dialog.findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    dialog.dismiss();
                    finish();
                }
            });
            ((AppCompatButton) dialog.findViewById(R.id.btn_permissio)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Intent intent;
                    dialog.dismiss();
                    try {
                        if (Build.VERSION.SDK_INT >= 29) {
                            int i = Build.VERSION.SDK_INT;
                            StorageManager storageManager = (StorageManager) getSystemService("storage");
                            StringBuilder sb = new StringBuilder();
                            sb.append(Environment.getExternalStorageDirectory());
                            sb.append(File.separator);
                            sb.append("Android/media/com.whatsapp/WhatsApp/Media/.Statuses");
                            String str = new File(sb.toString()).isDirectory() ? "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses" : "WhatsApp%2FMedia%2F.Statuses";
                            if (i >= 29) {
                                intent = storageManager.getPrimaryStorageVolume().createOpenDocumentTreeIntent();
                                str = intent.getParcelableExtra("android.provider.extra.INITIAL_URI").toString().replace("/root/", "/document/") + "%3A" + str;
                            } else {
                                intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
                            }
                            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(str));
                            intent.addFlags(2);
                            intent.addFlags(1);
                            intent.addFlags(128);
                            intent.addFlags(64);
                            try {
                                startActivityForResult(intent, PointerIconCompat.TYPE_COPY);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (Exception unused) {
                        Toast.makeText(WhatsappActivty.this, "can't find an app to select media, please active your 'Files' app and/or update your phone Google play services", Toast.LENGTH_LONG).show();
                    }
                }
            });
            dialog.show();
        }
        binding.viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(binding.tablayout));
        binding.tablayout.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewPager.setCurrentItem(tab.getPosition());
            }
        });
        setupViewPager(binding.viewPager);


        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(WhatsappActivty.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }


    @Override
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (Build.VERSION.SDK_INT > 29 && i != 1239 && i == 1011 && i2 == -1) {
            Uri data = intent.getData();
            if (data.toString().equals("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses")) {
                try {
                    getContentResolver().takePersistableUriPermission(data, 1);
                    if (new File("/storage/emulated/0/WhatsApp/Media/.Statuses/").exists()) {
                        Environment.getExternalStorageDirectory().getAbsolutePath();
                    }
                    Uri parse = Uri.parse(data.toString());
                    Cursor cursor = null;
                    c cVar = new c(null, this, DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse)));
                    ContentResolver contentResolver = cVar.f5a.getContentResolver();
                    Uri uri = cVar.b;
                    Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri, DocumentsContract.getDocumentId(uri));
                    ArrayList arrayList = new ArrayList();
                    try {
                        cursor = contentResolver.query(buildChildDocumentsUriUsingTree, new String[]{"document_id"}, null, null, null);
                        while (cursor.moveToNext()) {
                            arrayList.add(DocumentsContract.buildDocumentUriUsingTree(cVar.b, cursor.getString(0)));
                        }
                    } catch (Exception e) {
                        Log.w("DocumentFile", "Failed query: " + e);
                    }
                    c.c(cursor);
                    Uri[] uriArr = (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
                    int length = uriArr.length;
                    a[] aVarArr = new a[length];
                    for (int i3 = 0; i3 < uriArr.length; i3++) {
                        aVarArr[i3] = new c(cVar, cVar.f5a, uriArr[i3]);
                    }
                    for (int i4 = 0; i4 < length; i4++) {
                        a aVar = aVarArr[i4];
                        aVar.b();
                        if (!aVar.b().toString().contains(".nomedia") && !aVar.b().toString().equals("")) {
                            statusObjectsList.add(aVar.b());
                        }
                    }
                    Ads_constant.set_Setpermissin(this, "true");
                    binding.viewPager.setAdapter(new TabLayoutAdapter(this, getSupportFragmentManager(), binding.tablayout.getTabCount()));
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            } else {
                Toast.makeText(this, "You Give Wrong Folder Permission", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void getDataForAndroid11OnlyStatus(Uri uri) {
        Uri parse = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses");
        Cursor cursor = null;
        c cVar = new c(null, this, DocumentsContract.buildDocumentUriUsingTree(parse, DocumentsContract.getTreeDocumentId(parse)));
        ContentResolver contentResolver = cVar.f5a.getContentResolver();
        Uri uri2 = cVar.b;
        Uri buildChildDocumentsUriUsingTree = DocumentsContract.buildChildDocumentsUriUsingTree(uri2, DocumentsContract.getDocumentId(uri2));
        ArrayList arrayList = new ArrayList();
        try {
            cursor = contentResolver.query(buildChildDocumentsUriUsingTree, new String[]{"document_id"}, null, null, null);
            while (cursor.moveToNext()) {
                arrayList.add(DocumentsContract.buildDocumentUriUsingTree(cVar.b, cursor.getString(0)));
            }
        } catch (Exception e) {
            Log.w("DocumentFile", "Failed query: " + e);
        }
        c.c(cursor);
        Uri[] uriArr = (Uri[]) arrayList.toArray(new Uri[arrayList.size()]);
        int length = uriArr.length;
        a[] aVarArr = new a[length];
        for (int i = 0; i < uriArr.length; i++) {
            aVarArr[i] = new c(cVar, cVar.f5a, uriArr[i]);
        }
        for (int i2 = 0; i2 < length; i2++) {
            a aVar = aVarArr[i2];
            aVar.b();
            if (!aVar.b().toString().contains(".nomedia") && !aVar.b().toString().equals("")) {
                statusObjectsList.add(aVar.b());
            }
        }
        binding.viewPager.setAdapter(new TabLayoutAdapter(this, getSupportFragmentManager(), binding.tablayout.getTabCount()));
    }

    public class TabLayoutAdapter extends FragmentPagerAdapter {
        Context mContext;
        int mTotalTabs;

        public TabLayoutAdapter(Context context, FragmentManager fragmentManager, int i) {
            super(fragmentManager);
            this.mContext = context;
            this.mTotalTabs = i;
        }

        @Override
        public Fragment getItem(int i) {
            Log.d("asasas", i + "");
            if (i == 0) {
                return new ImageFragment();
            }
            if (i == 1) {
                return new VideoFragment();
            }
            if (i != 2) {
                return null;
            }
            return new MystoryFragment();
        }

        @Override
        public int getCount() {
            return this.mTotalTabs;
        }
    }

    private void setupViewPager(ViewPager viewPager2) {
        int i = 1;
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), 1);
        viewPagerAdapter.addFragment(new ImageFragment(), "");
        viewPagerAdapter.addFragment(new VideoFragment(), "");
        viewPagerAdapter.addFragment(new MystoryFragment(), "");
        viewPager2.setAdapter(viewPagerAdapter);
        if (viewPagerAdapter.getCount() > 1) {
            i = viewPagerAdapter.getCount() - 1;
        }
        viewPager2.setOffscreenPageLimit(i);
        viewPager2.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int i) {
                Log.d("ORANGES", "onPageScrollStateChanged: " + i);
            }

            @Override
            public void onPageScrolled(int i, float f, int i2) {
                Log.d("ORANGES", "onPageScrolled: " + i);
            }

            @Override
            public void onPageSelected(int i) {
                Log.d("ORANGES", "onPageSelected: " + i);
                if (i == 0) {
                    binding.hometext.setTextColor(getResources().getColor(R.color.tint));
                    binding.watxt.setTextColor(getResources().getColor(R.color.tint1));
                    binding.stutxt.setTextColor(getResources().getColor(R.color.tint1));
                    binding.homeic.setColorFilter(getResources().getColor(R.color.tint));
                    binding.waic.setColorFilter(getResources().getColor(R.color.tint1));
                    binding.stuic.setColorFilter(getResources().getColor(R.color.tint1));
                    binding.stuic.setColorFilter(getResources().getColor(R.color.tint1));
                } else if (i == 1) {
                    binding.hometext.setTextColor(getResources().getColor(R.color.tint1));
                    binding.watxt.setTextColor(getResources().getColor(R.color.tint));
                    binding.stutxt.setTextColor(getResources().getColor(R.color.tint1));
                    binding.homeic.setColorFilter(getResources().getColor(R.color.tint1));
                    binding.waic.setColorFilter(getResources().getColor(R.color.tint));
                    binding.stuic.setColorFilter(getResources().getColor(R.color.tint1));
                } else if (i == 2) {
                    binding.hometext.setTextColor(getResources().getColor(R.color.tint1));
                    binding.watxt.setTextColor(getResources().getColor(R.color.tint1));
                    binding.stutxt.setTextColor(getResources().getColor(R.color.tint));
                    binding.homeic.setColorFilter(getResources().getColor(R.color.tint1));
                    binding.waic.setColorFilter(getResources().getColor(R.color.tint1));
                    binding.stuic.setColorFilter(getResources().getColor(R.color.tint));
                }
            }
        });
    }

    public static class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList();
        private final List<String> mFragmentTitleList = new ArrayList();

        public ViewPagerAdapter(FragmentManager fragmentManager, int i) {
            super(fragmentManager, i);
        }

        public void addFragment(Fragment fragment, String str) {
            this.mFragmentList.add(fragment);
            this.mFragmentTitleList.add(str);
        }

        @Override
        public int getCount() {
            return this.mFragmentList.size();
        }

        @Override
        public Fragment getItem(int i) {
            return this.mFragmentList.get(i);
        }

        @Override
        public CharSequence getPageTitle(int i) {
            return this.mFragmentTitleList.get(i);
        }
    }

}