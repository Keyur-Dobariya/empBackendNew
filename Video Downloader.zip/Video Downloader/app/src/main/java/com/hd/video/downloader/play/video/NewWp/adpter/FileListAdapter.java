package com.hd.video.downloader.play.video.NewWp.adpter;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.NewWp.Utils.FileListClickInterface;
import com.hd.video.downloader.play.video.R;

import java.io.File;
import java.util.ArrayList;

public class FileListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    int AD_TYPE = 2;
    int TYPE_CONTENT = 1;
    Activity activity;
    private Context context;
    private ArrayList<File> fileArrayList;
    public FileListClickInterface fileListClickInterface;
    private LayoutInflater layoutInflater;

    public FileListAdapter( Context context2, ArrayList<File> arrayList, FileListClickInterface fileListClickInterface2, Activity activity2) {
        this.context = context2;
        this.fileArrayList = arrayList;
        this.activity = activity2;
        this.fileListClickInterface = fileListClickInterface2;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (this.layoutInflater == null) {
            this.layoutInflater = LayoutInflater.from(viewGroup.getContext());
        }
        return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.items_file_view, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        if (getItemViewType(i) == this.TYPE_CONTENT) {
            ViewHolder viewHolder2 = (ViewHolder) viewHolder;
            final File file = this.fileArrayList.get(i);
            try {
                if (file.getName().substring(file.getName().lastIndexOf(".")).equals(".mp4")) {
                    viewHolder2.ivPlay.setVisibility(View.VISIBLE);
                } else {
                    viewHolder2.ivPlay.setVisibility(View.GONE);
                }
                Glide.with(this.context).load(file.getPath()).into(viewHolder2.pcw);
            } catch (Exception e) {
                Log.d("ANJALI", "onBindViewHolder: " + e.getMessage());
            }
            viewHolder2.rlMain.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    FileListAdapter.this.fileListClickInterface.getPosition(i, file);
                }
            });
        }
    }

    @Override
    public int getItemViewType(int i) {
        if (this.fileArrayList.get(i) == null) {
            return this.AD_TYPE;
        }
        return this.TYPE_CONTENT;
    }

    @Override
    public int getItemCount() {
        ArrayList<File> arrayList = this.fileArrayList;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPlay;
        ImageView pcw;
        RelativeLayout rlMain;

        public ViewHolder(View view) {
            super(view);
            this.ivPlay = (ImageView) view.findViewById(R.id.ivplay);
            this.rlMain = (RelativeLayout) view.findViewById(R.id.rlmain);
            this.pcw = (ImageView) view.findViewById(R.id.pc);
        }
    }
}