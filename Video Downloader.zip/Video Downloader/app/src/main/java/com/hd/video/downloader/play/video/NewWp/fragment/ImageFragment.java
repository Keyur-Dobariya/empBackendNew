package com.hd.video.downloader.play.video.NewWp.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.NewWp.activity.WhatsappActivty;
import com.hd.video.downloader.play.video.NewWp.activity.WhatsappImageViewActivity;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.SmallNativeAds;
import com.hd.video.downloader.play.video.databinding.FragmentWhatsappBinding;
import com.hd.video.downloader.play.video.databinding.ItemsWhatsappViewBinding;

import java.util.ArrayList;

public class ImageFragment extends Fragment {
    public static ArrayList<Uri> statusObjectsList1 = new ArrayList<>();
    public static ArrayList<Uri> statusObjectsList12 = new ArrayList<>();
    MoviesAdapter mAdapter;
    private final String screenName = this.getClass().getSimpleName();

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FragmentWhatsappBinding binding = FragmentWhatsappBinding.inflate(layoutInflater, viewGroup, false);

        //        *********Smallnative*************
        new SmallNativeAds(screenName).showAd(getContext(), binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);

        statusObjectsList1.clear();
        if (WhatsappActivty.statusObjectsList.size() > 0) {
            for (int i = 0; i < WhatsappActivty.statusObjectsList.size(); i++) {
                if (!WhatsappActivty.statusObjectsList.get(i).toString().contains(".mp4")) {
                    statusObjectsList1.add(WhatsappActivty.statusObjectsList.get(i));
                }
            }
        }
        statusObjectsList12 = new ArrayList<>();
        for (int i3 = 0; i3 < statusObjectsList1.size(); i3++) {
            statusObjectsList12.add(statusObjectsList1.get(i3));
        }
        if (statusObjectsList12.size() > 0) {
            binding.nodata.setVisibility(View.GONE);
            binding.recyclerview.setVisibility(View.VISIBLE);
            final GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(), 3);
            binding.recyclerview.setLayoutManager(gridLayoutManager);
            binding.recyclerview.setItemAnimator(new DefaultItemAnimator());
            final MoviesAdapter moviesAdapter = new MoviesAdapter(statusObjectsList12);
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                public int getSpanSize(int i) {
                    int itemViewType = moviesAdapter.getItemViewType(i);
                    if (itemViewType == 1) {
                        return 1;
                    }
                    if (itemViewType != 2) {
                        return -1;
                    }
                    return gridLayoutManager.getSpanCount();
                }
            });
            this.mAdapter = moviesAdapter;
            binding.recyclerview.setAdapter(moviesAdapter);
        } else {
            binding.nodata.setVisibility(View.VISIBLE);
            binding.recyclerview.setVisibility(View.GONE);
        }
        return binding.getRoot();
    }

    public void onResume() {
        super.onResume();
    }

    public class MoviesAdapter extends RecyclerView.Adapter {
        int AD_TYPE = 2;
        int TYPE_CONTENT = 1;
        private ArrayList<Uri> moviesList = new ArrayList<>();

        public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
            ItemsWhatsappViewBinding binding;

            public Adapter_ViewHolder(ItemsWhatsappViewBinding view) {
                super(view.getRoot());
                binding = view;
            }
        }

        public MoviesAdapter(ArrayList<Uri> arrayList) {
            this.moviesList = arrayList;
        }

        @Override
        public Adapter_ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            return new Adapter_ViewHolder(ItemsWhatsappViewBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
        }

        public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, final int i) {
            final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
            if (getItemViewType(i) == this.TYPE_CONTENT) {
                adapter_ViewHolder.binding.tvdownload.setVisibility(View.GONE);
                if (this.moviesList.get(i).toString().contains(".mp4")) {
                    adapter_ViewHolder.binding.ivplay.setVisibility(View.VISIBLE);
                } else {
                    adapter_ViewHolder.binding.ivplay.setVisibility(View.GONE);
                }
                Glide.with(ImageFragment.this.getActivity()).load(this.moviesList.get(i)).into(adapter_ViewHolder.binding.pcw);
                myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        CallIntent(ImageFragment.this.getActivity(), WhatsappImageViewActivity.class, i);
                    }
                });
            }
        }

        public int getItemCount() {
            return this.moviesList.size();
        }

        public int getItemViewType(int i) {
            if (this.moviesList.get(i) == null) {
                return this.AD_TYPE;
            }
            return this.TYPE_CONTENT;
        }

        //                *************intetial**********************
        public void CallIntent(Activity activity, Class<?> cls, int i) {
            InterstitialAds.showAd(getActivity(), new OnInterstitialAdResponse() {
                @Override
                public void onAdClosed() {
                    final Intent intent = new Intent(activity, cls);
                    intent.putExtra("ImageDataFile", moviesList.get(i).toString());
                    ImageFragment.this.startActivity(intent);
                }

                @Override
                public void onAdImpression() {
                }
            });

        }
    }
}
