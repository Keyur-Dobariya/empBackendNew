package com.hd.video.downloader.play.video.NewWp.l.a;

import android.content.Context;
import android.net.Uri;

public abstract class a {
    public abstract Uri b();

    public a(a aVar) {
    }

    public static a a(Context context, Uri uri) {
        return new b((a) null, context, uri);
    }
}
