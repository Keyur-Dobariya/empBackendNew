package com.hd.video.downloader.play.video.NewWp.l.a;

import android.content.Context;
import android.net.Uri;

public class b extends a {
    public Uri b;
    public Context f4a;

    public b(a aVar, Context context, Uri uri) {
        super((a) null);
        this.f4a = context;
        this.b = uri;
    }

    public Uri b() {
        return this.b;
    }
}
