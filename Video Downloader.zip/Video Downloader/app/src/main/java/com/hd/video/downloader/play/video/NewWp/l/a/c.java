package com.hd.video.downloader.play.video.NewWp.l.a;

import android.content.Context;
import android.net.Uri;

public class c extends a {
    public Uri b;
    public Context f5a;

    public c(a aVar, Context context, Uri uri) {
        super(aVar);
        this.f5a = context;
        this.b = uri;
    }

    public static void c(AutoCloseable autoCloseable) {
        if (autoCloseable != null) {
            try {
                autoCloseable.close();
            } catch (RuntimeException e) {
                throw e;
            } catch (Exception unused) {
            }
        }
    }

    public Uri b() {
        return this.b;
    }
}
