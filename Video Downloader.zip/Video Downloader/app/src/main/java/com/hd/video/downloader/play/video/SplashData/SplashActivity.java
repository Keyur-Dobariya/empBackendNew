package com.hd.video.downloader.play.video.SplashData;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;

import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.StartAppActivity;
import com.hd.video.downloader.play.video.ads.commons.AdsManager;
import com.hd.video.downloader.play.video.ads.interfaces.OnFirstData;
import com.hd.video.downloader.play.video.databinding.ActivitySplashBinding;

public class SplashActivity extends AppCompatActivity implements OnFirstData {

    ActivitySplashBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Window window = SplashActivity.this.getWindow();
        window.setStatusBarColor(ContextCompat.getColor(SplashActivity.this, R.color.bg));

        binding.btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.btnRetry.setVisibility(View.GONE);
                AdsManager.getFirstData(getApplication(), getApplication(), SplashActivity.this, SplashActivity.this);
            }
        });
        binding.btnRetry.performClick();
    }
    @Override
    public void onSuccess() {
        startActivity(new Intent(SplashActivity.this, StartAppActivity.class));
        new Handler().postDelayed(this::finish, 500);
    }

    @Override
    public void onFailed() {
        binding.progress.setVisibility(View.GONE);
        binding.btnRetry.setVisibility(View.VISIBLE);
    }
}