package com.hd.video.downloader.play.video.ads.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object AdsClient {

    private var retrofit: Retrofit? = null
    private const val baseUrl = "https://adsbackend.onrender.com/"

    fun getClient(): AdsInterface {
        if (retrofit == null) {
            retrofit =
                Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create()).build()
        }
        return retrofit!!.create(AdsInterface::class.java)
    }
}