package com.hd.video.downloader.play.video.ads.api

import android.content.Context
import android.util.Log
import kotlin.random.Random

class AdsCommon {
    fun setGeoTargeting(context: Context) {
        val geoTargetingManager = GeoTargetingManager(context)

        geoTargetingManager.initializeGeoTargeting()

        geoTargetingManager.getGeoTargetingParams().forEach { (key, value) ->
            Log.d("TAG", "Geo targeting param: $key = $value")
        }
    }
}

