package com.hd.video.downloader.play.video.ads.api

import android.content.Context
import android.util.Log
import kotlin.random.Random

/**
 * GeoTargetingManager handles the random geo-targeting logic similar to the web implementation.
 * This class manages a list of predefined geo targets and randomly selects one for ad targeting.
 */
class GeoTargetingManager(private val context: Context) {
    
    companion object {
        private const val TAG = "GeoTargetingManager"
        
        // Predefined geo targets matching the web implementation
        private val GEO_TARGETS = arrayOf(
            "California, US",
//            "New York, US",
//            "Melbourne, AU",
//            "Victoria, AU",
//            "Toronto, CA",
//            "Ottawa, CA",
//            "Wellington, NZ"
        )
    }
    
    private var currentGeoTarget: String? = null
    private var geoTargetingEnabled = true
    
    /**
     * Initialize geo targeting with random selection
     * This mimics the web logic: if (Math.random() < 1)
     */
    fun initializeGeoTargeting(): String? {
        return if (shouldApplyGeoTargeting()) {
            selectRandomGeoTarget()
        } else {
            null
        }
    }
    
    /**
     * Determines if geo targeting should be applied
     * In the web version, this was always true (Math.random() < 1)
     * You can modify this logic for different probability
     */
    private fun shouldApplyGeoTargeting(): Boolean {
        // Using Random.nextDouble() < 1.0 (always true, matching web logic)
        // You can change this to Random.nextDouble() < 0.8 for 80% probability, etc.
        return Random.nextDouble() < 1.0 && geoTargetingEnabled
    }
    
    /**
     * Selects a random geo target from the predefined list
     * Equivalent to: geoTargets[Math.floor(Math.random() * geoTargets.length)]
     */
    private fun selectRandomGeoTarget(): String {
        val randomIndex = Random.nextInt(GEO_TARGETS.size)
        val selectedTarget = GEO_TARGETS[randomIndex]
        
        currentGeoTarget = selectedTarget
        Log.d(TAG, "GEO Targeted: $selectedTarget")
        
        return selectedTarget
    }
    
    /**
     * Get the current geo target
     */
    fun getCurrentGeoTarget(): String? = currentGeoTarget
    
    /**
     * Get all available geo targets
     */
    fun getAvailableGeoTargets(): Array<String> = GEO_TARGETS.clone()
    
    /**
     * Manually set a specific geo target (for testing purposes)
     */
    fun setGeoTarget(target: String) {
        if (target in GEO_TARGETS) {
            currentGeoTarget = target
            Log.d(TAG, "Manually set GEO Target: $target")
        } else {
            Log.w(TAG, "Invalid geo target: $target")
        }
    }
    
    /**
     * Enable or disable geo targeting
     */
    fun setGeoTargetingEnabled(enabled: Boolean) {
        geoTargetingEnabled = enabled
        Log.d(TAG, "Geo targeting ${if (enabled) "enabled" else "disabled"}")
    }
    
    /**
     * Check if geo targeting is enabled
     */
    fun isGeoTargetingEnabled(): Boolean = geoTargetingEnabled
    
    /**
     * Reset geo targeting (clear current target)
     */
    fun resetGeoTargeting() {
        currentGeoTarget = null
        Log.d(TAG, "Geo targeting reset")
    }
    
    /**
     * Get geo targeting information for ad requests
     * Returns a map with targeting parameters
     */
    fun getGeoTargetingParams(): Map<String, String> {
        val params = mutableMapOf<String, String>()
        
        currentGeoTarget?.let { target ->
            // Parse the geo target string (e.g., "California, US")
            val parts = target.split(", ")
            if (parts.size == 2) {
                params["geo_region"] = parts[0]
                params["geo_country"] = parts[1]
                params["geo_target"] = target
            } else {
                params["geo_target"] = target
            }
        }
        
        return params
    }
    
    /**
     * Get formatted geo target for display
     */
    fun getFormattedGeoTarget(): String {
        return currentGeoTarget ?: "No geo targeting applied"
    }
    
    /**
     * Refresh geo targeting (select new random target)
     */
    fun refreshGeoTargeting(): String? {
        resetGeoTargeting()
        return initializeGeoTargeting()
    }
    
    /**
     * Get geo target statistics
     */
    fun getGeoTargetStats(): Map<String, Any> {
        return mapOf(
            "total_targets" to GEO_TARGETS.size,
            "current_target" to (currentGeoTarget ?: "None"),
            "targeting_enabled" to geoTargetingEnabled,
            "available_targets" to GEO_TARGETS.toList()
        )
    }
}

