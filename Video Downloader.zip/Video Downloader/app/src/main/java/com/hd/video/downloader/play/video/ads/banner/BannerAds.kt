package com.hd.video.downloader.play.video.ads.banner

import android.app.Activity
import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.annotation.LayoutRes
import com.hd.video.downloader.play.video.ads.commons.AdsUtils
import com.hd.video.downloader.play.video.ads.commons.CustomEvents
import com.hd.video.downloader.play.video.ads.commons.dimen
import com.hd.video.downloader.play.video.ads.commons.hide
import com.hd.video.downloader.play.video.ads.commons.loge
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.hd.video.downloader.play.video.R
import com.hd.video.downloader.play.video.ads.api.AdsCommon


class BannerAds @JvmOverloads constructor(
    private val screenName: String, @LayoutRes private val loader: Int = R.layout.ads_loader
) {
    private var bannerIndex = 0

    fun showAd(context: Context, adMobBanner: FrameLayout, parent: View?) {
        if (!AdsUtils.isAdEnabled(context)) {
            parent?.hide()
            return
        }
        val bannerScreens = AdsUtils.getAdPref(context).bannerScreens.contains(screenName, true)
        if (!bannerScreens) {
            parent?.hide()
            return
        }
        addAdLoader(context, adMobBanner)
        if (AdsUtils.isNextBannerGoogle()) {
            showGoogleAd(context, adMobBanner)
        } else if (AdsUtils.isNextBannerMeta()) {
            showMetaAd(context, adMobBanner)
        }
    }

    private fun showMetaAd(context: Context, fbBanner: FrameLayout) {
        loge("loadAds:BannerAds:showMetaAd")
        com.facebook.ads.AdView(
            context, AdsUtils.getAdPref(context).fbBanner, com.facebook.ads.AdSize.BANNER_HEIGHT_50
        ).apply {
            val adListener = object : com.facebook.ads.AdListener {
                override fun onError(p0: Ad?, p1: AdError?) {
                    AdsUtils.setNextBannerOnMetaFail(context)
                    if (AdsUtils.isNextBannerGoogle()) {
                        showGoogleAd(context, fbBanner)
                    }
                }

                override fun onAdLoaded(p0: Ad?) {
                    fbBanner.removeAllViews()
                    fbBanner.addView(this@apply)
                    AdsUtils.setNextBanner(context, AdsUtils.META)
                }

                override fun onAdClicked(p0: Ad?) {}
                override fun onLoggingImpression(p0: Ad?) {
                    CustomEvents.bannerAd(context, CustomEvents.META)
                }
            }
            loadAd(this@apply.buildLoadAdConfig().withAdListener(adListener).build())
        }
    }

    private fun showGoogleAd(context: Context, adMobBanner: FrameLayout) {
        loge("loadAds:BannerAds:showGoogleAd")
        val placementId = getPlacementId(context)
        AdView(context).apply {
            adUnitId = placementId
            val adSize: AdSize = getAdSize(context, adMobBanner)
            setAdSize(adSize)
            val adRequest = AdRequest.Builder().build()
            AdsCommon().setGeoTargeting(context)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    adMobBanner.removeAllViews()
                    adMobBanner.addView(this@apply)
                    AdsUtils.setNextBanner(context, AdsUtils.GOOGLE)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    if (AdsUtils.getAdPref(context).bannerBackFill) {
                        showGoogleAdOnFail(context, adMobBanner)
                    }
                }

                override fun onAdImpression() {
                    CustomEvents.bannerAd(context, CustomEvents.ADMOB)
                }
            }
            loadAd(adRequest)
        }
    }

    private fun showGoogleAdOnFail(context: Context, adMobBanner: FrameLayout) {
        val placementId = getPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            return
        }
        AdView(context).apply {
            adUnitId = placementId
            val adSize: AdSize = getAdSize(context, adMobBanner)
            setAdSize(adSize)
            val adRequest = AdRequest.Builder().build()
            AdsCommon().setGeoTargeting(context)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    adMobBanner.removeAllViews()
                    adMobBanner.addView(this@apply)
                    AdsUtils.setNextBanner(context, AdsUtils.GOOGLE)
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    showGoogleAdOnFail(context, adMobBanner)
                }

                override fun onAdImpression() {
                    CustomEvents.bannerAd(context, CustomEvents.ADMOB)
                }
            }
            loadAd(adRequest)
        }
    }

    private fun getAdSize(context: Context, adContainerView: FrameLayout): AdSize {
        // Determine the screen width (less decorations) to use for the ad width.
        if (Build.VERSION.SDK_INT > 29) {
            val windowMetrics = (context as Activity).windowManager.currentWindowMetrics
            val bounds = windowMetrics.bounds

            var adWidthPixels = adContainerView.width.toFloat()

            // If the ad hasn't been laid out, default to the full screen width.
            if (adWidthPixels == 0f) {
                adWidthPixels = bounds.width().toFloat()
            }

            val density = context.resources.displayMetrics.density
            val adWidth = (adWidthPixels / density).toInt()

            return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth)
        } else {
            val display = (context as Activity).windowManager.defaultDisplay
            val outMetrics = DisplayMetrics()
            display.getMetrics(outMetrics)
            val density = outMetrics.density
            var adWidthPixels = adContainerView.width.toFloat()

            // If the ad hasn't been laid out, default to the full screen width.
            if (adWidthPixels == 0f) {
                adWidthPixels = outMetrics.widthPixels.toFloat()
            }
            val adWidth = (adWidthPixels / density).toInt()
            return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth)
        }
    }

    private fun getPlacementId(context: Context): String {
        val ids = AdsUtils.getAdPref(context).bannerIds
        bannerIndex = 0
        return ids[bannerIndex]
    }

    private fun getPlacementIdOnFail(context: Context): String {
        val ids = AdsUtils.getAdPref(context).bannerIds
        bannerIndex++
        return if (bannerIndex < ids.size) {
            ids[bannerIndex]
        } else {
            ""
        }
    }

    private fun addAdLoader(context: Context, view: FrameLayout) {
        (LayoutInflater.from(context).inflate(loader, view, false) as LinearLayout).apply {
            minimumHeight = context.dimen(R.dimen._banner_height).toInt()
            view.addView(this@apply)
        }
    }
}