package com.hd.video.downloader.play.video.ads.commons

import android.app.Activity
import android.app.Application
import android.content.Context
import android.util.Log
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.hd.video.downloader.play.video.ads.api.AdsClient
import com.hd.video.downloader.play.video.ads.app.MainApplication
import com.hd.video.downloader.play.video.ads.interfaces.OnFirstData
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds
import com.hd.video.downloader.play.video.ads.model.FirstData
import com.hd.video.downloader.play.video.ads.nativee.PreloadNativeAds
import com.hd.video.downloader.play.video.ads.nativee.PreloadSmallNativeAds
import com.hd.video.downloader.play.video.ads.reward.RewardInterstitialAds
import com.hd.video.downloader.play.video.ads.reward.RewardVideoAds
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object AdsManager {
    @JvmStatic
    fun getFirstData(
        application: Application, context: Context, activity: Activity, onFirstData: OnFirstData
    ) {
        try {
            AdsClient.getClient().getFirstDataCall(context.packageName.replace(".", "_").plus("3"))
                .enqueue(object : Callback<FirstData> {
                    override fun onResponse(call: Call<FirstData>, response: Response<FirstData>) {
                        Log.i(TAG, "onResponse: ${response}")
                        if (response.body() != null) {
                            val appData = response.body()!!.data
                            val appDataJson = Gson().toJson(appData)
                            AdsUtils.saveAdPref(context, appDataJson)
                            AdsUtils.initNextAds(context)
                            initAppOpenAd(context, application, activity, onFirstData)
                            RewardVideoAds.load(context)
                            RewardInterstitialAds.load(context)
                            PreloadNativeAds.loadAd(context)
                            PreloadSmallNativeAds.loadAd(context)
                        } else {
                            onFirstData?.onFailed()
                        }
                    }

                    override fun onFailure(call: Call<FirstData>, t: Throwable) {
                        Log.i(TAG, "onResponse: ${t.message}")
                        onFirstData?.onFailed()
                    }
                })
        } catch (error: Error) {
            Log.i(TAG, "onResponse: ${error.message}")
        }
//        AdsUtils.getMoreApps(context)
    }

    private fun initAppOpenAd(
        context: Context, application: Application, activity: Activity, onFirstData: OnFirstData?
    ) {
        val mainApplication = application as? MainApplication
        if (mainApplication == null) {
            handler(4000) { onFirstData?.onSuccess() }
        } else if (AdsUtils.isAppOpenEnabled(context)) {
            if (AdsUtils.isSplashAppOpenEnabled(context)) {
                mainApplication.initAppOpenManager(activity, object : MainApplication.OnSplashAd {
                    override fun onAdClosed(isFailed: Boolean) {
                        mainApplication.onSplashAd = null
                        if (isFailed) {
                            AdsUtils.ignoreIntSkip(context)
                        }
                        InterstitialAds.loadAd(context)
                        onFirstData?.onSuccess()
                    }
                })
            } else {
                mainApplication.initAppOpenManager()
            }
        } else {
            handler(4000) { onFirstData?.onSuccess() }
        }
    }

    @JvmStatic
    fun release(application: Application) {
        AdsUtils.reset()
        (application as? MainApplication)?.release()
        InterstitialAds.release()
        PreloadNativeAds.release()
        PreloadSmallNativeAds.release()
        RewardInterstitialAds.release()
        RewardVideoAds.release()
    }
}

data class AppData(
    val splashTime: Long,
    val maxVer: Int,
    val adEnabled: Boolean,
    val alEnabled: Boolean,
    val forcedInt: Boolean,
    val adPref: String,
    val adFirstServe: String,
    val adRoundRobin: Boolean,
    val nativePreload: Boolean,
    val nativeAdPref: String,
    val nativeFirstServe: String,
    val nativeRoundRobin: Boolean,
    val showFbRectBanner: Boolean,
    val bannerAdPref: String,
    val bannerFirstServe: String,
    val bannerRoundRobin: Boolean,
    val inHouseEnabled: Boolean,
    val iapEnabled: Boolean,
    val appOpenEnabled: Boolean,
    val splashAppOpenEnabled: Boolean,
    val backPressEnabled: Boolean,
    val rewardVideoEnabled: Boolean,
    val rewardIntEnabled: Boolean,
    val intType: String,
    val intSkip: Int,
    val intClickInterval: Int,
    val intTimeInterval: Int,
    val intRandom: Boolean,
    val nativeRandom: Boolean,
    val smallNativeRandom: Boolean,
    val bannerRandom: Boolean,
    val appOpenBackFill: Boolean,
    val intBackFill: Boolean,
    val nativeBackFill: Boolean,
    val smallNativeBackFill: Boolean,
    val bannerBackFill: Boolean,
    val rewardVideoBackFill: Boolean,
    val rewardIntBackFill: Boolean,
    val adBtnBGColor: String,
    val adBtnTxtColor: String,
    val ppLink: String,
    val feedBackId: String,
    val appOpenId: String,
    val appOpenIds: List<String>,
    val intIds: List<String>,
    val nativeIds: List<String>,
    val smallNativeIds: List<String>,
    val bannerIds: List<String>,
    val rewardIntIds: List<String>,
    val rewardVideoIds: List<String>,
    val alAppOpen: String,
    val alInt: String,
    val alNative: String,
    val alSmallNative: String,
    val alBanner: String,
    val alRewardVideo: String,
    val fbInt: String,
    val fbNative: String,
    val fbBanner: String,
    val fbNativeBanner: String,
    val fbRectBanner: String,
    val fbRewardInt: String,
    val intScreensCount: String,
    val intSkips: String,
    val intScreens: String,
    val nativeScreens: String,
    val smallNativeScreens: String,
    val bannerScreens: String,
    val cBannerScreens: String,
    val inlineBannerScreens: String,
    val rewardIntScreens: String,
    val rewardVideoScreens: String
)