package com.hd.video.downloader.play.video.ads.commons

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import com.hd.video.downloader.play.video.ads.api.AdsClient
import com.hd.video.downloader.play.video.ads.model.AdPrefs
import com.hd.video.downloader.play.video.ads.model.FirstData
import com.hd.video.downloader.play.video.ads.model.MoreApps
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class AdsUtils {

    companion object {
        private const val CIPHER_NAME = "AES/CBC/PKCS5PADDING"
        private const val CIPHER_KEY_LEN = 16 //128 bits
        private var adPrefs: AdPrefs? = null
        var moreApps: MoreApps? = null
        private var sharedPreferences: SharedPreferences? = null
        private var adRemoved: Boolean? = null
        var isInterstitialAdShowing = false
        var isBackPressAdShowing = false

        private const val BOTH = "both"
        const val GOOGLE = "google"
        const val META = "meta"

        private var nextInt = GOOGLE
        private var nextNative = GOOGLE
        private var nextSmallNative = GOOGLE
        private var nextBanner = GOOGLE

        fun isNextIntGoogle(): Boolean {
            return nextInt.equals(GOOGLE, true)
        }

        fun isNextIntMeta(): Boolean {
            return nextInt.equals(META, true)
        }

        fun isNextNativeGoogle(): Boolean {
            return nextNative.equals(GOOGLE, true)
        }

        fun isNextNativeMeta(): Boolean {
            return nextNative.equals(META, true)
        }

        fun isNextSmallNativeGoogle(): Boolean {
            return nextSmallNative.equals(GOOGLE, true)
        }

        fun isNextSmallNativeMeta(): Boolean {
            return nextSmallNative.equals(META, true)
        }

        fun isNextBannerGoogle(): Boolean {
            return nextBanner.equals(GOOGLE, true)
        }

        fun isNextBannerMeta(): Boolean {
            return nextBanner.equals(META, true)
        }

        @JvmStatic
        var appOpenAllowed = true
        private var rewardCounts = HashMap<String, Int>()

        private fun initSharedPreferences(context: Context) {
            if (sharedPreferences == null) {
                sharedPreferences = context.getSharedPreferences("ad_data", Context.MODE_PRIVATE)
            }
        }

        fun saveAdPref(context: Context, data: String) {
            initSharedPreferences(context)
            sharedPreferences!!.edit().putString("my_data", data).apply()
        }

        private fun saveMoreApps(context: Context, data: String) {
            initSharedPreferences(context)
            sharedPreferences!!.edit().putString("more_apps", data).apply()
        }

        @JvmStatic
        fun getAdPref(context: Context): AdPrefs {
            return if (adPrefs != null) {
                adPrefs!!
            } else {
                initSharedPreferences(context)
                adPrefs = Gson().fromJson(
                    sharedPreferences!!.getString("my_data", ""), AdPrefs::class.java
                )
                adPrefs!!
            }
        }

        @JvmStatic
        fun hasAdPref(context: Context): Boolean {
            initSharedPreferences(context)
            return !sharedPreferences!!.getString("my_data", "")!!.equals("", true)
        }

        @JvmStatic
        fun hasMorePref(context: Context): Boolean {
            initSharedPreferences(context)
            return !sharedPreferences!!.getString("more_apps", "")!!.equals("", true)
        }

        fun getMoreAppsPref(context: Context): MoreApps {
            return if (moreApps != null) {
                moreApps!!
            } else {
                initSharedPreferences(context)
                moreApps = Gson().fromJson(
                    sharedPreferences!!.getString("more_apps", ""), MoreApps::class.java
                )
                moreApps!!
            }
        }

        //todo
        @JvmStatic
        fun isAdEnabled(context: Context): Boolean {
            return if (!context.isInternetConnected) {
                false
            } else if (!hasAdPref(context)) {
                false
            } else if (getAdPref(context).maxVer < appVersionCode) {
                false
            } else if (adPrefs != null) {
                adPrefs!!.adEnabled && !isAdRemoved(context)
            } else {
                initSharedPreferences(context)
                adPrefs = Gson().fromJson(
                    sharedPreferences!!.getString("my_data", ""), AdPrefs::class.java
                )
                adPrefs!!.adEnabled && !isAdRemoved(context)
            }
        }

        @JvmStatic
        fun isAppOpenEnabled(context: Context): Boolean {
            return isAdEnabled(context) && getAdPref(context).appOpenEnabled
        }

        @JvmStatic
        fun isSplashAppOpenEnabled(context: Context): Boolean {
            return isAdEnabled(context) && getAdPref(context).splashAppOpenEnabled
        }

        @JvmStatic
        fun getSplashTime(context: Context): Long {
            return if (hasAdPref(context)) {
                getAdPref(context).splashTime.toLong()
            } else {
                4000L
            }
        }

        @JvmStatic
        fun isAdRemoved(context: Context): Boolean {
            return if (adRemoved != null) {
                adRemoved!!
            } else {
                initSharedPreferences(context)
                adRemoved = sharedPreferences!!.getBoolean("ad_remove", false)
                adRemoved!!
            }
        }

        @JvmStatic
        fun setAdRemoved(context: Context, boolean: Boolean) {
            adRemoved = boolean
            initSharedPreferences(context)
            sharedPreferences!!.edit().putBoolean("ad_remove", boolean).apply()
        }

        @JvmStatic
        fun isInHouseEnabled(context: Context): Boolean {
            return if (!hasAdPref(context)) {
                false
            } else if (!hasMorePref(context)) {
                false
            } else if (getMoreAppsPref(context).apps.size == 0) {
                false
            } else if (adPrefs != null) {
                adPrefs!!.inHouseEnabled && !isAdRemoved(context)
            } else {
                initSharedPreferences(context)
                adPrefs = Gson().fromJson(
                    sharedPreferences!!.getString("my_data", ""), AdPrefs::class.java
                )
                adPrefs!!.inHouseEnabled && !isAdRemoved(context)
            }
        }

        private var skipClickCount = 0
        private var isFirst = true
        private var currentClickCount = 0
        private var timePrevious = 0L

        fun ignoreIntSkip(context: Context) {
            skipClickCount = getAdPref(context).intSkip
        }

        fun isIntEligibleToShow(context: Context): Boolean {
            skipClickCount++
            return if (skipClickCount <= getAdPref(context).intSkip) {
                false
            } else if (getAdPref(context).intType.equals("click", true)) {
                if (isFirst) {
                    isFirst = false
                    true
                } else if (getAdPref(context).intClickInterval == 0) {
                    true
                } else if (getAdPref(context).intClickInterval == currentClickCount) {
                    true
                } else {
                    currentClickCount++
                    false
                }
            } else {
                System.currentTimeMillis() - timePrevious > getAdPref(context).intTimeInterval * 1000L
            }
        }

        fun intAdShown() {
            currentClickCount = 0
            timePrevious = System.currentTimeMillis()
        }

        @JvmStatic
        fun isRewardIntEligible(context: Context, key: String, rewardItem: Int): Boolean {
            initSharedPreferences(context)
            val count = rewardCounts[key] ?: -1
            return if (count == -1) {
                true
            } else {
                count % rewardItem == 0
            }
        }

        @JvmStatic
        fun isRewardVideoEligible(context: Context, key: String, rewardItem: Int): Boolean {
            initSharedPreferences(context)
            val count = rewardCounts[key] ?: -1
            return if (count == -1) {
                true
            } else {
                count % rewardItem == 0
            }
        }

        @JvmStatic
        fun setReward(key: String) {
            val count = (rewardCounts[key] ?: 0) + 1
            rewardCounts[key] = count
        }

        fun decrypt(encrypted: String): String? {
            var key = encrypted.take(16)
            val data = encrypted.drop(16)
            try {
                if (key.length < CIPHER_KEY_LEN) {
                    val numPad: Int = CIPHER_KEY_LEN - key.length
                    for (i in 0 until numPad) {
                        key += "0" //0 pad to len 16 bytes
                    }
                } else if (key.length > CIPHER_KEY_LEN) {
                    key = key.substring(
                        0, CIPHER_KEY_LEN
                    ) //truncate to 16 bytes
                }
                val parts = data.split(":").toTypedArray()
                val iv = IvParameterSpec(Base64.decode(parts[1], Base64.DEFAULT))
                val skeySpec = SecretKeySpec(key.toByteArray(StandardCharsets.ISO_8859_1), "AES")
                val cipher = Cipher.getInstance(CIPHER_NAME)
                cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv)
                val decodedEncryptedData = Base64.decode(parts[0], Base64.DEFAULT)
                val original = cipher.doFinal(decodedEncryptedData)
                return String(original)
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return null
        }

        @JvmStatic
        fun hasNativeScreen(context: Context, screenName: String): Boolean {
            if (!isAdEnabled(context)) {
                return false
            }
            val hasBannerScreen = getAdPref(context).inlineBannerScreens.contains(screenName, true)
            val hasNativeScreen = getAdPref(context).nativeScreens.contains(screenName, true)
            return hasBannerScreen || hasNativeScreen
        }

        @JvmStatic
        fun hasSmallNativeScreen(context: Context, screenName: String): Boolean {
            if (!isAdEnabled(context)) {
                return false
            }
            val hasInlineBannerScreen = getAdPref(context).inlineBannerScreens.contains(screenName, true)
            val hasNativeScreen = getAdPref(context).smallNativeScreens.contains(screenName, true)
            return hasInlineBannerScreen || hasNativeScreen
        }

        @JvmStatic
        fun hasRewardVideoScreen(context: Context, screenName: String): Boolean {
            if (!isAdEnabled(context)) {
                return false
            }
            if (!getAdPref(context).rewardVideoEnabled) {
                return false
            }
            return getAdPref(context).rewardVideoScreens.contains(screenName, true)
        }

        @JvmStatic
        fun hasRewardIntScreen(context: Context, screenName: String): Boolean {
            if (!isAdEnabled(context)) {
                return false
            }
            if (!getAdPref(context).rewardIntEnabled) {
                return false
            }
            return getAdPref(context).rewardIntScreens.contains(screenName, true)
        }

//        fun getMoreApps(context: Context) {
//            AdsClient.getClient().getMoreApps().enqueue(object : Callback<FirstData> {
//                override fun onResponse(call: Call<FirstData>, response: Response<FirstData>) {
//                    if (response.body() != null) {
//                        var moreAppsJson = decrypt(response.body()!!.data)
//                        val moreApps = Gson().fromJson(
//                            moreAppsJson, MoreApps::class.java
//                        )
//                        var removeIndex = -1
//                        moreApps.apps.forEachIndexed { index, apps ->
//                            if (apps.appPkgName.equals(context.packageName, true)) {
//                                removeIndex = index
//                            }
//                        }
//                        if (removeIndex > -1) {
//                            moreApps.apps.removeAt(removeIndex)
//                        }
//                        moreAppsJson = Gson().toJson(moreApps)
//                        saveMoreApps(context, moreAppsJson!!)
//                    }
//                }
//
//                override fun onFailure(call: Call<FirstData>, t: Throwable) {
//
//                }
//            })
//        }

        fun initNextAds(context: Context) {
            val intAdPref = getAdPref(context).intAdPref
            nextInt = if (intAdPref.equals(BOTH, true)) {
                if (getAdPref(context).intFirstServe.equals(GOOGLE, true)) {
                    GOOGLE
                } else {
                    META
                }
            } else {
                intAdPref
            }

            val nativeAdPref = getAdPref(context).nativeAdPref
            if (nativeAdPref.equals(BOTH, true)) {
                if (getAdPref(context).nativeFirstServe.equals(GOOGLE, true)) {
                    nextNative = GOOGLE
                    nextSmallNative = GOOGLE
                } else {
                    nextNative = META
                    nextSmallNative = META
                }
            } else {
                nextNative = nativeAdPref
                nextSmallNative = nativeAdPref
            }

            val bannerAdPref = getAdPref(context).bannerAdPref
            nextBanner = if (bannerAdPref.equals(BOTH, true)) {
                if (getAdPref(context).bannerFirstServe.equals(GOOGLE, true)) {
                    GOOGLE
                } else {
                    META
                }
            } else {
                bannerAdPref
            }
        }

        fun setNextIntOnMetaFail(context: Context) {
            if (getAdPref(context).intAdPref.equals(META, true) && (getAdPref(context).intRoundRobin)) {
                nextInt = GOOGLE
            } else if (getAdPref(context).intAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).intRoundRobin)
            ) {
                nextInt = GOOGLE
            }
        }

        fun setNextInt(context: Context, network: String) {
            if (getAdPref(context).intAdPref.equals(META, true)) {
                nextInt = META
            } else if (getAdPref(context).intAdPref.equals(GOOGLE, true)) {
                nextInt = GOOGLE
            } else if (getAdPref(context).intAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).intRoundRobin)
            ) {
                nextInt = if (network.equals(GOOGLE, true)) {
                    META
                } else {
                    GOOGLE
                }
            }
        }

        fun setNextNativeOnMetaFail(context: Context) {
            if (getAdPref(context).nativeAdPref.equals(
                    META, true
                ) && (getAdPref(context).nativeRoundRobin)
            ) {
                nextNative = GOOGLE
            } else if (getAdPref(context).nativeAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).nativeRoundRobin)
            ) {
                nextNative = GOOGLE
            }
        }

        fun setNextNative(context: Context, network: String) {
            if (getAdPref(context).nativeAdPref.equals(META, true)) {
                nextNative = META
            } else if (getAdPref(context).nativeAdPref.equals(GOOGLE, true)) {
                nextNative = GOOGLE
            } else if (getAdPref(context).nativeAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).nativeRoundRobin)
            ) {
                nextNative = if (network.equals(GOOGLE, true)) {
                    META
                } else {
                    GOOGLE
                }
            }
        }

        fun setNextSmallNativeOnMetaFail(context: Context) {
            if (getAdPref(context).nativeAdPref.equals(
                    META, true
                ) && (getAdPref(context).nativeRoundRobin)
            ) {
                nextSmallNative = GOOGLE
            } else if (getAdPref(context).nativeAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).nativeRoundRobin)
            ) {
                nextSmallNative = GOOGLE
            }
        }

        fun setNextSmallNative(context: Context, network: String) {
            if (getAdPref(context).nativeAdPref.equals(META, true)) {
                nextSmallNative = META
            } else if (getAdPref(context).nativeAdPref.equals(GOOGLE, true)) {
                nextSmallNative = GOOGLE
            } else if (getAdPref(context).nativeAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).nativeRoundRobin)
            ) {
                nextSmallNative = if (network.equals(GOOGLE, true)) {
                    META
                } else {
                    GOOGLE
                }
            }
        }

        fun setNextBannerOnMetaFail(context: Context) {
            if (getAdPref(context).bannerAdPref.equals(
                    META, true
                ) && (getAdPref(context).bannerRoundRobin)
            ) {
                nextBanner = GOOGLE
            }
            else if (getAdPref(context).bannerAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).bannerRoundRobin)
            ) {
                nextBanner = GOOGLE
            }
        }

        fun setNextBanner(context: Context, network: String) {
            if (getAdPref(context).bannerAdPref.equals(
                    META, true
                ) && (getAdPref(context).bannerRoundRobin)
            ) {
                nextBanner = META
            }
            else if (getAdPref(context).bannerAdPref.equals(
                    GOOGLE, true
                ) && (getAdPref(context).bannerRoundRobin)
            ) {
                nextBanner = GOOGLE
            }
            else if (getAdPref(context).bannerAdPref.equals(
                    BOTH, true
                ) && (getAdPref(context).bannerRoundRobin)
            ) {
                nextBanner = if (network.equals(GOOGLE, true)) {
                    META
                } else {
                    GOOGLE
                }
            }
        }

        fun reset() {
            adPrefs = null
            moreApps = null
            rewardCounts = HashMap<String, Int>()
            skipClickCount = 0
            isFirst = true
            currentClickCount = 0
            timePrevious = 0L
        }
    }
}