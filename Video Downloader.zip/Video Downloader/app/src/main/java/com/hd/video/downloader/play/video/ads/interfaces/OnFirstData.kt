package com.hd.video.downloader.play.video.ads.interfaces

interface OnFirstData {
    fun onSuccess()
    fun onFailed()
}