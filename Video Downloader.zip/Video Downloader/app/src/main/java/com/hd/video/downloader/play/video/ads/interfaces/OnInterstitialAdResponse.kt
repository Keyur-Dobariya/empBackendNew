package com.hd.video.downloader.play.video.ads.interfaces

interface OnInterstitialAdResponse {
    fun onAdClosed()
    fun onAdImpression()
}