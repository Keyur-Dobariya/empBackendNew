package com.hd.video.downloader.play.video.ads.interfaces

interface OnRewardAdResponse {
    fun onRewardEarned()
    fun onAdImpression()
    fun onAdCancelled()
    fun onAdFailed()
}