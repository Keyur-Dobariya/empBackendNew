package com.hd.video.downloader.play.video.ads.reward

import android.app.Activity
import android.content.Context
import android.view.Window
import androidx.annotation.LayoutRes
import androidx.appcompat.widget.AppCompatTextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.hd.video.downloader.play.video.ads.commons.AdsUtils
import com.hd.video.downloader.play.video.ads.commons.CustomEvents
import com.hd.video.downloader.play.video.ads.commons.handler
import com.hd.video.downloader.play.video.ads.commons.hide
import com.hd.video.downloader.play.video.ads.commons.show
import com.hd.video.downloader.play.video.ads.interfaces.OnRewardAdResponse
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.hd.video.downloader.play.video.R
import com.hd.video.downloader.play.video.ads.api.AdsCommon

object RewardInterstitialAds {

    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var rewardIndex = -1
    private var isFailed = false

    fun load(context: Context) {
        if (!AdsUtils.isAdEnabled(context) || !AdsUtils.getAdPref(context).rewardIntEnabled) {
            return
        }
        if (AdsUtils.getAdPref(context).rewardIntScreens.contains("none", true)) {
            return
        }
        if (rewardedInterstitialAd != null) {
            return
        }
        isFailed = false
        val placementId = getPlacementId(context)
        val adRequest = AdRequest.Builder().build()
        AdsCommon().setGeoTargeting(context)
        RewardedInterstitialAd.load(
            context,
            placementId,
            adRequest,
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    isFailed = false
                    rewardedInterstitialAd = ad
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    isFailed = true
                    rewardedInterstitialAd = null
                    if (AdsUtils.getAdPref(context).rewardIntBackFill) {
                        loadOnFail(context)
                    }
                }
            })
    }

    private fun loadOnFail(context: Context) {
        if (!AdsUtils.isAdEnabled(context) || !AdsUtils.getAdPref(context).rewardIntEnabled) {
            return
        }
        if (rewardedInterstitialAd != null) {
            return
        }
        isFailed = false
        val placementId = getPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            return
        }
        val adRequest = AdRequest.Builder().build()
        AdsCommon().setGeoTargeting(context)
        RewardedInterstitialAd.load(
            context,
            placementId,
            adRequest,
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    isFailed = false
                    rewardedInterstitialAd = ad
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    isFailed = true
                    rewardedInterstitialAd = null
                    loadOnFail(context)
                }
            })
    }

    fun show(
        context: Context,
        screenName: String,
        key: String,
        rewardItem: Int,
        msg: String,
        @LayoutRes dialogLayout: Int,
        onRewardAdResponse: OnRewardAdResponse?,
    ) {
        show(context, screenName, key, rewardItem, msg, dialogLayout, onRewardAdResponse, false)
    }

    fun show(
        context: Context,
        screenName: String,
        key: String,
        rewardItem: Int,
        msg: String,
        @LayoutRes dialogLayout: Int,
        onRewardAdResponse: OnRewardAdResponse?,
        showInterstitial: Boolean = false,
    ) {
        if (!AdsUtils.isAdEnabled(context)) {
            AdsUtils.setReward(key)
            onRewardAdResponse?.onRewardEarned()
            return
        }
        if (!AdsUtils.getAdPref(context).rewardIntEnabled) {
            if (AdsUtils.isRewardIntEligible(context, key, rewardItem)) {
                if (showInterstitial) {
                    showInterstitialAd(context, screenName, key, onRewardAdResponse)
                } else {
                    AdsUtils.setReward(key)
                    onRewardAdResponse?.onRewardEarned()
                }
            } else {
                AdsUtils.setReward(key)
                onRewardAdResponse?.onRewardEarned()
            }
            return
        }
        val hasRewardIntScreen = AdsUtils.getAdPref(context).rewardIntScreens.contains(screenName, true)
        if (!hasRewardIntScreen) {
            if (AdsUtils.isRewardIntEligible(context, key, rewardItem)) {
                if (showInterstitial) {
                    showInterstitialAd(context, screenName, key, onRewardAdResponse)
                } else {
                    AdsUtils.setReward(key)
                    onRewardAdResponse?.onRewardEarned()
                }
            } else {
                AdsUtils.setReward(key)
                onRewardAdResponse?.onRewardEarned()
            }
            return
        }
        if (!AdsUtils.isRewardIntEligible(context, key, rewardItem)) {
            AdsUtils.setReward(key)
            onRewardAdResponse?.onRewardEarned()
            return
        }
        BottomSheetDialog(context).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(dialogLayout)
            val width = (context.resources.displayMetrics.widthPixels * 0.95).toInt()
            window?.setLayout(width, -2)
            setCancelable(true)
            val txtMsg = findViewById<AppCompatTextView>(R.id.txt_msg)
            val btnOk = findViewById<MaterialButton>(R.id.btn_ok)
            val btnCancel = findViewById<MaterialButton>(R.id.btn_cancel)
            val progress = findViewById<ConstraintLayout>(R.id.lout_progress)

            txtMsg?.text = msg
            btnOk?.setOnClickListener {
                it.hide()
                btnCancel?.hide()
                progress?.show()
                if (rewardedInterstitialAd == null) {
                    showOnDemand(context, key, onRewardAdResponse, this)
                } else {
                    var isCompleted = false
                    handler(2500) {
                        if (!(context as Activity?)?.isFinishing!!) {
                            dismiss()
                        }
                        rewardedInterstitialAd?.apply {
                            fullScreenContentCallback = object : FullScreenContentCallback() {
                                override fun onAdDismissedFullScreenContent() {
                                    rewardedInterstitialAd = null
                                    AdsUtils.isInterstitialAdShowing = false
                                    if (isCompleted) {
                                        onRewardAdResponse?.onRewardEarned()
                                    } else {
                                        onRewardAdResponse?.onAdCancelled()
                                    }
                                    handler(2500) { load(context) }
                                }

                                override fun onAdShowedFullScreenContent() {
                                    AdsUtils.isInterstitialAdShowing = true
                                }

                                override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                    onRewardAdResponse?.onAdFailed()
                                }

                                override fun onAdImpression() {
                                    CustomEvents.rewardIntAd(context, CustomEvents.ADMOB)
                                }
                            }
                            show(context as Activity) {
                                AdsUtils.setReward(key)
                                isCompleted = true
                            }
                        }
                    }
                }
            }
            btnCancel?.setOnClickListener {
                if (!(context as Activity?)?.isFinishing!!) {
                    dismiss()
                }
                onRewardAdResponse?.onAdCancelled()
            }
            show()
        }
    }

    private fun showOnDemand(
        context: Context, key: String, onRewardAdResponse: OnRewardAdResponse?, dialog: BottomSheetDialog
    ) {
        val placementId = getPlacementId(context)
        val adRequest = AdRequest.Builder().build()
        AdsCommon().setGeoTargeting(context)
        RewardedInterstitialAd.load(
            context,
            placementId,
            adRequest,
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(rewardedInterstitialAd: RewardedInterstitialAd) {
                    dialog.dismiss()
                    var isCompleted = false
                    rewardedInterstitialAd.apply {
                        fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                AdsUtils.isInterstitialAdShowing = false
                                if (isCompleted) {
                                    onRewardAdResponse?.onRewardEarned()
                                } else {
                                    onRewardAdResponse?.onAdCancelled()
                                }
                                preload(context)
                            }

                            override fun onAdShowedFullScreenContent() {
                                AdsUtils.isInterstitialAdShowing = true
                            }

                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                onRewardAdResponse?.onAdFailed()
                                preload(context)
                            }

                            override fun onAdImpression() {
                                CustomEvents.rewardIntAd(context, CustomEvents.ADMOB)
                            }
                        }
                        show(context as Activity) {
                            AdsUtils.setReward(key)
                            isCompleted = true
                        }
                    }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    if (AdsUtils.getAdPref(context).rewardIntBackFill) {
                        showOnDemandOnFail(context, key, onRewardAdResponse, dialog)
                    } else {
                        dialog.dismiss()
                        onRewardAdResponse?.onAdFailed()
                        preload(context)
                    }
                }
            })
    }

    private fun showOnDemandOnFail(
        context: Context, key: String, onRewardAdResponse: OnRewardAdResponse?, dialog: BottomSheetDialog
    ) {
        val placementId = getPlacementIdOnFail(context)
        if (placementId.equals("", true)) {
            dialog.dismiss()
            onRewardAdResponse?.onAdFailed()
            preload(context)
            return
        }
        val adRequest = AdRequest.Builder().build()
        AdsCommon().setGeoTargeting(context)
        RewardedInterstitialAd.load(
            context,
            placementId,
            adRequest,
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(rewardedInterstitialAd: RewardedInterstitialAd) {
                    dialog.dismiss()
                    var isCompleted = false
                    rewardedInterstitialAd.apply {
                        fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                AdsUtils.isInterstitialAdShowing = false
                                if (isCompleted) {
                                    onRewardAdResponse?.onRewardEarned()
                                } else {
                                    onRewardAdResponse?.onAdCancelled()
                                }
                                preload(context)
                            }

                            override fun onAdShowedFullScreenContent() {
                                AdsUtils.isInterstitialAdShowing = true
                            }

                            override fun onAdFailedToShowFullScreenContent(p0: AdError) {
                                onRewardAdResponse?.onAdFailed()
                                preload(context)
                            }

                            override fun onAdImpression() {
                                CustomEvents.rewardIntAd(context, CustomEvents.ADMOB)
                            }
                        }
                        show(context as Activity) {
                            AdsUtils.setReward(key)
                            isCompleted = true
                        }
                    }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    showOnDemandOnFail(context, key, onRewardAdResponse, dialog)
                }
            })
    }

    private fun showInterstitialAd(
        context: Context, screenName: String, key: String, onRewardAdResponse: OnRewardAdResponse?
    ) {
        InterstitialAds.showForRewardAd(context, object : OnRewardAdResponse {

            override fun onRewardEarned() {
                AdsUtils.setReward(key)
                onRewardAdResponse?.onRewardEarned()
            }

            override fun onAdImpression() {
                onRewardAdResponse?.onAdImpression()
            }

            override fun onAdCancelled() {
                onRewardAdResponse?.onAdCancelled()
            }

            override fun onAdFailed() {
                onRewardAdResponse?.onAdFailed()
            }
        })
    }

    private fun preload(context: Context) {
        if (isFailed) {
            handler(2500) { load(context) }
        }
    }

    private fun getPlacementId(context: Context): String {
        val ids = AdsUtils.getAdPref(context).rewardIntIds
        rewardIndex = 0
        return ids[rewardIndex]
    }

    private fun getPlacementIdOnFail(context: Context): String {
        val ids = AdsUtils.getAdPref(context).rewardIntIds
        rewardIndex++
        return if (rewardIndex < ids.size) {
            ids[rewardIndex]
        } else {
            ""
        }
    }

    fun release() {
        rewardedInterstitialAd = null
    }
}