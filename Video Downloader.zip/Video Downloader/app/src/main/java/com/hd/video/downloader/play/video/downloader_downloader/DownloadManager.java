package com.hd.video.downloader.play.video.downloader_downloader;

import android.content.Context;
import android.content.Intent;


import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;
import com.hd.video.downloader.play.video.downloader_downloader.notify.DataChanger;
import com.hd.video.downloader.play.video.downloader_downloader.notify.DataWatcher;

import java.io.File;
import java.util.ArrayList;

public class DownloadManager {
    private static DownloadManager mInstance;
    private final Context context;
    private long mLastOperatedTime = 0;

    private DownloadManager(Context context2) {
        this.context = context2;
        context2.startService(new Intent(context2, DownloadService.class));
    }

    private boolean checkIfExecutable() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.mLastOperatedTime <= ((long) DownloadConfig.getConfig().getMinOperateInterval())) {
            return false;
        }
        this.mLastOperatedTime = currentTimeMillis;
        return true;
    }

    public static DownloadManager getInstance(Context context2) {
        DownloadManager downloadManager;
        synchronized (DownloadManager.class) {
            if (mInstance == null) {
                mInstance = new DownloadManager(context2);
            }
            downloadManager = mInstance;
        }
        return downloadManager;
    }

    public void add(DownloadEntry downloadEntry) {
        if (checkIfExecutable()) {
            Intent intent = new Intent(this.context, DownloadService.class);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ENTRY, downloadEntry);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ACTION, 1);
            this.context.startService(intent);
        }
    }


    public void cancel(DownloadEntry downloadEntry) {
        if (checkIfExecutable()) {
            Intent intent = new Intent(this.context, DownloadService.class);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ENTRY, downloadEntry);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ACTION, 4);
            this.context.startService(intent);
        }
    }


    public void deleteDownloadEntry(boolean z, DownloadEntry downloadEntry) {
        DataChanger.getInstance(this.context).deleteDownloadEntry(downloadEntry.id);
        if (z) {
            File downloadFile = DownloadConfig.getConfig().getDownloadFile(downloadEntry.name);
            if (downloadFile.exists()) {
                downloadFile.delete();
            }
        }
    }

    public void newOrUpdate(DownloadEntry downloadEntry) {
        DataChanger.getInstance(this.context).newOrUpdate(downloadEntry);
    }

//    public void pause(DownloadEntry downloadEntry) {
//        if (checkIfExecutable()) {
//            Intent intent = new Intent(this.context, DownloadService.class);
//            intent.putExtra(AppConstant.KEY_DOWNLOAD_ENTRY, downloadEntry);
//            intent.putExtra(AppConstant.KEY_DOWNLOAD_ACTION, 2);
//            this.context.startService(intent);
//            Log.e("sssssssss", "pause::::::::::");
//        }
//    }

    public void pauseAll() {
        if (checkIfExecutable()) {
            Intent intent = new Intent(this.context, DownloadService.class);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ACTION, 5);
            this.context.startService(intent);
        }
    }

    public ArrayList<DownloadEntry> queryAllCompletedEntriesByVideo() {
        return DataChanger.getInstance(this.context).queryAllCompletedEntriesByVideo();
    }

    public ArrayList<DownloadEntry> queryAllDownloadingEntries() {
        return DataChanger.getInstance(this.context).queryAllDownloadingEntries();
    }

    public DownloadEntry queryDownloadEntry(String str) {
        return DataChanger.getInstance(this.context).queryDownloadEntryById(str);
    }

    public void removeObserver(DataWatcher dataWatcher) {
        DataChanger.getInstance(this.context).deleteObserver(dataWatcher);
    }

    public void resume(DownloadEntry downloadEntry) {
        if (checkIfExecutable()) {
            Intent intent = new Intent(this.context, DownloadService.class);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ENTRY, downloadEntry);
            intent.putExtra(AppConstant.KEY_DOWNLOAD_ACTION, 3);
            this.context.startService(intent);
        }
    }
}