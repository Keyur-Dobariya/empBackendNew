package com.hd.video.downloader.play.video.downloader_downloader;

import android.util.Log;


import com.hd.video.downloader.play.video.downloader_downloader.entities.DownloadEntry;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadThread implements Runnable {
    private final File destFile;
    private final int endPos;
    private final int index;
    private volatile boolean isCancelled;
    private volatile boolean isError;
    private volatile boolean isPaused;
    private final boolean isSingleDownload;
    private final DownloadListener listener;
    private DownloadEntry.DownloadStatus mStatus;
    private final int startPos;
    private final String url;

    public interface DownloadListener {
        void onDownloadCancelled(int i);

        void onDownloadCompleted(int i);

        void onDownloadError(int i, String str);

        void onDownloadPaused(int i);

        void onProgressChanged(int i, int i2);
    }

    public DownloadThread(String str, File file, int i, int i2, int i3, DownloadListener downloadListener) {
        this.url = str;
        this.index = i;
        this.startPos = i2;
        this.endPos = i3;
        this.destFile = file;
        this.isSingleDownload = i2 == 0 && i3 == 0;
        this.listener = downloadListener;
    }

    public void cancel() {
        this.isCancelled = true;
        Thread.currentThread().interrupt();
    }

    public void cancelByError() {
        this.isError = true;
        Thread.currentThread().interrupt();
    }

    public boolean isRunning() {
        return this.mStatus == DownloadEntry.DownloadStatus.downloading;
    }

    public void pause() {
        this.isPaused = true;
        Thread.currentThread().interrupt();
    }

    public void run() {
        InputStream inputStream;
        this.mStatus = DownloadEntry.DownloadStatus.downloading;
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.url).openConnection();
            try {
                httpURLConnection.setRequestMethod("GET");
                if (!this.isSingleDownload) {
                    httpURLConnection.setRequestProperty("range", "bytes=" + this.startPos + "-" + this.endPos);
                }
                httpURLConnection.setConnectTimeout(10000);
                httpURLConnection.setReadTimeout(10000);
                int responseCode = httpURLConnection.getResponseCode();
                httpURLConnection.getContentLength();
                Log.e("kkkkkkkkkkkkkkk", "mStatus:::run()::::" + responseCode);
                if (responseCode == 206) {
                    RandomAccessFile randomAccessFile = new RandomAccessFile(this.destFile, "rw");
                    randomAccessFile.seek((long) this.startPos);
                    inputStream = httpURLConnection.getInputStream();
                    byte[] bArr = new byte[2048];
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read == -1 || this.isPaused) {
                            break;
                        } else if (this.isCancelled) {
                            break;
                        } else if (this.isError) {
                            break;
                        } else {
                            randomAccessFile.write(bArr, 0, read);
                            this.listener.onProgressChanged(this.index, read);
                        }
                    }
                    randomAccessFile.close();
                } else if (responseCode == 200) {
                    FileOutputStream fileOutputStream = new FileOutputStream(this.destFile);
                    inputStream = httpURLConnection.getInputStream();
                    byte[] bArr2 = new byte[2048];
                    while (true) {
                        int read2 = inputStream.read(bArr2);
                        if (read2 == -1 || this.isPaused) {
                            break;
                        } else if (this.isCancelled) {
                            break;
                        } else if (this.isError) {
                            break;
                        } else {
                            fileOutputStream.write(bArr2, 0, read2);
                            this.listener.onProgressChanged(this.index, read2);
                        }
                    }
                    fileOutputStream.close();
                } else {
                    this.mStatus = DownloadEntry.DownloadStatus.error;
                    DownloadListener downloadListener = this.listener;
                    int i = this.index;
                    downloadListener.onDownloadError(i, "server error:" + responseCode);
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                        return;
                    }
                    return;
                }
                inputStream.close();
                if (this.isPaused) {
                    this.mStatus = DownloadEntry.DownloadStatus.paused;
                    this.listener.onDownloadPaused(this.index);
                } else if (this.isCancelled) {
                    this.mStatus = DownloadEntry.DownloadStatus.cancelled;
                    this.listener.onDownloadCancelled(this.index);
                } else if (this.isError) {
                    this.mStatus = DownloadEntry.DownloadStatus.error;
                    this.listener.onDownloadError(this.index, "cancel manually by error");
                } else {
                    this.mStatus = DownloadEntry.DownloadStatus.completed;
                    this.listener.onDownloadCompleted(this.index);
                }
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                Log.e("kkkkkkkkkkkkkkk", "mStatus:::this.entry.mStatus:::::" + this.mStatus);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Throwable unused) {
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
            }
        } catch (IOException e2) {
            Log.e("kkkkkkkkkkkkkkk", "mStatus:::te3e3::::" + e2);
            e2.printStackTrace();
            if (!this.isPaused) {
                this.mStatus = DownloadEntry.DownloadStatus.paused;
                this.listener.onDownloadPaused(this.index);
            } else if (this.isCancelled) {
                this.mStatus = DownloadEntry.DownloadStatus.cancelled;
                this.listener.onDownloadCancelled(this.index);
            } else {
                this.mStatus = DownloadEntry.DownloadStatus.error;
                this.listener.onDownloadError(this.index, e2.getMessage());
            }
        }
    }
}
