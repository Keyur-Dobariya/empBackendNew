package com.hd.video.downloader.play.video.downloader_downloader;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class SharedConfig {
    private static SharedConfig instance;
    private SharedPreferences.Editor editor;
    private SharedPreferences sharedPreferences;

    private SharedConfig(Context context) {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        this.sharedPreferences = defaultSharedPreferences;
        this.editor = defaultSharedPreferences.edit();
    }

    public static SharedConfig getInstance(Context context) {
        SharedConfig sharedConfig;
        synchronized (SharedConfig.class) {
            if (instance == null) {
                instance = new SharedConfig(context);
            }
            sharedConfig = instance;
        }
        return sharedConfig;
    }

    public boolean readBoolean(String str, boolean z) {
        return this.sharedPreferences.getBoolean(str, z);
    }

    public boolean writeData(String str, boolean z) {
        this.editor.putBoolean(str, z);
        return this.editor.commit();
    }
}
