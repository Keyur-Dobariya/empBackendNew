package com.hd.video.downloader.play.video.downloader_downloader.entities;

import com.j256.ormlite.dao.ForeignCollection;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.field.ForeignCollectionField;
import com.j256.ormlite.table.DatabaseTable;

import java.io.Serializable;

@DatabaseTable(tableName = "videofolderentry")
public class VideoFolderEntry implements Serializable, Cloneable {
    @ForeignCollectionField(eager = true)
    public ForeignCollection<DownloadEntry> downloadEntries;
    @DatabaseField(unique = true)
    public String folder_name;
    @DatabaseField(generatedId = true)
    public Integer id;

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean equals(Object obj) {
        return (obj.hashCode() == hashCode() ? true : null).booleanValue();
    }
    public int hashCode() {
        return this.id.hashCode();
    }
}