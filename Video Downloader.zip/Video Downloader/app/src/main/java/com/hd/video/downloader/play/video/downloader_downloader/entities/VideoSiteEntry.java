package com.hd.video.downloader.play.video.downloader_downloader.entities;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.io.Serializable;

@DatabaseTable(tableName = "videositeentry")
public class VideoSiteEntry implements Serializable, Cloneable {
    @DatabaseField(id = true)
    public String id;
    @DatabaseField(unique = true)
    public String name;
    @DatabaseField
    public String url;

    public VideoSiteEntry() {
    }
    public VideoSiteEntry(String str, String str2) {
        this.id = str2;
        this.name = str;
        this.url = str2;
    }

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean equals(Object obj) {
        return (obj.hashCode() == hashCode() ? true : null).booleanValue();
    }

    public int hashCode() {
        return this.id.hashCode();
    }
}