package com.hd.video.downloader.play.video.facebook;

import android.util.SparseArray;
import android.view.View;

public class AdapterUtils {
    public static <T extends View> T getAdapterView(View view, int i) {
        SparseArray sparseArray = (SparseArray) view.getTag();
        if (sparseArray == null) {
            sparseArray = new SparseArray();
            view.setTag(sparseArray);
        }
        T t = (T) ((View) sparseArray.get(i));
        if (t != null) {
            return t;
        }
        T t2 = (T) view.findViewById(i);
        sparseArray.put(i, t2);
        return t2;
    }
}
