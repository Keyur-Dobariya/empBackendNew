package com.hd.video.downloader.play.video.facebook;

import android.content.Context;

public class Ajax {
    public static String title = "";
    public interact con = null;
    public Context context;


    public Ajax(Context context2, interact interact) {
        this.context = context2;
        this.con = interact;
    }


}
