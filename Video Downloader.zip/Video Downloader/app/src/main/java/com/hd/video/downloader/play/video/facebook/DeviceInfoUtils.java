package com.hd.video.downloader.play.video.facebook;

import android.content.Context;

public class DeviceInfoUtils {
    private DeviceInfoUtils() {
    }
    public static int getScreenWidth(Context context) {
        return context.getResources().getDisplayMetrics().widthPixels;
    }
}