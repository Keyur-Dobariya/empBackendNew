package com.hd.video.downloader.play.video.facebook;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.internal.MDButton;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.app.MainApplication;
import com.hd.video.downloader.play.video.downloader_downloader.AppConfig;
import com.hd.video.downloader.play.video.downloader_downloader.ConnectThread;
import com.hd.video.downloader.play.video.downloader_downloader.DownloadManager;
import com.hd.video.downloader.play.video.fragments_downloader.bean_downloader.UrlInformation;

import java.util.List;

public class DownloadDialog extends Dialog {
    public static String pathname = "";
    public Context context;
    public TextView name;
    public OnclickListner onclickListner;
    private VideoInformation videoInfo;
    private View view;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setGravity(83);
        view = LayoutInflater.from(this.context).inflate(R.layout.dialog_download_snaptube, (ViewGroup) null);
        view.setMinimumWidth(MainApplication.getInstance().getScreenWidth());

        name = (TextView) this.view.findViewById(R.id.name);
        name.setText(this.videoInfo.getVideoname());
        ((TextView) this.view.findViewById(R.id.text_website)).setText(this.videoInfo.getWebsite());
        view.findViewById(R.id.img_name_edit).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showRenameDialog();
            }
        });
        RecyclerView recyclerView = (RecyclerView) this.view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.context, 1, false));
        recyclerView.setAdapter(new Adapter(R.layout.dialog_download_snaptube_item, this.videoInfo.getUrlInfos()));
        setCanceledOnTouchOutside(true);
        setCancelable(true);
        setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialogInterface) {
                onclickListner.cancel(DownloadDialog.this, "");
            }
        });
        setContentView(this.view);
        loadRewardedVideoAd();
    }


    public interface OnclickListner {
        void Download(Dialog dialog, String str, String str2);

        void cancel(Dialog dialog, String str);
    }

    private void loadRewardedVideoAd() {
    }

    class Adapter extends BaseQuickAdapter<UrlInformation, BaseViewHolder> {

        public Adapter(int i, List<UrlInformation> list) {
            super(i, list);
        }

        public void convert(BaseViewHolder baseViewHolder, final UrlInformation urlInformation) {
            baseViewHolder.setText(R.id.text_quality, urlInformation.getFormat());
            getSize(urlInformation.getUrl(), (TextView) AdapterUtils.getAdapterView(baseViewHolder.getConvertView(), R.id.text_size));
            RelativeLayout relativeLayout = (RelativeLayout) AdapterUtils.getAdapterView(baseViewHolder.getConvertView(), R.id.btn_download);
            if (onclickListner != null) {
                relativeLayout.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        Log.e("str", "item.getUrl()===" + urlInformation.getUrl());
                        Toast.makeText(context, "Downloading...", Toast.LENGTH_SHORT).show();
                        DownloadDialog.pathname = name.getText().toString();
                        onclickListner.Download(DownloadDialog.this, urlInformation.getUrl(), name.getText().toString());
                    }
                });
            }
        }

        private void getSize(String str, final TextView textView) {
            final Handler r0 = new Handler() {
                @SuppressLint("HandlerLeak")
                public void handleMessage(Message message) {
                    super.handleMessage(message);
                    if (message.what == 2) {
                        textView.setText("" + Formatter.formatShortFileSize(context, Long.parseLong(String.valueOf(message.obj))));
                    }
                }
            };
            new Thread(new ConnectThread(str, new ConnectThread.ConnectListener() {
                @Override
                public void onConnectError(String str) {
                }

                @Override
                public void onConnected(boolean z, int i) {
                    Message message = new Message();
                    message.obj = Integer.valueOf(i);
                    message.what = 2;
                    r0.sendMessage(message);
                }
            })).start();
        }
    }

    public DownloadDialog(Context context2, VideoInformation videoInformation) {
        super(context2, R.style.BottomDialogStyle);
        this.videoInfo = videoInformation;
        this.context = context2;
    }

    public void showRenameDialog() {
        String charSequence = this.name.getText().toString();
        if (charSequence.endsWith(AppConfig.MP3) || charSequence.endsWith(AppConfig.MP4) || charSequence.endsWith(AppConfig.M4A)) {
            charSequence = charSequence.split("\\.m")[0];
        }
        new MaterialDialog.Builder(this.context).backgroundColor(this.context.getResources().getColor(R.color.white)).title(R.string.rename).titleColor(this.context.getResources().getColor(R.color.darkGray)).inputType(8289).contentColor(this.context.getResources().getColor(R.color.darkGray)).positiveText(R.string.confirm).positiveColor(this.context.getResources().getColor(R.color.black)).onPositive(new MaterialDialog.SingleButtonCallback() {

            @Override
            public void onClick(MaterialDialog materialDialog, DialogAction dialogAction) {
                String obj = materialDialog.getInputEditText().getText().toString();
                if (obj.contains(":") || obj.contains("/")) {
                    Toast makeText = Toast.makeText(context, "Can not contains : or / ", Toast.LENGTH_LONG);
                    makeText.setGravity(17, 0, 0);
                    makeText.show();
                } else if (DownloadManager.getInstance(context).queryDownloadEntry(obj) != null) {
                    ToastFactory.showLongToast(context, context.getString(R.string.file_already_exist));
                } else {
                    String extensionName = FileUtil.getExtensionName(name.getText().toString());
                    TextView textView = name;
                    textView.setText(obj + "." + extensionName);
                }
            }
        }).negativeText(R.string.cancel).negativeColor(this.context.getResources().getColor(R.color.black)).onNegative(new MaterialDialog.SingleButtonCallback() {

            @Override
            public void onClick(MaterialDialog materialDialog, DialogAction dialogAction) {
                materialDialog.dismiss();
            }
        }).alwaysCallInputCallback().input((CharSequence) this.context.getResources().getString(R.string.input), (CharSequence) charSequence, false, (MaterialDialog.InputCallback) new MaterialDialog.InputCallback() {
            @Override
            public void onInput(MaterialDialog materialDialog, CharSequence charSequence) {
                boolean z;
                MDButton mDButton;
                if (TextUtils.isEmpty(charSequence)) {
                    mDButton = materialDialog.getActionButton(DialogAction.POSITIVE);
                    z = false;
                } else {
                    mDButton = materialDialog.getActionButton(DialogAction.POSITIVE);
                    z = true;
                }
                mDButton.setEnabled(z);
            }
        }).show();
    }

    public void Myshow() {
        show();
    }

    public void setOnclickListner(OnclickListner onclickListner2) {
        this.onclickListner = onclickListner2;
    }
}
