package com.hd.video.downloader.play.video.facebook;

import android.content.Context;
import android.widget.Toast;

public class ToastFactory {
    private static Context context;
    private static Toast toast;

    public static Toast getLongToast(Context context2, String str) {
        if (context == context2) {
            toast.setText(str);
            toast.setDuration(1);
        } else {
            context = context2;
            toast = Toast.makeText(context2, str, 1);
        }
        return toast;
    }

    public static Toast getToast(Context context2, String str) {
        if (context == context2) {
            toast.setText(str);
            toast.setDuration(0);
        } else {
            context = context2;
            toast = Toast.makeText(context2, str, 0);
        }
        return toast;
    }

    public static void showLongToast(Context context2, String str) {
        getLongToast(context2, str).show();
    }

    public static void showToast(Context context2, String str) {
        getToast(context2, str).show();
    }
}
