package com.hd.video.downloader.play.video.facebook;

import com.hd.video.downloader.play.video.fragments_downloader.bean_downloader.UrlInformation;

import java.util.List;

public class VideoInformation {
    private List<UrlInformation> urlInfos;
    private String videoname;
    private String website;

    public List<UrlInformation> getUrlInfos() {
        return this.urlInfos;
    }

    public String getVideoname() {
        return this.videoname;
    }

    public String getWebsite() {
        return this.website;
    }

    public void setUrlInfos(List<UrlInformation> list) {
        this.urlInfos = list;
    }

    public void setVideoname(String str) {
        this.videoname = str;
    }

    public void setWebsite(String str) {
        this.website = str;
    }
}
