package com.hd.video.downloader.play.video.facebook.module;

import android.content.Context;

import dagger.internal.Factory;
import dagger.internal.Preconditions;

public final class AppModule_ProvideApplicationContextFactory_di implements Factory<Context> {
    private final App_Module_di module;

    public AppModule_ProvideApplicationContextFactory_di(App_Module_di app_Module_di) {
        this.module = app_Module_di;
    }

    @Override
    public Context get() {
        return provideInstance(this.module);
    }

    public static Context provideInstance(App_Module_di app_Module_di) {
        return proxyProvideApplicationContext(app_Module_di);
    }

    public static AppModule_ProvideApplicationContextFactory_di create(App_Module_di app_Module_di) {
        return new AppModule_ProvideApplicationContextFactory_di(app_Module_di);
    }

    public static Context proxyProvideApplicationContext(App_Module_di app_Module_di) {
        return (Context) Preconditions.checkNotNull(app_Module_di.provideApplicationContext(), "Cannot return null from a non-@Nullable @Provides method");
    }
}