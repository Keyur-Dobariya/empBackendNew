package com.hd.video.downloader.play.video.facebook.module;

import android.content.SharedPreferences;

import javax.inject.Inject;

public class SharedPref_database_model {
    private SharedPreferences preferences;

    @Inject
    public SharedPref_database_model(SharedPreferences sharedPreferences) {
        this.preferences = sharedPreferences;
    }

    public int getSpInt(String str, int i) {
        return this.preferences.getInt(str, i);
    }

    public void setSpInt(String str, int i) {
        this.preferences.edit().putInt(str, i).apply();
    }

    public String getSpString(String str, String str2) {
        return this.preferences.getString(str, str2);
    }

    public void setSpString(String str, String str2) {
        this.preferences.edit().putString(str, str2).apply();
    }

    public boolean getSpBoolean(String str, boolean z) {
        return this.preferences.getBoolean(str, z);
    }

    public void setSpBoolean(String str, boolean z) {
        this.preferences.edit().putBoolean(str, z).apply();
    }
}
