package com.hd.video.downloader.play.video.facebook.utilss;

import android.util.Log;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.AbstractDaoSession;
import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.identityscope.IdentityScopeType;
import org.greenrobot.greendao.internal.DaoConfig;

import java.util.Map;

public class DaoSession extends AbstractDaoSession {
    private DownloadMissionItemDao downloadMissionItemDao;
    public DaoSession(Database database, IdentityScopeType identityScopeType, Map<Class<? extends AbstractDao<?, ?>>, DaoConfig> map) {
        super(database);
        Log.e("hhhhhhhhhhhh", "map......" + map);
        DaoConfig clone = map.get(DownloadMissionItemDao.class).clone();
        clone.initIdentityScope(identityScopeType);
        this.downloadMissionItemDao = new DownloadMissionItemDao(clone, this);
    }

    public DownloadMissionItemDao getDownloadMissionItemDao() {
        return this.downloadMissionItemDao;
    }
}