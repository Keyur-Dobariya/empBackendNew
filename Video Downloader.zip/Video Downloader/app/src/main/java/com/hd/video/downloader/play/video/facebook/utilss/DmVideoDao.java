package com.hd.video.downloader.play.video.facebook.utilss;


import java.util.List;

import io.reactivex.Single;

public interface DmVideoDao {
    Single<List<DmVideo>> getAllFaviruteList();

    Single<List<DmVideo>> getAllWatchLaterList();

    DmVideo getDmVideo(String str);

    void insertDmVideo(DmVideo dmVideo);
}
