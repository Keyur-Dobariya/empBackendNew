package com.hd.video.downloader.play.video.facebook.utilss;

public class DownloadMissionItem {
    public long missionId;
    public String name;
    public int result;
    public String thumbnail;
    public String url;

    public DownloadMissionItem(long j, String str, String str2, String str3, int i) {
        this.missionId = j;
        this.url = str;
        this.name = str2;
        this.thumbnail = str3;
        this.result = i;
    }

    public long getMissionId() {
        return this.missionId;
    }

    public void setMissionId(long j) {
        this.missionId = j;
    }

    public String getUrl() {
        return this.url;
    }

    public String getName() {
        return this.name;
    }

    public int getResult() {
        return this.result;
    }

    public String getThumbnail() {
        return this.thumbnail;
    }
}
