package com.hd.video.downloader.play.video.fragments_downloader.bean_downloader;

public class UrlInformation {
    private String format;
    private String url;

    public String getFormat() {
        return this.format;
    }

    public String getUrl() {
        return this.url;
    }

    public void setFormat(String str) {
        this.format = str;
    }

    public void setUrl(String str) {
        this.url = str;
    }
}
