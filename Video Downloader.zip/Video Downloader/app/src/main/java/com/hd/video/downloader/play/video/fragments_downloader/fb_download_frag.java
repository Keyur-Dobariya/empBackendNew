package com.hd.video.downloader.play.video.fragments_downloader;

import static android.app.Activity.RESULT_OK;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.nativee.SmallNativeAds;
import com.hd.video.downloader.play.video.downloader_downloader.AppConfig;
import com.hd.video.downloader.play.video.fragments_downloader.adapter_downloader.adapter_fb_video_download;
import com.hd.video.downloader.play.video.fragments_downloader.bean_downloader.WAStatus;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class fb_download_frag extends Fragment implements adapter_fb_video_download.OnClickListener{
    public String SAVED_MEDIA_PATH2;
    String fileNames;
    private adapter_fb_video_download mAdapter;
    private Context mContext;
    public String mPath = "";
    private RecyclerView mRecyclerWAStatus;
    public ArrayList<WAStatus> mStatusesList;
    private TextView mTvNothingFound;

//    *****delete*******************************
    private ActivityResultLauncher<IntentSenderRequest> fileDeleteResultLauncher;
    public static int positionfromclick = 0;

    private class GetStatusesAsyncTask1 extends AsyncTask<Void, Void, List<WAStatus>> {
        private GetStatusesAsyncTask1() {
        }

        public void onPostExecute(List<WAStatus> list) {
            super.onPostExecute(list);
            setAdapter();
        }

        public List<WAStatus> doInBackground(Void... voidArr) {
            return getStatses(new File(SAVED_MEDIA_PATH2 + File.separator));
        }

        private List<WAStatus> getStatses(File file) {
            mStatusesList = new ArrayList<>();
            File[] listFiles = file.listFiles();
            Log.e("oooooo1", file.toString());
            if (listFiles != null) {
                for (File file2 : listFiles) {
                    if (!file2.isDirectory()) {
                        fileNames = file2.getName();
                        Log.e("oooooooooo1", "fileNames..." + fileNames);
                        if (fileNames.endsWith(AppConfig.MP4)) {
                            WAStatus wAStatus = new WAStatus();
                            wAStatus.setFileName(file2.getName());
                            wAStatus.setDate(fb_download_frag.getTimeAgo(file2.lastModified()));
                            wAStatus.setStatusType(download_file_util.getMimeType(file2));
                            wAStatus.setFilePath(file2.getAbsolutePath());
                            wAStatus.setFileSize(fb_download_frag.getHumanReadableSize(file2.length(), getContext()));
                            wAStatus.setDestPath(SAVED_MEDIA_PATH2 + File.separator + file2.getName());
                            mStatusesList.add(wAStatus);
                        }
                    }
                }
            }
            return mStatusesList;
        }
    }

    @Override
    public void setUserVisibleHint(boolean z) {
        super.setUserVisibleHint(z);
        if (z) {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
    }

    @Override
    public Context getContext() {
        return this.mContext;
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.frag_wastatus, viewGroup, false);
        init(inflate);

//        *********delete***********************
        fileDeleteResultLauncher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), result -> {
            if (result.getResultCode() == RESULT_OK) {
                mAdapter.mWAStatusesList.remove(positionfromclick);
                mAdapter.notifyDataSetChanged();
                Intent scanFileIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, fileToDelete);
                mContext.sendBroadcast(scanFileIntent);
                Toast.makeText(mContext, "Delete sucessfully", Toast.LENGTH_SHORT).show();
            }
        });
        return inflate;
    }

    @Override
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.SAVED_MEDIA_PATH2 = "/storage/emulated/0/Download/FaceBook Video Downloader";
        Log.e("TAG", "onViewCreated: " + SAVED_MEDIA_PATH2);
        new GetStatusesAsyncTask1().execute();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @SuppressLint("WrongConstant")
    public void setAdapter() {
        if (this.mStatusesList.size() == 0) {
            this.mTvNothingFound.setVisibility(View.VISIBLE);
            this.mTvNothingFound.setText("No media found");
        } else {
            this.mTvNothingFound.setVisibility(View.GONE);
        }
        this.mRecyclerWAStatus.setLayoutManager(new GridLayoutManager(getContext(), 3));
        mAdapter = new adapter_fb_video_download(getContext(), this.mStatusesList, this.mPath,this::onItemClick);
        this.mRecyclerWAStatus.setAdapter(mAdapter);
    }

    private void init(View view) {
        this.mRecyclerWAStatus = view.findViewById(R.id.recyclerWAStatusFragment);
        this.mTvNothingFound = view.findViewById(R.id.tvNothingFoundWA_Status);
    }

    public static String getHumanReadableSize(long j, Context context) {
        if (context == null) {
            return "";
        }
        if (j < 1024) {
            return String.format(context.getString(R.string.app_size_b), Double.valueOf((double) j));
        }
        double d = (double) j;
        if (d < Math.pow(1024.0d, 2.0d)) {
            return String.format(context.getString(R.string.app_size_kib), Double.valueOf((double) ((j / 1) << 10)));
        } else if (d < Math.pow(1024.0d, 3.0d)) {
            String string = context.getString(R.string.app_size_mib);
            double pow = Math.pow(1024.0d, 2.0d);
            Double.isNaN(d);
            return String.format(string, Double.valueOf(d / pow));
        } else {
            String string2 = context.getString(R.string.app_size_gib);
            double pow2 = Math.pow(1024.0d, 3.0d);
            Double.isNaN(d);
            return String.format(string2, Double.valueOf(d / pow2));
        }
    }

    public static String getTimeAgo(long j) {
        return DateUtils.getRelativeTimeSpanString(j, System.currentTimeMillis(), 60000).toString();
    }


    //    *******delete********************
    Uri fileToDelete;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onItemClick(int position) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            long mediaID = getFilePathToMediaID(mAdapter.mWAStatusesList.get(position).getFilePath(), mContext);
            fileToDelete = ContentUris.withAppendedId(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL), mediaID);
            PendingIntent pendingIntent = MediaStore.createDeleteRequest(mContext.getContentResolver(), Collections.singleton(fileToDelete));
            fileDeleteResultLauncher.launch(new IntentSenderRequest.Builder(pendingIntent.getIntentSender()).build());
            Intent scanFileIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, fileToDelete);
            mContext.sendBroadcast(scanFileIntent);

        } else {
            new AlertDialog.Builder(mContext).setMessage("Are you sure want to Delete").setPositiveButton(R.string.delete, (dialogInterface, i1) -> {
                if (new File(mAdapter.mWAStatusesList.get(position).getFilePath()).delete()) {
                    mAdapter.mWAStatusesList.remove(position);
                    mAdapter.notifyDataSetChanged();
//                    notifyItemRemoved(i1);
                    Intent scanFileIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, fileToDelete);
                    mContext.sendBroadcast(scanFileIntent);

                    Toast.makeText(mContext, "Delete sucessfully", Toast.LENGTH_SHORT).show();
                }
            }).setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) null).show();
        }
    }
    public long getFilePathToMediaID(String songPath, Context context) {
        long id = 0;
        ContentResolver cr = context.getContentResolver();

        Uri uri = MediaStore.Files.getContentUri("external");
        String selection = MediaStore.Audio.Media.DATA;
        String[] selectionArgs = {songPath};
        String[] projection = {MediaStore.Audio.Media._ID};

        Cursor cursor = cr.query(uri, projection, selection + "=?", selectionArgs, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(MediaStore.Audio.Media._ID);
                id = Long.parseLong(cursor.getString(idIndex));
            }
        }

        return id;
    }
}