package com.hd.video.downloader.play.video.instagram.Activity;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.InstaActivityMainBinding;
import com.hd.video.downloader.play.video.instagram.Adapter.Insta_TabAdapter;
import com.hd.video.downloader.play.video.instagram.Fragment.Insta_Download_Fragment;
import com.hd.video.downloader.play.video.instagram.Fragment.Insta_HomeFragment;

import java.io.File;
import java.util.ArrayList;

public class Insta_MainActivity extends AppCompatActivity {
    ArrayList<String> downloaded_list = new ArrayList<>();
    Insta_TabAdapter tabadapter = new Insta_TabAdapter(getSupportFragmentManager());
    private ReviewManager manager;
    private ReviewInfo reviewInfo;

    InstaActivityMainBinding binding;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = InstaActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        goReview();
    }


    private void init() {
        this.tabadapter.addFragment(new Insta_HomeFragment(this), "");
        this.tabadapter.addFragment(new Insta_Download_Fragment(this.downloaded_list, this), "");
        binding.viewpager.setAdapter(this.tabadapter);
        binding.tablayout.setupWithViewPager( binding.viewpager);
        getimagesfrompath();
        getvideosfrompath();
        this.tabadapter.notifyDataSetChanged();
        binding.viewpager.setAdapter(this.tabadapter);

        binding.back.setOnClickListener(v -> finish());
        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Insta_MainActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    public void getimagesfrompath() {
        this.downloaded_list.clear();
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath() + File.separator + "Insta Video Downloader");
        if (file.exists()) {
            File[] listFiles = file.listFiles();
            Log.i("TAG", "getimagesfrompath: ");
            for (File file2 : listFiles) {
                this.downloaded_list.add(String.valueOf(file2));
            }
        }
    }

    public void getvideosfrompath() {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath() + File.separator + "Insta Video Downloader");
        if (file.exists()) {
            File[] listFiles = file.listFiles();
            Log.i("TAG", "getimagesfrompath: ");
            for (File file2 : listFiles) {
                this.downloaded_list.add(String.valueOf(file2));
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getimagesfrompath();
        getvideosfrompath();
        this.tabadapter.notifyDataSetChanged();
        binding.viewpager.setAdapter(this.tabadapter);
        binding.tablayout.getTabAt(0);
        binding.tablayout.getTabAt(1);
        ViewGroup viewGroup = (ViewGroup) binding.tablayout.getChildAt(0);
        for (int i = 0; i < viewGroup.getChildCount() - 1; i++) {
            ((ViewGroup.MarginLayoutParams) viewGroup.getChildAt(i).getLayoutParams()).rightMargin = 300;
        }
    }

    private void goReview() {
        manager = ReviewManagerFactory.create(this);
        manager.requestReviewFlow().addOnCompleteListener(new OnCompleteListener() {
            @Override
            public final void onComplete(Task task) {
                if (task.isSuccessful()) {
                    reviewInfo = (ReviewInfo) task.getResult();
                    manager.launchReviewFlow(Insta_MainActivity.this, reviewInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                        }
                    });
                }
            }
        });
    }

}
