package com.hd.video.downloader.play.video.instagram.Activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.InstaActivityOpenFileBinding;
import com.hd.video.downloader.play.video.instagram.Adapter.Insta_HorizontalGalleryAdapter;

import java.io.File;
import java.util.ArrayList;

public class Insta_OpenFileActivity extends AppCompatActivity {
    public static int DELETE_REQUEST_CODE = 1003;
    int currentpossition;
    String data;
    private AlertDialog dialog;
    ArrayList<String> filelist;
    Insta_HorizontalGalleryAdapter horizontalGalleryAdapter;
    ArrayList<Uri> removableList = new ArrayList<>();
    public String removableLists = new String();
    ActivityResultLauncher<IntentSenderRequest> resultLauncher = registerForActivityResult(new ActivityResultContracts.StartIntentSenderForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            commicronstarsyoinstaActivityOpenFileActivity((ActivityResult) result);
        }
    });

    public void commicronstarsyoinstaActivityOpenFileActivity(ActivityResult activityResult) {
        int i;
        Log.i("TAG", "onActivityResult: ");
        if (activityResult == null || activityResult.getResultCode() != -1) {
            Log.i("TAG", "onActivityResult: can not delete");
            return;
        }
        for (int i2 = 0; i2 < this.filelist.size(); i2++) {
            if (this.filelist.get(i2).equalsIgnoreCase(this.removableLists)) {
                this.filelist.remove(i2);
                this.horizontalGalleryAdapter.notifyDataSetChanged();
                if (this.filelist.size() == 0) {
                    finish();
                } else if (this.currentpossition > this.filelist.size() || (i = this.currentpossition) == 0) {
                    int i3 = this.currentpossition;
                    if (i3 == 0) {
                        if (filelist.get(i3).endsWith(".mp4")) {
                            binding.currentiamgeview.setVisibility(View.GONE);
                            binding.currentvideoview.setVisibility(View.VISIBLE);
                            binding.currentvideoview.setVideoPath(this.filelist.get(this.currentpossition));
                            binding.currentvideoview.start();
                        } else {
                            binding.currentiamgeview.setVisibility(View.VISIBLE);
                            binding.currentvideoview.setVisibility(View.GONE);
                            Glide.with((FragmentActivity) this).load(this.filelist.get(this.currentpossition)).into(binding.currentiamgeview);
                        }
                    }
                } else {
                    int i4 = i - 1;
                    this.currentpossition = i4;
                    if (filelist.get(i4).endsWith(".mp4")) {
                        binding.currentiamgeview.setVisibility(View.GONE);
                        binding.currentvideoview.setVisibility(View.VISIBLE);
                        binding.currentvideoview.setVideoPath(this.filelist.get(this.currentpossition));
                        binding.currentvideoview.start();
                    } else {
                        binding.currentiamgeview.setVisibility(View.VISIBLE);
                        binding.currentvideoview.setVisibility(View.GONE);
                        Glide.with((FragmentActivity) this).load(this.filelist.get(this.currentpossition)).into(binding.currentiamgeview);
                    }
                }
            }
        }
        Toast.makeText(this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
        Log.i("TAG", "onActivityResult: deleted");
    }

    InstaActivityOpenFileBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = InstaActivityOpenFileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        click();

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Insta_OpenFileActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void init() {
        this.currentpossition = getIntent().getIntExtra("CURRENTPOSSITION", -1);
        this.filelist = getIntent().getExtras().getStringArrayList("FILELIST");
        this.horizontalGalleryAdapter = new Insta_HorizontalGalleryAdapter(this.filelist, this);
        binding.recyclerview.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        binding.recyclerview.setAdapter(this.horizontalGalleryAdapter);
        binding.recyclerview.scrollToPosition(this.currentpossition - 1);
        if (this.filelist.get(this.currentpossition).endsWith(".mp4")) {
            binding.currentiamgeview.setVisibility(View.GONE);
            binding.currentvideoview.setVisibility(View.VISIBLE);
            binding.currentvideoview.setVideoPath(this.filelist.get(this.currentpossition));
            binding.currentvideoview.start();
        } else {
            binding.currentiamgeview.setVisibility(View.VISIBLE);
            binding.currentvideoview.setVisibility(View.GONE);
            Glide.with((FragmentActivity) this).load(this.filelist.get(this.currentpossition)).into(binding.currentiamgeview);
        }
    }

    private void click() {
        binding.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });
        binding.currentvideoview.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setLooping(true);
            }
        });
        horizontalGalleryAdapter.setOnClickListener(new Insta_HorizontalGalleryAdapter.OnClickListener() {
            @Override
            public void onClick(int i) {
                currentpossition = i;
                if (filelist.get(i).endsWith(".mp4")) {
                    binding.currentiamgeview.setVisibility(View.GONE);
                    binding.currentvideoview.setVisibility(View.VISIBLE);
                    binding.currentvideoview.setVideoPath(filelist.get(i));
                    binding.currentvideoview.start();
                    return;
                }
                binding.currentiamgeview.setVisibility(View.VISIBLE);
                binding.currentvideoview.setVisibility(View.GONE);
                Glide.with((FragmentActivity) Insta_OpenFileActivity.this).load(filelist.get(i)).into(binding.currentiamgeview);
            }
        });
        binding.sharecard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    MediaScannerConnection.scanFile(Insta_OpenFileActivity.this, new String[]{filelist.get(currentpossition)}, null, new MediaScannerConnection.OnScanCompletedListener() {

                        public void onScanCompleted(String str, Uri uri) {
                            if (uri != null) {
                                Intent intent = new Intent("android.intent.action.SEND");
                                if (filelist.get(currentpossition).endsWith(".mp4")) {
                                    intent.setType("image/*");
                                } else {
                                    intent.setType("video/*");
                                }
                                intent.putExtra("android.intent.extra.STREAM", uri);
                                intent.putExtra("android.intent.extra.SUBJECT", getResources().getString(R.string.app_name));
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                                startActivity(Intent.createChooser(intent, "Choose one..."));
                            }
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        binding.deletecard.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 30) {
                    Insta_OpenFileActivity openFileActivity = Insta_OpenFileActivity.this;
                    openFileActivity.delete(openFileActivity.filelist.get(currentpossition));
                    return;
                }
                deletin10(Insta_OpenFileActivity.this.filelist.get(currentpossition));
            }
        });
    }

    private void hideDialog() {
        if (dialog != null) {
            if (dialog.isShowing()) {
                this.dialog.dismiss();
            }
            this.dialog = null;
        }
    }

    private void deletin10(String str) {
        File file = new File(str);
        hideDialog();
        View inflate = LayoutInflater.from(this).inflate(R.layout.insta_internet_dailog, (ViewGroup) null);
        TextView textView = (TextView) inflate.findViewById(R.id.txtwifi);
        TextView textView2 = (TextView) inflate.findViewById(R.id.txtinternet);
        ((TextView) inflate.findViewById(R.id.txtTitle)).setText(getString(R.string.delete_dialog_title));
        ((TextView) inflate.findViewById(R.id.txtMsg)).setText(getString(R.string.delete_dialog_msg));
        textView.setText("No");
        textView2.setText("Yes");
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideDialog();
            }
        });
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideDialog();
                if (file.delete()) {
                    for (int i = 0; i < filelist.size(); i++) {
                        if (filelist.get(i).equalsIgnoreCase(removableLists)) {
                            filelist.remove(i);
                            horizontalGalleryAdapter.notifyDataSetChanged();
                        }
                    }
                    MediaScannerConnection.scanFile(getApplicationContext(), new String[]{str}, null, new MediaScannerConnection.OnScanCompletedListener() {

                        public void onScanCompleted(String str, Uri uri) {
                            Toast.makeText(Insta_OpenFileActivity.this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
        dialog = new AlertDialog.Builder(this).setView(inflate).setCancelable(false).show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
    }

    private void delete(String str) {
        this.removableList.add(Uri.parse(str));
        this.removableLists = str;
        final ArrayList arrayList = new ArrayList();
        MediaScannerConnection.scanFile(this, new String[]{str}, null, new MediaScannerConnection.OnScanCompletedListener() {

            public void onScanCompleted(String str, Uri uri) {
                PendingIntent pendingIntent;
                arrayList.add(uri);
                if (Build.VERSION.SDK_INT >= 30) {
                    pendingIntent = MediaStore.createDeleteRequest(getContentResolver(), arrayList);
                    resultLauncher.launch(new IntentSenderRequest.Builder(pendingIntent).build());
                } else {
                    pendingIntent = null;
                }
                try {
                    startIntentSenderForResult(pendingIntent.getIntentSender(), Insta_OpenFileActivity.DELETE_REQUEST_CODE, null, 0, 0, 0, null);
                } catch (Exception unused) {
                }
            }
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onResume() {
        super.onResume();
        if (this.filelist.get(this.currentpossition).endsWith(".mp4")) {
            binding.currentvideoview.start();
        }
        this.horizontalGalleryAdapter.notifyDataSetChanged();
    }
}
