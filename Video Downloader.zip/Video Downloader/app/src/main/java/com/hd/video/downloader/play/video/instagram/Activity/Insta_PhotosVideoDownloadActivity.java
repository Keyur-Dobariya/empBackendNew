package com.hd.video.downloader.play.video.instagram.Activity;

import android.app.AlertDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.databinding.InstaActivityOpenFileBinding;
import com.hd.video.downloader.play.video.databinding.InstaActivityPhotosVideoDownloadBinding;
import com.hd.video.downloader.play.video.instagram.Adapter.Insta_DownloadMediaAdapter;
import com.hd.video.downloader.play.video.instagram.Models.Insta_JsonArrayRootModel;
import com.hd.video.downloader.play.video.pinterest.PinActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class Insta_PhotosVideoDownloadActivity extends AppCompatActivity {
    AlertDialog dialog;
    Insta_DownloadMediaAdapter downloaded_media_adapter;
    List<Insta_JsonArrayRootModel> downloadlist = new ArrayList();
    List<Insta_JsonArrayRootModel> finalresponse = new ArrayList();
    ProgressBar progressbar;
    String stringobj;
    View view;
    InstaActivityPhotosVideoDownloadBinding binding;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = InstaActivityPhotosVideoDownloadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        view = LayoutInflater.from(this).inflate(R.layout.insta_progress_dailog, (ViewGroup) null);
        progressbar = (ProgressBar) view.findViewById(R.id.progressbar);
        init();
        onclick();
    }


    private void init() {
        stringobj = getIntent().getStringExtra("FINALRESPONSE");
        finalresponse = (List) new Gson().fromJson(this.stringobj, new TypeToken<List<Insta_JsonArrayRootModel>>() {
        }.getType());
        downloaded_media_adapter = new Insta_DownloadMediaAdapter(this.finalresponse, this);
        binding.imagerecyclerview.setLayoutManager(new GridLayoutManager(this, 3));
        binding.imagerecyclerview.setAdapter(this.downloaded_media_adapter);
    }

    private void onclick() {
        binding.back.setOnClickListener(view -> finish());
        binding.btntrynew.setOnClickListener(view -> finish());
        downloaded_media_adapter.setOnClickListener(list -> {
            Log.i("TAG", "onClick: ");
            downloadlist = list;
            if (downloadlist.size() == 0) {
                binding.btndownloadall.setVisibility(View.VISIBLE);
                binding.btndownload.setVisibility(View.GONE);
                return;
            }
            binding.btndownloadall.setVisibility(View.GONE);
            binding.btndownload.setVisibility(View.VISIBLE);
        });
        binding.btndownloadall.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                progressdailog();
                for (int i = 0; i < finalresponse.size(); i++) {
                    if (finalresponse.get(i).getUrl().get(0).getExt().equals("mp4")) {
                        downloading(finalresponse.get(i).getUrl().get(0).getUrl(), ".mp4", Environment.DIRECTORY_MOVIES);
                    } else {
                        downloading(finalresponse.get(i).getUrl().get(0).getUrl(), ".jpg", Environment.DIRECTORY_PICTURES);
                    }
                }
            }
        });
        binding.btndownload.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                progressdailog();
                for (int i = 0; i < downloadlist.size(); i++) {
                    if (downloadlist.get(i).getUrl().get(0).getExt().equals("mp4")) {
                        downloading(downloadlist.get(i).getUrl().get(0).getUrl(), ".mp4", Environment.DIRECTORY_MOVIES);
                    } else {
                        downloading(downloadlist.get(i).getUrl().get(0).getUrl(), ".jpg", Environment.DIRECTORY_PICTURES);
                    }
                }
            }
        });

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Insta_PhotosVideoDownloadActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void downloading(final String str, final String str2, final String str3) {
        ScheduledExecutorService newSingleThreadScheduledExecutor = Executors.newSingleThreadScheduledExecutor();
        final Handler handler = new Handler(Looper.getMainLooper());
        newSingleThreadScheduledExecutor.execute(new Runnable() {
            int count;

            public void run() {
                try {
                    URLConnection openConnection = new URL(str).openConnection();
                    openConnection.connect();
                    int contentLength = openConnection.getContentLength();
                    InputStream inputStream = openConnection.getInputStream();
                    File file = new File(Environment.getExternalStoragePublicDirectory(str3).getAbsolutePath() + File.separator + "Insta Video Downloader");
                    if (!file.exists()) {
                        file.mkdir();
                    }
                    FileOutputStream fileOutputStream = new FileOutputStream(file + "/download_" + generateFileName() + str2);
                    byte[] bArr = new byte[1024];
                    long j = 0;
                    while (true) {
                        int read = inputStream.read(bArr);
                        this.count = read;
                        if (read != -1) {
                            j += (long) read;
                            Insta_PhotosVideoDownloadActivity photosVideoDownloadActivity = Insta_PhotosVideoDownloadActivity.this;
                            photosVideoDownloadActivity.publishProgress(new Integer[]{Integer.valueOf("" + ((int) ((100 * j) / ((long) contentLength))))});
                            fileOutputStream.write(bArr, 0, this.count);
                        } else {
                            fileOutputStream.flush();
                            fileOutputStream.close();
                            inputStream.close();
                            handler.post(new Runnable() {
                                public void run() {
                                    hideDialog();
                                    finish();
                                }
                            });
                            return;
                        }
                    }
                } catch (Exception unused) {
                }
            }
        });
    }

    private String generateFileName() {
        return String.valueOf(System.nanoTime());
    }

    private void publishProgress(Integer... numArr) {
        this.progressbar.setProgress(numArr[0]);
    }

    private void progressdailog() {
        if (this.dialog == null) {
            dialog = new AlertDialog.Builder(this).setView(this.view).setCancelable(false).show();
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }
    }

    private void hideDialog() {
        if (dialog != null) {
            if (dialog.isShowing()) {
                this.dialog.dismiss();
            }
            this.dialog = null;
        }
    }
}