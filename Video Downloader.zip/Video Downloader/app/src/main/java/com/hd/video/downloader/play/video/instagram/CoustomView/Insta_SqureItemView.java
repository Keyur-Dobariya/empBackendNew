package com.hd.video.downloader.play.video.instagram.CoustomView;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class Insta_SqureItemView extends ImageView {
    public Insta_SqureItemView(Context context) {
        super(context);
    }

    public Insta_SqureItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public Insta_SqureItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public Insta_SqureItemView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
    }


    public void onMeasure(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (mode == 1073741824 && mode2 != 1073741824) {
            setMeasuredDimension(size, size);
        } else if (mode2 != 1073741824 || mode == 1073741824) {
            super.onMeasure(i, i2);
        } else {
            setMeasuredDimension(size2, size2);
        }
    }
}
