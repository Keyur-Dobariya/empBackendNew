package com.hd.video.downloader.play.video.instagram.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.ads.nativee.SmallNativeAds;
import com.hd.video.downloader.play.video.databinding.InstaFragmentDownloadBinding;
import com.hd.video.downloader.play.video.instagram.Adapter.Insta_GalleryViewAdapter;

import java.util.ArrayList;

public class Insta_Download_Fragment extends Fragment {
    Context context;
    ArrayList<String> download_list;
    Insta_GalleryViewAdapter galleryViewAdapter;

    private final String screenName = this.getClass().getSimpleName();

    public Insta_Download_Fragment(ArrayList<String> arrayList, Context context2) {
        this.download_list = arrayList;
        this.context = context2;
    }

    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        InstaFragmentDownloadBinding binding = InstaFragmentDownloadBinding.inflate(layoutInflater, viewGroup, false);

//        *********Smallnative*************
        new SmallNativeAds(screenName).showAd(context, binding.admobSmallNative, binding.fbSmallNative, binding.cardSmallNative);

        if (this.download_list.size() == 0) {
            binding.rvgalleryfragment.setVisibility(View.GONE);
        } else {
            binding.rvgalleryfragment.setVisibility(View.VISIBLE);
        }
        this.galleryViewAdapter = new Insta_GalleryViewAdapter(this.download_list, this.context, getActivity());
        binding.rvgalleryfragment.setLayoutManager(new GridLayoutManager(this.context, 3));
        binding.rvgalleryfragment.setAdapter(this.galleryViewAdapter);
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
