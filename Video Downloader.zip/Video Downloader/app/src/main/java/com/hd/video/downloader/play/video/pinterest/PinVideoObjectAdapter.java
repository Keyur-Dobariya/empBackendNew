package com.hd.video.downloader.play.video.pinterest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.Utils.ShowDialog;
import com.hd.video.downloader.play.video.databinding.PinDownloadDialogContentBinding;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;

public class PinVideoObjectAdapter extends RecyclerView.Adapter {
    private final Activity ac;
    private final ArrayList<PinVideoObject> accountModelArrayList;
    private final Context context;

    public PinVideoObjectAdapter(ArrayList<PinVideoObject> arrayList, Context context2, Window window, Activity activity) {
        this.accountModelArrayList = arrayList;
        this.context = context2;
        this.ac = activity;
    }

    @Override
    public Adapter_ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new Adapter_ViewHolder(PinDownloadDialogContentBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false));
    }

    public void onBindViewHolder(RecyclerView.ViewHolder myViewHolder, final int i) {
        final Adapter_ViewHolder adapter_ViewHolder = (Adapter_ViewHolder) myViewHolder;
        adapter_ViewHolder.binding.videoquality.setText(this.accountModelArrayList.get(i).getQuality());
        adapter_ViewHolder.binding.videosize.setText(this.accountModelArrayList.get(i).getVideoSize());
        adapter_ViewHolder.binding.accountimage.setImageBitmap(this.accountModelArrayList.get(i).getThumb());
        adapter_ViewHolder.binding.AccountOne.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new DownloadFile().execute(((PinVideoObject) accountModelArrayList.get(i)).getVideoUrl(), ((PinVideoObject) accountModelArrayList.get(i)).getType());
            }
        });
    }

    public class Adapter_ViewHolder extends RecyclerView.ViewHolder {
        PinDownloadDialogContentBinding binding;

        public Adapter_ViewHolder(PinDownloadDialogContentBinding view) {
            super(view.getRoot());
            binding = view;
        }
    }

    public File getPublicAlbumStorageDir() {
        File file = new File((Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString() + "/Pintrest Video Downloader"));
        if (!file.mkdirs()) {
            Log.e("Error", "Directory not created");
        }
        return file;
    }

    @Override
    public int getItemCount() {
        return this.accountModelArrayList.size();
    }


    @SuppressLint("StaticFieldLeak")
    private class DownloadFile extends AsyncTask<String, String, String> {
        private ProgressDialog progressDialog;

        private DownloadFile() {
        }

        public void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(context);
            progressDialog.setProgressStyle(1);
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        public String doInBackground(String... strArr) {
            String str;
            byte[] bArr;
            String str2;
            try {
                URL url = new URL(strArr[0]);
                URLConnection uRLConnection = (URLConnection) FirebasePerfUrlConnection.instrument(url.openConnection());
                uRLConnection.connect();
                int contentLength = uRLConnection.getContentLength();
                if (contentLength < 0) {
                    contentLength = 19215984;
                }
                BufferedInputStream bufferedInputStream = new BufferedInputStream(FirebasePerfUrlConnection.openStream(url), 8192);
                String format = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.US).format(new Date());
                int i = 1;
                String substring = strArr[0].substring(strArr[0].lastIndexOf(47) + 1, strArr[0].length());
                new Random().nextInt(900000);
                String str3 = format + "_" + substring + "";
                String str4 = "gif";
                if (strArr[1].equals("video") || strArr[1].equals(str4)) {
                    str3 = str3 + ".mp4";
                } else if (strArr[1].equals("image")) {
                    str3 = str3 + ".jpg";
                } else if (strArr[1].equals("audio")) {
                    str3 = str3 + ".m4a";
                }
                String str5 = getPublicAlbumStorageDir() + File.separator;
                File file = new File(str5);
                if (!file.exists()) {
                    file.mkdirs();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(str5 + str3);
                byte[] bArr2 = new byte[1024];
                long j = 0;
                while (true) {
                    int read = bufferedInputStream.read(bArr2);
                    if (read == -1) {
                        break;
                    }
                    j += (long) read;
                    String[] strArr2 = new String[i];
                    strArr2[0] = "" + ((int) ((100 * j) / ((long) contentLength)));
                    publishProgress(strArr2);
                    fileOutputStream.write(bArr2, 0, read);
                    str3 = str3;
                    str4 = str4;
                    i = 1;
                }
                fileOutputStream.flush();
                fileOutputStream.close();
                bufferedInputStream.close();
                if (!strArr[1].equals("video")) {
                    str2 = str4;
                    if (strArr[1].equals(str2)) {
                        str = str3;
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append(str5);
                        str = str3;
                        sb.append(str);
                        Bitmap createScaledBitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeFile(sb.toString()), 64, 64, false);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        createScaledBitmap.compress(Bitmap.CompressFormat.PNG, 30, byteArrayOutputStream);
                        context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".fileprovider", new File(str5 + str))));
                        if (!strArr[1].equals("image")) {
                            addImage(new File(str5 + str), str);
                        } else if (strArr[1].equals("video") || strArr[1].equals(str2)) {
                            addVideo(new File(str5 + str), str);
                        }
                        return "Downloaded at: " + str5 + str;
                    }
                } else {
                    str = str3;
                    str2 = str4;
                }
                Bitmap createVideoThumbnail = ThumbnailUtils.createVideoThumbnail(str5 + str, 3);
                if (createVideoThumbnail == null) {
                    createVideoThumbnail = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(context.getResources(), R.drawable.astronaut), 64, 64, false);
                }
                ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                createVideoThumbnail.compress(Bitmap.CompressFormat.PNG, 30, byteArrayOutputStream2);
                context.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".fileprovider", new File(str5 + str))));
                if (!strArr[1].equals("image")) {
                }
                return "Downloaded at: " + str5 + str;
            } catch (Exception e) {
                e.printStackTrace();
                return "Something went wrong";
            }
        }

        public void onProgressUpdate(String... strArr) {
            this.progressDialog.setProgress(Integer.parseInt(strArr[0]));
        }

        public void onCancelled() {
            ProgressDialog progressDialog2 = this.progressDialog;
            if (progressDialog2 != null && progressDialog2.isShowing()) {
                this.progressDialog.dismiss();
            }
            super.onCancelled();
        }

        public void onPostExecute(String str) {
            ProgressDialog progressDialog2;
            try {
                if (!ac.isFinishing() && (progressDialog2 = this.progressDialog) != null && progressDialog2.isShowing()) {
                    this.progressDialog.dismiss();
                }
            } catch (Exception unused) {
            }
            new ShowDialog().show(context, context.getString(R.string.success), context.getString(R.string.videodownloaded), "success");
        }

        public Uri addVideo(File file, String str) {
            ContentValues contentValues = new ContentValues(3);
            contentValues.put("title", str);
            contentValues.put("mime_type", "video/*");
            contentValues.put("_data", file.getAbsolutePath());
            return context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues);
        }

        public Uri addImage(File file, String str) {
            ContentValues contentValues = new ContentValues(3);
            contentValues.put("title", str);
            contentValues.put("mime_type", "image/*");
            contentValues.put("_data", file.getAbsolutePath());
            return context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        }
    }
}