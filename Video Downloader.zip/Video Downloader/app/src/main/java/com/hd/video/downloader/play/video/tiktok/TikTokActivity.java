package com.hd.video.downloader.play.video.tiktok;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.awesomedialog.blennersilva.awesomedialoglibrary.AwesomeInfoDialog;
import com.google.android.gms.common.internal.ImagesContract;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.hd.video.downloader.play.video.Mainvideos.AllDownLoadVideo;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.Utils.ShowDialog;
import com.hd.video.downloader.play.video.Utils.VideoObject;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.NativeAds;
import com.hd.video.downloader.play.video.databinding.ActivityAllMainBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TikTokActivity extends AppCompatActivity implements View.OnClickListener {
    private ConsentInformation consentInformation;
    private Dialog downloadwait;
    private boolean premium = false;
    private final String screenName = this.getClass().getSimpleName();

    ActivityAllMainBinding binding;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityAllMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadGDPR();
        binds();

        //        *******native********************************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        if (action != null && action.equals("android.intent.action.SEND") && type.startsWith("text/")) {
            String stringExtra = intent.getStringExtra("android.intent.extra.TEXT");
            if (stringExtra != null) {
                ((EditText) findViewById(R.id.searchmain)).setText(stringExtra);
            } else {
                new ShowDialog().show(this, getString(R.string.warning), getString(R.string.notextfound), "warning");
            }
        }

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(TikTokActivity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void binds() {
        binding.download.setOnClickListener(this);
        binding.past.setOnClickListener(this);
        binding.gallery.setOnClickListener(this);
        binding.txt.setText("Tiktok Video Downloader");
        binding.back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.past:
                pasteClick(view);
                break;
            case R.id.download:
                downloadClick(view);
                break;
            case R.id.gallery:
                openGalleryProperWay();
                break;
            case R.id.back:
                finish();
                break;
        }
    }

    private void openGalleryProperWay() {
        InterstitialAds.showAd(TikTokActivity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                Intent intent = new Intent(TikTokActivity.this, AllDownLoadVideo.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onAdImpression() {
            }
        });

    }

    private void loadGDPR() {
        ConsentRequestParameters build = new ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build();
        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(this, build, () -> {
            if (consentInformation.isConsentFormAvailable()) {
                loadForm();
            }
        }, formError -> {
        });
    }

    public void loadForm() {
        UserMessagingPlatform.loadConsentForm(this, consentForm -> {
            if (consentInformation.getConsentStatus() == 2) {
                consentForm.show(TikTokActivity.this, formError -> loadForm());
            }
        }, formError -> {
        });
    }

    public void pasteClick(View view) {
        ClipData clipData;
        int i;
        String str;
        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboardManager.hasPrimaryClip()) {
            clipData = clipboardManager.getPrimaryClip();
            i = clipData.getItemCount();
        } else {
            clipData = null;
            i = 0;
        }
        if (i > 0) {
            try {
                str = clipData.getItemAt(0).getText().toString();
            } catch (Exception e) {
                new ShowDialog().show(this, getString(R.string.emptyclipboard), getString(R.string.notalink), "error");
                e.printStackTrace();
                str = "";
            }
            if (str.toLowerCase().contains("http")) {
                binding.searchmain.setText(str.substring(str.indexOf("http")));
                new ShowDialog().show(this, getString(R.string.success), getString(R.string.pasted), "success");
                return;
            }
            new ShowDialog().show(this, getString(R.string.error), getString(R.string.cantfindtweet), "error");
            return;
        }
        new ShowDialog().show(this, getString(R.string.error), getString(R.string.nopastedtext), "error");
    }

    public void downloadClick(View view) {
        String obj = binding.searchmain.getText().toString();
        if (obj.contains("https://www.tiktok.com")) {
            downloadwait = ((AwesomeInfoDialog) ((AwesomeInfoDialog) ((AwesomeInfoDialog) ((AwesomeInfoDialog) ((AwesomeInfoDialog) new AwesomeInfoDialog(this).setTitle(R.string.loading)).setMessage(R.string.waittofind)).setColoredCircle(R.color.dialogInfoBackgroundColor)).setDialogIconAndColor(R.drawable.ic_dialog_info, R.color.white)).setCancelable(false)).show();
            new ArrayList();
            RequestQueue newRequestQueue = Volley.newRequestQueue(this);
            StringRequest r10 = new StringRequest(0, "https://tiktok.bubiapps.com/api.php?link=" + obj, new Response.Listener<String>() {
                public void onResponse(String str) {
                    new processTheResponse().execute(str);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    downloadwait.dismiss();
                }
            }) {
                @Override
                public Map<String, String> getParams() {
                    return new HashMap();
                }
            };
            r10.setRetryPolicy(new DefaultRetryPolicy(60000, 1, 1.0f));
            newRequestQueue.add(r10);
        } else if (obj.equals("")) {
            Toast.makeText(TikTokActivity.this, "Please enter correct link", Toast.LENGTH_SHORT).show();
        }

    }

    public static Bitmap getBitmapFromURL(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) ((URLConnection) FirebasePerfUrlConnection.instrument(new URL(str).openConnection()));
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();
            InputStream inputStream = httpURLConnection.getInputStream();
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            options.outHeight = 60;
            options.outWidth = 60;
            try {
                return BitmapFactory.decodeStream(inputStream);
            } catch (RuntimeException unused) {
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public class processTheResponse extends AsyncTask<String, Void, String> {
        public void onPostExecute(String str) {
        }

        public void onPreExecute() {
        }

        public void onProgressUpdate(Void... voidArr) {
        }

        private processTheResponse() {
        }

        public String doInBackground(String... strArr) {
            String str = strArr[0];
            Log.e("Response", "doInBackground: Response;" + str);
            final ArrayList arrayList = new ArrayList();
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.getString("state").equals("error")) {
                    if (jSONObject.getInt("error_code") == 1) {
                        ShowDialog showDialog = new ShowDialog();
                        showDialog.show(TikTokActivity.this, getString(R.string.error), getString(R.string.onairtweetcantdownload), "error");
                        if (isFinishing() || downloadwait == null || !downloadwait.isShowing()) {
                            return "Executed";
                        }
                        downloadwait.dismiss();
                        return "Executed";
                    } else if (jSONObject.getInt("error_code") == 2) {
                        if (!isFinishing() && downloadwait != null && downloadwait.isShowing()) {
                            downloadwait.dismiss();
                        }
                        ShowDialog showDialog2 = new ShowDialog();
                        showDialog2.show(TikTokActivity.this, getString(R.string.error), getString(R.string.notweetfounded), "error");
                        return "Executed";
                    } else if (jSONObject.getInt("error_code") != 3) {
                        return "Executed";
                    } else {
                        if (!isFinishing() && downloadwait != null && downloadwait.isShowing()) {
                            downloadwait.dismiss();
                        }
                        ShowDialog showDialog3 = new ShowDialog();
                        showDialog3.show(TikTokActivity.this, getString(R.string.error), getString(R.string.nomediaontweet), "error");
                        return "Executed";
                    }
                } else if (!jSONObject.getString("state").equals("success")) {
                    return "Executed";
                } else {
                    JSONArray jSONArray = jSONObject.getJSONArray("url_nwm");
                    Bitmap bitmapFromURL = TikTokActivity.getBitmapFromURL(jSONObject.getString("cover"));
                    for (int i = 0; i < jSONArray.length(); i++) {
                        String string = getString(R.string.video);
                        String string2 = jSONArray.getJSONObject(i).getString(ImagesContract.URL);
                        if (jSONArray.getJSONObject(i).getString("type").equals("video")) {
                            string = getString(R.string.video);
                        } else if (jSONArray.getJSONObject(i).getString("type").equals("image")) {
                            string = getString(R.string.image);
                        } else if (jSONArray.getJSONObject(i).getString("type").equals("audio")) {
                            string = getString(R.string.audio);
                        }
                        arrayList.add(new VideoObject(bitmapFromURL, string2, "FHD", jSONArray.getJSONObject(i).getString("type"), string));
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            @SuppressLint("ResourceType") AlertDialog.Builder builder = new AlertDialog.Builder(TikTokActivity.this);
                            View inflate = getLayoutInflater().inflate(R.layout.download_dialog, (ViewGroup) null);
                            LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.addAccount);
                            RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.rv10);
                            TiktokObjectAdapter videoObjectAdapter = new TiktokObjectAdapter(arrayList, TikTokActivity.this, TikTokActivity.this, premium);
                            recyclerView.setLayoutManager(new LinearLayoutManager(TikTokActivity.this));
                            recyclerView.setAdapter(videoObjectAdapter);
                            builder.setView(inflate);
                            final AlertDialog create = builder.create();
                            linearLayout.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View view) {
                                    if (create.isShowing()) {
                                        create.dismiss();
                                    }
                                }
                            });
                            if (!isFinishing()) {
                                try {
                                    create.show();
                                } catch (Exception unused) {
                                }
                            }
                            if (downloadwait != null && downloadwait.isShowing()) {
                                downloadwait.dismiss();
                            }
                        }
                    });
                    return "Executed";
                }
            } catch (JSONException e) {
                if (downloadwait != null && downloadwait.isShowing()) {
                    downloadwait.dismiss();
                }
                Log.d("ckeke", "doInBackground: ");
                e.printStackTrace();
                return "Executed";
            }
        }
    }

    @Override
    public void onDestroy() {
        if (downloadwait != null && downloadwait.isShowing()) {
            this.downloadwait.dismiss();
        }
        super.onDestroy();
    }

}