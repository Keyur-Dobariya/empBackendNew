package com.hd.video.downloader.play.video.twiter.activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.awesomedialog.blennersilva.awesomedialoglibrary.AwesomeInfoDialog;
import com.google.android.gms.common.internal.ImagesContract;
import com.google.android.ump.ConsentForm;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.FormError;
import com.google.android.ump.UserMessagingPlatform;
import com.google.firebase.perf.network.FirebasePerfUrlConnection;
import com.hd.video.downloader.play.video.Mainvideos.AllDownLoadVideo;
import com.hd.video.downloader.play.video.R;
import com.hd.video.downloader.play.video.Utils.ShowDialog;
import com.hd.video.downloader.play.video.Utils.VideoObject;
import com.hd.video.downloader.play.video.ads.interfaces.OnInterstitialAdResponse;
import com.hd.video.downloader.play.video.ads.interstitial.InterstitialAds;
import com.hd.video.downloader.play.video.ads.nativee.NativeAds;
import com.hd.video.downloader.play.video.databinding.ActivityAllMainBinding;
import com.hd.video.downloader.play.video.databinding.InstaActivityMainBinding;
import com.hd.video.downloader.play.video.pinterest.PinActivity;
import com.hd.video.downloader.play.video.tiktok.TikTokActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Twitter_Activity extends AppCompatActivity implements View.OnClickListener {
    private ConsentInformation consentInformation;
    private Dialog downloadwait;

    ActivityAllMainBinding binding;
    private final String screenName = this.getClass().getSimpleName();

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        binding = ActivityAllMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadGDPR();
        binds();
        //        *******native********************************
        new NativeAds(screenName).showAd(this, binding.admobNative, binding.fbNative, binding.cardNative);

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        if (action != null && action.equals("android.intent.action.SEND") && type.startsWith("text/")) {
            String stringExtra = intent.getStringExtra("android.intent.extra.TEXT");
            if (stringExtra != null) {
                ((EditText) findViewById(R.id.searchmain)).setText(stringExtra);
            } else {
                new ShowDialog().show(this, getString(R.string.warning), getString(R.string.notextfound), "warning");
            }
        }

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                InterstitialAds.showBackPressAd(Twitter_Activity.this, new OnInterstitialAdResponse() {
                    @Override
                    public void onAdClosed() {
                        finish();
                    }

                    @Override
                    public void onAdImpression() {

                    }
                });
            }
        });
    }

    private void binds() {
        binding.download.setOnClickListener(this);
        binding.past.setOnClickListener(this);
        binding.gallery.setOnClickListener(this);
        binding.txt.setText("Twitter Video Downloader");
        binding.back.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.past:
                pasteClick(view);
                break;
            case R.id.download:
                downloadClick(view);
                break;
            case R.id.gallery:
                openGalleryProperWay();
                break;
            case R.id.back:
                finish();
                break;
        }
    }

    public void loadGDPR() {
        ConsentRequestParameters build = new ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build();
        consentInformation = UserMessagingPlatform.getConsentInformation(this);
        consentInformation.requestConsentInfoUpdate(this, build, new ConsentInformation.OnConsentInfoUpdateSuccessListener() {
            @Override
            public void onConsentInfoUpdateSuccess() {
                if (consentInformation.isConsentFormAvailable()) {
                    loadForm();
                }
            }
        }, new ConsentInformation.OnConsentInfoUpdateFailureListener() {
            @Override
            public void onConsentInfoUpdateFailure(FormError formError) {
            }
        });
    }

    public void loadForm() {
        UserMessagingPlatform.loadConsentForm(this, new UserMessagingPlatform.OnConsentFormLoadSuccessListener() {
            @Override
            public void onConsentFormLoadSuccess(ConsentForm consentForm) {
                if (consentInformation.getConsentStatus() == 2) {
                    consentForm.show(Twitter_Activity.this, new ConsentForm.OnConsentFormDismissedListener() {
                        @Override
                        public void onConsentFormDismissed(FormError formError) {
                            loadForm();
                        }
                    });
                }
            }
        }, new UserMessagingPlatform.OnConsentFormLoadFailureListener() {
            @Override
            public void onConsentFormLoadFailure(FormError formError) {
            }
        });
    }

    private void openGalleryProperWay() {
        InterstitialAds.showAd(Twitter_Activity.this, new OnInterstitialAdResponse() {
            @Override
            public void onAdClosed() {
                Intent intent = new Intent(Twitter_Activity.this, AllDownLoadVideo.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onAdImpression() {
            }
        });
    }

    public void pasteClick(View view) {
        ClipData clipData;
        int i;
        String str;
        ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboardManager.hasPrimaryClip()) {
            clipData = clipboardManager.getPrimaryClip();
            i = clipData.getItemCount();
        } else {
            clipData = null;
            i = 0;
        }
        if (i > 0) {
            try {
                str = clipData.getItemAt(0).getText().toString();
            } catch (Exception e) {
                new ShowDialog().show(this, getString(R.string.emptyclipboard), getString(R.string.notalink), "error");
                e.printStackTrace();
                str = "";
            }
            if (str.toLowerCase().contains("http")) {
                binding.searchmain.setText(str.substring(str.indexOf("http")));
                new ShowDialog().show(this, getString(R.string.success), getString(R.string.pasted), "success");
                return;
            }
            new ShowDialog().show(this, getString(R.string.error), getString(R.string.cantfindtweet), "error");
            return;
        }
        new ShowDialog().show(this, getString(R.string.error), getString(R.string.nopastedtext), "error");
    }

    public void downloadClick(View view) {
        String obj = binding.searchmain.getText().toString();
        if (obj.contains("tw")) {
            final String str;
            this.downloadwait = ((AwesomeInfoDialog) ((AwesomeInfoDialog) ((AwesomeInfoDialog) ((AwesomeInfoDialog) ((AwesomeInfoDialog) new AwesomeInfoDialog(this).setTitle(R.string.loading)).setMessage(R.string.waittofind)).setColoredCircle(R.color.dialogInfoBackgroundColor)).setDialogIconAndColor(R.drawable.ic_dialog_info, R.color.white)).setCancelable(false)).show();
            if (!binding.searchmain.getText().toString().contains("tw")) {
                double d = (double) getResources().getDisplayMetrics().widthPixels;
                Double.isNaN(d);
                double d2 = (double) getResources().getDisplayMetrics().heightPixels;
                Double.isNaN(d2);
                this.downloadwait.dismiss();
                return;
            }
            new ArrayList();
            String[] split = binding.searchmain.getText().toString().split("/");
            if (split[split.length - 1].contains("?")) {
                str = split[split.length - 1].split("\\?")[0];
            } else {
                str = split[split.length - 1];
            }
            RequestQueue newRequestQueue = Volley.newRequestQueue(this);
            StringRequest r0 = new StringRequest(1, "https://twittervideodownloaderpro.com/twittervideodownloadv2/index.php", new Response.Listener<String>() {
                public void onResponse(String str) {
                    new processTheResponse().execute(str);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                }
            }) {
                @Override
                public Map<String, String> getParams() {
                    HashMap hashMap = new HashMap();
                    hashMap.put("id", str);
                    return hashMap;
                }
            };
            r0.setRetryPolicy(new DefaultRetryPolicy(60000, 1, 1.0f));
            newRequestQueue.add(r0);
        }else if (obj.equals("")) {
            Toast.makeText(Twitter_Activity.this, "Please enter correct link", Toast.LENGTH_SHORT).show();
        }
    }

    public static Bitmap getBitmapFromURL(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) ((URLConnection) FirebasePerfUrlConnection.instrument(new URL(str).openConnection()));
            httpURLConnection.setDoInput(true);
            httpURLConnection.connect();
            InputStream inputStream = httpURLConnection.getInputStream();
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            options.outHeight = 60;
            options.outWidth = 60;
            try {
                return BitmapFactory.decodeStream(inputStream);
            } catch (RuntimeException unused) {
                return null;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public class processTheResponse extends AsyncTask<String, Void, String> {
        public void onPostExecute(String str) {
        }

        public void onPreExecute() {
        }

        public void onProgressUpdate(Void... voidArr) {
        }

        private processTheResponse() {
        }

        public String doInBackground(String... strArr) {
            String str = strArr[0];
            final ArrayList arrayList = new ArrayList();
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.getString("state").equals("error")) {
                    if (jSONObject.getInt("error_code") == 1) {
                        ShowDialog showDialog = new ShowDialog();
                        showDialog.show(Twitter_Activity.this, getString(R.string.error), getString(R.string.onairtweetcantdownload), "error");
                        if (isFinishing() || downloadwait == null || !downloadwait.isShowing()) {
                            return "Executed";
                        }
                        downloadwait.dismiss();
                        return "Executed";
                    } else if (jSONObject.getInt("error_code") == 2) {
                        if (!isFinishing() && downloadwait != null && downloadwait.isShowing()) {
                            downloadwait.dismiss();
                        }
                        ShowDialog showDialog2 = new ShowDialog();
                        showDialog2.show(Twitter_Activity.this, getString(R.string.error), getString(R.string.notweetfounded), "error");
                        return "Executed";
                    } else if (jSONObject.getInt("error_code") != 3) {
                        return "Executed";
                    } else {
                        if (!isFinishing() && downloadwait != null && downloadwait.isShowing()) {
                            downloadwait.dismiss();
                        }
                        ShowDialog showDialog3 = new ShowDialog();
                        showDialog3.show(Twitter_Activity.this, getString(R.string.error), getString(R.string.nomediaontweet), "error");
                        return "Executed";
                    }
                } else if (!jSONObject.getString("state").equals("success")) {
                    return "Executed";
                } else {
                    JSONArray jSONArray = jSONObject.getJSONArray("videos");
                    for (int i = 0; i < jSONArray.length(); i++) {
                        Bitmap bitmapFromURL = Twitter_Activity.getBitmapFromURL(jSONArray.getJSONObject(i).getString("thumb").replace("http", "https"));
                        String d = Double.toString(jSONArray.getJSONObject(i).getDouble("size") / 1048576.0d);
                        String substring = d.substring(0, Math.min(d.length(), 4));
                        String string = getString(R.string.image);
                        String replace = jSONArray.getJSONObject(i).getString(ImagesContract.URL).replace("http", "https");
                        if (!jSONArray.getJSONObject(i).getString("type").equals("video")) {
                            if (jSONArray.getJSONObject(i).getString("type").equals("gif")) {
                            }
                            arrayList.add(new VideoObject(bitmapFromURL, replace, substring + " mb", jSONArray.getJSONObject(i).getString("type"), string));
                        }
                        String[] split = jSONArray.getJSONObject(i).getString(ImagesContract.URL).split("/");
                        string = split[split.length - 2];
                        replace = jSONArray.getJSONObject(i).getString(ImagesContract.URL);
                        arrayList.add(new VideoObject(bitmapFromURL, replace, substring + " mb", jSONArray.getJSONObject(i).getString("type"), string));
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            @SuppressLint("ResourceType") AlertDialog.Builder builder = new AlertDialog.Builder(Twitter_Activity.this);
                            View inflate = getLayoutInflater().inflate(R.layout.download_dialog, (ViewGroup) null);
                            LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.addAccount);
                            RecyclerView recyclerView = (RecyclerView) inflate.findViewById(R.id.rv10);
                            TiwtterObjectAdapter tiwtterObjectAdapter = new TiwtterObjectAdapter(arrayList, Twitter_Activity.this, Twitter_Activity.this);
                            recyclerView.setLayoutManager(new LinearLayoutManager(Twitter_Activity.this));
                            recyclerView.setAdapter(tiwtterObjectAdapter);
                            builder.setView(inflate);
                            final AlertDialog create = builder.create();
                            linearLayout.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View view) {
                                    if (create.isShowing()) {
                                        create.dismiss();
                                    }
                                }
                            });
                            if (!isFinishing()) {
                                try {
                                    create.show();
                                } catch (Exception unused) {
                                }
                            }
                            if (downloadwait != null && downloadwait.isShowing()) {
                                downloadwait.dismiss();
                            }
                        }
                    });
                    return "Executed";
                }
            } catch (JSONException unused) {
                if (downloadwait == null || !downloadwait.isShowing()) {
                    return "Executed";
                }
                downloadwait.dismiss();
                return "Executed";
            }
        }
    }

    @Override
    public void onDestroy() {
        if (downloadwait != null && downloadwait.isShowing()) {
            this.downloadwait.dismiss();
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}